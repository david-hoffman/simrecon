"""Root finite invocation procedure for six already-reviewed negative controls.

No source imports, numerical work, retry, measurement observer or alternate waiter.
The existing study resource parent owns every child and its sole wait4.
"""
from pathlib import Path
import copy
import hashlib
import json
import subprocess
import time

E = Path('/workspace/work/campaign/evidence/114')
W = Path('/workspace/work/issue-114')
BASE = E / 'current-method-attempts-1'
M01 = BASE / 'M01-current-controls-attempt1'
PY = str(W / '.venv/bin/python')
SRC = str(W / 'docs/reports/half-precision-study/study.py')
PREFIX = json.loads((M01 / 'launch.json').read_text())['cleared_prefix']
PROTOTYPE = json.loads((E / 'pre-data-bound-instance-1/binding.json').read_text())
CONTEXT_CODE = (M01 / 'C-observation-code.txt').read_text()
CASES = [
    ('M03', 'malformed-record', 'malformed-or-incomplete-child-record', 3, None),
    ('M04', 'oversized-record', 'oversized-child-record', 3, None),
    ('M05', 'child-error', 'child-nonzero-exit: child-operation-or-observer-failure', 2, None),
    ('M06', 'self-term', 'child-signaled', None, 15),
    ('M07', 'timeout', 'timeout', None, 15),
    ('M08', 'timeout-ignore-term', 'timeout', None, 9),
]

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

for case, control, expected, exit_code, signal in CASES:
    runid = case + '-' + control + '-attempt1'
    K = BASE / runid
    K.mkdir(exist_ok=False)
    output = E / 'current-runs-1' / runid
    assert not output.exists()
    B = copy.deepcopy(PROTOTYPE)
    b, g, c = K / 'binding.json', K / 'grant.json', K / 'context.json'
    slot = '$ROOT_BINDING_SHA256'
    parent = [PY, SRC, '--route', 'resource', '--grant', str(g), '--binding-receipt', str(b), '--binding-sha256', slot, '--row', 'W02', '--strategy', 'PREPARED_WIDER', '--repetition', '1', '--run-id', runid]
    child = [PY, SRC, '--route', 'resource-child', '--grant', str(output / 'grant.original.json'), '--binding-receipt', str(b), '--binding-sha256', slot, '--row', 'W02', '--strategy', 'PREPARED_WIDER', '--repetition', '1', '--run-id', runid]
    B['bindings'].update(route='resource', output=str(output), grant={'original': str(g), 'copy': str(output / 'grant.original.json')}, parent_argv_shape=parent, target_argv_shape=child)
    write(b, B)
    bh = sha(b)
    code = CONTEXT_CODE.replace('per-M01', 'per-' + case).replace('admits ONLYM01', 'admits ONLY' + case)
    cp = subprocess.run(PREFIX + [PY, '-c', code], capture_output=True, timeout=30)
    (K / 'C.stdout').write_bytes(cp.stdout)
    (K / 'C.stderr').write_bytes(cp.stderr)
    assert cp.returncode == 0, cp.stderr
    C = json.loads(cp.stdout)
    assert C['sigint_default'] and C['sigchld_default']
    C.update(case=case, scope='Fresh Root admission for one reviewed pre-numerical-import negative lifecycle control only; source W05 ledger conservatively covers W02.', binding_sha256=bh)
    write(c, C)
    G = {'authorization': 'HP114_NUMERICAL_WINDOW', 'environment': 'simrecon-campaign-ubuntu', 'route': 'resource', 'control_release': True, 'method_control': control, 'bindings': B['bindings'], 'candidate': B['bindings']['candidate'], 'binding_receipt': {'path': str(b), 'sha256': bh}, 'context': {'path': str(c), 'sha256': sha(c)}, 'harness_sha256': B['artifacts']['harness_sha256'], 'manifest_sha256': B['artifacts']['manifest_sha256'], 'runs': [['W02', 'PREPARED_WIDER', 1]], 'run_id': runid, 'resource_admission': {'accepted': True, 'rationale': C['admission_rationale'] + ' This control does no scientific import/operation.', 'evidence_sha256': sha(c)}, 'deadline_seconds': 5.0, 'startup_seconds': 3.0, 'term_grace_seconds': 1.0, 'kill_reap_seconds': 3.0, 'readiness_bytes': 4096}
    write(g, G)
    inner = [bh if x == slot else x for x in parent]
    argv = PREFIX + inner
    write(K / 'launch.json', {'scope': 'ROOT separately releases this ONE reviewed negative method control, in the fixed M03-M08 finite sequence. Existing source parent solewait4 owns child. No scientific import/resource benchmark, GNUtime wrapper, alternate waiter, source change, retry or QUALIFY/matrix release. Stop on unexpected result or missing closure. Other roles FILE-DATA only.', 'case': case, 'Bsha': bh, 'Csha': sha(c), 'Gsha': sha(g), 'inner_argv': inner, 'outer_argv': argv, 'runtime_released': True, 'source_output_absent': not output.exists(), 'expected_parent_status': expected, 'expected_parent_exit': 2, 'time_unix_ns': time.time_ns()})
    assert not output.exists()
    start = time.time_ns()
    print('START', case, control, flush=True)
    with (K / 'stdout.txt').open('xb') as stdout, (K / 'stderr.txt').open('xb') as stderr:
        result = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
    attempt = json.loads((output / 'attempt.json').read_text())
    terminal = attempt.get('terminal')
    matched = result.returncode == 2 and attempt['status'] == expected and terminal is not None and terminal['exit_code'] == exit_code and terminal['signal'] == signal
    write(K / 'ROOT-target-terminal.json', {'scope': 'Actual expected-negative collection only; independent method qualification pending.', 'returncode': result.returncode, 'start_unix_ns': start, 'finish_unix_ns': time.time_ns(), 'status': attempt['status'], 'terminal': terminal, 'matched_expected_collection': matched, 'attempt_sha256': sha(output / 'attempt.json'), 'stdout_sha256': sha(K / 'stdout.txt'), 'stderr_sha256': sha(K / 'stderr.txt')})
    assert attempt['materials_before'] == attempt['materials_after'] and attempt['git_before'] == attempt['git_after']
    assert not attempt['wait_ownership_lost'] and not attempt['coordinator_recovery_required']
    assert (output / 'grant.original.json').read_bytes() == g.read_bytes()
    identities = {'parent': attempt['parent_identity'], 'child': attempt['owned_child']}
    write(K / 'identities-to-close.json', identities)
    close_code = "from pathlib import Path\nimport json\nK=Path(" + repr(str(K)) + ")\nD=json.loads((K/'identities-to-close.json').read_text());out={}\nfor name,v in D.items():\n try:\n  f=(Path('/proc')/str(v['pid'])/'stat').read_text().rsplit(')',1)[1].split();out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'current_start':int(f[19]),'original_identity_absent':int(f[19])!=v['start_ticks']}\n except FileNotFoundError:out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'original_identity_absent':True}\nassert all(x['original_identity_absent'] for x in out.values()),out\nprint(json.dumps(out))\n"
    closed = subprocess.run(PREFIX + [PY, '-c', close_code], capture_output=True, timeout=20)
    assert closed.returncode == 0, closed.stderr
    write(K / 'ROOT-closed-collection-summary.json', {'scope': 'Actual expected-negative method collection; parent/child identities closed and original/copy/material/Git preserved. No numerical qualification.', 'case': case, 'matched_expected_collection': matched, 'status': attempt['status'], 'terminal': terminal, 'postclose_identities': json.loads(closed.stdout), 'attempt_sha256': sha(output / 'attempt.json'), 'time_unix_ns': time.time_ns()})
    print('CLOSED', case, attempt['status'], terminal['exit_code'], terminal['signal'], 'matched', matched, flush=True)
    assert matched, (case, attempt['status'], terminal)

print('FINITE_M03_M08_COLLECTION_CLOSED; qualification pending, no other case released', flush=True)
