"""ROOT one separately released signal-control attempt, not a retry loop.

Only outer Docker invocation is waited here; source owns its child sole wait4.
"""
from pathlib import Path
import copy, hashlib, json, subprocess, time

E = Path('/workspace/work/campaign/evidence/114')
BASE = E / 'current-method-attempts-1'
OLD = BASE / 'M10-single-sigint-attempt2'
L0 = json.loads((OLD / 'launch.json').read_text())
PREFIX = L0['cleared_prefix']
PY = L0['inner_argv'][0]

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def write(p, value):
    with Path(p).open('x') as f:
        json.dump(value, f, indent=2, sort_keys=True)
        f.write('\n')

close_code = '''from pathlib import Path
import json
K=Path(KPATH);D=json.loads((K/"identities-to-close.json").read_text());out={}
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
for name,v in D.items():
 try:
  f=(Path('/proc')/str(v['pid'])/'stat').read_text().rsplit(')',1)[1].split();out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'current_start':int(f[19]),'original_identity_absent':boot!=v['boot_id'] or int(f[19])!=v['start_ticks']}
 except FileNotFoundError:out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'original_identity_absent':True}
assert all(x['original_identity_absent'] for x in out.values()),out
print(json.dumps(out))
'''

def close(K, R):
    a = json.loads((R/'attempt.json').read_text())
    assert a['materials_before']==a['materials_after'] and a['git_before']==a['git_after']
    assert not a['wait_ownership_lost'] and not a['coordinator_recovery_required']
    assert (K/'grant.json').read_bytes()==(R/'grant.original.json').read_bytes()
    write(K/'identities-to-close.json', {'parent':a['parent_identity'],'child':a['owned_child']})
    code=close_code.replace('KPATH',repr(str(K)))
    r=subprocess.run(PREFIX+[PY,'-c',code],capture_output=True,timeout=20)
    (K/'postclose.stdout').write_bytes(r.stdout);(K/'postclose.stderr').write_bytes(r.stderr)
    assert r.returncode==0,r.stderr
    return a,json.loads(r.stdout)

# Attempt2 is already terminal. Never send a late signal to it.
old_a,old_closed=close(OLD,E/'current-runs-1'/OLD.name)
assert old_a['status']=='timeout' and not (OLD/'ROOT-single-SIGINT.json').exists()
write(OLD/'ROOT-failed-controller-sequencing-diagnosis-and-closure.json',{
 'scope':'Failed intended SIGINT control, preserved; no signal operation ran. Actual source timeout and child TERM remain actual data. No relabel/pass/retry inference.',
 'root_cause':'Root sequential tool orchestration awaited target completion before signal operation; no signal operation files were created. Correct next attempt launches target with Popen then runs one concurrent identity-guarded signal operation before waiting outer target.',
 'actual_status':old_a['status'],'terminal':old_a['terminal'],'postclose_identities':old_closed,
 'attempt_sha256':sha(E/'current-runs-1'/OLD.name/'attempt.json'),
 'material_git_grant_unchanged':True,'new_source_or_scientific_change':False,'time_unix_ns':time.time_ns()})

runid='M10-single-sigint-attempt3';K=BASE/runid;K.mkdir(exist_ok=False);R=E/'current-runs-1'/runid
assert not R.exists()
B=copy.deepcopy(json.loads((OLD/'binding.json').read_text()))
B['bindings']['output']=str(R);B['bindings']['grant']={'original':str(K/'grant.json'),'copy':str(R/'grant.original.json')}
for key in ['parent_argv_shape','target_argv_shape']:
 B['bindings'][key]=[x.replace('M10-single-sigint-attempt2',runid) for x in B['bindings'][key]]
write(K/'binding.json',B);bh=sha(K/'binding.json')
code=(BASE/'M01-current-controls-attempt1/C-observation-code.txt').read_text().replace('per-M01','per-M10-attempt3').replace('admits ONLYM01','admits ONLYM10-attempt3')
r=subprocess.run(PREFIX+[PY,'-c',code],capture_output=True,timeout=30)
(K/'C.stdout').write_bytes(r.stdout);(K/'C.stderr').write_bytes(r.stderr);assert r.returncode==0,r.stderr
C=json.loads(r.stdout);assert C['sigint_default'] and C['sigchld_default']
C.update(case='M10',scope='Fresh Root admission for ONE separately released attempt3 signal-control only. Attempts1/2 failures preserved, both wholeclosed; no source change or primary study release.',binding_sha256=bh)
write(K/'context.json',C)
G=copy.deepcopy(json.loads((OLD/'grant.json').read_text()));G.update(bindings=B['bindings'],candidate=B['bindings']['candidate'],binding_receipt={'path':str(K/'binding.json'),'sha256':bh},context={'path':str(K/'context.json'),'sha256':sha(K/'context.json')},run_id=runid)
G['resource_admission']['evidence_sha256']=sha(K/'context.json');write(K/'grant.json',G)
inner=[bh if x=='$ROOT_BINDING_SHA256' else x for x in B['bindings']['parent_argv_shape']]
child=[bh if x=='$ROOT_BINDING_SHA256' else x for x in B['bindings']['target_argv_shape']]
L={'scope':'ROOT separately releases ONE M10attempt3 after two diagnosed controller failures and actual wholeclose. Exact unchanged scientific source/bounds/expectedcase. Popen target, then concurrently run supported guarded one os.kill(SIGINT) to verified observer, then wait outer Docker only. Source solewait4 owns child. No child/group signal, repeat, PIDfd/atomic reuse/universal cleanup claim, new source/measurement framework, autoretry or study149 release.', 'run_id':runid,'runtime_released':True,'Bsha':bh,'Csha':sha(K/'context.json'),'Gsha':sha(K/'grant.json'),'inner_argv':inner,'target_argv':child,'cleared_prefix':PREFIX,'outer_argv':PREFIX+inner,'time_unix_ns':time.time_ns(),'source_output_absent':not R.exists()}
write(K/'launch.json',L)
signal_code='''from pathlib import Path
import json,os,signal,time
K=Path(KPATH);L=json.loads((K/'launch.json').read_text());R=Path(RPATH);deadline=time.monotonic()+10
def facts(pid):
 p=Path('/proc')/str(pid);f=(p/'stat').read_text().rsplit(')',1)[1].split();return {'pid':pid,'ppid':int(f[1]),'start_ticks':int(f[19]),'state':f[0],'process_group':int(f[2]),'session':int(f[3]),'argv':[x.decode() for x in (p/'cmdline').read_bytes().split(b'\\0') if x],'executable':os.readlink(p/'exe')}
ready=False
while time.monotonic()<deadline:
 try:
  intent=json.loads((R/'spawn-intent.json').read_text());owned=json.loads((R/'owned-child.json').read_text());parent=intent['parent'];pf=facts(parent['pid']);cf=facts(owned['pid']);boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
  ready=pf['start_ticks']==parent['start_ticks'] and cf['start_ticks']==owned['start_ticks'] and boot==parent['boot_id']==owned['boot_id'] and pf['argv']==L['inner_argv'] and cf['argv']==L['target_argv'] and pf['state']!='Z' and cf['state']!='Z' and cf['ppid']==pf['pid'] and cf['process_group']==cf['session']==cf['pid'] and time.monotonic_ns()-intent['monotonic_ns']<10_000_000_000
  if ready:break
 except (OSError,ValueError):pass
 time.sleep(.01)
assert ready,'exactcurrentobserver/execchildnotobserved; NOsignal sent'
current=facts(parent['pid']);assert current['start_ticks']==parent['start_ticks'] and current['argv']==L['inner_argv'] and current['state']!='Z'
record={'scope':'ONEordinaryPOSIXSIGINTonlytoimmediatelyidentityverifiedcurrentobserver; no child/group/repeated signal, waiter/reaper or atomicPIDreuse claim','parent':current,'child_before_signal':cf,'boot_id':boot,'signal':int(signal.SIGINT),'signal_time_unix_ns':time.time_ns()}
os.kill(current['pid'],signal.SIGINT)
record['signal_sent_once']=True
with (K/'ROOT-single-SIGINT.json').open('x') as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\\n')
print(json.dumps({'sent_once_to_observer':current['pid'],'child':cf['pid']}))
'''.replace('KPATH',repr(str(K))).replace('RPATH',repr(str(R)))
# Source field identity is frozen by ordinary raw receipt inspection.
intent_example=json.loads((E/'current-runs-1'/OLD.name/'spawn-intent.json').read_text())
assert 'monotonic_ns' in intent_example, list(intent_example)
(K/'single-SIGINT-operation-code.txt').write_text(signal_code)
assert not R.exists()
start=time.time_ns()
with (K/'stdout.txt').open('xb') as out,(K/'stderr.txt').open('xb') as err:
 target=subprocess.Popen(L['outer_argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err)
 try:
  sig=subprocess.run(PREFIX+[PY,'-c',signal_code],capture_output=True,timeout=20)
  (K/'signal-operation.stdout').write_bytes(sig.stdout);(K/'signal-operation.stderr').write_bytes(sig.stderr)
  write(K/'ROOT-signal-operation-terminal.json',{'returncode':sig.returncode,'time_unix_ns':time.time_ns(),'stdout_sha256':sha(K/'signal-operation.stdout'),'stderr_sha256':sha(K/'signal-operation.stderr')})
 finally:
  rc=target.wait()
a=json.loads((R/'attempt.json').read_text());matched=rc==2 and a['status']=='observer-cancelled' and (K/'ROOT-single-SIGINT.json').exists()
write(K/'ROOT-target-terminal.json',{'scope':'ActualM10attempt3 collection, independentassessmentpending','returncode':rc,'start_unix_ns':start,'finish_unix_ns':time.time_ns(),'status':a['status'],'terminal':a['terminal'],'matched_expected_collection':matched,'attempt_sha256':sha(R/'attempt.json')})
a,closed=close(K,R)
write(K/'ROOT-closed-collection-summary.json',{'scope':'ActualM10attempt3 oneSIGINT collection only; attempts1/2 remain failed and unchanged, independentreviewpending','matched_expected_collection':matched,'status':a['status'],'terminal':a['terminal'],'postclose_identities':closed,'attempt_sha256':sha(R/'attempt.json'),'material_git_grant_unchanged':True,'time_unix_ns':time.time_ns()})
print(json.dumps({'runid':runid,'status':a['status'],'matched':matched,'signal_operation_exit':sig.returncode,'postclose':closed}),flush=True)
assert matched and sig.returncode==0
