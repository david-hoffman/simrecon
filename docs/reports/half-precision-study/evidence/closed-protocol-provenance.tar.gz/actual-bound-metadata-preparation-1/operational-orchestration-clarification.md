# ROOT operational clarification — existing one-case harness, ordinary finite orchestration

ROOT wholly read/applied the completed conditional source-review handoff and checklist under actual-bound-source-preparation-1/ROOT-completed-source-review-intake-1.json SHA039850a06db060dbb562b4e670b0d70281e5abcd059db6537a6db9f7410e055a. Its frozen26 artifacts are not changed by this later clarification.

The checklist's “no batch” wording describes the existing harness boundary: each invocation/resource grant selects one attempt and one fresh direct child; every case has its separate current admission, exact B/C/G/expanded-argv/L, immutable artifacts, actual status and whole closure before the next. No shared-grant multi-case workload, automatic retry/fallback, scientific adaptation, new helper/framework or weakened freshness/closure is introduced.

ROOT may use ordinary finite orchestration of the already predeclared cases while respecting those per-case boundaries. The user's campaign authorization covers routine execution transitions;149 nominal observations do NOT require149manualhuman approvals or a fresh role for every grant. A new physical check/admission/receipt is an operational evidence action, not a user authorization interview. Exact accepted§8A wording/design/order remains unchanged. SOURCE/metadata preparation, accepted parent/material/method/scientific conditions and ROOT's explicit actual execution/window releases remain separate.

ROOT reported113fullgate3 actualPASS but finalD/actualparent acceptance/publication still pending at this clarification. No114integration/runtime transition is inferred. This new note is external operational provenance only, not a source or frozen-checklist edit, new schema or grant.
