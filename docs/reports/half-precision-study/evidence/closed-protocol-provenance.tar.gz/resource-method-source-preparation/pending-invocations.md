# Pending invocation bindings — NOT READY, NONEXECUTED

Execution HOLD is unconditional in this external copy. This is an argv inventory,
not a shell command, grant, reserved directory or execution instruction.
Actual accepted113, parent/integration/candidate/default/single profile, material,
startup/native/grant/context/root/output and all command identities are UNBOUND.
The external source is not a direct target. No runnable approved grant exists.

Historical target shape to reconcile after final113, with every path UNBOUND:

```text
cwd/root (UNBOUND): /workspace/work/issue-114
interpreter (UNBOUND prefix and realpath): /workspace/work/issue-114/.venv/bin/python
source (UNBOUND): /workspace/work/issue-114/docs/reports/half-precision-study/study.py
manifest (UNBOUND): /workspace/work/issue-114/docs/reports/half-precision-study/manifest.md
parent argv (NOT READY):
[/workspace/work/issue-114/.venv/bin/python,
 /workspace/work/issue-114/docs/reports/half-precision-study/study.py,
 --route, resource, --grant, <UNBOUND_ROOT_ONE_ATTEMPT_GRANT_PATH>,
 --row, W01, --strategy, WIDER, --repetition, 1,
 --run-id, <UNBOUND_UNIQUE_RUN_ID>]
direct target argv (NOT READY):
[/workspace/work/issue-114/.venv/bin/python,
 /workspace/work/issue-114/docs/reports/half-precision-study/study.py,
 --route, resource-child, --grant, <UNBOUND_OUTPUT>/grant.original.json,
 --row, W01, --strategy, WIDER, --repetition, 1,
 --run-id, <UNBOUND_UNIQUE_RUN_ID>]
bootstrap argv protocol (NOT READY):
[<UNBOUND_INTERPRETER>, -c, <FROZEN_SESSION_BOOTSTRAP_BYTES>,
 <OWNED_READINESS_FD>, <ATTEMPT_NONCE>, <JSON_DIRECT_TARGET_ARGV>,
 <UNBOUND_ROOT_READINESS_BYTES>]
output (UNBOUND): <UNBOUND_ROOT_EVIDENCE>/<UNBOUND_UNIQUE_RUN_ID>
```

These are the existing first-case labels only, not a scheduled attempt. No
single-profile or precision flag is inferred. No --qualification reaches the
resource child; future root grant names a reviewed row qualification hash, without
loading qualification arrays there. Parent/grant-copy paths differ deliberately;
future source/grant bindings must reconcile both and exact argv including source
and interpreter. Both grants retain identical bytes and digest when copied.

Before any later command READY, root must freeze actual accepted113/parent/base/
candidate commit/tree/clean status, actual public signatures/default and accepted
single-profile boundary, final source/manifest/import-bearing/startup indexes,
interpreter path/prefix/realpath, required FFT module names/paths/hashes, bootstrap
bytes/hash and FD/nonce protocol, exact parent/direct target argv, .venv/.pth/
startup/coverage behavior, OS, all six THREAD_KEYS=1 before startup, SciPy workers=1,
array-API/allocator/preload settings, and unique output destination. Parent startup
stdout/stderr capture must be outside its interpreter startup; child capture is
owned by the dormant parent file actions from bootstrap startup through exit.
Raw output/disk and startup safety admission fields remain UNBOUND.

Bind one root-owned current-context receipt only after command READY. Record
exposed host/cgroup correspondence, visible ancestry, headroom/swap/events/pressure/
competing load and unknown_unobservable external ancestors. Grant no ancestry
certainty from the leaf-only guard. Root #117 measurement exclusivity remains.
Freeze positive deadline/startup/TERM/reap values and readiness bytes for this
actual case, not from #116. No batch, fallback, retry or profile Cartesian growth.

Retain original grant, spawn intent, owned-child marker, exact bootstrap/target
argv, raw child stdout/stderr, startup-readiness.bin, child.json, attempt.json,
terminal/status/cleanup facts and before/after material/native indexes. Separate
diagnostics retain their unique JSON/NPY outputs. Partial/missing artifacts are
incomplete evidence. Parent disappearance does not prove target exit; no abrupt
orphan experiment or recovery signal is authorized here.

Final binding-loader/hash-cycle design, FFT module applicability, filesystem
failure behavior and affected lifecycle qualification remain the concrete gaps
in preparation-report.md. Final integration/rebinding, fresh affected method
review and a separate root finite release precede any execution. Full study,
scientific review, exact Ubuntu gate and fresh D remain later obligations.
