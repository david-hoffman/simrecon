# R1 finite external source preparation report

Disposition: SOURCE DRAFT ONLY; unconditional execution HOLD, all actual final
bindings UNBOUND, no command READY, no qualification or acceptance claim.
Date: 2026-11-16. Role: fresh nonblind source author R1, not product C or B/D.
The coordinator packet identifies the historical clean checkout as
`d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67`; read-only Git observation at admission
matched that HEAD and emitted no tracked status entries. No tracked write occurred.

## Exact artifacts and input identity

All owned outputs are directly under
`/workspace/work/campaign/evidence/114/resource-method-source-preparation/`:
`study.py`, `manifest.md`, `source-delta.patch`, `frozen-inputs.sha256`,
`outputs.sha256`, this report, `pending-invocations.md`, `author-accounting.md`.
The hash indexes give complete byte identities; outputs.sha256 excludes itself.
Coordinator-owned packet/inputs/launch/accounting files were not modified.
Packet SHA256: 0c6a907841929b0e30e1507bb5a061b5040a61d7232f79d7834acbc115a8e85b.
Own immutable source: 9daa4744fbb30833f26d8cc249f0db27c26502f3410216fa808910fc09a402c7.
Own immutable manifest: 6ae262ce4d228feff8d4dc2e2831dce010bbadd3a156d018402b7cbf272d604d.

Only named inputs were consulted for method work. Accepted #116 lifecycle source
was used nonblind as a method reference; no raw arrays, science truth, peaks,
resource caps or qualification claims were read/copied. No #117 inputs or
measurements were accessed. Scientific baseline b344e41a8b52de76d7cbbf8450319893904c3b8f
and original source pins remain explicitly historical, not final binding.

## Changed-function map

- Added execution_hold before imports and at authorize/main. Existing parent and
  child unconditional refusal remains. A grant cannot unlock any entry.
- Added explicit UNBOUND binding inventory; ROOT/EVIDENCE/EXPECTED are None.
  authorize's dormant code checks named paths/argv/bootstrap/material/startup/
  context identity instead of admitting historical BASE as final parent.
- memory_state adds only conditional exposed-domain/unknown_unobservable labels;
  resource formulas/headroom arithmetic are unchanged.
- environment preserves optional path absence and safely describes optional
  scalar/type metadata; added safe_attribute and required_fft_provenance.
  resource_child records post-call binary identity; validate_resource_record
  requires it; main records post-call identity for diagnostic work.
- resource_materials adds a named startup index to before/after identity capture.
- write_once serializes completely before exclusive creation; main uses it too.
- resource_parent alone gains small nested FD/readiness helpers and the fixed
  inline same-PID setsid/readiness/exec bootstrap. No new observer framework.
  Existing collect remains the sole exact-PID wait4 owner and terminal cache.
  Signals are direct PID, never group. Startup/readiness bounds are root-supplied.
  Writer aliases close after spawn; buffered readiness drains after cached exit;
  pre-session birth and verified session identity are compared separately.
  Primary stop reason survives secondary failure; existing bounded TERM/KILL/reap
  behavior stays explicit. Raw child capture includes bootstrap and imports.

## Unchanged-science map

Text diff contains no edits to SHAPES, STRATEGIES, RESOURCE_STRATEGIES, OPTICS,
OBSERVATION_BYTES, RECORD_LIMIT_BYTES, SNAPSHOT_SCOPES or the following functions:
`timed`, `remember`, `encode`, `numeric_chunks`, `array_identity`, `array_hash`,
`paired_chunks`, `scalar_stats`, `stats`, `error_metrics`, `pack`, `phases_for`,
`generator`, `settings`, `make_transfer`, `workflow`, `one_time`, `compose`,
`corrected_replay`, `index_frequency`, `assemble_replay`, `exact_inverse`,
`oracle_checks`, `decision_projection`, `parameter_comparison`,
`expected_branches`, `public_boundaries`, `run_workflow`, `failure`,
`fit_equal_power`, `fit_general`, `run_kernel`, `cpu_feasibility`, `resource_plan`,
`standalone_plan`, `guard_resource`, `retained_payload`, `resource_snapshot`,
`resource_git`, `child_identity`, `resource_caller`, `resource_stage`,
`refuse_quarantined_resource_launch`, `decode_scalar`, `finite_controls`.
Numerical body/rows/formulas/caller/conversion/result retention inside the changed
resource_child remain verbatim; added provenance is outside scientific computation.
All original manifest scientific sections and tables are retained verbatim.
No shape/precision/API/oracle/tolerance/profile/matrix expansion was introduced.
This is text-delta evidence, not parsed or executed equivalence verification.

## Concrete pending gaps and limits

1. Actual accepted113/parent/base/candidate/tree/clean state, public default and
   supported single-profile signatures/material applicability remain UNBOUND.
   The scaffold is deliberately not a complete binding loader. Final binding
   design must avoid self-referential candidate/source/manifest/grant hashes:
   final candidate identity and own artifact hashes belong in an external receipt
   frozen after source, not hard-coded into bytes that determine that candidate.
   Grant paths are named; no grant self-hash is embedded in its own bindings.
2. ROOT/output/manifest/argv/source/import/native/startup/context and unique run
   binding remain UNBOUND. Interpreter realpath/prefix, actual OS and exact
   environment, .pth/startup/import-bearing closure, both coverage-trigger
   conditions, preload/allocator/array-API settings and fileless namespaces need
   actual final-parent reconciliation. Current fixed version checks are historical
   requirements pending applicability; this preparation invents no new versions.
3. required_fft_provenance currently names both known FFT modules. Applicability
   to resource paths and non-FFT kernel rows needs final-source review; a missing
   required module fails closed. No import solely to manufacture binary evidence.
4. Root must freeze readiness bytes, startup/deadline/TERM/reap bounds and per-case
   disk/raw-output/context admission. Existing 50 ms nominal polling is not a
   scheduling guarantee. No operational safety cap is inferred from #116 or old
   control2. Leaf guard cannot establish hidden-ancestor or competing-load safety.
5. FD close/readiness artifact write/fsync failures can prevent the final sidecar.
   Cached terminal usage lives in memory until persistence; durable-intent/raw
   recovery remains root-owned. No claim of atomic multi-file output or abrupt
   observer-death support. Fast child exit before a usable /proc birth snapshot
   remains fail-closed rather than inferred success.
6. Fresh affected review must challenge startup/setsid/readiness/exec failures,
   EOF/malformed/oversized/late/buffered-after-exit readiness, spawn writer cleanup,
   cached exact wait, stop precedence, SIGINT, TERM/KILL/reap gaps, record parsing,
   identity drift and output failure. No new runtime release is implied.
7. Existing live headroom checks are admission evidence only. There is no process
   RSS sampler/gap-qualification implementation in this narrow delta; any such
   future commissioning requires separately frozen semantics and affected review.
8. Whole-child wait4 and cumulative self samples stay distinct; exec high-water
   retention is unresolved. No subtraction/aggregate/benefit/nativehalf claim.
   Full W/K science, phase/noise witnesses, report review, exact integrated Ubuntu
   gate and fresh D remain later root-owned obligations.

## Attempts, checks and ownership

One R1 source-author attempt; all source changes are external. Only text/Git/file
hash/source-write operations were performed. No Python/AST/compile/import/lint/
types/tests/install/native/probe/control/benchmark/process scan/signal/workload
spawn occurred. No refusal path was executed. Git diff exit 1 denotes expected
text differences, not a failed check. Some long text displays were truncated;
relevant narrower slices were reread. No patch application failed. Reviewable
text diagnostics removed a contemplated grant self-digest check before completion
and clarified exec-retention wording; neither draft was executed.

No owned active target process exists: this author launched no target, control,
measurement, helper service or agent. No process scan was performed; no claim is
made about other roles' processes. No scratch or fixtures beyond the eight named
outputs were created. Inputs and durable evidence are retained. No deletion,
commit, restack, push, test, gate or qualification occurred.

Historical control1 remains INCOMPLETE. Historical control2 receipt
434198b6e10e2df1fd60fd7c20e81fc7225a22e7b5ce21b23457a6b65a42691f
retains its actual-time/material-specific scope only; its arrays were not read,
its helpers were not rerun and it supplies no R1 lifecycle/scientific acceptance.
Prior charges remain. See author-accounting.md for the separately added R1 charge.
