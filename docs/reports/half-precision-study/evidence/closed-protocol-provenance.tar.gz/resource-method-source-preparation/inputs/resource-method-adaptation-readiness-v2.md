# #114 smallest resource-method adaptation: source-only readiness plan v2

2026-11-16. This finite continuation creates only this external plan. It does not implement, qualify, schedule or release anything. Historical plan `future-resource-route-plan.md` is retained. Sole tracked Current state is unchanged; checkout HEAD `d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67` is clean. File-only reread confirms study SHA256 `9daa4744fbb30833f26d8cc249f0db27c26502f3410216fa808910fc09a402c7` and manifest `6ae262ce4d228feff8d4dc2e2831dce010bbadd3a156d018402b7cbf272d604d`. No imports, AST, lint, tests, installation, benchmarks, measurement or roles were run. No owned active target exists.

## 1. Integration and profile bindings remain open

Root's intended stack is 116→117→118→119→120→113→114 after earlier accepted work. Actual accepted final #113 is mandatory; the old public-main `BASE` label is historical scientific provenance, not that future parent. Before changes, root must supply and reconcile these exact fields:

| Binding | Present value / required later action |
| --- | --- |
| accepted113 commit/tree/PR and #114 actual parent/integration base | **UNRESOLVED**; do not substitute #116, #117 candidate or old main |
| rebased #114 candidate commit/tree/clean status | **UNRESOLVED**; root integrates, this coordinator does not restack |
| default public workflow/prepared-stage signatures, operation order, validation, output retention | **UNRESOLVED on final parent**; current study calls public APIs without a precision argument |
| accepted single-profile spelling, supported entrypoints/dtypes, exclusions and default behavior | **UNRESOLVED**; current own checkout has no precision/profile argument in the named entrypoints |
| renewed source/import/startup/lock/interpreter/native identities; commands and grants | **UNRESOLVED**, freeze after integration and before readiness/release |

The existing default wider API path remains the comparison meaning. `H1` is half caller storage followed by the existing wider computation; `H1_PROMOTED` is the same rounded half values stored as one float64 caller, separating dtype dispatch from quantization. Neither means a product single profile. Any later accepted single profile may be identified and compared only at its actually supported public entrypoints and named cases after material/intake applicability review; do not automatically multiply this matrix or add a profile switch to the product. If unsupported there, report that boundary. `PREPARED_HALF` is `<f2` real/imaginary storage plus complex128 unpack/downstream compute. H3 native-half computation is unsupported by current evidence; there is no assumed complex32 dtype. CPU FFT internal arithmetic remains unknown. Optional GPU documentary feasibility is not an install or executable backend proposal.

## 2. Exactly what would change, after those prerequisites

Keep both unconditional guards in `study.py:resource_parent` and `resource_child` effective now. The dormant parent's `posix_spawn(..., setsid=True)` is known unsupported on this interpreter. Removing only that keyword would also invalidate its pre-readiness `killpg(pid,...)` assumption.

Propose a localized change within the report harness plus its existing manifest, not a new observer/artifact framework: a fixed stdlib bootstrap constant and small launch/readiness helper; adapt the existing exact-PID wait owner, cleanup, grant/record validation and provenance. Plain `posix_spawn` starts the bootstrap. In that same PID, bootstrap calls `setsid`, writes one bounded nonce/PID/PPID/session/PGID/executable readiness message, closes its FD, and `execve`s the frozen direct target. Parent creates its sole `wait4(exact_pid,WNOHANG)` owner immediately after spawn and closes writer aliases. Readiness is drained even after cached terminal exit. Before verified readiness, signal only the still-owned direct PID; do not assume a group exists. Keep cached terminal usage through parser/cleanup failures. Default SIGCHLD/no auto-reaper and the supported ordinary Python SIGINT handler are explicit admission preconditions. No Popen polling/reaping, hidden fallback, new interpreter or retry loop.

Renew checks before native imports and capture whole-startup stderr; the prior diagnostic wrapper established that imports can warn/fail before the study warning context. Do not reuse its Popen renderer as a scientific wait4 observer. Record actual loaded required FFT paths/hashes after calls, with safe scalar/type handling for optional attributes; a pre-call null snapshot cannot qualify a binary. Fully build JSON before exclusive final-sidecar creation so serialization failures remain failures without a misleading complete sidecar. Extend existing material checks to the actual final-parent named import-bearing inputs/bootstrap/startup, preserving before/after identities and ignored/untracked-input limitations. This is narrow lifecycle/provenance work, not a numerical vector/oracle rewrite.

Method-only reference read: accepted #116 checkout `158776ade28079276304d49a6b973eccbf4109c9`, `docs/reports/reconstruction-working-set/`:

| Source | File SHA256 |
| --- | --- |
| `observer.py` | `384b4f1a95ad135136c60b9bb750437fe72e5bbb1a94fc21bd7cc1ae14ff6c9e` |
| `run_attempt.py` | `2c2358bbcb801a970de6b1d3c786cf510394887ef397b1e14d7ad4a843efea1e` |
| `workload_child.py` | `5249e4cdadbee6523012127468fd9c3d90228df2558c81087929bc35e60e5459` |
| `manifest.json` | `bd633265f3ac1967420b2032401b4f52c2a525271da510ed16dfb3506ef05234` |

Use only the plain-spawn/readiness/exact-wait and qualified terminal-observation design. No #116 raw science, resource thresholds, measured peaks, accepted truth or blanket qualification is transferred. #117 source-reviewed external binding is not needed for this minimal plan, and its pending runtime qualifier supplies no authority.

## 3. Frozen ten rows, witnesses and retention

Do not expand the study. W01 `(1,1,3,1,16,16)` native 2D/O2/supplied/read-only/strided boundaries; W02 `(1,3,5,4,16,16)` 3D/supplied; W03 W02 searched; W04 `(2,3,5,4,16,16)` t0-search/reuse and changed modulation; W05 `(1,3,5,4,32,32)` Y/X-only resource step; W06 W02 geometry/nonuniform full-rank phases/signed near cancellation. K01 has the existing 16 real range words, reversed-imaginary paired encoding and FFT16 policy case; K02 eight values × three alpha declarations (large geometry metadata only); K03 exactly 16 dyadic product/energy/cross cases (length16/4096); K04 existing finite inverse-growth, fit/tie/singularity/phase formulas. No full-volume extrapolation allocation.

For each W row, retain the existing once `QUALIFY` diagnostic and wider/H1/H1_PROMOTED/four isolated H2-site comparisons, three fresh successful repetitions as designed; K rows need one deterministic numerical pass. This is a case inventory, not authority for a batch or automatic retries. Resource representations remain the existing five named paths only (`WIDER`, `H1`, `H1_PROMOTED`, `PREPARED_WIDER`, `PREPARED_HALF`) within admitted W rows, three fresh successful repetitions, each explicitly scheduled one attempt at a time. Prepared pair compares only its matched stage interval, never a full-workflow peak against a prepared-stage peak. No standalone resource claim for corrected/filtered/embedded replay. A failed fixture branch is diagnosed as fixture failure; it is not tuned until a favorable half result appears.

Own witnesses remain the frozen analytic Fourier/finite-sum signs/scales/coordinates, wider branch qualification, half-value promoted dtype control, exact dyadic K03 sums, and K04 finite formulas. No new oracle or tolerance is proposed. Range/finite/signed-zero/negative/sign-change, max-absolute/RMS/relative-L2 with zero rule, carrier units/bins, modulation amplitude/wrapped phase (undefined at zero), phase/noise/gain diagnostics and discrete branches retain their existing definitions. Missing phase/noise qualifications remain missing. Scientific usefulness and any acceptance proposal require later independent scientific review; finite output alone does not pass science.

Resource child: one declared caller, necessary work/conversions, one complete retained result, one call. Keep no analytic truth volume, comparison baseline or qualification arrays in that child. Full-workflow WIDER/H1/H1_PROMOTED have identical full-result retention. Prepared setup may release raw input, but its cost remains in cumulative/terminal high-water; packed caller and promoted bands coexist explicitly. Input and common-output shape/dtype/endianness/strides/read-only/ownership/canonical hashes and finite/range records link independently saved diagnostics. Shared backing counts once in reachable payload. No full-array reload or reference workflow in measured child.

## 4. Direct target and outputs to freeze, not execute

Concrete current target shape for the first later admitted resource attempt is:

```text
cwd/root: /workspace/work/issue-114
target argv: [/workspace/work/issue-114/.venv/bin/python,
 /workspace/work/issue-114/docs/reports/half-precision-study/study.py,
 --route, resource-child, --grant,
 /workspace/work/campaign/evidence/114/study/W01-WIDER-resource-method7-attempt1/grant.original.json,
 --row, W01, --strategy, WIDER, --repetition, 1,
 --run-id, W01-WIDER-resource-method7-attempt1]
parent argv: same interpreter/study, --route resource, same row/strategy/repetition/run-id,
 --grant /workspace/work/campaign/evidence/114/W01-WIDER-resource-method7-attempt1-root-grant.json
```

This is a NOT-READY proposal, not a runnable grant or reserved output directory. Interpreter realpath may resolve outside `.venv`; record both prefix and actual resolved binary. Root-provisioned Ubuntu24.04.5 container and cwd/root must agree; no host qualification. All six existing thread variables are explicitly `1` before startup and SciPy workers=1 within calls; name actual array-API, allocator, preload, startup/.pth/venv and both coverage-trigger conditions. Final single-profile argument, if any, is **UNRESOLVED and absent from this target**. No `--qualification` reaches the resource child: root binds the reviewed row qualification hash in its one-attempt grant, checked without loading it there.

Manifest path is the existing `docs/reports/half-precision-study/manifest.md`, renewed after source change. Frozen target/parent/bootstrap argv, bootstrap bytes, environment, candidate/base/parent/tree, source/material/startup indexes, input expected identities, scientific qualification and output destination all need exact hashes before command READY. Preserve `grant.original.json`, intent/owned-child/readiness bytes, raw stdout/stderr, child.json, parent attempt/terminal/cleanup evidence and material/native indexes at the unique output path. Diagnostic run.json/NPYs stay at separately unique run IDs; retain file byte counts/headers/hashes and full raw values. No in-place repair or overwrite of an old attempt.

## 5. Qualification gaps and exact observation limits

Minimum affected fresh method review must cover this actual target/root/manifest/output binding, same-PID bootstrap protocol, sole wait ownership, pre-import limits/capture, bounded observations and post-call native identity. Then root may release own finite controls: normal target; spawn/setsid/readiness/exec failures; readiness absent/malformed/late/buffered-after-exit; missing/malformed/oversized child JSON; finite child exception/self-signal; deadline TERM and TERM-ignore/KILL cleanup; supported observer interruption; identity/material/grant changes; lost wait ownership; missing/invalid process RSS including terminal race and independent stop precedence. Test observable semantics, not clone every #116 vector. Abrupt observer kill is not silently supported; with container PID1 sleep/no-init, do not deliberately orphan a target. Incomplete recovery is an explicit stop requiring root disposition.

Existing finite source bounds are 65,536 bytes per numeric observer buffer (not total scratch), streaming file hash chunks 1MiB, child-record parse bound4MiB and the explicit standalone live-array ledger including 16 observer buffers. Keep them explicit or justify a reviewed delta; Python metadata/allocator/native workspace remain unknown. Proposed readiness/parser byte bounds, polling/deadline/cleanup budgets, startup safety limits and raw-output/disk admission must be frozen for #114 from its own payload/current context, not copied from #116 or old control2. Do not invent human budgets. Root captures context only after exact command READY, grants an exclusive window and one execution; admission conditional on exposed host/cgroup correspondence/visible ancestors/headroom/swap/events/pressure/competing load. External ancestors remain `unknown_unobservable`.

Record pre-call/call-end/post-observation cumulative self high-water, conversion-inclusive/call-only clocks and terminal direct-child native `wait4` usage through final exit/JSON/teardown, Linux KiB×1024. Live samples are headroom/guard evidence; neither sampled maximum nor call-end self sample substitutes for terminal usage. Missing RSS is not zero or proof of exit: preserve actual sample timestamp, bounded confirmation and independent stop precedence; do not erase an expired gap after late exit. Same-PID exec does not prove every bootstrap/pre-exec peak survives. No peak subtraction, exact allocation attribution, tree aggregate, warmed throughput, 16GiB feasibility or storage/speed benefit follows automatically. Count hashes, setup, pack/unpack, result retention, observation/serialization and unknown native workspace honestly.

## 6. Historical evidence and finish condition

Retain control1 INCOMPLETE (serialization failure/partial post/no maps), all frozen executed inputs and every charge/failure/repair. Control2 receipt `434198b6e10e2df1fd60fd7c20e81fc7225a22e7b5ce21b23457a6b65a42691f` remains its actual time/material-specific bounded method/dependency qualification: command `198794e6…e9d7`, candidate64edcad/tree1ef, samePID46240, 78 array files, 19 intentional warnings, both actual FFT binary identities, and source-supported fileless namespace disposition. It supports unchanged wire/hash/rounding/dyadic/error/FFT-policy reasoning; it does not qualify a changed source/parent/native route, full K02/K04, phase/noise witness, W science, resource lifecycle, internal FFT precision or benefit. Preserve all archived attempts/reviews/logs/accounting; no rerun of already-passed helpers merely to refresh a status label. Actual future renewal scope follows changed materials and affected review, not a generic new review loop.

Finish this readiness continuation here. Actual source work and native qualification remain blocked on accepted113/material/profile reconciliation and root's explicit scoped dispatch/release. Full study/report scientific review, supported/unsupported matrix and one implementation handoff or supported negative outcome, exact integrated Ubuntu gate/fresh D and publication remain later root-owned work. Current/source remain clean and unchanged.
