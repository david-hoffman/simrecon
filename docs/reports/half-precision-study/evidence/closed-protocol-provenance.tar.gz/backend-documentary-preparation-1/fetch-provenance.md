# HP114 backend documentary fetch provenance

This is a record of public documentation reads on **2026-11-17 UTC**, beginning after shell timestamp00:48:15 and ending before final report freeze. Individual web-tool wall timestamps are not exposed; sequence/order and returned source labels are retained, not invented per-request clocks. Public NVIDIA documents only; no authentication, binary/PDF retrieval, native-library/package/source archive or executable fetch, installation, browser action or GPU probe.

The purpose-built tool discovered through ALL_TOOLS was `mcp__codex_apps__search_service_web_run`; its documented open/find/search interfaces were used. Nine calls yielded the exact saved result objects `fetch-01…fetch-09*.json`. `fetch-requests.json` retains their exact submitted request envelopes in sequence. Each result contains complete returned content blocks, source URL/reference labels, relevant excerpts, metadata and failures from that call. These are exact tool observations, not complete HTTP responses or full upstream HTML. Hashes of these local JSON bytes do not authenticate the vendor or supply hashes of unread page content. No raw-page body hash is claimed.

| Call/result file | Exact operation family and relevant requested inputs |
| --- | --- |
|01 live-docs | Open `https://docs.nvidia.com/cuda/cufft/`, `/cuda/eula/index.html`, `/cuda/cuda-toolkit-release-notes/index.html`; returned titles13.5/13.5 and EULAJan26,2026. |
|02 versioned-attempt-and-finds | Open `/cuda/archive/13.5.0/{cufft,eula,cuda-toolkit-release-notes}/index.html`: all inaccessible via tool, not proof those URLs never exist. Find Half-precision, CUDA_C_16F, cuFFT in initial live sources. |
|03 bounded-version-search | Queries: `site:docs.nvidia.com/cuda/archive/ cuFFT 13.5 half SM_75`; `site:docs.nvidia.com/cuda/archive/13.0.0/cufft Half-precision`; `site:docs.nvidia.com/cuda/cuda-math-api __half2 two half`. Used only NVIDIA primary results; search crawl/publication labels not adopted as vendor release dates. |
|04 archive-13-0-3-primary | Open `/cuda/archive/13.0.3/{cufft,eula,cuda-toolkit-release-notes}/index.html` plus `/cuda/archive/13.0.3/cuda-math-api/cuda_math_api/struct____half2.html`. |
|05 targeted-primary-finds | Find half-precision in requested live release reference; Half-precision cuFFT Transforms, cufftXtMakePlanMany, unnormalized, Just-in-Time, 8*batch, Last updated in archive cuFFT; GeForce and Attachment A in archive EULA. One returned release find identifies archive13.0.3 rather than the requested live reference: report treats its actual source as archived and does not infer current bug status. Later literal-URL live read resolves history. Missing literal matches stay missing. |
|06 release-api-representation | Literal open live release notes at880 (unrelated viewport, not relied on); archive cuFFT at130/2110; query `site:docs.nvidia.com CUDA_C_16F complex real imaginary half2 cufft`. Search-only PDF/older-library results are not treated as opened proof or added candidates. |
|07 normalization-dependencies-platform | Literal find current cuFFT un-normalized/cufftXtGetSizeMany and live release notes 3.2.cuFFT; open archive13.0.3 Linux installation guide and CUDA runtime TYPES. Live history shows size1 issue fixed13.1, current workspace-alias issue and LTO dependency changes. |
|08 representation-sync-platform-license | Literal opens archive synchronization, archive half conversion, current EULA176; finds24.04 in archive Linux guide, CUDA_C_16F in runtime TYPES (not found), NVRTC/cufftSetAutoAllocation in current cuFFT. |
|09 sync-license-planning-and-sample-discovery | Literal open archive synchronization190, live EULA180, current cuFFT117; query `site:github.com/NVIDIA/CUDALibrarySamples "half" "cufftXt"` yielded no results. No sample downloaded or used as ABI proof. |

Source paths above are on `https://docs.nvidia.com` unless explicitly noted. Exact returned sources and excerpts, not inferred URLs, govern each factual claim. `/cuda/cufft/` and `/cuda/cufft/index.html` are the same live document family; their derivations are treated together. Versioned13.0.3 and live13.5 are distinguished throughout. No full current13.5 archive was obtained. Current HTML copyright/update/publication date is not independently determined where absent; EULA and runtime displayed dates are recorded literally.

One separately attempted ordinary text fetch used:

```text
curl --proto '=https' --tlsv1.2 --max-time45 --fail --location
  --max-redirs3 --silent --show-error --dump-header OWNED.headers.txt
  --output OWNED.html --write-out '%{json}\n'
  https://docs.nvidia.com/cuda/archive/13.0.3/cufft/index.html
```

The real shell argv used separate option/value words as normal; the compact text above omits only owned absolute output prefixes. Exit22; proxy CONNECT returned403 Forbidden; no HTML body was received/created. `sources/archive-13.0.3-cufft.headers.txt` and `.transfer.json` retain exact observed headers and curl transfer metadata, including date00:49:34UTC and curl library version. No retry, proxy change or bypass. The subsequent supported purpose-built reader was already available and successful; it did not convert this failed curl into a raw-page success. This failure is source-access/tooling evidence, not scientific/backend failure.

The source anchors used in the report are: archived13.0.3 cuFFT/API/half2/conversion/EULA/release/Linux-guide/runtime-sync, live13.5 cuFFT/release, and current EULA. Technical facts are paraphrased and locally linked; no source publication date is invented. The report explicitly retains the archive runtime page's self-labelv13.0.2 and installation table's Update2/Ubuntu point-release cap rather than relying on URL version alone.

`inputs.sha256` records exact local contract/manifest/design-decision inputs. `outputs.sha256` covers the full saved response/provenance/report/accounting/distinct-final/header/transfer byte inventory except itself. Every full SHA256 identifies the stated local artifact only. The final response supplies the external manifest identity; there is no selfhash cycle or scientific-material binding/grant.
