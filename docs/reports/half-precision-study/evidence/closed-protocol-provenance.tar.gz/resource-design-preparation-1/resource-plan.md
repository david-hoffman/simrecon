# HP114 minimal resource-design proposal — SOURCE ONLY / HOLD

2026-11-17. Fresh nonblind resource-plan author, task
`/root/issue_114_resource_design_preparation/resource_plan_author`.
**Disposition: propose a scoped design amendment for independent review; not accepted,
not a completion verdict, not an execution grant.** Scientific utility, error,
resource results and feasibility conclusions remain UNMEASURED. All runtime,
actual-parent, binding, native, numerical, scientific-review and final-gate holds
remain. This report is evidence preparation, not a second Current state.

## 1. Decision and the exact completion boundary

Recommend **12 additional matched standalone observations**, confined to
PREPARED_WIDER/PREPARED_HALF on W02 and W05, three fresh successful repetitions
per arm and geometry. Retain the entire six-W/four-K numerical study, every
numerical variant, all successful-W repetitions and per-comparison diagnostic
resource facts. Select this resource question before any candidate results:

> For the frozen supplied-carrier W02/W05 cases, what whole-direct-child native
> peak RSS and elapsed intervals accompany explicit paired-half prepared-band
> storage, its setup packing, required complex128 unpacking and wider downstream
> estimation/reconstruction, under the same caller/result retention policy?

This is the minimum matched design for that particular two-geometry question:
2 representations × 2 existing geometries × 3 repetitions = 12. Removing an arm
loses the matched representation comparison; removing either geometry loses the
contract's W02/W05 spatial step; reducing repetitions violates the successful-W
design. It is **not a universal minimum independent of claims**. Zero standalone
observations could leave every actual benefit unmeasured, but would not answer the
selected conversion-inclusive peak question or support this resource handoff.

Resource90 = 5 named standalone variants × 6 W rows × 3 repetitions. It is not
scientifically necessary for the narrower question. It would measure full-workflow
WIDER/H1/H1_PROMOTED and prepared-stage pairs across all six cases; no such broad
resource claim is proposed here. H1_PROMOTED remains an essential numerical
same-half-values control. Its standalone resource arm is unnecessary when no H1
resource comparison is claimed. W01/W03/W04/W06 standalones would add resource
questions about true 2D, search, reuse or nonuniform phases that this proposal
expressly leaves unmeasured. Numerical evidence for those cases is retained.
Corrected/filtered/embedded H2 remain diagnostic replay only, as already scoped.

**Twelve does not satisfy the unchanged design by assertion.** The tracked manifest
lists all five standalone variants and retains three repetitions within W01–W06
[M0:394–405]; the accepted source witness repeats that design [M:602–614]. The
witness explicitly retains resource90 as a PROPOSAL [M:41–43,138–142]. Although
90 is neither a human quota nor a runtime batch authorization, reducing its
planned observations changes the recorded normative experimental design. It is
not an ordinary scheduling choice or mechanical prose cleanup. Obtain the actual
affected intake/design disposition described in §8 before ROOT selects twelve.
Until then, this is an unaccepted alternative; do not silently replace or activate
90, twelve, or any intermediate count. If unchanged broader claims are required,
retain their corresponding five-arm/six-row design rather than using this proposal
as a waiver. No automatic fallback or result-dependent expansion is proposed.

### Adjudication of the three controlling phrases

| Source wording | Required retained evidence | What it does not establish |
| --- | --- | --- |
| S7: “W02/W05 and other completed workflow rows”; “Fresh-process raw runs; unsupported envelope explicit” [T:88] | Fresh-process diagnostic lifecycle observations for **every completed W comparison**, including W01/W03/W04/W06; three repetitions for successful comparisons; W02/W05 additionally receive the selected matched pair | S7 cannot be met by showing only twelve records and omitting other completed rows. Diagnostic coexistence does not establish optimized memory/speed benefit |
| Contract §5: “run each comparison in a fresh process”, caller inputs retained, same threads; three fresh successful-W repetitions; cold/setup versus call-only; packing/unpacking in end-to-end; whole-process RSS/payload [C:180–192] | All 126 planned repeated diagnostic W observations retain these facts. Kernels retain their numerical/lifecycle facts with timing unresolved if too small. The twelve matched children are additional, with their distinct scopes | The text does not say every diagnostic comparison must also receive a second standalone resource experiment. It also does not permit treating unmatched diagnostic peaks as causal benefit |
| Manifest: all-five standalone table and three-W language [M0:394–405; M:602–614] | Preserve every numerical mode. Explicitly amend **which standalone comparisons are selected**, their claims and remaining UNMEASURED cells through affected intake and independent scientific/method review | Merely relabeling omitted observations “unmeasured” cannot amend the current design or itself establish completion |
| Contract final matrix allows demonstrated / technically unavailable / scientifically unsuitable / unmeasured / unresolved [C:152–155] | Give every strategy/site/backend a named-case disposition and reason, with separate numerical, diagnostic-resource and matched-resource columns | UNMEASURED is an honest matrix state, not scientific evidence of no benefit or automatic satisfaction of a required measurement |

The proposed resolution is that S7 requires all-completed-workflow lifecycle facts,
while matched causal benefit claims may be narrower. This preserves §5's “each
comparison” and timing/RSS obligations and changes only the standalone selection
and recommendation scope. An independent reviewer must accept that explicit
interpretation and the actual intake amendment; otherwise completion remains
blocked. There is no evidence-based scientific selection of prepared storage as
useful yet. This selects a question, not its answer or a preferred outcome.

## 2. Immutable finite observation inventory

The following is a proposed finite inventory, not a generated batch or grant.
Every cell is **PENDING/HOLD**, with no new attempt made here. Freeze this inventory,
claims and exact materials before trials. Row/mode/repetition identifies an
observation target, not a replaceable attempt directory.

| Family | Exact targets | Nominal records if all succeed |
| --- | --- | ---: |
| Wider qualification | W01,W02,W03,W04,W05,W06; QUALIFY; rep1, each in its own diagnostic process | 6 |
| Repeated numerical diagnostics | Each W01–W06 × WIDER,H1,H1_PROMOTED,H2_CORRECTED,H2_PREPARED,H2_FILTERED,H2_EMBEDDED × rep1,rep2,rep3; one invocation each | 126 |
| Kernel numerical rows | K01,K02,K03,K04; KERNEL; rep1, one process per row | 4 |
| Bounded CPU H3 | K01; CPU; rep1, NumPy/SciPy 16-value transform diagnostics only | 1 |
| Selected matched resource | W02/W05 × PREPARED_WIDER/PREPARED_HALF × rep1,rep2,rep3, one parent and one fresh direct child per invocation | 12 |
| Total primary planned observations | 6+126+4+1+12; not a human cap, timing estimate, guaranteed successes or authorization | 149 |

The 126 diagnostics include 18 WIDER repetitions and 108 half/dtype-control/site
comparisons. QUALIFY is not a substitute for a repeated WIDER observation. Its
full/summary pair and boundary examples remain within that existing row, not new
matrix rows. Kernel subvariants remain exactly frozen [M:338–379; H:1546–1758]:

- W01 true 2D/O2 plus finite read-only/strided same-value input, selected half
  public-input/acquisition and invalid boundary diagnostics; corrected W01 K1
  transfer; W02 known 3D and selected half prepare_bands acceptance.
- W03 searched maxima/alias/refinement/floor/phase replacement; W04 t0 search,
  later carrier reuse with independently fitted changed modulation; W05 W02's
  equations with only Y/X resource step; W06 supplied full-rank phases, signed
  near cancellation. Wider branches and finite signed outputs must actually qualify.
- K01 sixteen real boundary words and reverse-imaginary paired encoding; K02
  eight values under all three frozen alphas, large metadata case without volume;
  K03 all sixteen length/magnitude/pattern dyadic cases; K04 every frozen inverse,
  equal/general fit, ordered tie, singular/nonsingular regression and phase-design
  case. Do not discard intentional overflow/singularity or relabel formula-only
  K04 witnesses as public branch execution. CPU feasibility is attached to K01.

Lifecycle/observer controls and prior control2 are a separate evidence family.
No fixed new control count is invented here. Before release ROOT and the affected
method reviewer must freeze the smallest exact control selection required for
changed inputs/launch/record/timing semantics, retain applicability decisions for
unchanged controls, and list each control attempt separately. Their absence keeps
the primary inventory held. Controls are not additional scientific workloads or
successful W repetitions. Do not rerun a valid unchanged control merely for a label.

Each future immutable attempt record/index must identify target, unique attempt
ID, before/after materials, command/argv and status, original/copy grant and
binding/context/launch receipts, raw stdout/stderr, available markers/child JSON,
terminal record, array/file indices and hashes, timestamps/units, warnings,
exceptions and diagnosis. Append failed/refused/skipped/partial attempts with their
original identities; never overwrite, remove or count them as successful repetitions.
Distinguish admission refusal, unsafe headroom skip, fixture/oracle failure, numeric
incompatibility, method/record failure, environment failure, signal/timeout,
identity drift and unresolved ownership. Unstarted held targets are not measured
skips. Unsafe skips need actual preallocation headroom evidence and ROOT return;
they are neither zero cost nor no-benefit observations. A failed intended wider
fixture blocks affected candidates and returns to its author; a genuine half
failure is retained under its original semantics. Failure does not authorize a
replacement success, tuning or automatic retry. Any separately released diagnosed
attempt is linked to its predecessor, adds to cumulative accounting and leaves
three successful repetitions required wherever a comparison is reported successful.
No attempt quota is invented; unresolved targets remain explicitly incomplete.

## 3. Numerical and compatibility evidence remains complete in scope

Preserve all contract §4 metrics for every completed comparison: dtype/shape,
strides/alignment/ownership, ranges, nonfinite/zero-loss/subnormal counts, signed
minima/negative/sign-change/zero-sign facts; maximum absolute count-unit error,
RMS and relative L2 with the frozen zero-reference rule; carriers in cycles/um
and Fourier bins; complex/amplitude/wrapped-phase modulation error with undefined
zero phase; noise/gain/frame-sum/separator/residual/condition facts. Retain full
ordered traces, coarse maxima/ties, aliases, strict improvement, fits/floors/reuse/
phase replacement and exception/failure context [C:122–150; M:415–460]. No new
acceptance tolerance, gain, scaling, cutoff, half solve/fit/reduction, clipping,
reassociation or adaptive fitting is proposed. Wider defaults remain reference.

The accepted witness is **source-only accepted**. For each W row the independent
qualification obligations remain: raw/admitted float32 inputs; independent alpha
and coordinates; phase/noise/preparation, actual transfer stencils/filtering and
estimator premises; the complete conditional full-grid assembly reference with
its upstream conditioning limits and reference-error assessment; and the complete
RM84 common projection [Q:11–218,219–319]. Selected sums, expected branch strings,
negative pixels or zero selected summary error do not discharge these obligations.
W06 ideal rank/sign reasoning is not observed finite factorization/noise/image
truth. K04 equal energies or outside-range formulas are limited witnesses.

QUALIFY full/summary compatibility remains required on all six rows. Assess all
common scalar/array bits, signed zeros, metadata identities, ordered traces,
logical projections and the separately evidenced structural/type/ownership facts
specified in Q. JSON cannot restore lost original container or lifetime evidence.
Missing facts remain unresolved and block a complete compatibility claim. Numerical
agreement, resource observation, physical usefulness and compatibility are separate
verdicts. H1 summary support beyond existing finite scope remains unmeasured.

Before interpreting a resource child's numbers, independently bind its caller,
transfer, seed/settings and common-output identities to the qualified numerical
experiment. The standalone prepared route constructs initial carriers directly;
the diagnostic composition uses baseline.initial_carriers [H:912–924,2123–2154].
Do not assume scalar/vector trig or actual-parent seed arithmetic is bit-identical.
Prove applicability using retained exact identities and public meanings; any
mismatch is diagnosed before a resource/scientific combined claim, without adding
a tolerance or tuning seeds to obtain favorable agreement. Scalar resource hashes
alone supply no missing image/parameter error analysis. If the retained diagnostic
proof cannot qualify the selected standalone operation, the future author must
resolve that method applicability under affected review before release, or leave
this proposal blocked. Twelve is not a cure for an unqualified fixture or method.

## 4. Resource ownership and intervals

**Diagnostics:** every fresh W comparison constructs and retains analytic64,
raw32, specimen, wider baseline and relevant candidate/packed/promoted/record/
replay arrays. WIDER lacks the additional candidate lifetime. Candidate calls
follow a warmed baseline. Full NPY export and observers contribute additional
whole-run high-water [H:1348–1506,1798–1826,3138–3261; M:521–573]. These are valid
per-comparison lifecycle observations. Their cross-mode RSS/time differences are
systematically unmatched and cannot establish actual storage savings or speed.
Retain pre-call cumulative self high-water, before/after-export native RSS, raw
bytes, whole-run/export and named operation/conversion times, caller/result and
reachable backing payload (shared ndarray backing counted once). Unknown external
backing extent, allocator/Python metadata and workspace remain unknown.

**Selected standalone pair:** one row/arm per fresh child. Setup generates only
the required float32 raw caller using bounded x-row temporaries; public acquisition
preparation occurs once, then releases raw. PREPARED_WIDER retains complex128
quadratures and unchanged wider metadata. PREPARED_HALF allocates explicit
little-endian binary16 real/imaginary components `(...,2)`, retains packed caller
and metadata, releases source quadratures, then allocates complex128 working bands
for the same downstream estimator and per-time known reconstruction. Both retain
one result including parameters/known records and concatenated image through exit;
neither loads qualification/reference arrays or runs a reference workflow
[H:2067–2157,2164–2385; M:602–652]. Transfer caller/declaration, phase/noise,
overlap snapshots, workspace, outputs and observation buffers remain accounted.
The metadata holder with quadratures=None is never a public numerical operand.
Unpacking restores a valid band record before public validation.

Source-to-packed coexistence during setup and packed-plus-unpacked work during
operation can erase a payload saving in process peak. Releasing setup inputs does
not reset prior high-water. Paired storage is 4 bytes/complex versus 16 for current
complex128, not a complex32 ndarray/FFT operand; wider input is 4-byte raw32 versus
2-byte half and 8-byte promoted-half where those unselected resource arms are
concerned. These ratios are payload arithmetic, not RSS predictions.

| Interval/observation | Exact interpretation required |
| --- | --- |
| Cold/import | Persist monotonic start immediately before numerical imports and end after import/environment setup; exclude preceding interpreter/bootstrap startup and describe that exclusion |
| Caller/setup | Persist start before generator/settings/transfer/public preparation and end after caller construction/packing/identity checks, before pre_call; retain packing as part of this interval |
| Setup packing | Retain pack start/end inside PREPARED_HALF setup, separate from subsequent unpack; include it in full setup-to-call end-to-end time |
| pre_call | Cumulative self ru_maxrss after setup/caller identity, before conversion-inclusive/call clocks |
| Conversion+call | Existing conversion_start_ns to call_end_ns; includes half unpack+public downstream call; **excludes setup packing**, so cannot be named complete pack/unpack end-to-end time |
| Call-only | Existing call_start_ns to call_end_ns, excluding setup, unpack, caller hashing, observers and serialization |
| Setup-to-call end-to-end | Actual monotonic setup-start to call-end, including generation, transfer/preparation, packing, identity/setup work, unpack and call; disclose those contents, never subtract setup from the resource result |
| call_end / post_observation | Cumulative self RSS immediately after call, then after bounded output/material observers but before JSON/teardown; timestamps and raw Linux KiB ×1024 bytes |
| Whole-child / parent elapsed | Child's existing whole_child_until_json includes imports/setup/call/observations but excludes final JSON/teardown; parent spawn-to-terminal-observed includes bootstrap/exec, exit and delayed wait observation, not exact death time |
| Terminal native RSS | Sole cached exact-PID wait4 terminal usage through JSON/teardown; direct child only, excludes observer, not concurrent tree aggregate or numerical-only allocation; bootstrap/pre-exec peak retention across exec remains unresolved |

**Concrete remaining timing requirement:** existing H:2262–2281,2360–2375 records
call/unpack boundaries and a whole-until-JSON duration, but no separately retained
cold/import/setup or setup-pack clock endpoints. Diagnostics likewise time calls,
not separately all setup phases. The future named source author must record these
few scalar endpoints locally in the existing functions/record, using existing
monotonic_ns/timed machinery, and obtain affected review. No new timer/profiler/
helper framework is needed or commissioned here. Never derive “pure setup” by
subtracting calls from a whole duration that also contains observers. Missing
intervals stay unknown and cannot satisfy the contract's separation by renaming.

Record every repetition and raw median/range separately per row/arm/interval.
Retain fixed pre-result one-at-a-time order: W02 rep1 WIDER-then-HALF,
rep2 HALF-then-WIDER, rep3 WIDER-then-HALF; then the same order for W05.
Here WIDER/HALF mean PREPARED_WIDER/PREPARED_HALF only. This predetermined order
adds no workload or automatic runner, and makes remaining host/order noise
visible. Three observations support descriptive medians/ranges, not a significance
threshold, universal causal proof or extrapolation. No baseline/RSS subtraction
produces an isolated call peak; no zero RSS increment proves zero allocation.

## 5. Safety, identity and one-at-a-time invocation SHAPE

Current read-only Git observation: HEAD d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67,
tree b38e1e2f744b21814881a6dec9663b4723124ccc, first parent
64edcadb2b042c334b9ff73ea0b2b0aee1f04367; tracked status emitted no entries.
This is provisional115 ancestry, not accepted actual113 or future integration.
No current-parent or native applicability is inferred from clean Git or hashes.

Before future runs ROOT must supply accepted113 commit/tree/readiness and actual
114 parent/base/candidate/tree/clean tracked diff; reconcile default double versus
accepted opt-in single boundaries without adding a single-profile matrix; freeze
source/manifest, all named scientific and import-bearing support files/lock,
interpreter/prefix/resolved executable, startup/.pth/autostart/preload/allocator/
array-API environment and native route evidence. Renew required loaded FFT module
paths/hashes after actual calls and explicitly resolve the current two-module
requirement on non-FFT kernel routes; do not import an unused backend to manufacture
provenance. Historical BASE/HISTORICAL_EXPECTED and control2 remain scoped history
[H:41–77,1933–1983; M:64–142; T:98–170].

For each attempt use the existing conservative resource_plan/standalone_plan
simultaneous-buffer ledger: retained original/caller, conversions/setup sources,
phase/camera/transform/filter work, metadata, overlaps, inverse/phase/signed result,
transfer, observers. Compare it with current exposed physical/cgroup headroom,
ancestor correspondence, memory/swap current/max/events, pressure and CPU/load;
include parent/OS/background/caller reserves and disk/output admission. The leaf
fit check is necessary and insufficient. Unobservable external ancestors remain
unknown_unobservable, not unlimited. Unknown native/Python/backend workspace is
not zero. Stop before unsafe allocation and return to ROOT; no OOM, larger case,
fixed reserve percentage, numerical ceiling, source-limit expansion or 16 GiB
promise. 16 GiB = 17,179,869,184 bytes is a separate workstation objective;
K02 metadata and these crops cannot measure it [C:194–205; H:1798–1899].

All binding literals below are UNBOUND. This is text, **not command READY or
executable shell**, and not a grant. ROOT's actual pinned Ubuntu24.04.5 container,
provisioned per-worktree .venv and identical effective threads precede any launch.
Existing prefix: docker exec --user 1000:1000, workdir UNBOUND_ROOT, named
simrecon-campaign-ubuntu, pinned PATH, and all six THREAD_KEYS=1 before interpreter
startup, scipy workers=1 during calls. Root captures parent stdout/stderr before
its interpreter startup. No overlapping exclusive campaign window.

```text
PARENT_ARGV_SHAPE = [
  "UNBOUND_INTERPRETER", "UNBOUND_TRACKED_STUDY_SOURCE",
  "--route", "resource", "--grant", "UNBOUND_ORIGINAL_ONE_ATTEMPT_GRANT",
  "--binding-receipt", "UNBOUND_EXTERNAL_BINDING_RECEIPT",
  "--binding-sha256", "$ROOT_BINDING_SHA256",
  "--row", "UNBOUND_SELECTED_W02_OR_W05",
  "--strategy", "UNBOUND_SELECTED_PREPARED_WIDER_OR_PREPARED_HALF",
  "--repetition", "UNBOUND_SELECTED_1_2_OR_3", "--run-id", "UNBOUND_UNIQUE_ATTEMPT"
]
TARGET_ARGV_SHAPE = [
  "UNBOUND_INTERPRETER", "UNBOUND_TRACKED_STUDY_SOURCE",
  "--route", "resource-child", "--grant", "UNBOUND_OUTPUT/grant.original.json",
  "--binding-receipt", "UNBOUND_EXTERNAL_BINDING_RECEIPT",
  "--binding-sha256", "$ROOT_BINDING_SHA256",
  "--row", "UNBOUND_SAME_ROW", "--strategy", "UNBOUND_SAME_STRATEGY",
  "--repetition", "UNBOUND_SAME_REPETITION", "--run-id", "UNBOUND_SAME_ATTEMPT"
]
DIAGNOSTIC_SHAPE = same explicit interpreter/source/binding operands,
  --route diagnostic --grant UNBOUND_GRANT --row UNBOUND_ROW
  --strategy UNBOUND_EXISTING_MODE --repetition UNBOUND_REP --run-id UNBOUND_UNIQUE_ID
  [--qualification UNBOUND_ACCEPTED_ROW_RUN_JSON for W non-QUALIFY only]
```

These symbolic objects are neither valid receipt values nor actual argv. Before
use, freeze an exact shape with every literal other than the single binding digest
slot resolved. The digest slot occurs exactly once as the --binding-sha256 operand;
no general environment expansion. ROOT alone fills B/C/G/L in acyclic order:
freeze candidate/artifacts/materials/recipes, external binding B then Bsha, fresh
immutable physical context C, one-attempt grant G binding B/C, literal argv, final
fresh recheck and independent launch receipt L. L binds original G's hash; G never
hashes itself. Original and resource grant copy are distinct paths with identical
bytes, checked before/after. No receipt hashes its determining bytes; no later L
hash feeds B/C/G. No actual receipt/grant is written here [M:64–142; H:202–529].

Native qualification remains separate: accepted source loader is not proven runtime.
Fresh affected method review must assess actual bindings/argv, direct plain-spawn
bootstrap/setsid/exec/readiness/FD capture and failures, sole exact-PID cached wait4,
status/native usage, timeout/TERM/KILL/reap/SIGINT, identity drift and persistence/
ownership-loss recovery. Existing seven fixed controls do not automatically cover
all changed semantics; freeze only diagnosed affected controls before execution.
No sampler, guardian, Popen waiter, automatic retry or alternative launcher is
introduced. Polling gap is observer delay, not sampled RSS. Missing terminal usage
is null, not zero. After observer/marker/ownership loss ROOT must establish actual
boot/PID/start identity and owned-work termination before another attempt; no stale
PID signaling, inferred exit, deliberate orphan experiment or fabricated recovered
wait4 peak [M:733–873; H:2492–2903].

## 6. Final matrix and exact claims

Use separate columns for numerical/decision qualification, public/isolated scope,
diagnostic lifecycle, matched-resource evidence and remaining applicability. Before
results every empirical cell below is PENDING/HOLD, not demonstrated.

| Strategy/site/backend | Retained study scope | Matched-resource disposition under this amendment |
| --- | --- | --- |
| H1 half input | All six W numerical modes; required public half boundary facts, quantization versus unquantized input | UNMEASURED on all rows; diagnostic timings/RSS do not establish H1 benefit |
| H1_PROMOTED | All six W numerical same-half-values wider-caller control, distinguish dtype route from quantization | UNMEASURED; no standalone H1/dtype resource conclusion |
| H2 corrected | All six W one-site formula replay plus public downstream, limited frozen no-edge/no-drift meaning | UNMEASURED; no matched or full-workflow saving claim |
| H2 prepared | All six W numerical pack/unpack/public downstream; full qualification prerequisites | W02/W05 selected pair only, pending all twelve qualified observations; W01/W03/W04/W06 UNMEASURED |
| H2 filtered / embedded | Both separate numerical modes on all six W, parameters/filtering fixed wider and isolated assembly replay | UNMEASURED; no full pipeline/stage resource benefit inferred |
| H3 CPU | Bounded K01 exact-version input/output dtype/unsupported-norm/complex32 evidence | Arithmetic/workspace internals unknown absent proof; no half-compute or speed/memory benefit |
| H3 optional cuFFT Xt | Documentary candidate only: future exact vendor version/date/architecture/layout/stride/precision/workspace/driver/toolkit/license/portability assessment | GPU execution/time/device memory UNMEASURED; no installation, accelerator adoption or performance claim |
| K01–K04 | Every finite range/normalization/product/fit/tie/phase/failure subcase retained | Lifecycle facts retained; timing unresolved when not meaningful; no scaling/full-volume benefit |

After qualified observations, permitted statements are the actual named-case
numerical errors/decisions/failures and explicit scope; measured per-comparison
**diagnostic** lifecycle facts; and empirical PREPARED pair differences/medians/
ranges at W02/W05 under the complete stated lifecycle. A lower matched terminal
peak could support a claim only about that exact prepared-storage protocol and
retention, not a production precision mode or isolated allocator mechanism.
A call-only difference must be accompanied by conversion/setup-inclusive costs.
If setup dominates, say so; do not report a hypothetical post-reset peak as measured.

Withhold full-workflow/H1 resource benefit, prepared benefit on other W rows,
corrected/filtered/embedded saving, general 2D/search/reuse/nonuniform-phase
resource applicability, support beyond the finite matrix, native complex32/half
CPU arithmetic, whole-tree/observer-inclusive RAM, physical-recovery certification,
16 GiB feasibility, a fixed latency ratio or product precision activation.
Do not infer no benefit from noise, unchanged peaks, nonzero RSS, missing measurements
or no selected tolerance. H3 unavailability leaves H1/H2 open. A numerical failure
may justify unsuitability for its named case only after fixture/oracle qualification;
it does not establish global failure of half storage. A no-activation recommendation
can cite unresolved acceptance meaning and missing data without claiming an
evidence-backed global negative. One bounded future implementation slice, if
warranted, must identify prepared-storage site/API, wider operations, measured scope,
acceptance **proposal**, exclusions and uncertainties; otherwise recommend no
activation and name the missing evidence. Do not switch the resource question to
a favorable site after results or force a positive recommendation.

## 7. Why this proposal can be adequate, and where it cannot

The issue requests a small representative study and supported/not-supported matrix,
not a Cartesian resource sweep [I, C:88–120]. All original numerical decisions and
per-comparison lifecycle observations survive. W02/W05 exercise the same declared
known-carrier equations on the required spatial step; the selected paired storage
question has a matched wider arm, actual conversion/caller/result retention and
three fresh repeats at each size. The other cases challenge numerical usefulness
without claiming their unmeasured causal resource behavior. Thus twelve is
scientifically defensible **for this bounded question with the explicit amendment**.

It is inadequate for the current all-five/six-row standalone design without that
disposition, for a generally supported prepared-storage mode, for H1 resource
recommendations, or for overall scientific completion before the independent
witness/compatibility/method evidence is supplied. Nor does documentary H3
unavailability or a noisy W02/W05 comparison allow dropping any numerical row.
If independent review interprets S2/S7 as requiring a matched result for every
completed row/mode rather than lifecycle facts plus bounded resource claims,
that is an unresolved completion meaning for actual intake, not a reviewer waiver.
All unamended obligations remain blocking. This author does not selfapprove.

## 8. Required future disposition and activation sequence

1. A fresh independent scientific/method report reviewer first assesses primary
   sources and then this frozen proposal. Its exact verdict must explicitly cover
   S7's other completed rows, §5 each-comparison timing/RSS/repetitions, manifest
   all-five language, all matrix dispositions, twelve's bounded claim and the
   cold/setup/pack and numerical-applicability prerequisites. Findings return to
   an authorized author; reviewer neither repairs nor activates.
2. ROOT routes the narrowing through **actual affected intake of the existing
   report-only study**, with named author ownership. No new product A/B/C checkpoint
   or human approval ceremony is manufactured. This report alone does not amend
   tracked bytes. The future author must reconcile contract/task/manifest/report/
   recommendation consistently, preserving every numerical row/variant/repetition
   and existing gates; the actual amendment receives fresh independent scientific/
   method acceptance before ROOT adopts it. If contractual meaning changes beyond
   authorized finite-study design, resolve it at intake; do not presume authority.
3. The exact proposed amendment bytes are in §8A below, including the contract
   clarification, manifest selection and S7 row. They are not applied. The reviewer
   must assess them together with the original issue's declared small representative
   matrix and the manuscript's resource90 proposal. This is a proposed in-scope
   finite-study design decision under existing issue114 authority, requiring an
   actual intake record and fresh independent scientific/method disposition, not
   a new human approval. New meaning or an outside-request objective still returns
   to intake. Preserve §5's each-comparison obligations rather than deleting them.
4. Actual113 and final material reconciliation then proceed under ROOT authority.
   A future named nonblind source author completes the local scalar timing records
   and any diagnosed existing-method applicability correction, without new matrix,
   helper, tolerance, product mode or dependency. Freeze exact source/manifest/
   candidate; fresh affected review checks changed method and retained evidence.
   Keep all unconditional holds until separate explicit release conditions are met.
5. ROOT supplies B/C/G/L and current per-attempt safety/resource admission, qualifies
   actual native/method controls, then qualifies each W scientific witness and full
   compatibility before affected comparisons. Only ROOT schedules each admitted
   attempt, one at a time in the pinned Ubuntu environment. Numeric or ownership
   failure returns to the diagnosed author/review route; no automatic rerun.
6. Fresh independent final scientific review assesses the completed exact finite
   report/evidence and acceptance proposal. ROOT freezes the final integrated clean
   candidate, performs exact canonical Ubuntu make verify with all thirteen phases,
   current native coverage integrity/both wheels/import/audit/same-run M25, then
   obtains fresh post-gate D readiness. Historical control2 or another issue's gate
   replaces none of these. Root alone owns restack/publication; no merge/release or
   manual issue closure is authorized here.

The precise present handoff is **PROPOSED REDUCED12 / ACTUAL INTAKE AND INDEPENDENT
DISPOSITION REQUIRED / HOLD**. It is neither an accepted resource plan nor a claim
that twelve observations complete issue114. No command is READY.

### 8A. Exact proposed normative text — NOT APPLIED

The following text is a concrete review target only. It commissions no tracked
edit and no run. The author/reviewer must preserve the rest of the named documents.

**Contract §5:** insert the following paragraph immediately after the existing
paragraph ending “asynchronous dispatch is not elapsed compute time.” Keep that
entire preceding paragraph, including each-comparison/fresh-process/repetition/
cold-setup/conversion/RSS/payload requirements, unchanged:

> Resource evidence has two distinct scopes. Every completed numerical comparison
> retains the required fresh-process diagnostic lifecycle observations, including
> cold/setup and call-only monotonic seconds, conversion-inclusive end-to-end time,
> native whole-process peak RSS, pre-call high-water and retained reachable array
> payload. Successful W01–W06 comparisons retain three fresh successful repetitions.
> Diagnostic runs retain a wider reference beside the candidate, so their cross-mode
> timings and peaks cannot establish optimized storage or speed benefit. The selected
> additional standalone matched experiment is PREPARED_WIDER versus PREPARED_HALF
> on W02 and W05 only, with three fresh successful repetitions per arm and row.
> It includes setup packing, required unpacking, wider downstream computation and
> the same caller/result retention through exit. Report its whole-child native peak
> and separately scoped cold/setup, pack, conversion/call and setup-to-call elapsed
> intervals; do not subtract high-waters or omit setup conversions. No standalone
> resource benefit is claimed for H1, H1_PROMOTED, other H2 sites or W01/W03/W04/W06.
> Their matched-resource cells remain explicitly UNMEASURED, while all original
> numerical comparisons and diagnostic resource observations remain required.
> These unselected standalone UNMEASURED dispositions are permitted finite-study
> completion outcomes; they are not evidence of no benefit and waive no numerical,
> compatibility, safety, qualification, independent-review or final-gate obligation.
> A scientific recommendation is limited to the evidence actually qualified; no
> product precision mode or broader resource feasibility is activated by the study.

**Manifest standalone section:** retain the existing five-row “Resource strategy”
table, which defines the five available experimental meanings. Replace exactly
the paragraph beginning “These are representations/sites within original W01–W06”
and ending “inferred from caller packing.” [M0:402–407; M:610–615] with:

> These five variants define available representations/sites within original
> W01–W06, not five commissioned arms on every row or a Cartesian extension.
> The selected additional standalone observations are W02 and W05, each with
> PREPARED_WIDER and PREPARED_HALF, each at repetitions 1, 2 and 3: twelve planned
> successful observations. Each invocation is a separately admitted fresh child;
> no batch, automatic retry or outcome-dependent selection is authorized. Keep all
> W01–W06 numerical modes and their three fresh successful repetitions, all ten W/K
> rows and every per-comparison diagnostic lifecycle observation. WIDER, H1 and
> H1_PROMOTED remain numerical modes, but their standalone resource cells are
> UNMEASURED. PREPARED resource benefit on W01/W03/W04/W06 and corrected-frame,
> filtered and embedded replay resource benefit also remain UNMEASURED. Corrected,
> filtered and embedded modes retain their diagnostic/isolated scope. PREPARED_*
> remains rejected on the diagnostic route. Only the W02/W05 prepared-stage pair
> can support a matched resource comparison, after independent qualification of
> numerical applicability, conversions, clocks, caller/result lifetime and native
> usage. Setup packing and public preparation remain in cumulative/terminal peak
> and setup-to-call elapsed time; conversion-and-call excludes setup packing and
> is labeled accordingly. No full-workflow saving, native-half arithmetic or
> extrapolation to other rows or volumes follows. Every failed/refused/skipped or
> partial attempt remains indexed with its reason and original bytes. Missing
> required evidence leaves the affected conclusion unresolved.

**Task scenario table:** replace the single S7 row [T:88] with exactly:

```text
| S7 | Resource feasibility with conversion/workspace/headroom | Contract §5 | W01–W06 diagnostic lifecycle; W02/W05 matched PREPARED_WIDER/PREPARED_HALF pair | Fresh-process raw observations and three fresh repetitions for successful W comparisons; matched benefit restricted to the selected prepared-stage pair; other standalone benefit UNMEASURED; unsupported envelope explicit |
```

The future author must also replace any report/recommendation wording claiming
that all five standalone arms × six rows are selected with the exact selection
above, leaving historical resource90 proposals labeled historical. No Current
edit is authorized in this preparation. Independent acceptance must explicitly
state whether this exact text is an acceptable issue114 design disposition; an
acceptance of source mechanics alone does not adopt it. Author correction and
fresh affected review handle any finding without quietly broadening the text.

## 9. Opened primary sources and literal identities

Line references above are to the following absolute paths. Source reads only;
none was imported or executed. The prior transition is historical preparation,
not current authority. Historical claims in M0/M remain historical where later
witness amendments explicitly supersede them.

- I: `/workspace/work/campaign/issue-114.md`, SHA256
  `2ddab99a15e26ff0f419be0827f6eb799b7fca37bb0f3c16a66ed914ddc61cf2`.
- C: `/workspace/work/issue-114/docs/contracts/half-precision-feasibility-v1.md`,
  `bb5963ce268e81dabf8773f8bce5f1b37e8153e2d18886ddef1e5766bd384284`.
- T (sole Current): `/workspace/work/issue-114/docs/tasks/half-precision-study.md`,
  `0c12b4d174e7e811728cd62d44db3acf86d266f59172da3dbe4f45f45d91f329`.
- M0: `/workspace/work/issue-114/docs/reports/half-precision-study/manifest.md`,
  `6ae262ce4d228feff8d4dc2e2831dce010bbadd3a156d018402b7cbf272d604d`.
- H: `/workspace/work/campaign/evidence/114/witness-source-correction-1/study.py`,
  `bf82fb7ba4f23b6f5026e5391e3ae893737f3b2831c9846f5acd8012778eb7c2`.
- M: sibling witness `manifest.md`,
  `c6d3b1b101f3fc2eb4a45bb2b44208a71ad0f69fb9f5f90a1212232159406c4d`.
- Q: sibling witness `qualification-obligations.md`,
  `1759b3d976a04150e96d706b90d7020d585880abaaff0474591983f5d8aa5566`.
- Prior preparation: `/workspace/work/campaign/evidence/114/final-transition-source-preparation-1/transition.md`,
  `278c77e3b44201b12d92cdf8d201c38766710a52d73b154159b8be4580b1de0a`.
- Packet: `/workspace/work/campaign/evidence/114/resource-design-preparation-1/author-packet.md`,
  verified `9e4c287bf6b43a16ee52f840124571554d5404cce087560680aada593031142f`.

Operational instructions read: W114 AGENTS.md; docs/PROJECT.md; intake,
implement-work and review-work SKILL.md; docs/operations/role-launches.md.
Their scientific role separation, independent report review, no nested launches,
exact candidate/full-local gate, preserved charges and report-only ownership apply.
This author created only the four packet-named durable role outputs, no scratch,
fixture, helper, study process, grant, binding, tracked change or deletion.
