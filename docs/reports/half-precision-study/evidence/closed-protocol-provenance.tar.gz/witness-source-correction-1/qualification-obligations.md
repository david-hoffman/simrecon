# HP114 affected scientific qualification obligations — SOURCE proposal only

2026-11-16. This authored finite design is complete for fresh independent SOURCE
review. No quantity below was numerically evaluated here, no fixture is qualified,
and no execution is authorized. The exact final source/manifest identities are
outside those files in outputs.sha256. This procedure covers the existing six W
rows and inherited compatibility obligations only. K01–K04 retain their original
meanings. It introduces no row, tolerance, gain, physical-recovery claim, backend,
parser, automatic comparator or generic scientific framework.

## Public sources and finite anchors

Paths below are relative to /workspace/work/issue-114/docs/contracts/; their
literal byte identities are in inputs.sha256. Relevant primary equations/fields:
CE02 c-equivalence-preprocessing-v1.md:116–206; CE03
c-equivalence-optical-transfer-v1.md:121–151,257–286; CE04
c-equivalence-known-parameters-v1.md:114–130,132–262; CE05
c-equivalence-carrier-modulation-v1.md:92–180,185–455; CE06
c-equivalence-acquisition-modes-v1.md:212–262,307–328,689–710,996–1014,
1093–1140; CE07 c-equivalence-workflow-v1.md:385–436,510–546,584–690;
RM84 reconstruction-memory-v1.md:40–180; HP114
half-precision-feasibility-v1.md:88–150. These are the expectation sources,
not production helpers or earlier numerical observations.

All rows have L=2, A=1, dxy=1/10 um. Alpha=1/(X*Y*Z*4*D):

| Row | (T,D,P,Z,Y,X); O | Denominator; exact alpha | Full image shape; coordinates |
| --- | --- | --- | --- |
| W01 | (1,1,3,1,16,16); 2 | 16*16*1*4*1=1024; 1/1024 | (1,1,32,32); x,y=(index-16)/20 um; z=0 |
| W02 | (1,3,5,4,16,16); 3 | 16*16*4*4*3=12288; 1/12288 | (1,4,32,32); x,y=(index-16)/20 um; z=(h-2)/5 um |
| W03 | W02 | 12288; 1/12288 | W02 |
| W04 | (2,3,5,4,16,16); 3 | 12288; 1/12288, independent of T | (2,4,32,32); W02 coordinates |
| W05 | (1,3,5,4,32,32); 3 | 32*32*4*4*3=49152; 1/49152 | (1,4,64,64); x,y=(index-32)/20 um; z=(h-2)/5 um |
| W06 | W02 | 12288; 1/12288 | W02 |

Neither P nor T divides alpha. Side-order factor 2 and inverse normalization are
separate operations. The independent coordinate labels do not shift inverse
array indices. For example W01/W02 x[0]=-4/5 um, x[16]=0, x[31]=3/4 um;
W05 x[0]=-8/5 um, x[32]=0, x[63]=31/20 um; all 3D z labels are
(-2/5,-1/5,0,1/5) um. These are exact real anchors, not assertions that every
rational is exactly representable in binary64. Source expected_alpha is the
binary64 division of 1 by the independently fixed integer. Its equality Boolean
is a scalar diagnostic, not a complete reference-accuracy or admission test.
Coordinate error_metrics likewise does not prove signed-zero compatibility.

Source oracle_checks now retains those alpha/coordinate anchors, compares scale
and workflow/stage coordinates, uses independent alpha in its selected forward
sums, and uses independent x/y in assembly corroboration. It preserves the
shared-scale corrected_replay as its separately labeled H2 recipe. Existing
selected forward sums still use public separators and cover only t0 slots0/1/2;
the phase inverse is separately challenged. Existing inverse sums still use
replay-embedded coefficients at two points. They are selected diagnostics, not
the complete full-grid anchor below. All existing fixture finite/negative/branch
guards remain necessary and unchanged; none certifies the complete mapping.

## SR1 native transfer prerequisite and affected shared callers

make_transfer now receives the already resolved acquisition_mode from BOTH
run_workflow and resource_child. For W01 explicit 2d chooses radial (2,64,1);
for all other W rows explicit 3d retains (3,64,64). Values remain
H_m=1-m/8+i*m/32, complex64-exact, dkr=dkz=1/4 cycles/um. No inferred mode,
resampling, normalization or metadata rebinding is introduced. The explicit
setting and SHAPES W01 Z1 are fixed existing recipe declarations. At K1 all
visited z are0 and both axial interpolation vertices address the sole plane.
The duplicate vertices and all lateral stencil checks still apply. Mathematical
constancy is not a waiver of finite interpolation arithmetic or actual stencil
qualification. 3D callers retain their original axial table bytes/meaning.

This repairs the diagnosed fixture SOURCE domain defect. It establishes no
actual rejection stage/exception, successful baseline or precision conclusion.
The resource child's only edit is the transfer-call operand; no launch, native
wait, lifetime, bootstrap, sampling, record or timing logic is changed.

## SR2 full-grid conditional assembly anchor, independent of replay buffers

This is an explicit finite reference proposal from CE04/CE06 equations, for
EVERY output index of EVERY time, direction and retained order in the table.
It has no FFT and does not read assemble_replay's padded buffer or returned
coordinate vectors. It is currently mathematical source design, not an added
executed/full-grid observer. A future materialization/evaluation requires its own
ROOT release and affected independent review; it must not be silently supplied
by changing this held source or by treating the present selected sums as full.

First fix the boundary: let F[t,d,q,kz,ky,kx] be the actual public retained
filtered_quadratures for that time, and K[t,d] the actual retained fitted/known/
reused carrier. Those finite values are CONDITIONING INPUTS, not independently
proved truths. The conditional expectation tests assembly from this boundary.
Their independent upstream checks are separate below. Do not replace K by nominal
generator carriers, or assert output=S or known analytic illumination amplitudes
are the fitted factors. Known-carrier workflows still fit modulation.

For each native full index (a,b,c), 0<=a<Z,0<=b<Y,0<=c<X, define the signed
lift ell_N(n)=n if n<=floor(N/2), else n-N. Thus even Nyquist is positive.
Set (kz,ky,kx)=(ell_Z(a),ell_Y(b),ell_X(c)). If kx>=0, read each quadrature at
(a,b,kx). If kx<0, read at ((-kz) mod Z,(-ky) mod Y,-kx) and conjugate EACH
read quadrature separately. Let C_0 be that order0 read. For m>0 let
C_m=E_m+i*O_m AFTER those possible conjugations. In particular replacing this
by conj(E_m+i*O_m) is wrong; that expression reverses the odd sign. Keep raw
native Nyquist slot meanings inherited from preparation. No endpoint splitting.

For output (h,i,j) with 0<=h<Z,0<=i<2Y,0<=j<2X define the finite polynomial

U[t,d,m,h,i,j] = sum_(a=0..Z-1,b=0..Y-1,c=0..X-1)
  C_m[t,d,a,b,c] * exp(+2*pi*i_complex*(
    ell_Z(a)*h/Z + ell_Y(b)*i/(2Y) + ell_X(c)*j/(2X))).

The symbol i_complex is sqrt(-1), distinct from the y index i. This is directly
the native coefficient sum, with zero omitted output frequencies implicit.
There is NO divisor Z*(2Y)*(2X). W01 is the Z1 2D sum with h=a=0 and no axial
transform; A remains1. The exact unshifted inverse origin is h=i=j=0, where U
is simply the sum of native coefficients. Signed lifts can appear directly in
the exponential because adding output extents changes it by integer cycles.

Independently set x_j=(j-X)/20 um, y_i=(i-Y)/20 um, and
phi_m=2*pi*m*(Kx[t,d]*x_j+Ky[t,d]*y_i). The expected signed image is formed
from zero in direction d ascending, order m ascending:

Istar[t,h,i,j] = sum_d (Re(U_0) +
  sum_(m=1..O-1) 2*Re(U_m*exp(+i_complex*phi_m))).

No axial carrier ramp, positivity clipping, phase/direction division, fitted
gain, registration or physical-mass normalization is allowed. Keep order for
finite accumulation: each d's order0 first, then positive side orders. Its
exact-real formula covers the entire grid; an actual floating evaluation must
retain per-point term magnitudes and reference evaluation uncertainty rather
than asserting it exactly reproduces FFT roundoff. Nonfinite/undefined operands
or arithmetic are unresolved/failure evidence, never omitted voxels.

Future record assessment must identify exact F/K/row/transfer/raw/environment
inputs, establish all prescribed index extents and quadrature associations, and
retain expected-versus-public values across the COMPLETE grid (not selected
voxels, min<0, aggregate RMS only or fitted scale). It must also compare public
stage image stacking to workflow image in t order and independently verify x/y/z
labels. An unevaluated point leaves full-grid evaluation incomplete. A finite
residual without an independently justified reference/floating error analysis
leaves numerical interpretation unresolved. No blanket FFT/native tolerance is
proposed; no source-only equality theorem about finite libraries follows.

## Separate upstream premises: what conditional assembly cannot establish

Use the frozen independent specimen/illumination equations in manifest.md,
not production generators/helpers or returned preparation/filter records as the
sole expected values. Bind the actual admitted float32 raw values separately
from analytic binary64 R. The float32 cast discrepancy is its own recorded
quantity. The following quantities define where a future source-independent
expectation comes from; all their actual evaluation/finite checks remain open.

1. Raw/camera/phase/preparation: independently reconstruct the declared finite R
   from S, illumination and B, establish float32 rounding and no sentinel/map/
   edge/equalization effects for these rows, then Jstar=alpha_star*(raw32-B)
   using the alpha table. Actual finite raw values, rather than ideal S alone,
   anchor subsequent numerical checks. For uniform rows derive L0p=1,
   L(2m-1,p)=cos(m*2*pi*p/P), L(2m,p)=sin(m*2*pi*p/P), and scalar noise exactly1.
   Ideal q0=P*alpha*S and E_m+i*O_m=(P/2)*alpha*a_m*S*
   exp(-i*(m*carrier_angle+psi_m)) explain sine sign/no phase divisor BEFORE
   spatial transforms on ideal data; they do not erase cast error or Nyquist.
   For W06 derive the supplied scaled design A[p,:]=[1,2cos(phi),2sin(phi),
   2cos(2phi),2sin(2phi)]/5 and L=A^-1 independently. Keep the actual declared
   finite angles, independent scalar-trig error and achieved inverse residual
   distinct from ideal real full rank. Scalar noise is inverse-row energy/P,
   paired even+odd rows for each side order, not uniform ones.
   For every t,d,q and stored (a,b,c), form the negative finite Fourier sum
   over physical z,y,x of sum_p Lstar[q,p]*Jstar[t,d,p,z,y,x] when c<X/2.
   At c=X/2 use Jstar phase p=q directly, before the same spatial sum.
   For W01 omit the axial transform; other rows use unnormalized negative axial
   sum. This defines every expected prepared coefficient, including slots3/4
   and later times outside the present selected observer. Assess phase/scale/
   cast/reference errors separately; no global tolerance or product solver is
   borrowed as the only oracle.
2. Transfer/filter: the expected complete table values come from the fixed H_m
   above and the corrected radial extents, not returned sampled H. Enumerate
   actual CE03 bilinear stencil indices including zero/duplicate vertices,
   source one-wrap axial mapping and validity before assigning sample values.
   Use CE04/CE06 public native traversal on independently checked prepared
   coefficients: self radius<=R, other signed-order radius<R, per-order cutoff
   ceil/truncate/clip, time-specific noise, every eligible denominator power,
   w^2 last, numerator conj(H_self)*conj(modulation_m)/v, no taper/suppression
   in these fixtures. Preserve outside-support/axial-zero writes, reflected
   side reads, full temporary and E/O recombination in source order. This is
   the finite specification of expected F; using actual F in U does not
   discharge it. Actual safe stencils/support/cutoffs/weights/F arithmetic and
   their errors remain unproved in all six rows. No broad new filter/reference
   implementation is delivered or commissioned by this design.
3. Estimator: fix initial vectors from CE07 linespacing/(O-1) and angle schedule,
   separately from the independent generator's nominal carriers. Check actual
   CE05/06 overlap builds, thresholds/short circuit, inverse signs, regression
   energies/cross/forward/reverse/combined/correlation and all required domain
   checks against the public equations with independently checked bands/H.
   Search rows need the actual finite row-major peak, periodic neighbors,
   aliases, strict comparisons, literal angle/magnitude walk, stale bracket,
   parabolas and frozen/remade overlap use. 2D products use CE06, 3D does not.
   Floors and phase replacement follow raw fits; intended branch strings alone
   are insufficient. This finite trace-dependent upstream task has not been
   solved by the source anchors or by conditioning on returned K/modulation.

| Row | Independent expected quantities supplied as source above | Additional row-specific unproved premise, beyond common finite preparation/filter/floating premises |
| --- | --- | --- |
| W01 | exact alpha, 2D coordinates/K1 table, entire 2D conditional polynomial | actual known-vector 2D fits/cumulative products; public read-only/strided/half and invalid boundary outcomes; finite signed final image |
| W02 | exact alpha, 3D coordinates/table, entire 3D conditional polynomial | actual known-vector order fits and separate half prepare_bands acceptance |
| W03 | W02 geometry/anchors | actual search/coarse/alias/refinement/floor/replacement trace and parameters, including order2 frozen-overlap factor |
| W04 | both times' entire 3D conditional polynomials; same alpha | actual t0 search; exact t0 carrier reuse; new t1 known-vector overlaps/factors/adjustments; changed illumination alone proves none of these |
| W05 | exact resource-step alpha/coordinates and larger finite polynomial | actual known fits and unchanged physical equations; no resource inference from the larger polynomial |
| W06 | W02 geometry/anchors, distinct phase/noise equations | actual supplied-design factorization/residual/noise and rounding of full raw near B=128; final signed image not implied by ideal signs |

W06 ideal nodes are distinct (smallest gap 2*pi/5-3/64>0), hence its degree-four
Laurent-polynomial rank proof remains valid. With e=2^-10,c=2^-9 its cancelling
pair has cosine coefficient c+(8-c)*(1-cos(e)) and POSITIVE sine coefficient
(8-c)*sin(e); magnitude<5/512. Signed ideal specimen extrema and |R-128|<6
are raw witnesses only. No actual finite phase solve/residual/noise/final signed
image has been observed. Preserve this distinction and the existing guards.

K04 formulas/source are untouched. Its outside-range scalar fit is not a
reachable coarse-global-maximum case: for peak differences u,v>=0 the offset
(u-v)/(2*(u+v)) lies in [-1/2,1/2], or curvature is zero. Regression energy
equality is not execution of the public combined-fit failure. Quantized finite
matrix inversion is not a public half phase solver. These remain limited
formula witnesses, not new branch or precision claims.

## SR5 concrete retained-record exact common-contract assessment

The existing summary_compatibility dictionary remains SELECTED diagnostics.
Zero numeric error/branches_equal cannot establish signed-zero equality or the
remaining common fields. Before a complete compatibility claim for a W row,
a fresh assessor must complete the following finite retained-record procedure
on that row's existing wider QUALIFY full/summary pair in the SAME environment.
This is a manual field/projection assessment design; no parser/comparator is
added. Runtime/array-reading evaluation is not authorized in this source turn.

A. Bind the exact run.json, array_index, each referenced NPY file byte SHA,
source/manifest/material/input/environment identities and actual pair's status.
Missing/partial/nonfinite/drift evidence blocks completion. Follow each encoded
array descriptor through its unique array key to the indexed retained file;
generated keys, filesystem filenames and NPY headers are storage locators, not
expected equality between full and summary. Verify shape and original dtype
against the descriptor. Existing array_identity observes shape, canonical
little-endian dtype and canonical C-order content SHA preserving zero signs.
For an exact comparison use that observer on both corresponding retained
numeric arrays under separately authorized observation, preserving original
dtype and all component bits; compare all three identity fields. Hash equality
is content-identity evidence with SHA256's ordinary collision assumption, not a
mathematical proof without that assumption. No casting, rounded summaries,
allclose, relative error or sign-count equality substitutes for per-element
bits. When contents are available, inspect any identity mismatch before a claim.

B. For scalar leaves compare exact kind and value, with Python binary64/complex
component bits including +0/-0; encode already retains float64_bits_be for zero/
nonfinite floats and separate complex components. Finite nonzero JSON numbers
must roundtrip as the original binary64 values; verify that premise before
reusing them. Preserve None versus missing, bool versus int, strings/bytes,
integer values, lengths and EVERY ordered key/event/sequence entry. Do not turn
ordered pair sequences into dictionaries, sort events, deduplicate builds or
compare only decision_projection. A wrong/missing/extra key is a discrepancy,
not ignored metadata. encode converts tuple/list to JSON lists and dataclasses
to field dictionaries, so raw JSON alone cannot prove original Python container
classes, frozen/read-only status, ownership or absence of hidden arrays. Those
RM84 structural/lifetime obligations require separately authorized live-object
observation or applicable accepted evidence; leave them unresolved if absent.
No fabricated reconstruction from JSON establishes them.

C. Walk this COMPLETE common projection, recording the actual full path, summary
path, projection rule, evidence locator and exact-match/discrepancy/missing
outcome for every named entry and every recursive leaf. No empty unchecked
category can be reported as a match:

| Full record source | Summary field(s); exact assessment rule |
| --- | --- |
| image; x_um; y_um; z_um | same fields; original dtype/shape/canonical bits |
| intensity_unit; intensity_semantics | same exact strings |
| parameters.carriers_cyc_um, modulation, raw_modulation, branches | carriers_cyc_um, modulation, raw_modulation, branches; all actual values/order, not just existing metrics |
| initial_carriers_cyc_um; phase_linkage_carriers_cyc_um; effective_wiener | same fields; independent complete array identities |
| input_identities | same complete lexicographic records; name/shape/dtype/sha256 and order |
| source_declarations; resolved_settings | same ordered fields under RM84 original-array projection, discussed below; every declaration/default/metadata leaf retained |
| bands except quadratures, off_quadratures, trace | preparation; ALL fields in CE06 public table order, arrays replaced by identities with correct logical name |
| parameters except overlaps, trace | estimation; ALL CE05/06 fields/order; scientific arrays become identities here even though values occur top-level |
| reconstructions[t] except image, filtered_quadratures, x_um, y_um, z_um, mode_trace | filtering[t]; ALL remaining KnownReconstruction fields/order, including actual cutoffs/settings/source tuples and identities; effective t order |
| transfer | transfer; ALL OpticalTransfer fields/order, including identity named transfer.samples with actual consumed table dtype/shape/content |
| calibration; layout | calibration; layout; both None in every present W row. Non-None is a discrepancy for these declarations, not an omitted field |
| parameters.overlaps | overlap_builds; one descriptor per build, exact index/time/direction/purpose/orders and carrier float pair; repeated equal-valued builds preserved, all references resolve by position |
| parameters.trace | search_trace; EVERY event kind/time/direction/detail/order, omit ONLY coarse correlation_complex/correlation_power; retained small arrays become nested scalar tuples with exact component bits |
| bands.trace | preparation_trace; same ModeEvent indices/order/details except ONLY RM84 spatial omissions (between-build centers/fourier; drift-correlation cross_spectrum/correlation/absolute_correlation; exposure-correction and between-correction phase_multiplier; off-combination quadratures_after); other arrays become exact scalar tuples |
| reconstructions[t].mode_trace | filtering_trace[t]; wiener-step/sector-boundaries retained with exact tuple conversion; each maximal consecutive precise-query run having the same indices becomes one precise-query-count with its exact positive count; split on changed index or other event |
| trace | trace; exact CE07 event values, stage/time, ordered keys/details and sequence |
| source_revision; reference_sha256; limitations | same fields; every string/hash pair/limit in exact order, preserving CE06 ten-file top-level versus CE05 six-file estimator tuples |
| full-debug retention rather than a common field | diagnostics must be exactly summary; omitted_diagnostics exactly the nine-item RM84 tuple in contract order, not invented full fields |

For compact records, recurse in the referenced PUBLIC TABLE order, NOT an
incidental dataclass/dictionary order. Every ndarray becomes ArrayIdentity
(name,shape,dtype,sha256), including small arrays. The name starts at its SUMMARY
field and appends .field/.key/.index by logical key for named pairs and decimal
index only for ordinary sequences. Scalars/sequences retain inherited types;
already declared stage tuple settings remain tuples, not reconstructed arrays.
Different output identity names are expected only as this explicit path mapping
requires, never because bytes/types/shapes may differ.

Top-level resolved_settings/source_declarations require the original array-valued
caller declarations before CE07 full-record array-to-list conversion. For these
finite rows, bind those arrays via the full input_identities and retained exact
call declarations: W03 carrier.amplitude_floors, W06 acquisition.phases_rad,
and accepted transfer samples as applicable. Use the actual original identity
shape/dtype/content and rename only to its required summary logical path, e.g.
resolved_settings.carrier.amplitude_floors or
resolved_settings.acquisition.phases_rad. Verify every array-valued declaration
is accounted for against the frozen call, rather than guessing from the JSON
list type; do not hash a newly inferred dtype or a rounded list. If original
array identity/provenance cannot establish that projection, mark it MISSING
and withhold complete compatibility. These rows use only built-in non-array
identity metadata and native layout; no empirical/layout domain is added.
The top-level input_identities equality remains separately mandatory.

D. The assessor records field-by-field evidence and unresolved structural/type/
reference premises before issuing any exact common-value/decision verdict.
Full records deliberately retain extra arrays; those explicit RM84 omissions
are not missing common values. Missing required fields, ambiguous type/identity
projection, unsigned-zero normalization, event reordering or unequal scalar/array
bits prevents a COMPLETE common-contract compatibility claim. Retain the
original pair/discrepancy and diagnose rather than overwriting or retrying into
success. Even a completed common projection is compatibility corroboration;
it does not discharge the independent scientific/upstream qualification above,
resource/lifetime claims, actual-parent integration or final SCI acceptance.

## Future scope and present disposition

Smallest affected SOURCE review covers make_transfer and BOTH callers,
oracle_checks' alpha/coordinate uses and unchanged dependent replay equations,
QUALIFY retained-record labeling, this full-grid conditional proposal and exact
retained-record procedure, and preservation of W06/K04 limited labels. Primary
independent assessment must precede exposure to prior opinions. That review is
ROOT-launched after this exact completed author handoff; no self-acceptance.

Later actual qualification, only if separately released, must establish W01 K1
public acceptance at both diagnostic/resource setup boundaries, retain unchanged
3D tables/call meanings, evaluate six rows' independent anchors and finite
conditional full grids with upstream premises separately disposed, and complete
the six full/summary common projections. No broader matrix, extra repetition,
resource child or native launch is authorized here. All ten rows, three fresh
successful-W repetitions, resource90 PROPOSAL, wider operations/precision meanings,
H3 limits, B/C/G/L loader, every unconditional HOLD and actual UNBOUND pin remain.
H3 unavailable or noisy RSS cannot settle H1/H2. Actual-parent/binding/native/
numerical/branch/scientific qualification, final exact gate and final SCI/D remain
pending. This SOURCE design grants no exception to ROOT120's exclusive window.
