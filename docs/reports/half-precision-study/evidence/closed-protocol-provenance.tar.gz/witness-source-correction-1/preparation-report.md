# HP114 scientific witness SOURCE correction 1 — completed author delivery

2026-11-16. This is a COMPLETED authored external SOURCE handoff, ready for ONE
fresh independent affected scientific SOURCE review. It is not independent
acceptance, actual fixture/branch/numeric/native qualification, product C/B/D,
final SCI, integration, a comparison run or execution authority. All eight owned
artifacts are identified by outputs.sha256 plus its separate tool-final hash;
that index excludes itself. ROOT archives the distinct final separately.

Authority: author-packet.md SHA256
e1363c3db356a0d8ab8d41539e99c3e50ea52c71dc7a870d534e67ab1c2898cb;
actual ROOT release ROOT-findings-and-corrective-source-release-1.json SHA256
b706c24d5ee5dfb849a40ac81d71475084775fbf357daaaf9736d34939fd607b.
Both literal files were read and their exact hashes matched. The immutable
source2 study.py/manifest pair remains 4011064e31cf21c837c788b70b91b146213253f2f24cc5c4cc531c6955e48d83 /
03f766262a119759ff2dbc0eb06d8c2502dbc54f0896aaabec12d151e898b22c.
The preliminary assessment/report/distinct-final hashes also matched the packet.

Final authored source study.py SHA256:
`bf82fb7ba4f23b6f5026e5391e3ae893737f3b2831c9846f5acd8012778eb7c2`.
Final authored manifest.md SHA256:
`c6d3b1b101f3fc2eb4a45bb2b44208a71ad0f69fb9f5f90a1212232159406c4d`.
These are external proposal identities only. They do not populate any live pin.

## Diagnosed correction and authored design

SR1 is the definite existing-fixture domain defect: native W01 Z1 requires radial
K1. It is not a product failure/half-precision negative; no exception stage or
runtime result is inferred. make_transfer (current study.py:849) now takes the
explicit already-resolved acquisition_mode, using axial_samples=1 for 2d and64
otherwise. Constant per-order complex values, orders, increments and all other
physical meanings are unchanged. BOTH shared callers were located by text search
and changed: run_workflow:1352 and resource_child:2229. No other builder caller
exists in this source text. The resource call is operand plumbing only, as
expressly authorized; the native/setup/lifetime/clock/record procedure is otherwise
verbatim. W01 now declares (2,64,1), W02–W06 still (3,64,64).

SR2 affects oracle_checks:1079. Independently fixed integer denominators are
1024 (W01), 12288 (W02/W03/W04/W06), 49152 (W05), from X*Y*Z*L^2*A*D;
P/T do not divide. Expected x/y are (index-X or Y)*0.05 um, z=(h-floor(Z/2))*
0.2 um in 3D and0 for W01. Source retains those anchors and scalar input-scale
comparison; workflow/stage coordinate errors remain diagnostics. Selected direct
prepared sums now use independent alpha, not bands.input_scale. Assembly replay
corroboration uses independent x/y rather than returned coordinates. The existing
H2 corrected_replay keeps its original public input_scale dependency and precise
storage/computation meaning. No tolerance, clipping, new admission guard or
favorable equality condition is added; all original guards/retention remain.

qualification-obligations.md is the finite SOURCE design for complete-grid
conditional assembly: every native full index's positive-Nyquist signed lift,
negative-x all-axis reflection, separate E/O conjugation, positive unnormalized
inverse, independently centered positive carrier ramp, and ordered signed
accumulation. It does not reuse replay-embedded arrays/returned coordinates. It
conditions explicitly on public filtered quadratures/carriers; those values
remain independent upstream qualification obligations. The document separately
defines expected raw/cast/camera/phase/preparation quantities from the frozen
analytic equations and exact admitted raw samples, public transfer/filter
quantities, and finite estimator/search/reuse/floor/replacement obligations for
all six W rows. It names each row's remaining premises and the unproved finite/
reference/floating evaluation. No entire-grid observer/backend or broader
scientific implementation was introduced. This is a complete authored proposal,
not a claim that its full grids were evaluated or upstream premises discharged.

SR5 uses the explicitly allowed retained-record alternative. The existing
summary_compatibility dictionary has a selected-diagnostics scope label at1405.
The design specifies a complete full-to-summary field walk with exact canonical
array dtype/shape/content, signed-zero scalar/complex bits, all metadata/source
identity distinctions, original-array setting projections, duplicate overlap
build descriptors and every ordered trace/decision under only RM84's omissions
and precise-query-count runs. It uses the existing observer under later separate
observation authorization, not a new parser/comparator. Missing original identity,
wire-type, structural/lifetime or reference evidence stays unresolved. Complete
common-value/decision compatibility cannot follow from existing metrics alone.

SR3/SR4 formulas and source limited labels are unchanged. W06 ideal distinct-node
rank/noise/sign derivations do not qualify actual factorization/residual/noise or
final filtered signed image. Positive residual-pair sine sign is preserved. K04
outside-range scalar fit is not reachable-coarse-global-maximum proof, and energy
equality does not execute the public combined-fit failure. No new recipe,
conditioning cutoff, error precedence or public branch claim was added.

## Preservation and exact text evidence

The complete source-delta.patch was inspected as text against the EXACT baseline;
it contains only make_transfer, oracle_checks, the diagnostic caller operand,
summary scope string and resource caller operand, plus manifest clarification.
This establishes by textual diff that EVERY loader B/C/G/L helper/schema/
authorization/material/argv function and all unconditional top-level-before-
imports/main/authorize/resource HOLDs are unchanged, as are all actual UNBOUND
pins. Native exact-PID wait4/live-headroom/lifecycle/bootstrap is unchanged apart
from that transfer-call operand. No parser, observer framework, control/RSS method,
policy, dependency, product/test or tracked file change occurred. The source's
existing numeric array/hash/error observer implementations are unchanged.

All W01–W06/K01–K04 rows, precision strategies/sites, successful-W three fresh
repetitions and resource90 PROPOSAL remain. The coordinate/alpha diagnostics add
only small diagnostic anchors; no resource child retains them, no resource ledger
or numeric resource meaning was changed. No H3 result, noisy-RSS conclusion,
scientific negative, storage benefit or native-half claim follows. All older
partial sources/control1/control2/reviews/exposure/charges retain original scope;
none were inspected as fresh scientific evidence or requalified here.

Read-only Git before and after authoring returned HEAD
`d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67`, tree
`b38e1e2f744b21814881a6dec9663b4723124ccc`, empty status --short.
Provisional115/actual113-pending is inherited navigation only; no actual-parent
acceptance, rebinding or qualification is supplied. ROOT120 exclusive gate stays.

## Tools, limitations, exposure and repairs

Only FILE/TEXT/HASH/read-only Git/manual mathematical reasoning were used:
cat, sed, rg/rg --files, wc, cp, diff, sha256sum (including --check), apply_patch,
shell here-documents, and git rev-parse/status. No interpreted source/script
transformation or assessment was used. The code-orchestration tool only dispatched
allowed text/file tools; it never imported, parsed or executed the held source.
No Python/AST/compile/import/probe/test/lint/types/numerical/calculator/native
process scan/spawn/signal/Docker/install/build or refusal-path execution occurred.
No runtime check or scientific arithmetic program ran; no checks were relocated
to another environment. diff status1 meant expected textual differences, never a
failed runtime check. All indexed input hash checks returned OK.

No production implementation, history/archive/lessons, old controls/raw results/
arrays, sibling opinions or unrelated science was read. Permitted nonblind
preliminary opinions/release were deliberately read, so this author claims no
blindness. The only directory inventory was rg --files of the permitted
preliminary-review directory to locate its distinct final; coordinator filenames
were visible but their contents were not opened. Current task state was not read.
Governance references were not followed into implementation/history.

Initial large combined text calls and a headings search were truncated. Required
role/PROJECT, review/primary/final, transfer/preparation/known/carrier/workflow/RM84
equations and affected source sections were subsequently read in bounded direct
ranges. Baseline source scientific ranges79–107,531–1699 and necessary first-HOLD/
shared resource caller/main retention context were read; loader preservation is
established by the complete narrow diff, not a claim of re-reviewing its science
or authorization model. Baseline manifest was read in bounded ranges after the
initial concatenated output. An attempted AGENTS sed75–145 exceeded its55 lines
and returned nothing; wc identified the location mistake and40–55 was read
explicitly. This was a text-location correction, not a target/check failure.
No source repair beyond the diagnosed delta/design or automatic retry occurred.

The eight owned outputs are durable external evidence; no extra scratch, fixture,
NPY/raw data, target process or scan was created by this role. No other role's
process/scratch/reference ownership was inspected, and no global cleanup claim
is made. Optional memory/per-role read-only controls were unavailable; shared
filesystem/prompt restrictions are not engineered isolation. No delegation.

## Required next disposition

One fresh independent affected scientific SOURCE reviewer must form and WRITE
its primary assessment BEFORE reading prior opinions, then examine exact final
source/manifest/proposal identities and all affected shared callers/helpers.
ROOT owns that launch. This delivery is complete; I do not self-approve it or
launch a reviewer. Static acceptance can authorize no actual fixture/science
qualification or execution by itself.

Smallest later affected qualification expectations, all UNEXECUTED: W01 K1 public
acceptance plus unchanged 3D table meanings at both setup callers; all six rows'
alpha/coordinate/complete-grid conditional reference and separate upstream/finite
premise assessment; six complete retained full/summary common projections.
Existing public branch/negative-image requirements remain, with no expansion of
matrix/repetitions/native/resource protocol. Actual113/parent/candidate/material/
binding reconciliation, native/bootstrap/lifecycle/environment and finite
scientific qualification, comparisons, resource evidence, final exact gate and
final SCI/D remain pending under ROOT authorization. H3 unavailable/noisy RSS
cannot dispose H1/H2. No actual run command is READY.
