# HP114 affected scientific SOURCE correction review

2026-11-16. SOURCE ACCEPT for this exact dormant source/procedure proposal. No blocking source/proposal findings. This is not formal SCI/B/D, actual fixture/branch/native/numerical/binding qualification, execution permission, activation or readiness. Actual113 remains pending; all holds and actual UNBOUND pins remain.

The independent primary assessment was completed and written first, without prior opinions/results: primary-assessment-review.md SHA256 bf8fc235442840f95e9d9d2b352b0c80a8a4a14b63a821d02e373d943b6a8595. Its detailed derivations, field audit and exposure/accounting statement are part of this review. No additional opinion or result was consulted afterward.

## Exact accepted source scope

Under /workspace/work/campaign/evidence/114/witness-source-correction-1/:

| File | SHA256 |
| --- | --- |
| reviewer-packet.md | 4aade6078f1bbf1acc925c4e1675bd6a3721c68f65f9357c6bf9a3ad015d5851 |
| study.py | bf82fb7ba4f23b6f5026e5391e3ae893737f3b2831c9846f5acd8012778eb7c2 |
| manifest.md | c6d3b1b101f3fc2eb4a45bb2b44208a71ad0f69fb9f5f90a1212232159406c4d |
| source-delta.patch | 1aaead44ff9b501e80e79c5d18927d6220489de88908c3a46a38ed16c7269387 |
| qualification-obligations.md | 1759b3d976a04150e96d706b90d7020d585880abaaff0474591983f5d8aa5566 |
| inputs.sha256 | 529ccdd8cf1f011af79e205df953c4c6a41eac97b42ee602b4c3c88b47757099 |
| outputs.sha256 | c487b69b224f42fce3a11333fc39c8736887a68aea5b8758c6daf5cacce6a5f7 |

Whole-file source/manifest comparisons against the immutable source2 hashes in the packet agree with the authored scientific delta. Author preparation/accounting bodies and earlier reviews were excluded; this review does not requalify their contents or assert their results.

## Independent reasons for acceptance

- study.py:849-857 and both callers at :1352/:2229 now give fixed native W01 its required radial K1 domain while preserving the existing 3D K64 declarations and dyadic complex transfer values. This follows c-equivalence-acquisition-modes-v1.md:689-710,996-1014. Every shared builder caller is covered. Actual stencil arithmetic and actual success remain qualification work.
- study.py:1083-1097,1162,1194-1228 correctly derives row-specific alpha and coordinates independently of returned scale/labels. From CE02 alpha=1/(XYZ L^2 A D), the denominators are 1024,12288,12288,12288,49152,12288. No P/T divisor appears. L2/A1 centered physical labels follow CE04:122-130 and CE07:623-645; unshifted inverse indices remain distinct.
- qualification-obligations.md:84-137 supplies an explicit every-index conditional assembly expectation from CE04:223-259/CE06:1093-1130. It preserves positive Nyquist, all-axis negative-x reflection and separate quadrature conjugation, unnormalized positive inverse, positive centered carrier phase and direction/order signed accumulation. It depends explicitly on actual retained post-filter F and carrier K. It does not pretend that selected two-point replay sums, returned inputs or an unevaluated polynomial prove the full workflow. The complete-grid retained-value/stacking/coordinate procedure and per-point reference-uncertainty obligation are concrete enough for this source proposal.
- qualification-obligations.md:139-203 separately names raw32/cast/camera/phase/noise, every stored prepared coefficient/Nyquist, transfer stencils/filtering and trace-dependent estimator premises. Source helpers corrected_replay, exact_inverse, assemble_replay, one_time, compose, public_boundaries, run_workflow, resource setup and their applicable callers were assessed in their limited roles. No shared helper agreement is accepted as unconditional upstream proof. Scalar trig, finite-design inverse conversion/residuals, safe actual arithmetic and floating/reference interpretation remain unproved and block broader claims.
- W06's ideal distinct-node rank proof and positive cancelling-pair sine sign are valid; its pair amplitude is <2^-9+8*2^-10=5/512 and its raw excursion is <6 counts. These are not finite solver/noise/final-image results. K04's general/equal-spacing fits, strict ties and limited formula labels remain sound: a selected finite coarse maximum has offset bounded by 1/2, so the scalar outside-range witness is not that coarse branch; scalar energy equality does not execute the combined-fit failure. Source formulas and limiting labels are preserved.
- qualification-obligations.md:219-319 covers the complete RM84 common projection. It includes raw/final parameters, exact bits and signed zero, dtype/shape, units, guesses/schedule, all input identities/declarations/settings/stage fields, logical identity names, None alternatives, build indices/repetitions, ordered events/decisions, allowed event omissions/query-run compression and exact source/limit/omission tuples. It distinguishes original workflow array projection from stage tuple settings. The existing encoder/array observer/export paths supply a concrete retained-record route; filename equality and selected metrics do not substitute. JSON cannot prove original container classes, ownership/read-only/lifetime/no-hidden-array properties, and the proposal explicitly requires further evidence or withholds complete compatibility. Actual six pairs remain unobserved.

Public expectations above are under /workspace/work/issue-114/docs/contracts/. The primary assessment records the exact applicable CE02/03/04/05/06/07, RM84 and HP114 clauses and independent derivations.

## Preservation and remaining boundaries

The exact diff leaves the entire B/C/G/L loader/schema/authorization/material/argv mechanism, UNBOUND actual bindings and unconditional top-level-before-imports/main/authorize/resource gates unchanged. Exact-PID wait4, live-headroom/bootstrap/lifecycle/record methods are unchanged except the necessary resource-child transfer-call operand. Preservation does not constitute renewed native/security/runtime acceptance. All ten rows, original generator/settings, precision meanings, three successful-W repetitions and resource90 PROPOSAL remain. The unchanged K64 resource planning allowance is conservative for corrected W01, rather than a new lower admission allowance. No new recipe, precision, tolerance, resource matrix or sampler appears. H3 unavailability/noisy RSS cannot dispose H1/H2.

Required later actual-parent/113/integration/binding/method/native/scientific qualification, separately released full-grid/reference evaluation, all six exact common projections, exact final gate and final SCI/D remain pending. ROOT120's exclusive gate is unaffected. Accepted old source is not a current runtime receipt. Filling inputs or producing later observations changes the evidence and requires affected review; this verdict grants no execution or exception.

## Method, exposure and charge

FILE/TEXT/HASH/manual math only: cat/sed/rg/wc, sha256sum, old/new diff and named report writes; no source/helper/refusal execution, interpreted script/Python/AST/import/probe/test/native/numerical/build/install/Docker operation. No target launch or process scan, delegation, repair or owned scratch/target process. Excluded report/opinion/control/result/array/taskCurrent/lesson/history/sibling bodies were not read. No prohibited exposure identified. Hash-index filenames/digests are not substantive exposure.

One fresh affected independent SOURCE review charge; preserve all prior attempts/costs without reset. Requested gpt-6.1-sol/high/fork_turns=none; actual serving/calibration/tokens/cache/cost/precise elapsed meters UNKNOWN. Optional memory-disable and per-role read-only controls unavailable; shared filesystem/prompt limits prove no engineered isolation. Only primary-assessment-review.md, source-review.md and review-outputs.sha256 are written. Stop after exact handoff; ROOT owns further routing/release.
