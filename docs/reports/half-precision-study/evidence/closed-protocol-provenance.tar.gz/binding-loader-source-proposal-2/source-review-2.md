# HP114 proposal 2 independent affected SOURCE review

2026-11-16. **SOURCE ACCEPT** for the exact frozen proposal below. No actionable
source finding in the reviewed delta. This verdict accepts a dormant external
binding-loader source proposal. It does not accept a later populated binding,
authorize execution or release any hold, qualify a native method or scientific
result, supply product B/D acceptance, or establish final readiness.

## Identity and input boundary

All SHA256 values below were checked individually with `sha256sum`.

| Reviewed artifact | SHA256 |
| --- | --- |
| reviewer-packet-3.md | `4d35b362e6767f64a6dbfb2637f02afc308f206a430a385c019824b0c549f216` |
| study.py | `4011064e31cf21c837c788b70b91b146213253f2f24cc5c4cc531c6955e48d83` |
| manifest.md | `03f766262a119759ff2dbc0eb06d8c2502dbc54f0896aaabec12d151e898b22c` |
| source-delta.patch | `e6e9db3e8a60d33e4780333b1af18612eab2967211b06891b8ea5182b6fd3557` |
| binding-receipt-template.json | `f56d764fa4f9ef697d8387a0fe91b41e6f6042c499c2ab004398de9c7dd6c225` |
| pending-invocations.md | `63b7fcec0a3a424a731841cfe6b90d9c1510f2dd24e1f65efdfc6f907fab4f66` |
| frozen-inputs.sha256 | `b5578b6486651e2898e7c506bb8c7ea196d42e44d66fe4f456cea2b3cdf60f47` |
| outputs.sha256 | `11c61b88651d5f581aa26e963ca4843fd218a464546a8cbab1a6ea29abf4cf7f` |

Immutable R1 comparisons were study.py
`dcb1d5eee748c3cd442def84ae4ddbb362790b7f6fc00d6b0d683a4abac545a6`,
manifest.md `db5c9c38ff808ad50fb6f480f674a6eba55d1a6d8f3f568170c4693446f416fc`,
and pending-invocations.md
`8efce773f99574c751afd2cbc422d28888efaf0a5d121c4566d5d5df51aafac2`.
The relative allowed entries in outputs.sha256 agree with those observed hashes.
I did not open excluded reports to validate other index entries.

Read-only Git inspection of `/workspace/work/issue-114` returned no short-status
entries, HEAD `d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67` and tree
`b38e1e2f744b21814881a6dec9663b4723124ccc`. This is the supplied provisional115
checkout identity, not an actual accepted113 integration or qualification.

I used the narrow AGENTS.md, PROJECT.md, review-work skill, role-launch guidance,
HP114 contract, and task route/gate/historical applicability. I formed this
assessment from the permitted proposal/R1 source, manifest and pending text.
I read no coordinator records, launch/handoff/checklist, author reports/accounting,
source-review reports, excluded transition, unrelated history or numerical data.
Names and hashes of excluded artifacts appearing in permitted indexes were not
followed. Historical assertions in the permitted manifest are not independent
correctness evidence for this proposal.

## Source assessment

- **Holds and initialization:** study.py:15–20 still raises unconditionally before
  stdlib imports; authorize:357 and main:3058 retain their separate execution
  holds. The unconditional resource refusal at :2121–2129 and :2456 remains.
  No receipt, grant or CLI operand bypasses them. Dormant main calls the loader
  at :3080 before route dispatch/output creation and before numerical imports;
  authorize:359 reloads independently for internal entry, and resource_parent:2457
  loads before EVIDENCE use. Resource-child reaches authorize before EVIDENCE use.
- **Independent receipt and actual path consistency:** :202–240 reads a bounded
  external receipt and checks its bytes against a digest supplied separately by
  the invocation, then checks explicit root/source/manifest/output and interpreter
  path/resolved executable/prefix. ROOT/EVIDENCE/EXPECTED are assigned only at
  :351–352 after the loader checks. Neither cwd nor the external proposal folder
  determines ROOT. :242–298 validates candidate/profile/hash structures and frozen
  source/manifest bytes. authorize retains actual material/startup verification.
  Candidate/base/parent duplicated attestations must agree, but are not an
  independent proof of actual113 ancestry or profile semantics. Those facts remain
  ROOT-owned final reconciliation, as declared. Resource-parent actual Git checks
  remain in the existing lifecycle; diagnostics retain the declared ROOT-attested
  Git boundary.
- **Exact invocation and copy:** :188–199 permits exactly one digest slot, solely
  as the operand of one `--binding-sha256`; it substitutes only the independently
  supplied digest. :300–350 checks route/run operands, source/interpreter/receipt
  and exact actual argv. The resource target is an exact fixed list. :308–312
  requires its grant copy to be output/grant.original.json, distinct from the
  original, which stays outside that attempt. :415–427 compares original/copy
  lengths and stream bytes. Parent copying precedes authorize (:2609–2618), so
  that check does not demand a nonexistent copy. :2669–2683 propagates the same
  receipt operands through the unchanged bootstrap target construction. No
  qualification arrays or new profile API are introduced in the child.
- **Determining paths and aliases:** :179–185 requires canonical absolute paths
  for receipt/grant/startup/profile/native/context inputs. Material names are
  root-relative with containment checks (:260–272). :325–335 resolves material
  paths before comparing them with the excluded receipt/original/copy paths;
  the other determining paths have already passed canonical-path validation.
  Thus an absolute startup/profile/native alias or root-relative material alias
  cannot evade these exclusions merely by spelling. The context distinctness
  check at :401–411 likewise uses resolved materials and canonical other paths.
  Exclusion prevents placing B/G's own determining identity into duplicated
  bindings; it does not waive actual hash verification of legitimate materials.
  This is trusted provisioning consistency, not adversarial filesystem isolation
  or a hard-link/authenticity guarantee.
- **Before/after and status behavior:** :1961–1985 captures the named materials,
  explicit source/manifest, independently pinned B, profiles, immutable context,
  startup and original/copy grants; receipt drift and copy mismatch raise.
  Main adds the same capture before numerical work and after export. :3204–3210
  distinguishes changed identities from identity-observer failure; :3221–3223
  gives those statuses the existing nonzero retained-failure exit. It does not
  convert ordinary completed scientific negatives/unsupported results into
  operator failures or impose a broad success-status whitelist. Earlier retained
  failures remain failures; identity failure can supersede the top-level status
  while the retained scientific result/failure remains available. Filesystem,
  serialization, fsync, abrupt observer-loss and non-atomic capture limitations
  still apply; no completed artifact is promised after such failures.

## Dependency order and sequencing disposition

The actual source/schema supports a finite acyclic proposal: frozen
source/manifest/materials and invocation SHAPE precede B; B contains their
identities and grant paths, not G/C/L hashes. Its own digest is supplied outside B.
Fresh C can follow B without expanded argv or a B digest in C. G then identifies
Bpath/Bsha and Cpath/Csha (:394–414), repeats unchanged B.bindings and existing
guards, and has no selfhash. Completing argv substitutes known Bsha, and an
independent ROOT launch attestation L can bind actual argv and B/C/G identities,
including original Gsha. Fresh final headroom/recheck is an L fact or separate C2
bound only by L. There is no source requirement for Ldigest in B/C/G/literal argv,
and no reason to mutate C once G binds its digest. Exact original/copy comparison
does not add a grant selfhash. This is more than normalizing a pile of cyclic
digest fields: later context was removed from B, G owns the later context binding,
and B owns only the unexpanded invocation shape.

R1 pending-invocations explicitly says “Bind one root-owned current-context
receipt only after command READY.” Proposal2 manifest:51–56 and pending text
explicitly propose shapeREADY → C → G → literalcomplete → fresh recheck/L instead.
I accept that narrow sequencing disposition as the dormant SOURCE design; it is
a method sequencing change, not proof that the old exact-command ordering has
already been fulfilled. Actual affected bound-method acceptance, immutable C,
fresh L/C2 admission and ROOT release remain prerequisites to activation. No
actual context, grant, admission or execution follows this verdict. Opaque
profile/startup/qualification/admission evidence must be independently inspected
when filled so that it does not hide a later G/L dependency. The loader is not a
general semantic DAG prover or cryptographic ROOT-authenticity mechanism.

## Preserved science, controls and remaining qualification

The independent whole-file R1/proposal `diff -u` is confined to binding helpers,
authorization consistency, binding/material capture and argv propagation, plus
the narrow diagnostic status handling. Numerical functions, W01–W06/K01–K04
values, generators, formulas, precision boundaries, analytical oracles, observer
arithmetic, repetition design, resource ledgers and native exact-PID wait4/live
headroom lifecycle are unchanged. The manifest comparison adds only its 92-line
proposal preface and preserves the R1 body. This is an unchanged-science scope
claim from text comparison, not scientific validation of the inherited method.

The finite control plan still separates observer/serialization/generator controls
from numerical qualification and native lifecycle controls. Future actual bound
controls must challenge the new receipt/argv/path/material boundaries as well as
the existing runtime lifecycle obligations; none has been run here. Historical
control1 remains INCOMPLETE; control2 is limited to clean64edcad and its exact
scoped method evidence. Neither qualifies this changed source. Resource90 remains
a proposal with no automatic batch. Reduced resource scope still requires an
independent S7 contract/design disposition. H3 unavailability or noisy RSS cannot
dispose of H1/H2 or establish an overall scientific negative. Fixed required FFT
module applicability to non-FFT K routes remains separate and unresolved; no
unused import is authorized to fabricate provenance.

All actual accepted113/candidate/parent/base/default/single profile, material,
native/startup, interpreter, ROOT/context/grant/output/run/argv pins remain UNBOUND
in the delivered template/source. Actual final-parent reconciliation, populated
B/C/G/L review, import/startup/native applicability and qualification, ROOT-scoped
controls, complete matrix/witness/scientific review, exact final clean Ubuntu full
gate and fresh D readiness remain later work. No final filled receipt is accepted
prospectively by this report.

## Checks, exposure and accounting

Checks performed: permitted file/text inspection and `rg`, individual SHA256
checks, independent R1/proposal text diffs, and read-only Git status/rev-parse.
Diff exit 1 means the reviewed text differs; it is not a failed runtime check.
No Python, AST/compile/import, lint/types/probe/test/native/process inspection,
Docker, installation, build, numerical work or refusal path was executed. No
target was launched and no scan was performed. No fixes, commit, restack, push or
PR were made. Only this source-review-2.md was written; no scratch or owned
process was created. Durable input evidence is retained.

This session completed one independent source assessment, with no repair or
delegation. Prior cumulative attempts/charges are coordinator-owned and not reset
or inferred here. Requested model/effort is gpt-6.1-sol/high; independently verified
serving attribution, token/cache/cost and elapsed meters are unknown. Optional
memory-disable and per-role read-only enforcement were not exposed; shared
filesystem and prompt restrictions are not engineered isolation. No excluded
content exposure was observed.
