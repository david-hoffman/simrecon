# HP114 binding-loader proposal 2 source review 1 — INCOMPLETE

2026-11-16. **INCOMPLETE; no fresh independent SOURCE ACCEPT.** This is an affected SOURCE review attempt only, not scientific review, native qualification, actual-binding acceptance, product B/D, execution permission, or readiness. The coordinator must obtain a replacement fresh source verdict. No source defect verdict follows from the independence problem below.

## Exposure and review boundary

I formed a primary source/DAG assessment from the supplied proposal source, manifest, template, pending invocation text and immutable R1 comparison. Before writing that assessment, I additionally read `/workspace/work/campaign/evidence/114/final-transition-source-preparation-1/transition.md` to verify the historical after-command-READY wording. That is a coordinator handoff outside the explicit primary-source allowlist, and it includes broader historical method/resource opinions. This violates the packet requirement to write the independent assessment before coordinator opinions. I disclosed this immediately to the coordinator and stopped widening reads. The coordinator directed retention of observations with an INCOMPLETE verdict and a fresh replacement review.

I did not read preparation-report.md, author-accounting.md, author-packet.md, proposal1 coordinator direction, or old reviewer reports. Hash-index entries naming such files were visible as identities only. The observations below are retained for accounting and diagnosis; they must not substitute for the fresh review.

Applied `/workspace/work/issue-114/.agents/skills/review-work/SKILL.md` in the packet's specially restricted SOURCE mode, not its product D acceptance mode. Read the named AGENTS, PROJECT, role-launch guidance and HP114 contract. The sole Current was used for held route, gate and historical applicability. Shared filesystem and prompt restrictions are not engineered isolation; optional memory-disable and per-role read-only controls are unavailable.

## Exact identities observed

All supplied literal identities matched using SHA256 file hashing. Read-only Git returned no porcelain entries and returned HEAD `d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67`, tree `b38e1e2f744b21814881a6dec9663b4723124ccc`. This is provisional115, not actual accepted113.

| File | SHA256 |
| --- | --- |
| reviewer-packet.md | e852c51afb0bfc314aa1d4b2f3819e5b8cc40a880cecbe783c5c0cb7f637846a |
| study.py | 4011064e31cf21c837c788b70b91b146213253f2f24cc5c4cc531c6955e48d83 |
| manifest.md | 03f766262a119759ff2dbc0eb06d8c2502dbc54f0896aaabec12d151e898b22c |
| source-delta.patch | e6e9db3e8a60d33e4780333b1af18612eab2967211b06891b8ea5182b6fd3557 |
| binding-receipt-template.json | f56d764fa4f9ef697d8387a0fe91b41e6f6042c499c2ab004398de9c7dd6c225 |
| pending-invocations.md | 63b7fcec0a3a424a731841cfe6b90d9c1510f2dd24e1f65efdfc6f907fab4f66 |
| frozen-inputs.sha256 | b5578b6486651e2898e7c506bb8c7ea196d42e44d66fe4f456cea2b3cdf60f47 |
| outputs.sha256 | 11c61b88651d5f581aa26e963ca4843fd218a464546a8cbab1a6ea29abf4cf7f |
| R1 study.py | dcb1d5eee748c3cd442def84ae4ddbb362790b7f6fc00d6b0d683a4abac545a6 |
| R1 manifest.md | db5c9c38ff808ad50fb6f480f674a6eba55d1a6d8f3f568170c4693446f416fc |

The proposal hashes were computed from the target directory, matching its relative index entries for the named delivery. The indexes were read as literal identities; author reports were not opened. Direct text diffs against R1 showed the supplied source/manifest delta; diff exit 1 meant text differences, not a failed runtime check. Some combined displays truncated; narrower source reads followed. No syntax or executable validity conclusion follows.

## Retained source observations, not an acceptance

1. Holds and loader placement: study.py:15–20 retains the unconditional top-level refusal before imports. Main at study.py:3056 retains its hold; authorize at study.py:353 retains its hold and independently reloads binding before numerical imports; resource parent/child retain their unconditional quarantine refusals at study.py:2456 and :2128. Main invokes the loader before route dispatch/output use (:3079); parent reloads before EVIDENCE use (:2457); child reaches authorize before numerical imports. Receipt/CLI/grant text offers no present hold bypass.

2. Primary dependency assessment: the source's B schema has only schema/bindings/artifacts (:211–215); its binding keys (:46–51) carry grant paths and invocation shapes, not later context/grant/launch hashes. Artifacts hold independently frozen source/manifest hashes (:282–288). Expansion replaces exactly one digest operand (:186–198), using independently supplied args.binding_sha256; neither B nor G supplies that expected digest. G subsequently compares its B path/hash and repeated bindings (:390–395), then identifies C path/hash (:396–416). Original/copy G streams are compared without G selfhash (:417–428). Thus the direct fields support the proposed order frozen inputs/shape -> B -> C -> G -> completed literal argv -> L with fresh recheck. The loader cannot prove opaque evidence has no semantic backedge or authenticate ROOT. L remains external and unimplemented here; it must independently bind original G hash, B/C/G identities, full actual argv and immediate admission/recheck without feeding its own digest back into B/C/G/argv or mutating C after G.

3. Ordering disposition remains a proposed affected method change. R1 pending-invocations explicitly says context is bound only after command READY. Proposal pending-invocations explicitly proposes shapeREADY -> C -> G -> literalcomplete -> fresh headroom/recheck/L and disclaims satisfaction of the old order. Source review must assess this proposal; actual sequencing still requires affected design acceptance and ROOT binding/admission/release. This attempt supplies no such acceptance.

4. Root/path/material observations: ROOT/EVIDENCE/EXPECTED begin None and are assigned only at the end of receipt validation (:350–351). Explicit canonical source/sibling manifest/root/output and interpreter path/resolved/prefix checks occur at :221–241. B materials are root-relative, disallow parent traversal and resolve inside root (:260–270); startup/profile/native paths use binding_path. The determining-path exclusion resolves root-relative material aliases and compares canonical startup/profile/native paths to B and original/copy G paths (:324–335). Context likewise must be canonical and distinct from canonical materials and receipt/grants/artifacts (:399–412). These checks retain actual immutable-material hashing in authorize, rather than waiving it to break the cycle. They are consistency checks under trusted ROOT provisioning, not hard-link/adversarial isolation or atomic snapshots.

5. Candidate/profile/native scope: the loader rejects malformed structured commit/tree/profile pins and contradictory duplicated parent/base/candidate fields (:242–259), validates profile bytes (:245–249), freezes source/manifest bytes (:282–288), and compares exact completed invocation and route/grant path (:341–348). Existing resource parent captures actual Git and compares to G before launch (:2621–2626). Actual accepted113 ancestry, signatures/default/single-profile meaning, import-bearing closure and runtime identity still require final-parent reconciliation. Format/equality checks and opaque profile receipts do not prove those semantics. No filled final binding was supplied or accepted.

6. Status requirements: the main return delta at :3221–3223 adds only changed-identities and identity-observer-failure to the existing failed-retained nonzero set. Identity drift/observer failure overwrites completion after export at :3204–3211. Successful scientific result statuses and expected negative/unsupported observations embedded in normal results otherwise keep the old exit behavior; no generic failure parser/control matrix was added. Operator binding/authorization errors remain distinct pre-run failures. This is a source observation, not exercised evidence of retention or filesystem failure handling.

7. Unchanged-science and method scope: the R1 text delta changes binding helpers/guards, receipt/material fields, loader placement, receipt operand propagation and diagnostic before/after identity disposition. It does not alter W01–W06/K01–K04 values, numerical functions/formulas/generators, precision/oracle semantics, repetition design or existing resource ledger and native wait4/headroom lifecycle body. No product/tests/dependencies/policy/RSS sampler/framework change appears in this comparison. Existing persistence, observer-loss, bootstrap high-water and native qualification limits survive.

## Limits and next owner

All actual accepted113/candidate/head/tree/parent/base/default/single-profile/material/interpreter/startup/native/context/grant/root/run/output/argv identities remain UNBOUND. All holds remain. No command is READY. The fresh replacement should independently assess exact source/DAG/order, ROOT status semantics and absolute/root-relative alias exclusions without this report or coordinator opinions.

Even a later SOURCE ACCEPT would establish neither actual bindings nor runtime qualification. ROOT still owns integration, actual parent/material reconciliation, affected bound-method review, smallest justified finite control plan and separate release, scientific witness qualification/comparisons, exact final Ubuntu full gate and fresh D. The existing proposed resource90 has no autobatch authority; a reduced claim/design requires independent contract/design S7 disposition. H3 unavailability or noisy/unsupported RSS cannot dispose of H1/H2. Required FFT module applicability to non-FFT K routes is separately unresolved; forced unused imports would fabricate applicability. Historical control1 stays INCOMPLETE; control2 retains only its clean64edcad-specific bounded scope. No native-half arithmetic, storage/speed benefit, physical recovery, overall scientific negative or 16 GiB feasibility follows.

## Checks and accounting

This attempt used only file/text/hash/read-only Git operations: cat, sed, rg, diff, sha256sum, git status and rev-parse. The only written file is this report. No repair, commit/restack/push/PR, tests, interpreted script, Python/AST/compile/import/lint/types/probe/native/control/scientific execution, refusal-path execution, install/build, process scan/spawn/signal, cleanup or deletion was performed. No target was launched and no scan was made. No owned target/helper process or disposable task fixture was created; durable evidence and all target bytes are retained.

Count this as one source-review attempt, INCOMPLETE due exposure, with zero fresh acceptance verdicts and zero runtime attempts. Prior cumulative attempts/costs remain the coordinator's ledger; this session does not reset them. Requested route/model/effort: fresh tool session, gpt-6.1-sol/high/fork_turns=none per packet; actual serving/model/effort attribution beyond exposed launch facts, tokens/cache, monetary cost and elapsed meters are unknown. Missing measurements are not zero. No human numerical spending cap was supplied in this packet. Replacement review is an additional charge.
