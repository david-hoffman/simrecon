# HP114 binding-loader SOURCE proposal 2 — complete authored handoff

2026-11-16. Complete author2 delivery of the nine named external outputs, pending
fresh independent affected SOURCE review. SOURCE ONLY / HOLD / NOT READY. No
runtime qualification, scientific verdict, actual binding, grant or readiness.
Source and manifest were frozen before their hashes and this report. Their final
identities are external; no determining source/manifest byte contains its own hash.

Read-only Git observed clean d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67,
tree b38e1e2f744b21814881a6dec9663b4723124ccc. This is provisional115,
not actual accepted113. The task document remains the sole Current state.

## Exact delivery and historical boundary

All nine outputs are directly under
/workspace/work/campaign/evidence/114/binding-loader-source-proposal-2/:
study.py, manifest.md, source-delta.patch, binding-receipt-template.json,
pending-invocations.md, preparation-report.md, author-accounting.md,
frozen-inputs.sha256, outputs.sha256. The output index excludes itself; its final
identity is supplied in the distinct final handoff. Coordinator files are untouched.

- study.py: 4011064e31cf21c837c788b70b91b146213253f2f24cc5c4cc531c6955e48d83
- manifest.md: 03f766262a119759ff2dbc0eb06d8c2502dbc54f0896aaabec12d151e898b22c
- source-delta.patch: e6e9db3e8a60d33e4780333b1af18612eab2967211b06891b8ea5182b6fd3557
- binding-receipt-template.json: f56d764fa4f9ef697d8387a0fe91b41e6f6042c499c2ab004398de9c7dd6c225
- pending-invocations.md: 63b7fcec0a3a424a731841cfe6b90d9c1510f2dd24e1f65efdfc6f907fab4f66

The patch contains only study.py and manifest.md against immutable R1 with portable
R1/ and proposal2/ labels. R1 source dcb1d5eee748c3cd442def84ae4ddbb362790b7f6fc00d6b0d683a4abac545a6,
manifest db5c9c38ff808ad50fb6f480f674a6eba55d1a6d8f3f568170c4693446f416fc,
transition 278c77e3b44201b12d92cdf8d201c38766710a52d73b154159b8be4580b1de0a,
and author2 packet 83f09cd6cbc38b18880841d8c871028360346ef2d883b9f5baff7566269b8e0c
were literally hashed. Full input identities are in frozen-inputs.sha256.

Partial1 supplied historical starting text, not completed delivery or acceptance.
Its freeze transition records no observed final handoff and no outputs.sha256;
final-looking assertions inside its report do not override that observation.
Partial1 and its nine-file drafting costs, superseded context-normalization draft,
two reported patch-context failures, all source repairs and UNKNOWN meters remain
preserved in their original records. Availability transition is neither a numerical
failure nor proof of a host restart. No partial1 reviewer verdict is inferred.

## Actual source diagnosis and changed-function map

R1 has explicit UNBOUND inventory and holds but no external binding loader. It
cannot directly execute after merely receiving a grant. Partial1 adds the loader
and the ROOT-directed acyclic design; author2 independently inspected that text.
Two narrow defects were corrected rather than copying its completion claims:

1. Partial1 excluded startup/profile/native paths from direct receipt/grant hash
   dependencies but omitted root-relative material paths. load_bindings now
   resolves all material paths before applying the same exclusion. Absolute
   material keys remain rejected; aliases through an allowed in-root path resolve
   to canonical paths and cannot pin original/copy G or B. Existing root containment
   and actual material hash checks are retained. C later must also be distinct
   from B/material/startup/profile/native/source/manifest/grant paths.
2. Partial1 retained diagnostic identity drift/observation failure but returned
   zero for those new statuses. main now returns 2 for changed-identities and
   identity-observer-failure, alongside the existing failed-retained. No ordinary
   completed scientific negative/unsupported status or expected exception outcome
   was added to that set; its existing scientific evidence/exit semantics remain.

Against R1, four small helpers are added: binding_hash, binding_path,
expanded_binding_argv, load_bindings. They admit bounded independently pinned B
bytes, explicit canonical root/evidence/source/sibling-manifest/output paths,
interpreter lexical/resolved/prefix identity, structured actual-parent/profile/
candidate attestations, named material/startup/native identities and exact route/
original-copy argv. ROOT/EVIDENCE/EXPECTED are assigned only after validation.
The loader is called after argparse before dispatch/raw mkdir/numerical imports;
authorize reloads independently and resource_parent loads before EVIDENCE access.

Changed authorize retains its first unconditional hold, then checks B independently,
finite G size, correct route/path, unchanged B.bindings and candidate, G's exact B
identity, and a distinct immutable C identity. It retains C in GRANT_CONTEXT for
capture, compares original/copy G byte streams and retains all existing source,
artifact, environment, run and admission checks. B has no C/G/L hash or G selfhash.

Changed resource_materials uses explicit bound source/manifest paths and includes
B, startup/profile evidence, C, original G and copied G in before/after capture.
It enforces B's independent digest, C's G-bound digest and original/copy equality.
resource_parent adds only load-before-EVIDENCE and exact B operand propagation/
comparison through the unchanged fixed bootstrap to the direct target. main adds
required B path/hash options, pre-dispatch loading and diagnostic before/after
capture with retained method-failure status and corresponding nonzero return.
The template contains no executable actual pins; every actual value stays UNBOUND.

Every existing R1 function except authorize, resource_materials, resource_parent
and main is verbatim. The added four helpers and binding globals are the remaining
source additions. Localized text diff leaves all scientific bodies, W01-W06 and
K01-K04 values, SHAPES, precision/strategy meanings, generators, encodings, formulas,
oracles, range/error/decision observers, resource ledgers and repetition design
unchanged. This includes three successful fresh W repetitions and one deterministic
K pass. All R1 execution_hold/refuse functions and unconditional top-level-before-
imports/main/authorize/resource-parent/resource-child calls remain verbatim.
Native exact-PID wait4 ownership, bootstrap, child body, readiness/FD handling,
signals/headroom and lifecycle behavior are unchanged. Manifest adds only the
binding proposal; its entire R1 tail is preserved. This is localized text-delta
evidence, not parsed, compiled, imported or executed equivalence proof.

## Acyclic freeze and independence boundary

Freeze final source/manifest/material/candidate and invocation recipe/SHAPE first.
B then names immutable materials/artifacts/path/shape identities only. After B is
frozen, obtain Bsha. Fresh physical C need not contain Bsha or expanded argv; freeze
C. G binds Bpath/Bsha, Cpath/Csha, candidate/source/spec and existing guards; G has
no selfhash or later Ldigest. C remains immutable once G binds it. Any G admission
proof must already precede G (C or independently frozen earlier proof), never L/C2.

Known identities complete literal argv. Independent later ROOT L binds complete
actual argv, B/C/G identities and a last-moment physical recheck/admission. Recheck
facts are L-only or separate C2 bound by L, never appended to C. No Ldigest feeds
B/C/G or literal argv. Source/manifest/candidate/grant identities remain outside
bytes determining them. Direct path checks help prevent obvious cycles; opaque
evidence semantics still need independent review and cannot be certified by this
loader. No additional hash-slot normalization is claimed to solve dependencies.

B's only recipe slot is one literal $ROOT_BINDING_SHA256 at exactly the operand
of --binding-sha256. Its independent value comes from ROOT's literal launch argv/
attestation, never B itself or G. Expansion only completes that operand. G repeats
the unexpanded shapes and names real Bpath/Bsha. L independently binds Gsha; no
new grant-hash argv option is required. B is a named immutable external input,
recorded before/after. Its source must be eventual tracked __file__ under explicit
root, not this external proposal directory or cwd. Parent opens original G; child
opens output/grant.original.json; both paths are explicit and both byte streams
must match, without a G selfhash. Diagnostic/controls use copy=null and target=[].

Old wording is not silently fulfilled: R1 pending-invocations says context is bound
"only after command READY"; the transition requires "after-command-READY ROOT
context/proof". This proposal explicitly changes sequencing to SHAPE-ready -> C ->
G -> literalcommandcomplete -> fresh recheck/L. ROOT directed this narrow correction;
it remains proposed for affected independent review and later actual binding/
admission/release. It creates no command READY, grant or new human checkpoint.
Consistency checks are no ROOT authentication, atomic snapshot or engineered
isolation. Filesystem races and persistence/observer loss remain limitations.

## Smallest future binding controls — UNEXECUTED

Use existing routes/material fixtures with ROOT-frozen inputs, one retained finite
attempt at a time, without a parser/observer/control framework or autobatch:

1. Independent B identity mismatch must refuse before globals/raw mkdir/imports;
   matching B/G assertions cannot rescue it. Wrong/extra/misplaced digest slot and
   later G.binding_receipt mismatch must also refuse.
2. B/material/C drift after validation must remain method-incomplete, retained as
   changed-identities or identity-observer-failure where capture reaches output,
   with diagnostic nonzero status. Missing capture/output remains incomplete.
   A material alias directly naming B/original G/copy G must be rejected.
3. Missing/different original-copy G bytes or wrong-route grant path must refuse
   before numerical imports/spawn, retaining available failure facts. No retry is
   inferred from a failed attempt.
4. Parent/direct-child B path and independent digest, interpreter/source, row,
   strategy, repetition and run-id must propagate exactly. Changed/duplicate
   operands must refuse; legitimate shape expansion leaves G's shape unexpanded.
5. One future actual admitted fixture with correct bindings and original/copy bytes
   must reach its existing observation route with stable before/after identities.
   Ordinary scientific negative/unsupported outcomes retain existing disposition;
   identity failure cannot become scientific negative or complete observation.

These are expected controls, not launch authority or executed evidence. ROOT
chooses actual affected finite controls after fresh SOURCE review. Native lifecycle,
readiness/exec/signal/FD/wait4/persistence qualification remains a separate later
ROOT obligation. No refusal path, syntax check or positive fixture was executed.

## Remaining limits, attempts and ownership

Actual accepted113 ancestry/signatures/default/supported-single, actual114 base/
candidate, material/import-bearing/startup/native closure, exact interpreter and
pinned environment remain UNBOUND. Structured attestation does not prove semantic
truth. Resource Git comparison is unchanged; diagnostic candidate provenance is
ROOT-attested. Fixed required FFT module applicability to non-FFT K routes remains
separately pending; no unused backend import was added for provenance.

Historical control1 stays INCOMPLETE. Control2 remains clean64edcad/material/time-
specific and supplies no loader/native/full-study acceptance. No old array was
read, helper rerun or scoped acceptance expanded. W/K witnesses, phase/noise/
Fourier/finite-sum oracle review, all S1-S8 dispositions, SCI, exact integrated clean
Ubuntu full gate and final D remain pending. Resource90 remains proposed, without
autobatch. Reduced resource scope needs independent S7 contract/design disposition;
H3 unavailable/noisy RSS cannot dispose of H1/H2 or prove a scientific negative.

One fresh author2 SOURCE attempt. Named file/text/hash/read-only Git operations
only; four historical draft files copied into the nine-file scope, two localized
successful source corrections and manifest/pending wording updates, new reports/
indexes, expected text diffs. Initial broad filename-only discovery showed names
of other issue instruction/packet files; no other issue science body was read.
Two long batched read outputs truncated; needed governing/binding slices were
reread narrowly. No source was assessed/transformed by an interpreted script.
No failed patch application. A diff-return-1 chain skipped a subsequent Git status;
that read was performed separately and remained clean. Diff status1 is expected
text difference, not a failed runtime check. Preliminary pre-second-correction
hashes were authoring intermediates, never reported as final candidate/receipts.

No Python/AST/compile/import/refusal-path/probe/lint/types/test/install/build/native/
science/resource/measurement execution, process scan/spawn/signal or delegation.
No target/helper/agent launched by this author; no owned target exists by that
fact, without scanning or claiming others' process state. No tracked/live source/
pin edit, commit/rebase/push/publication/READY/grant/context/release activation.
No extra scratch, fixture or cleanup/deletion target. All inputs/old evidence are
retained. Source/manifest final hashes precede report/index generation; costs and
serving/meters remain UNKNOWN as recorded separately. Stop for fresh independent
SOURCE review of this exact complete delivery; no runtime readiness follows.
