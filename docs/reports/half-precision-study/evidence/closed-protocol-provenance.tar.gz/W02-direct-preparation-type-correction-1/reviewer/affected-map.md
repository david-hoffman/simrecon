# Independent API, delta and retained-evidence map

Candidate: 246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635. Baseline: d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094. Frozen primary: 9715239afb6903fdc09ce5d2641f73aad56ca6e6d8eb01aa4bd78266be7808b0.

## Every direct API argument

| Argument | Fixed W02 value/type | Public CE02 admission and disposition |
|---|---|---|
| images | raw.astype(np.float16), (1,3,5,4,16,16) | Positive six axes, Z>=2, even X>=2, ndarray standard-real dtype; finite samples exact in float32. Finite half embeds exactly; actual values/operations unobserved here. |
| dxy_um | float0.1 | Positive finite nonboolean real, um. Fits. |
| dz_um | float0.2 | Positive finite nonboolean real, um. Fits. W01 zero never enters this branch. |
| norders | int3 | Positive signed32 nonboolean integer; Q5<=P5. Fits. |
| background | float256.0 | Finite nonboolean real scalar in counts (alternative array shape16x16 not selected). Fits. |
| lateral_zoom | copied float2.0 becomes built-in int2 | Positive signed32 integer, nonbool, float32-exact. Sole corrected type. Physical dimensionless value stays2; alpha stays1/12288. |
| axial_zoom | int1 | Positive signed32 nonboolean integer. Fits. |
| flatfield_slope | omitted/None | Owned ones default; alternative finite standard-real16x16 multiplicative map unselected. |
| exposure_background | omitted/None | Owned zeros default; alternative finite standard-real1x3x5x4 counts array unselected. |
| phases_rad | omitted/None | Uniform default. Supplied finite3x5 inverse/left-inverse/rank/residual path unselected and unchanged. |
| edge_pixels | int0 | Signed32 nonboolean integer <=16; zero bypass. Fits. |
| equalize | boolFalse | Actual boolean; disables gain division, preserving sums and recorded settings. |
| equalize_z | boolFalse | Actual boolean; fits. |
| equalize_time | boolFalse | Actual boolean; fits. |

The options comprehension excludes phase_policy and acquisition_mode, which CE02 does not accept. It supplies exactly ten accepted keywords plus images; no missing required or extra keyword remains. Real pitches/background, integer order/axial/edge and bool flags are separately checked; no general numeric coercion assumption is used. Source products XYZ1024, (X+2)YZ1152, DPZ60, QP25, D*orders9 fit signed32. Fixed binary64 workspace122880B, complex128 output138240B, separator600B fit supported platform-intp arithmetic; these are metadata arithmetic, not measured allocations/headroom. A loose real generator bound3394.14 counts is far below65504; it is not observed finite admission or scientific accuracy. Correction/sentinel/edges/sums/uniform separation/lateral and axial transforms/finite errors/owned return fields remain unchanged. MemoryError/interruption and numerical failures remain possible.

## Exact delta and protected bodies

diff -u independently reports one hunk, one addition, no deletion: at candidate1407 `options["lateral_zoom"] = int(options["lateral_zoom"])`, immediately before existing direct call1408. Old145957B/3357lines becomes146024B/3358lines (+67 bytes). Removing that exact unique added line with text filtering recovers SHA d423. This is full-file byte preservation proof, not a claim to have semantically reread every baseline line.

| Scope | Exact preservation / affected meaning |
|---|---|
| W02 QUALIFY direct call | Only selected local options type changes. int receives closed fixed2.0 from settings, yielding2. No arbitrary user zoom reaches it in this harness path. It does not mutate acquisition. |
| Global settings/science | float2.0 persists. Generator/phases/transfer/optics/carrier/filtering/expected branches/oracles/replay/formulas/tolerances/metrics/rows all identical. W01 remains native2D/O2/K1; other rows3D/K64. |
| W01 and other scientific calls | Full/summary/workflow/acquisition/composition, W/H/K/CPU and resource public calls byte-identical. No empirical success or same timing predicted. |
| Entry/load/authorization | Dormant hold definitions/constants, ROOT/EVIDENCE/EXPECTED/BINDINGS None initializations, B loading, one-slot argv expansion, grant/material/default/native/startup/environment/thread checks and source-hash qualification guard unchanged. Old bindings cannot authorize changed bytes. |
| Serialization/hash/observers | encode, numeric_chunks, array_identity/hash, stats/error/pack, remember/KEEP/ARRAYS, retained_payload, unique directories, NPY export and failed-record retention unchanged. No new schema/helper/guard. |
| Controls/kernel/CPU | finite_controls, run_kernel, cpu_feasibility and dispatch unchanged. Adapter branch unreachable in these routes. Their actual finite observations retain named scope. |
| Native/resource | SESSION_BOOTSTRAP, posix_spawn, readiness/ordinary FD handling, sole exact-PID wait4, signal/timeout/escalation/closure, resource parent/child/validators/caller/stage and allocation guards unchanged. |
| Clocks/lifetimes | All local/entry/import/setup/pack/call/endpoints and parent terminal observation definitions unchanged. W02 successful work past former failure will take time/retain new output; no old failed total is a new successful measurement. |
| Profiles/material | Default e644184f…/single9fcfc4e0… declarations unchanged. Current143M,7S,2N checks all match; src/tests/config/lock diff to274c empty. New material map must replace harness entry after ROOT integration. |

## Completed evidence retained, without replay

| Exact completed evidence | Retained applicability and limits |
|---|---|
| Earlier report f6bcd184… and clarifications21e1e047…/6fe87d6d… | Finite staged method, actual default-double/public generic RM84 mechanism reuse, conditional known/T1 used-seed reasoning and native/clock definitions retain applicability to unchanged bodies/materials. They grant no live HP114 object properties or complete scientific reference. Earlier static route eligibility is superseded by actual M01 only within that accepted scope. |
| M01 report ec015355… / disposition b797d2bc… / ROOT application d48dd40e… | Retain actual finite IEEE wires/canonical identity/four roundtrips/74 indexed arrays/18 raw-generation pairs/K01/K03/cancellation/error/incomplete-refusal/CPU-promotion observations and ordinary normal direct-Python GNUtime correspondence. This review does not re-decode NPYs or repeat the original raw audit. Original caveats survive: some raw/FFT arrays unarchived; no independent FFT accuracy/native-internal theorem; null-snapshot case fails an earlier prerequisite; JSON/NPY cannot reconstruct live flags/alias/payload graph. Raw WIDER identity mapping extends only to same float32 resource raw branch, not prepared/seed/all-metadata equivalence. |
| M01 normal GNUtime | Historical85560 LinuxKiB=87613440B, ≥ source85416KiB endpoints; elapsed1.60s/user1.22/system0.24 remain that attempt's broad formatted values. Reuse ordinary route method only with fresh per-attempt B/C/G/L/admission/clean startup/thread/locale/unique absent output/exact subject/tool/raw status/units/source consistency/whole closure. Tool3b11dec5… is recorded inside-Ubuntu provenance, not a new reviewer execution. No source endpoint relabeled terminal, peak subtraction, causal late-allocation, observer/tree sum or future value theorem. |
| Negative report005b2d14… / disposition d1485f83… / ROOT application6e3c6a18… | Retain finite M02 missing, M03 malformed, M04 oversize, M05 child-error, M06 self-term, M07 TERM timeout, M08 KILL escalation, M09 wrong-B refusal and M10a3 single ordinary observer-SIGINT cleanup predicates. M10a1/a2 remain failed intended SIGINT controls. Ordinary FD scope, readiness-before-exec, sole wait ownership, check-to-signal race, finite windows/nonuniversal cleanup and exec/inherited/descendant high-water caveats survive. M09 abnormal GNUtime unqualified; a3 rationale erratum preserved. No added control/reviewer/native replay is needed solely for this adapter. |
| Historical W01 | Local affected scientific/body path unchanged. It is eligible to remain historical evidence for separately completed actual row/reference/common-projection assessment; this review neither reads active partials nor accepts its scientific row. It is never current-source qualification. |
| Historical W02 | run22f94496… failed-retained, direct CE02 integer-domain mismatch, qualification null. ROOT diagnosis608c2b41… agrees with independent raw/type facts.16 retained NPYs/abnormal usage remain original and unqualified for successful science; not a half negative or product defect. No NPY decoded. |

No concrete affected control/native mechanism was found. Retaining named applicability after ROOT's new source/material/candidate freeze is justified by exact body/actual material preservation; it does not reuse historical B/C/G/L as new grants or accept unobserved future values.

## Current-source obligations

ALL SIX NEW QUALIFY W01,W02,W03,W04,W05,W06 are required under new actual source/material/candidate/parent/B identities after ROOT integration. Unchanged authorize compares qualification harness digest with digest(__file__) and manifest digest. Branch/body equivalence cannot override that guard. The review supplies no grant and changes no guard. W02 direct-call outcome is pending; W03–W06 were not collected by the stopped old procedure.

Manifest ddf038c0…, obligations d02b904f…, HP1149367…, exact149/ten rows/three fresh successful W repetitions/fixed12 W02/W05 prepared pair order remain intact. All six complete common projections, full-grid/upstream/reference uncertainty and prepared-resource applicability obligations survive. Historical/public reusable evidence keeps its finite limitations. Missing independent premises can remain scoped UNRESOLVED/noactivation. ROOT owns new parent HEAD^/tracked-status/B/artifacts/material143 harness entry, runtime/admission, scientific evidence, final SCI, exact clean Ubuntu full13 and fresh D/report integration.
