# Input and read ledger

Completed input inventory for this NONBLIND bounded external source author. Hashes in `read-inputs.sha256` identify whole-file bytes even when inspection used only named excerpts. `inputs.sha256` separately identifies the packet, immutable source, three frozen scientific determining files and completed ROOT diagnosis. These indexes confer no authority and do not hash themselves.

| Read input | Inspection and purpose |
| --- | --- |
| author-packet-1.md | Full packet; SHA e089f9271ffaa913657eeb2a250394791fdeaa36cd9a60748241e97f8dbe7ca8 verified. Exact ownership and prohibited operations. |
| issue-114/AGENTS.md | Full operational instructions; no delegation, bounded ownership, required fresh reviewer and accounting. Ancestor instruction-file existence checked; no ancestor AGENTS content found by those checks. |
| docs/PROJECT.md | Project/public-boundary/hold/delivery context. Initial combined output truncated; relevant command/coverage/role portions inspected with targeted follow-ups, including 275–382. No claim of whole linked-policy/archive review. |
| docs/operations/role-launches.md | Full role launch guidance; fresh reviewer and distinct report/final; shared controls and unknown metering. |
| docs/operations/model-selection.md | Full selection/calibration context. Requested Sol/high is not actual serving proof. |
| docs/reports/half-precision-study/intake-author.md | Full intake completion evidence; study-only scope and restrictions. |
| docs/contracts/half-precision-feasibility-v1.md | Full current HP114 contract; ten rows and §5 selected resource experiment, independent scientific acceptance limits. |
| docs/contracts/c-equivalence-preprocessing-v1.md | Full CE02 public contract; signature, shape/type/units, normalization, phase/edge/equalization/error/representation domains. |
| docs/usage/c-preparation.md | Full public usage; direct integer-zoom example and direct native3D limits. |
| src/simrecon/__init__.py | Targeted prepare_bands export/import lines 11 and 79 only. |
| src/simrecon/acquisition/preparation.py | Complete plaintext source inspected across bounded reads, including full direct signature/body 278–479, all validation helpers and selected phase/edge bodies. No import or execution. |
| docs/reports/half-precision-study/study.py | Sole candidate derivation input, whole-file SHA d423 verified. Inspected constants/None declarations 1–175, external loader/authorize 206–535, timed/remember, phases/generator/settings/transfer/workflow 759–887, branch/public-boundary/run_workflow 1301–1440, resource entry excerpts and main 3165–3265. Targeted definition/clock/wait4/terminal searches. Remaining bytes preserved by exact diff and removal/cmp, not claimed independently reviewed scientific implementation. |
| docs/reports/half-precision-study/manifest.md | Sections/headings and lines 1–100; exact current selection, 149 inventory and frozen hash. No full historical-layer rereview. |
| docs/reports/half-precision-study/qualification-obligations.md | Headings and lines 1–205; retained full scientific obligations, future applicability and timing limits; frozen hash. No scientific execution or full old-procedure rereview. |
| campaign/evidence/114/resource-design-preparation-1/resource-plan.md | Located by filename search, headings and §8A lines 442–514; exact previously accepted selection text as frozen contextual evidence, not a new design adoption. |
| current-qualification-captures-1/Q-W02-QUALIFY-r1-attempt1/ROOT-failed-fixture-diagnosis-and-closure.json | Full completed ROOT diagnosis; SHA608c2b41 verified. Actual traceback/domain message, closure, 16-file verification and material/grant invariance are attributed to that record. Did not open/decode NPYs or independently reproduce those observations. |

Read-only Git observations: HEAD b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d; HEAD^ 1e25db68e262708e27f1ea5f6f88b0de01280449; tree 76edc6e8ee178d3a1c125a11e3cd290231816fd7; `git status --short` emitted no entries. No Git mutation was performed. No actual new candidate commit/tree/material binding is asserted.

Narrow path/definition searches also printed filenames and matching headings from the half-precision task/packet/report area. They were navigation, not full reads or new authority. An initial broad search produced truncated output; critical contract/preparation/option reads were repeated in bounded commands. A resource-plan lookup at `docs/reports/half-precision-study/resource-plan.md` returned missing-path status 2, then the actual external plan above was located and read. The precreation `ls` of the new author directory returned expected absent-path status 2. These are static navigation observations, not runtime failures or role-launch failures. Source/helper line anchors in the map were corrected to the observed 479-line file before completion.

Only new files under this packet's `author/` were written. No repository tracked file, old evidence, raw run, capture, NPY, manifest, obligations, task, contract, report or material input was edited. Outputs were inspected using plaintext diff, text search, line counts, hashes and byte comparison only. No blind role, review history, broad archive/lesson inspection, new framework or delegated task was used.
