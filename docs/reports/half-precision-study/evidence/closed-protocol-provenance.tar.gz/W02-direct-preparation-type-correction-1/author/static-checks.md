# Completed static checks

These are byte/text checks only. No source execution, syntax/AST/compile check or scientific test occurred.

| Check actually performed | Observation |
| --- | --- |
| Packet hash before work | Matched authorized e089f9271ffaa913657eeb2a250394791fdeaa36cd9a60748241e97f8dbe7ca8. |
| Accepted study hash before derivation | Matched d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094. |
| awk insertion target count | Exactly one existing direct-call anchor; command status0. |
| Unified diff | Status1 expected for difference; one hunk, one added line, no removed source line. Saved exact bytes to exact.diff. |
| Candidate hash | 246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635. |
| Remove exactly inserted assignment, cmp against accepted source | Status0, byte-identical. Performed after construction and again at final source/input verification. |
| Line counts | Accepted3357; candidate3358. Public preparation source479. |
| `sha256sum -c inputs.sha256` | Status0; all six immutable packet/source/frozen-document/diagnosis identities match. Full output retained in input-verification.txt. |
| `sha256sum -c read-inputs.sha256` | Status0; all sixteen read-input whole-file identities match. Full output retained in read-verification.txt. |
| `git diff --no-index --check` accepted versus candidate | Status0; no whitespace diagnostic. |
| Read-only `git status --short` at final source/input verification | Status0; no entries. Tracked checkout remains unchanged by this author. |

Full direct API audit is in api-option-and-preservation-map.md. No other concrete fixed-option type mismatch was found; success, scientific suitability and runtime qualification remain UNEVALUATED. The author does not accept the candidate or evidence applicability. Fresh affected review is pending; ROOT owns integration, binding, runtime and scientific release.
