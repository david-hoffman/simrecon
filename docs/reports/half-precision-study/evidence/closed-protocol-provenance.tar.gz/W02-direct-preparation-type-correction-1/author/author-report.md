# Completed W02 direct preparation type correction author report

AUTHOR OUTPUTS COMPLETE — SOURCE ONLY; pending fresh independent affected review. This is an authored candidate and static audit, not acceptance, qualification or a release.

## Result and exact ownership

Produced external `author/study.py`, SHA256 `246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635`, derived exclusively from accepted source SHA256 `d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094`. The candidate adds exactly one local assignment immediately before the existing QUALIFY/W02 `sim.prepare_bands(half, **options)` call:

```python
options["lateral_zoom"] = int(options["lateral_zoom"])
```

`exact.diff` SHA256 `8a364c131e517383c5b91885cf526212298e1cbc395bc213891eae1bbe734404` has one hunk, one added line and no removed source line. Candidate has 3358 lines versus accepted 3357. Deleting precisely that added line yields byte-for-byte accepted source (`cmp` status 0). The original study source is unchanged.

Only new files under `/workspace/work/campaign/evidence/114/W02-direct-preparation-type-correction-1/author/` were written. No tracked source, material, manifest, obligations, contract, task, report, tests, gates, configuration, old run/capture/native evidence or NPY was edited. No commit or external action occurred. No source was imported or executed.

## Diagnosed cause and static scope

The packet SHA e089f9271ffaa913657eeb2a250394791fdeaa36cd9a60748241e97f8dbe7ca8 and accepted source SHA d423 were verified before editing. Completed ROOT diagnosis SHA608c2b41abbdc6635b80c60d53f6a3beca0c72adf48daa140e2d90725fea65f7 records actual W02 target exit 2 and `SimreconError`, code `preparation-domain`, message `lateral_zoom: must be an integer scalar`, at accepted study line1407. The direct CE02 function calls `_integer(lateral_zoom, ...)`, which rejects float scalars; W02's workflow/acquisition declaration supplies valid numeric `2.0` for that broader route. The direct-call fixture forwarded its type unchanged. This is the identified fixture API adapter mismatch. It is not evidence of half scientific unsuitability or a product defect.

This author read the completed diagnosis JSON including traceback. Its verification of 16 retained NPY files, closure and unchanged material/grant identities is attributed evidence, not a new independent observation. No NPY was decoded and no raw experiment was retried. The old W02 abnormal GNUtime values remain raw/unqualified and supply no half positive/negative result. Old W01 remains historical, not current-source scientific acceptance. All originals are preserved.

The inserted assignment acts on the existing newly copied direct-call options only. Global `settings` still declares lateral_zoom=2.0; actual numeric zoom remains two and alpha remains 1/12288 for this W02 geometry. Axial_zoom1, norders3, edge_pixels0 and boolean controls remain unchanged. The fixed value is known from the immutable fixture; this does not establish a policy for arbitrary real zoom conversion. No helper, generic coercion, guard, new validation, tolerance, oracle/capture framework, API behavior change or outcome fitting was added.

## Completed full direct API audit

`api-option-and-preservation-map.md` accounts for all 14 signature arguments: one images argument, ten supplied keywords and three omitted array defaults. It records fixed type/value, shape/domain/units, exact validation requirements, array/finite/float32 rules, integer controls, real pitches/background, boolean flags, phase defaults, index products, wider workspaces and full body error/finite behavior. Full public prepare_bands signature/body and validation/phase/edge helpers were inspected as plaintext, together with CE02 contract, usage and facade exports. No additional concrete fixed-option type mismatch was found. No extra field was changed.

The shape `(1,3,5,4,16,16)`, O3/Q5/P5, scalar pitches/background, integer axial/order/edge values and actual bool flags fit their declared API domains statically. Optional slope/extra/phase arrays are absent, selecting ones/zeros/uniform defaults. Finite binary16 samples are exactly representable in float32; source formula range has a loose bound below half overflow. Actual generated/cast bits, exact admission, sentinel events, downstream finite arithmetic, scientific accuracy, shape/backend execution and success remain UNEVALUATED. The audit preserves explicit numerical and allocation/interruption failures. It supplies no empirical pass or qualification.

## Preservation and required next route

The exact byte delta retains every scientific value/formula/guard/row/native/clock/loader/output byte outside the single insertion. The detailed preservation table covers global science and all calls; ROOT/EVIDENCE/EXPECTED and BINDINGS None initialization; genuine external receipt/material/source/environment/import/qualification guards; local/diagnostic/resource clocks; lifecycle retention/output behavior; bootstrap/readiness/exact-PID wait4/terminal native units and closure; finite controls; W01 K1 and W02/W05 K64; all old attempts and evidence. Source line references after insertion shift by one.

Manifest ddf038c074f6ed0d927da0cf704163d81083bc9733a428dc62e967a6c44020ba, obligations d02b904f4d08d347d30a23a85762f50d3bf57ab628a7ace012209885ec680527 and contract9367ed8c9b4b28d3d65a69839a98f104ffb8513ff78164d35183e30c3439a3ef stay frozen. All ten rows and 149 nominal observations remain: 126 W numerical, six QUALIFY, four KERNEL, one CPU and twelve selected §8A W02/W05 PREPARED_WIDER/PREPARED_HALF observations in fixed order; three fresh successful W repetitions retained. Full-grid/upstream/compatibility obligations remain intact.

Earlier accepted finite controls and normal GNUtime applicability are coordinator-supplied context, not blanket future scientific/native evidence. Fresh affected SOURCE review must explicitly assess this exact delta plus retention of those finite controls/native/normal GNUtime evidence and historical W01 eligibility. No redundant preliminary reviewer or new control replay was initiated by this author. No concrete adapter-only reason for broad controls/native replay was found; the independent reviewer owns applicability acceptance.

The genuine unchanged current-harness hash guard prevents old qualification records from qualifying changed source. ROOT owns later integration after completed affected acceptance, new clean candidate/source/material B identities and all SIX NEW current-source QUALIFY. Old W01 cannot be relabeled and old W02 remains a failed-retained fixture attempt. Manifest/obligations scientific bodies and default/single/native/startup facts need no gratuitous change when their actual determining bytes and independently retained scope are unchanged. This author creates no new actual HEAD/B/material freeze, runtime grant or scientific acceptance. No self-review verdict is claimed.

## Commands, identities, outputs and accounting

Read-only Git observed HEAD b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d, parent1e25db68e262708e27f1ea5f6f88b0de01280449, tree76edc6e8ee178d3a1c125a11e3cd290231816fd7 and clean short status. Text/JSON reads, rg navigation, sha256sum, owned heredocs, awk insertion, diff, sed and cmp are the only work types. Diff status1 is the expected textual difference, not a failed test. Initial broad output truncation was resolved for critical source/contract sections with bounded follow-up reads; missing-path navigation observations are disclosed in `read-ledger.md`. No runtime/import/AST/compile/NPY/native/probe/Docker/install/lint/types/tests/benchmark/full gate ran.

Deliverables are candidate `study.py`, `exact.diff`, `api-option-and-preservation-map.md`, this completed detailed report, DISTINCT `final-author-message.md`, `inputs.sha256`, `read-inputs.sha256`, `read-ledger.md`, `accounting.json`, final static verification logs and `outputs.sha256`. Output inventory excludes itself to avoid a circular digest. Input and read inventories bind actual opened inputs; accounting and read ledger have their own output hashes. Final hashes are outside tracked/determining bytes.

Requested configuration is Sol/high, fresh fork-none author attempt1, no delegation. Actual serving model/effort, response/input/cache/output metering, verified money and complete elapsed/owner-wait totals are UNKNOWN. Human numeric quota is NOT SET. Optional separate memory/delegation/read-only controls are unavailable; shared filesystem/permissions and role restrictions are prompts, not engineered isolation. Prior campaign charges are unchanged and coordinator-owned. No disposable scratch, background processes or temporary fixtures were created; durable author evidence remains for review. No cleanup/deletion was performed.
