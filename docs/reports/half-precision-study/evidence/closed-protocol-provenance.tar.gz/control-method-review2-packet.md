# HP114 fresh independent CONTROL-METHOD delta review2

You are the assigned fresh report-only reviewer, no author history, no child
launch/delegation, no repairs or execution. Apply review-work independent method/
oracle/risk principles in this explicitly scoped scientific-method mode, not
B/D/product/whole-study acceptance. Root authorizes this source-only review.

## Target and permitted inputs

Review CM1/CM2 startup admission/capture/post-call identity correction only.
Immutable study.py9daa4744fbb30833f26d8cc249f0db27c26502f3410216fa808910fc09a402c7
and manifest6ae262ce4d228feff8d4dc2e2831dce010bbadd3a156d018402b7cbf272d604d
remain from source349bf30/tree8e5cc9bd. Current tracked8ad87d3 is status-only;
coordinator may further refresh task/ledger, never target source. No final113
rebase or study/math/vector change. Root actual execution remains held.

Read only:
- AGENTS/PROJECT/review-work and relevant role/model guidance.
- Prior independent report `/workspace/work/campaign/evidence/114/control-method-review1.md`
  SHAaa2d9a28ad225e53886196a31e3f387945d6c0fd46cd11bbdc9fbec06345b8c8.
  Assess retained finite-control applicability independently by unchanged hashes;
  no need to reopen unrelated resource lifecycle implementation.
- `control-startup-proposal2/` preimport_control.py, method-delta.md,
  admission-proposal.json, command-proposal.sh.txt, materials.sha256 and
  material-paths.txt; external control-startup-proposal2-index.sha256.
  Wrapper619a4a6a39210cc6f53d63e1701d1ffd24d5c35c5ef3837cab0326b2cc7b60a9;
  command24e412cb92f9760d42b0474a028a364ee5344017a1d54632e248d620d64a8811;
  material index5afcbe0f9024f8a11e983907b3d728e2772396d5aee1df8bc2d4f83ac4cfec66.
- Existing unchanged scripts/source_free_check.py SHA
  cdf5894e916c9445a1627da9e654d853b8f772fba9f376cee80680fed9701564
  and scripts/source_free_sitecustomize/sitecustomize.py SHA
  5c2992da3a882201fb15e5e8cc2a9cdbbbab6f2d6ea7a3db8a4eda4d5d73fc6f.
- Exact study/manifest and needed primary current product/dependency/stdlib source
  to challenge this limited delta (no import/execution). Control-method-inputs1
  frozen originals may confirm byte identity. Do not read author reports/tasks/
  ledger/conversations/lessons/116 unrelated work or numerical candidate outputs.

Allowed commands: read-only shell/Git/hash source inspection. NO Python at all,
AST/compile/lint/format/test, module/product/dependency/control/wrapper execution,
lifecycle probe, installs, benchmark, repair or extra control. Mathematical and
limit/exit reasoning is by source inspection only. No approved admission/grant
exists; proposal authorizedfalse/missing exact hashes cannot authorize execution.

## Concrete questions / verdict scope

1. Does unchanged source_free_check command + outer exclusive stdout/startup.stderr
   capture retain warnings/native stderr beginning before either interpreter's
   imports? PYTHONWARNINGS=always is set before startup; injected sitecustomize is
   unchanged source-free rendering only. The study's original record[warning]
   coverage stays incomplete for imports; root must read full raw stderr before
   any qualification. Does the delta clearly retain that obligation?
2. Does stdlib-only wrapper put verified resourceAS/CPU and real timer before
   runpy can execute immutable study and product/native imports, with same target
   PID and no wrapper spawn? Assess finite constants: AS min(currentVm+1GiB,
   2GiB,existing finite soft/hard), min512MiB allowance; CPU currentceil+30s bounded
   by existing limits/min5s allowance/hard≤soft+1; wall90s + renderer120s. These are
   one-case safety settings, not human/product/RAM or performance promises. Does
   any failure/timeout/exception/teardown path masquerade as successful evidence?
   Native calls may delay Python alarm, so ordinary renderer timeout is required.
3. Admission: exact wrapper/study/manifest/grant/material identities, pinned
   interpreter/prefix/thread/backend/diagnostic environment, newly root-reviewed
   context≤60s old, actual complete effective ancestor list or refusal, fresh
   MemAvailable/cgroup free≥3GiB and disk≥256MiB. Root must still supply actual
   context/grant and resolve hidden limits; neither stale proposal nor a true
   boolean alone is runtime proof. Limits are per target after stdlib startup;
   parent/interpreter/sitecustomize startup and aggregate RSS are not capped or
   measured by this wrapper. Native IO initialization is explicitly admitted by
   frozen material list/context, not described as inert.
4. Finally-after-calls provenance: actual sys.modules file paths/hashes/versions,
   both non-null exact expected FFT paths/binary hashes matching admitted files,
   maps, unchanged source/grant/admission and same PID. Missing/unexpected identity
   forces nonzero/incomplete; old pre-FFT snapshot is not silently replaced.
   Sidecar write/final maps failure and renderer termination can leave partial
   files; root acceptance requires complete outputs AND successful transport,
   never just an early pending status. Does any wrong/missing provenance pass?
5. Prior finite math/representation controls are retained under identical source
   and constants; no phase/noise witness is added or claimed. Is any delta changing
   those meanings rather than startup/capture/safety? Root must manually inventory
   every expected/actual control outcome, all warnings/arrays and wrappers after
   later actual execution. Exit0 is observation only. FullW/diagnostic matrix,
   resource quarantine/working116method/final113 and scientific acceptance remain.

Return scoped ACCEPT (suitable proposal for root's separate fresh admission and
execution decision), actionable findings or INCOMPLETE. Explain retained review1
scope and remaining runtime assumptions. No unconditional actual command execution,
method runtime capability, B/D/scientific report or memory-benefit qualification.
Reviewer never repairs or approves own repair. A concrete flaw returns to named
coordinator wrapper owner for diagnosis and fresh affected review.

## Freshness/output/accounting

Fresh fork_turnsnone requested gpt-6.1-sol/high, project conservative scientific
setting. Actual serving attribution/effort/meters unknown where not exposed.
Optional memory/delegation/read-only controls unavailable; shared filesystem and
prompt-only restrictions are not engineered isolation. No author conversation
inherited. Report forbidden exposure rather than proceed as independent reviewer.

Write ONLY new `/workspace/work/campaign/evidence/114/control-method-review2.md`,
never overwrite review1/target. Return separate final message and notify campaign
root `/root` and issue coordinator (which yields WAIT). Include exact reviewed
identities, finding/risk/retained-scope decisions, commands/statuses and limitations,
own scratch/process facts. No tracked edit/commit/rebase/push/publication/closure.
This is fresh control-method review2; prior INCOMPLETE, all author/check/failure/
repair charges remain. Human numeric scientific limits not set; chosen safety
settings are experimental admission bounds. Missing meters/cost/time are unknown.
