"""ROOT finite selected12 invocation procedure, not a numerical observer.

Separate later release and row-specific actual scientific applicability required.
Unwrapped unchanged source parent owns every child and sole exact-PID wait4.
"""
from pathlib import Path
import copy, hashlib, json, subprocess, time

E=Path('/workspace/work/campaign/evidence/114');W=Path('/workspace/work/issue-114')
M01=E/'current-method-attempts-1/M01-current-controls-attempt1'
PREFIX=json.loads((M01/'launch.json').read_text())['cleared_prefix']
PROTO=json.loads((E/'actual-bound-instance-2/binding-prototype.json').read_text())
PY=str(W/'.venv/bin/python');SRC=str(W/'docs/reports/half-precision-study/study.py')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,v):
 with Path(p).open('x') as f:json.dump(v,f,indent=2,sort_keys=True);f.write('\n')
release=json.loads((E/'ROOT-matched-resource12-release-2.json').read_text())
assert release['runtime_released'] is True and release['procedure_sha256']==sha(__file__)
expected=[[row,strategy,rep] for row in ['W02','W05'] for rep,arms in [(1,['PREPARED_WIDER','PREPARED_HALF']),(2,['PREPARED_HALF','PREPARED_WIDER']),(3,['PREPARED_WIDER','PREPARED_HALF'])] for strategy in arms]
assert release['cases']==expected
BASE=E/'current-resource-captures-2';BASE.mkdir(exist_ok=False)
for row,strategy,rep in release['cases']:
 runid=f'R2-{row}-{strategy}-r{rep}-attempt1';K=BASE/runid;K.mkdir(exist_ok=False);R=E/'current-runs-2'/runid;assert not R.exists()
 B=copy.deepcopy(PROTO);b=K/'binding.json';g=K/'grant.json';c=K/'context.json';slot='$ROOT_BINDING_SHA256'
 def git(*args):return subprocess.check_output(['git','-C',str(W),*args]).decode().strip()
 candidate=B['bindings']['candidate'];assert git('rev-parse','HEAD')==candidate['commit'] and git('rev-parse','HEAD^{tree}')==candidate['tree'] and git('rev-parse','HEAD^')==candidate['parent'] and not git('status','--porcelain','--untracked-files=no')
 assert hashlib.sha256(subprocess.check_output(['git','-C',str(W),'diff','--binary','HEAD'])).hexdigest()==candidate['tracked_diff_sha256']
 parent=[PY,SRC,'--route','resource','--grant',str(g),'--binding-receipt',str(b),'--binding-sha256',slot,'--row',row,'--strategy',strategy,'--repetition',str(rep),'--run-id',runid]
 child=[PY,SRC,'--route','resource-child','--grant',str(R/'grant.original.json'),'--binding-receipt',str(b),'--binding-sha256',slot,'--row',row,'--strategy',strategy,'--repetition',str(rep),'--run-id',runid]
 B['bindings'].update(route='resource',output=str(R),grant={'original':str(g),'copy':str(R/'grant.original.json')},parent_argv_shape=parent,target_argv_shape=child)
 write(b,B);bh=sha(b)
 code=(E/'actual-integrated-environment-2/C-observation-code.txt').read_text().replace('per-M01','per-'+runid)
 cp=subprocess.run(PREFIX+[PY,'-c',code],capture_output=True,timeout=30);(K/'C.stdout').write_bytes(cp.stdout);(K/'C.stderr').write_bytes(cp.stderr);assert cp.returncode==0,cp.stderr
 C=json.loads(cp.stdout);assert C['sigint_default'] and C['sigchld_default']
 C.update(case=runid,row=row,scope='Fresh Root admission for ONE selected small matched prepared-stage resource child. Prior row-specific raw/seed/prepared/used-field/operation applicability separately accepted and bound in Rootrelease. Source own exact simultaneous ledger is checked before spawn/setup/call; W05 diagnostic ledger here conservatively covers selected fixed small arrays with ample current margin. Unknown native/metadata/background/pressure/ancestor reserves conditional, notzero/16GiBfit.',admission_rationale='Actual visible charged headroom and disk greatly exceed source-derived conservative W05 modeled payload. Only ONE unchanged selected prepared-stage child, no reference or concurrent study/test/install/benchmark/observer RSS sampler. Source own specific standalone ledger and current guard repeated. Admit only '+runid,binding_sha256=bh)
 write(c,C)
 q=release['qualification_records'][row];assert sha(q['path'])==q['sha256']
 G={'authorization':'HP114_NUMERICAL_WINDOW','environment':'simrecon-campaign-ubuntu','route':'resource','bindings':B['bindings'],'candidate':B['bindings']['candidate'],'binding_receipt':{'path':str(b),'sha256':bh},'context':{'path':str(c),'sha256':sha(c)},'harness_sha256':B['artifacts']['harness_sha256'],'manifest_sha256':B['artifacts']['manifest_sha256'],'runs':[[row,strategy,rep]],'run_id':runid,'qualification_sha256':{row:q['sha256']},'resource_admission':{'accepted':True,'rationale':C['admission_rationale'],'evidence_sha256':sha(c)},'deadline_seconds':60.0,'startup_seconds':10.0,'term_grace_seconds':2.0,'kill_reap_seconds':5.0,'readiness_bytes':4096}
 write(g,G)
 inner=[bh if x==slot else x for x in parent];target=[bh if x==slot else x for x in child]
 L={'scope':'ROOT separately releases ONE of fixed selected12 in exact predeclared order. Unchanged source parent solewait4/native terminal accounting, no GNUtime wrapper or diagnostic reference in child, no automatic retry. Stop on unexpected/missing closure; no scientific benefit/accuracy/activation acceptance by collection.','run_id':runid,'runtime_released':True,'release_path':str(E/'ROOT-matched-resource12-release-2.json'),'release_sha256':sha(E/'ROOT-matched-resource12-release-2.json'),'Bsha':bh,'Csha':sha(c),'Gsha':sha(g),'inner_argv':inner,'target_argv':target,'outer_argv':PREFIX+inner,'source_output_absent':not R.exists(),'time_unix_ns':time.time_ns()}
 write(K/'launch.json',L);print('START',runid,flush=True);start=time.time_ns()
 with (K/'stdout.txt').open('xb') as out,(K/'stderr.txt').open('xb') as err:r=subprocess.run(L['outer_argv'],stdin=subprocess.DEVNULL,stdout=out,stderr=err)
 a=json.loads((R/'attempt.json').read_text());terminal=a.get('terminal')
 matched=r.returncode==0 and a['status']=='observed-pending-independent-scientific-qualification' and terminal is not None and terminal['exit_code']==0 and terminal['signal'] is None
 write(K/'ROOT-target-terminal.json',{'scope':'Actual selected resource collection only; independent assessment pending','returncode':r.returncode,'start_unix_ns':start,'finish_unix_ns':time.time_ns(),'status':a['status'],'terminal':terminal,'matched_expected_collection':matched,'attempt_sha256':sha(R/'attempt.json'),'stdout_sha256':sha(K/'stdout.txt'),'stderr_sha256':sha(K/'stderr.txt')})
 assert a['materials_before']==a['materials_after'] and a['git_before']==a['git_after']
 assert not a['wait_ownership_lost'] and not a['coordinator_recovery_required']
 assert (R/'grant.original.json').read_bytes()==g.read_bytes()
 identities={'parent':a['parent_identity'],'child':a['owned_child']};write(K/'identities-to-close.json',identities)
 code="from pathlib import Path\nimport json\nD=json.loads(Path("+repr(str(K/'identities-to-close.json'))+").read_text());boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();out={}\nfor name,v in D.items():\n try:\n  f=(Path('/proc')/str(v['pid'])/'stat').read_text().rsplit(')',1)[1].split();out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'current_start':int(f[19]),'original_identity_absent':boot!=v['boot_id'] or int(f[19])!=v['start_ticks']}\n except FileNotFoundError:out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'original_identity_absent':True}\nassert all(x['original_identity_absent'] for x in out.values()),out\nprint(json.dumps(out))\n"
 closed=subprocess.run(PREFIX+[PY,'-c',code],capture_output=True,timeout=20);(K/'postclose.stdout').write_bytes(closed.stdout);(K/'postclose.stderr').write_bytes(closed.stderr);assert closed.returncode==0,closed.stderr
 # All processes are closed before external counterpart identity analysis.
 native_collection_matched=matched
 identity_comparison={'scope':'Actual caller/sevenoutput canonical shape/dtype/component identity check only; no newly captured fullmetadata/trace or scientificaccuracy/benefit proof','evaluated':False,'native_collection_matched':native_collection_matched}
 if matched:
  child_record=json.loads((R/'child.json').read_text())
  expected=release['identity_expectations'][row][strategy][str(rep)]
  actual={'caller':child_record['caller'],'outputs':{name:v['identity'] for name,v in child_record['outputs'].items()},'branches':child_record['branches']}
  assert set(expected)=={'caller','outputs','branches'}
  assert set(expected['outputs'])=={'image','x_um','y_um','z_um','carriers_cyc_um','modulation','raw_modulation'}
  assert set(expected['caller'])=={'shape','canonical_dtype','content_sha256'}
  assert all(set(v)=={'shape','canonical_dtype','content_sha256'} for v in expected['outputs'].values())
  identity_comparison.update(evaluated=True,expected=expected,actual=actual,all_expected_identities_equal=actual==expected,child_record_sha256=sha(R/'child.json'))
  matched=matched and actual==expected
 write(K/'ROOT-actual-counterpart-identity-comparison.json',identity_comparison)
 write(K/'ROOT-closed-collection-summary.json',{'scope':'Collected selected resource actual, no scientific/benefit acceptance','run_id':runid,'matched_expected_collection':matched,'status':a['status'],'terminal':terminal,'postclose_identities':json.loads(closed.stdout),'attempt_sha256':sha(R/'attempt.json'),'material_git_grant_unchanged':True,'counterpart_identity_comparison_sha256':sha(K/'ROOT-actual-counterpart-identity-comparison.json'),'native_collection_matched':native_collection_matched,'time_unix_ns':time.time_ns()})
 print('CLOSED',runid,a['status'],'peakKiB',terminal['native_ru_maxrss'] if terminal else None,'matched',matched,flush=True)
 assert matched,(runid,a['status'],a.get('failure'))
print('SELECTED_RESOURCE12_COLLECTED_CLOSED; independent final assessment pending',flush=True)
