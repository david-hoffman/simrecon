"""Read only this completed case's bounded JSON/NPY metadata and tiny witnesses."""
import ast
import hashlib
import json
import math
from pathlib import Path
import re
import struct

BASE = Path("/workspace/work/campaign/evidence/114")
CASE = BASE / "study/control-method-K01-attempt2"
TRANSPORT = BASE / "control-startup-attempt2"

def bounded_json(path):
    if path.stat().st_size > 1024**2:
        raise RuntimeError("unexpected metadata size")
    return json.loads(path.read_text())

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(65536), b""):
            h.update(data)
    return h.hexdigest()

def number(v):
    return struct.unpack(">d", bytes.fromhex(v["float64_bits_be"]))[0] if isinstance(v, dict) else v

def header(path, expected_sha):
    if path.stat().st_size > 262144:
        raise RuntimeError("unexpected control array file size")
    assert sha(path) == expected_sha
    with path.open("rb") as stream:
        assert stream.read(6) == b"\x93NUMPY"
        version = tuple(stream.read(2))
        assert version in ((1, 0), (2, 0), (3, 0))
        width = 2 if version == (1, 0) else 4
        size = int.from_bytes(stream.read(width), "little")
        assert size <= 65536
        info = ast.literal_eval(stream.read(size).decode("utf8" if version == (3, 0) else "latin1"))
        start = stream.tell()
    assert set(info) == {"descr", "fortran_order", "shape"}
    assert info["descr"] in ("<f2", "<f4", "<f8", "<c16", ">f4", ">c16")
    assert type(info["fortran_order"]) is bool
    assert type(info["shape"]) is tuple and all(type(n) is int and n >= 0 for n in info["shape"])
    payload_bytes = math.prod(info["shape"]) * int(info["descr"][2:])
    assert path.stat().st_size == start + payload_bytes
    return dict(path=str(path), dtype=info["descr"], shape=list(info["shape"]),
                fortran=info["fortran_order"], data_offset=start, payload_bytes=payload_bytes,
                file_bytes=path.stat().st_size, sha256=expected_sha)

j = bounded_json(CASE / "run.json")
p = bounded_json(TRANSPORT / "wrapper/post-import.json")
c = j["result"]
assert j["status"] == c["status"] == "controls-observed-pending-review"
headers = {}
for key, entry in j["array_index"].items():
    assert re.fullmatch(r"arrays/[0-9]{5}\.npy", entry["path"])
    path = CASE / entry["path"]
    assert path.stat().st_size == entry["nbytes"]
    headers[key] = header(path, entry["sha256"])
assert len(headers) == 74
small_headers = []
for i, entry in enumerate(c["numpy_serialization"]):
    h = header(CASE / f"control-array-{i}.npy", entry["file_sha256"])
    assert h["dtype"] == ("<f8", ">f4", ">c16", "<f2")[i]
    assert h["shape"] == ([4], [4], [2], [0, 2])[i]
    assert h["payload_bytes"] <= 32
    with Path(h["path"]).open("rb") as stream:
        stream.seek(h["data_offset"])
        raw = stream.read(h["payload_bytes"])
    component = int(h["dtype"][2:]) // (2 if h["dtype"][1] == "c" else 1)
    canonical = (b"".join(raw[k:k+component][::-1] for k in range(0, len(raw), component))
                 if h["dtype"].startswith(">") else raw)
    assert hashlib.sha256(canonical).hexdigest() == entry["original"]["content_sha256"]
    assert entry["original"] == entry["roundtrip"]
    assert entry["dtype_endian_equal"] and entry["shape_content_equal"]
    small_headers.append(h)

packed = headers["K01.real.packed"]
assert packed["dtype"] == "<f2" and packed["shape"] == [16] and packed["payload_bytes"] == 32
with Path(packed["path"]).open("rb") as stream:
    stream.seek(packed["data_offset"])
    actual_half_bits = list(struct.unpack("<16H", stream.read(32)))
expected_half_bits = [0,0x8000,0,0x8000,1,0x8001,0x0400,0x8400,0x3c00,0xbc00,
                      0x7bff,0xfbff,0x7c00,0xfc00,0x7c00,0xfc00]
assert actual_half_bits == expected_half_bits
assert c["K01_range"]["half_limits"] == {
    "maximum":65504.0,"smallest_normal":2**-14,"smallest_subnormal":2**-24,"epsilon":2**-10}
assert all(r["identical_ieee_components"] for r in c["scalar_wire"]) and len(c["scalar_wire"]) == 7
expected_hash = hashlib.sha256(struct.pack("<4d", 0.0, -0.0, 1.0, -2.0)).hexdigest()
for r in c["canonical_hashes"]:
    assert r["content_equal"] and r["shape_preserved"]
    if r["case"] not in ("empty", "scalar"):
        assert r["identity"]["content_sha256"] == expected_hash
assert len(c["canonical_hashes"]) == 7
assert len(c["raw_generation"]) == 18 and all(r["identical"] for r in c["raw_generation"])
for r in c["K03_products"]:
    a, n = r["magnitude"], r["n"]
    energy = n * 65 * a*a / 64
    scale = n if r["pattern"] == "constant" else 0
    cross = (scale * 95 * a*a/128, -scale * 5 * a*a/32)
    assert r["exact_sx"] == r["original_sx"] == r["quantized_operands_wide_sx"] == energy
    for key in ("exact_cross", "original_cross", "quantized_operands_wide_cross"):
        assert (number(r[key]["real"]), number(r[key]["imag"])) == cross
assert len(c["K03_products"]) == 16
cancel = c["K03_cancellation"]
assert number(cancel["explicit_half_left_association"]) == cancel["expected_half_left_association"] == 0
assert cancel["quantized_operands_wider"] == cancel["exact_dyadic_sum"] == 1
error = c["error_observer"]
assert error["observed"]["max_absolute"] == error["expected_max_absolute"] == 1
assert error["observed"]["rms"] == error["expected_rms"] == math.sqrt(5/12)
assert error["observed"]["relative_l2"] == error["expected_relative_l2"] == 0.5
for name in ("zero_rule", "strided_same_values", "transposed_storage_same_values", "empty_rule"):
    assert all(number(error[name][key]) == 0 for key in ("max_absolute","rms","relative_l2"))
assert all(r["disposition"] == "rejected" for r in c["incomplete_record_controls"])
assert len(c["incomplete_record_controls"]) == 2
fft = c["K01_fft_policy"]
assert fft["complex32_dtype"]["exception"] == "TypeError"
for name in ("numpy.fft", "scipy.fft"):
    row = fft[name]
    assert row["input"]["dtype"] == "<f2" and row["input"]["shape"] == [16]
    assert row["forward"]["real"]["dtype"] == row["forward"]["imag"]["dtype"] == "<f4"
    assert row["inverse"]["dtype"] == "<f4" and row["scipy_effective_workers"] == 1
    assert row["forward_norm"] == row["inverse_norm"] == "backward"
    assert row["unsupported_norm"]["exception"] == "ValueError"
    assert row["internal_arithmetic_precision"] == "unknown"
assert len(j["warnings"]) == 19 and all(w["category"] == "RuntimeWarning" for w in j["warnings"])
assert {m:sum(w["message"] == m for w in j["warnings"]) for m in set(w["message"] for w in j["warnings"])} == {
    "overflow encountered in cast":3,"overflow encountered in multiply":12,
    "overflow encountered in reduce":2,"invalid value encountered in reduce":2}
assert not (TRANSPORT / "startup.stderr.log").read_bytes()
assert p["pid"] == 46240 and p["same_pid"] and p["target_exit"] == 0
assert not p["missing_or_unadmitted_fft"] and not p["immutable_inputs_changed"]
assert not p["alarm_fired"] and p["failure"] is None
assert all(r["exact_expected_fft"] and r["matches_admitted_material"] for r in p["required_fft_after_calls"].values())
assert len(p["loaded_modules_after_calls"]) == 344
assert {name for name,r in p["loaded_modules_after_calls"].items() if not r["matches_admitted_material"]} == {
    "scipy._external", "scipy._external.packaging_version"}
result = {"status":"all selected expected-control and bounded array checks satisfied",
          "run_sha256":sha(CASE/"run.json"),"post_sha256":sha(TRANSPORT/"wrapper/post-import.json"),
          "headers":headers,"tiny_npy_headers":small_headers,"K01_half_bits":actual_half_bits,
          "array_files":78,"largest_file_bytes":max(h["file_bytes"] for h in headers.values()),
          "limits":"No NumPy/product import or rerun. Only headers, four <=32B payloads and one32B half witness decoded. Namespace/manual-context disposition is separate; no science/resource acceptance."}
with (BASE/"attempt2-metadata-assessment.json").open("x") as stream:
    json.dump(result,stream,indent=2,allow_nan=False)
    stream.write("\n")
print("bounded completed-case metadata/78headers-hashes/tiny witness assessment satisfied; no target rerun")
