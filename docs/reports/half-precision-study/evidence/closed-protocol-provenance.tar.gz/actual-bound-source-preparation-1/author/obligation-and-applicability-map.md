# HP114 five-call transition and Option A — obligation and applicability map

Completed named NONBLIND source/method author preparation. Static text only. This map describes candidate `study.py` SHA256 `d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094`, derived solely from accepted external baseline `3cfafc5c491c12d3310317dda4d1fc7cc8dc9ea14cfb15546ec83ef45916628d`. It is no independent verdict, actual-parent freeze, integration, run release or scientific qualification.

## Exact source changes

Baseline line numbers are immutable3cf; candidate locations identify the remaining surrounding code. The entire source diff has six hunks, six removed lines and seven added lines: five removed CALL statements and one replaced preparation-call line. No other byte ranges change.

| Change | Baseline location | Candidate location and effect | Preserved meaning / remaining obligation |
| --- | --- | --- | --- |
| Retire module CALL | 20 `execution_hold()` with its inline comment | Module helper remains at15; imports begin after the resulting blank lines | Raising helper body15–17 unchanged. Import no longer encounters this unconditional refusal; stdlib imports and local monotonic origin become reachable if someone imports it. This author did not import it. Execution remains administratively prohibited; binding/grant checks still guard numerical routes. |
| Retire authorize CALL | 362 `execution_hold()` | authorize359, immediately followed by existing global/load_bindings statements | The independently pinned external binding load, unbound check, authorization, context, materials, environment, exact-run and qualification checks retain identical bytes. This is no no-op helper substitution. |
| Retire resource_child CALL | 2203 `refuse_quarantined_resource_launch()` | resource_child2199; existing entry clock then authorize follow | Raising resource refusal helper2194 and RESOURCE_LAUNCH_HOLD119 remain unchanged. Entry authorization, resource admission, qualification/control release, numerical imports and caller/result policy remain. Removal alone supplies no safe native route or numerical applicability. |
| Retire resource_parent CALL | 2563 same refusal | resource_parent2564; load_bindings remains before EVIDENCE use/raw mkdir | Single exact-PID lifecycle ownership, bootstrap/readiness/argv/native/identity checks, wait4 status/native usage, bounded signaling/reap/recovery and all refusal/failure records retain their original source. No Popen/fallback path or probe added. |
| Retire main CALL | 3165 `execution_hold()` | main3165; existing entry clock and argument parser follow | Required grant/receipt/digest/row/strategy/repetition/run-id parsing, load_bindings before dispatch, diagnostic authorize and no-overwrite raw destination remain. |
| Align direct preparation declaration | 2276 one-line public prepare call | 2273–2279 multiline public prepare call | Keeps caller and prep_options, adds `**OPTICS`, `linespacing_um=carrier["linespacing_um"]`, `phase_start_angle_rad=carrier["phase_start_angle_rad"]`. All downstream extraction/packing/release/finite checks remain identical. No negative_angle_step argument added; public defaultFalse already equals the selected workflow setting. |

Both raising helper definitions remain raising, with no caller remaining anywhere in the candidate. Their strings/docstrings and the RESOURCE_LAUNCH_HOLD constant remain literal historical wording by the exact narrow ownership instruction. No bypass flag, alternate guard, source-root inference or replacement launcher is introduced.

## Why Option A is a declaration alignment

ROOT choice record `6cdbce665c4d4c2ea9e4ca5ca2b028756be4b9cc56e005d3f76dbfdd68403048` selects Option A before data. The completed public applicability report `f83f09065f2cc5d2d8082fd19270b1211ac29d8b39e3a20a17d0e809fd115243` records the discrepancy and distinguishes inactive metadata hypotheses from observed numerical effects. Relevant public issue-113 source was inspected as text: modes.py430–464 defaults,708–711 optical requirement,1041–1046 resolved settings; reconstruct.py333–348 public preparation composition; parameter_estimation.py1135–1140/1181–1196 initial validation and known branch.

| Field | Old standalone default | Candidate declaration | Selected workflow declaration |
| --- | --- | --- | --- |
| wavelength_nm | None | OPTICS=520 | 520 |
| numerical_aperture | None | OPTICS=1.2 | 1.2 |
| immersion_index | None | OPTICS=1.33 | 1.33 |
| linespacing_um | None | carrier setting0.4 | 0.4 |
| phase_start_angle_rad | 1.57193 | carrier setting0.0 | 0.0 |
| negative_angle_step | False | omitted; defaultFalse | False |

The five prior differences stay in historical evidence. The direct call now explicitly supplies their workflow declarations. Supplying optics also changes scalar validation/setup work and recorded resolved settings; this is inside setup elapsed/cumulative and terminal child high-water. This author does not claim zero timing cost, equality of numerical outputs, successful public validation, fixture qualification or a product defect. For selected no-off/no-drift/uniform W02/W05, the earlier source mapping suggested these differences were inactive metadata; that remains a source-supported hypothesis, not a measured fact. No data-driven normalization, favorable fitting, seed change or silent record rewriting occurs.

## Unchanged binding, guard and source obligations

| Area | Byte-preserved source meaning | ROOT / independent review work before later use |
| --- | --- | --- |
| Source-unbound initialization | ROOT/EVIDENCE/EXPECTED=None; BINDINGS=dict.fromkeys; BINDING_RECEIPT and GRANT_CONTEXT=None. Existing load_bindings alone populates actual globals. BASE/HISTORICAL_EXPECTED remain historical. | Establish accepted113/default path and actual integration, then externally bind actual clean candidate, source/manifest, interpreter/profiles/materials/startup/native/route/argv/grant paths. Do not embed final identities in this source. |
| B loader | Bounded independently hashed external receipt, exact schema/key/path checks, actual source/root/interpreter/profile/candidate/material/native/bootstrap/argv checks, grant original/copy distinction and consistency retained. | Independently pin B and its determining inputs; actual B is absent. This author creates none. |
| C/G/L and authority | Fresh distinct context digest, exact numerical-window authorization, frozen source/manifest/material hashes, route/run/headroom/control or qualification requirements retained; physical resource admission and final ROOT recheck remain external. | Construct B, fresh physical C, later G, literal invocation and L/fresh recheck without a selfhash cycle. Removal of refusals is no grant. |
| Qualification and safety | Exact harness/manifest qualification identities, reviewed qualification hash, route restrictions, one-run resource grant, environment/thread/backend, numerical version/import path, finite/conversion/resource/context checks remain. | Freeze actual source+manifest before QUALIFY. Later edits require refreeze and affected requalification. ROOT must assess semantic applicability; a stored hash is insufficient. |
| Native/lifecycle | Existing readiness/marker/nonce/group/session/boot/start ownership, exact-PID wait4, deadline/TERM/KILL/reap and no retry/fallback semantics retained. | Independently admit actual native method, headroom and lifecycle controls. Pre-exec peak retention across exec remains unresolved. |
| Observers/schema | Local clocks, bounded chunk/file hashing, serialization, seven required common-output identities, record validators and allowlists remain. | Validate actual endpoints/scopes and original records; no new full trace/seed/metadata/lifetime observation is manufactured by this transition. |
| Scientific fixture | Generator, resource_caller, resource_stage seeds/formulas, settings, transfer including W01 K1, pack/unpack, all H1/H2/H3 scopes/tolerances/error/sign/decision meanings retained. | Assess actual raw/seed/used-field/transfer/grid/noise/caller/output applicability and numerical effects independently. No positive equality assumed. |

## Preserved accepted finite inventory and science

Accepted manifest `26a3728ca1adecda950e60f9630fb9c4f535d4e56cfeb5036e902496eca32e38`, obligations `a49fb3af7f5215f156e81c20b7051b8956d02d61c26449249bf9fc9bc2f2ae17` and exact accepted §8A patch `a86bbe9bdb7851c18d8d2281c85219c47be6ed2b162b0a055bc6c75a0c3ad216` remain immutable referenced components. None is copied or edited under this ownership.

Ten rows remain W01–W06/K01–K04. Preserve 126 W numerical observations (six rows × seven modes × three fresh successful repetitions), six QUALIFY, four KERNEL, one bounded K01 CPU and twelve selected standalone observations:149 nominal records if successful. Controls and failed/refused/unsafe/skipped/partial attempts retain their separate accounting;149 is no human quota or retry cap.

Fixed twelve order remains: W02 rep1 WIDER, HALF; rep2 HALF, WIDER; rep3 WIDER, HALF; then W05 in that same repetition/arm order. Here WIDER/HALF abbreviate PREPARED_WIDER/PREPARED_HALF only. Each remains one independently admitted fresh child. No batch/order helper is added. Unselected standalone benefits remain UNMEASURED; numerical, diagnostic lifecycle and qualification obligations remain.

Accepted full-grid and upstream scientific obligations remain; the accepted conditional design covers all six rows: native coefficient rather than replay-buffer polynomial; correct negative-x quadrature conjugation before E+iO; unsplit native Nyquist; unnormalized inverse sum; signed coordinates and side-order phase/count factors; all grid points/times/directions/orders; explicit reference uncertainty. Actual F/K are conditioning inputs, not independently certified truths. Separate raw/cast/phase/noise/preparation, transfer/stencil/support/filter and estimator/search/reuse/floor/fit reference/decision assessment remains. W06 ideal rank/sign witnesses and K04 limited formula witnesses retain their limited meaning. No broad upstream reference framework or new capture extension is authored. ROOT may reuse accepted public runtime/math/compatibility evidence with precise actual113/default-material applicability; missing independent premises may support scoped UNRESOLVED and no-activation conclusions. A concrete retained-QUALIFY assessment or materialized full-grid conditional polynomial is future work only if needed for the intended claim, under separate ROOT release and affected review, with honest reference uncertainty. An unproved-quantity inventory does not require recreating a complete upstream implementation.

All six complete RM84 full/summary common projections remain required, beyond selected metrics: every array shape/dtype/component bit including signed zero; all recursive scalar/ordered metadata; original input/declaration array identity; complete compact records, traces/omissions, overlap descriptors, revisions and limitations. JSON/NPY alone cannot prove original live types/ownership/readonly/alias/no-cache/lifetime facts. Generic public RM84 reuse is proposed subject to actual-parent/default-profile/material/import applicability and independent acceptance. Known/T1 returned carrier identity is a proposed existing used-seed witness through the public known-branch rule, with explicit time-axis mapping; it is not nominal generator equality or a proof for searched/reused rows.

## Truthful later prose and provenance reconciliation — ROOT ownership

No candidate manifest is authored here. The accepted manifest remains a historical record of3cf. ROOT must not place it beside the transitioned source and claim its unconditional-call statements still describe the new phase. Before actual freeze ROOT owns the following narrow reconciliation, preserving historical originals and accepted §8A substance:

1. Label this five-call transition/source digest and Option A preparation declaration explicitly; preserve3cf and the earlier metadata discrepancy history as prior inputs, not current source meaning.
2. Replace current-phase claims of literal unconditional HOLD at manifest opening8–10, local clock52–54, loader/launch descriptions207/297/378, standalone description726, controls1018 and evidence index1086. Historical layers159 and other predecessor prose need explicit historical scoping. The raising strings remain dormant definitions, not unconditional entry calls. Correct obligations opening/current transition language while retaining all scientific obligations, rather than claiming its historical sentence “Every execution hold stays in source” applies unchanged.
3. State that stdlib imports/local origin are now reachable but unauthorized to exercise in this lane; numerical routes still require the unchanged external checks. Actual bindings remain unavailable and no runtime READY claim follows.
4. Describe the explicit preparation arguments and changed setup validation/metadata scope. Do not retain the old five differences as current call declarations, or call the change proven numerically inactive.
5. Resolve accepted113/integration, actual default/single profiles and expanded material/import applicability; publish truthful exact final candidate/source/manifest identities outside determining bytes. Preserve B→C→G→literal argv→L dependency direction without embedded candidate/selfhash/grant cycles.
6. Obtain fresh exact affected source/method/scientific review, freeze before QUALIFY, then complete separately admitted controls/qualification/study/SCI/full13/D/PRCI obligations. Source acceptance cannot stand in for actual-parent/material/native/numerical or independent final acceptance.

These are remaining internal responsibilities, not newly invented user approvals or external blockers. This completed source preparation leaves every actual release held.
