# HP114 actual-bound source transition — completed NONBLIND author report

The requested source preparation is complete within its narrow ownership. Candidate `study.py` SHA256 `d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094` retires exactly five unconditional refusal CALL statements and expands only the existing resource_child preparation call with ROOT's selected Option A arguments. No other source ranges change. This is a completed author artifact for fresh review, not self-acceptance, actual-bound readiness, integration or permission to run.

All actual113 acceptance/material/integration/native/runtime/grant dependencies remain held. ROOT's exclusive113 gate is respected. The provisional W114 d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67/treeb38e1e2f744b21814881a6dec9663b4723124ccc is packet context only; this author did not derive from or edit its tracked historical9daa source and does not attest current Git state.

## Authority, exact basis and ownership

The exact author packet is `../author-packet.md`, SHA256 `c83cd166dd30ddd42cc8db867dd41f75dc01d5f8a002550613fce9fbd999c08b`. W114 AGENTS.md, PROJECT.md, role-launch guidance and actual `half-precision-feasibility-v1.md` were read as text. The HP114 contract hash is `bb5963ce268e81dabf8773f8bce5f1b37e8153e2d18886ddef1e5766bd384284`. Its no-runtime source hold applies here; no ordinary cheap preflight exception was used.

The sole source parent is `/workspace/work/campaign/evidence/114/combined-source-preparation-1/author-correction-1/study.py`, SHA256 `3cfafc5c491c12d3310317dda4d1fc7cc8dc9ea14cfb15546ec83ef45916628d`. The observed hash matched the packet before transformation and was rehashed into inputs.sha256. No tracked9daa/private branch or alternate source supplied candidate bytes.

Immutable referenced components remain:

- accepted manifest `26a3728ca1adecda950e60f9630fb9c4f535d4e56cfeb5036e902496eca32e38`;
- accepted qualification obligations `a49fb3af7f5215f156e81c20b7051b8956d02d61c26449249bf9fc9bc2f2ae17`;
- exact accepted §8A proposed-contract-manifest patch `a86bbe9bdb7851c18d8d2281c85219c47be6ed2b162b0a055bc6c75a0c3ad216`.

None was rewritten or copied as a candidate manifest. `obligation-and-applicability-map.md` is a new map, not a replacement contract. `inputs.sha256` inventories17 opened substantive/provenance files with absolute paths; its SHA256 is `3f0ac6117ec2d84bdc3229b417cebf142844a73926f2431f6c7e30d726fd5392`.

ROOT choice `6cdbce665c4d4c2ea9e4ca5ca2b028756be4b9cc56e005d3f76dbfdd68403048` supplies scope/authority for Option A, not scientific proof. Completed applicability report `f83f09065f2cc5d2d8082fd19270b1211ac29d8b39e3a20a17d0e809fd115243` and transition report `770fb85031a260709f25407b2349903bc44a7c3deb4db188d29dd3bdfbd876e9` were used nonblind. ROOT's follow-up explicitly preserves this scope, permits precise reuse of applicable public runtime/math/compatibility evidence and scoped UNRESOLVED/no-activation conclusions, and disallows commissioning a full upstream implementation merely from an inventory of unproved quantities. No scientific result is imported by authority alone.

## Exact authored change and its semantics

The five removed statements are immutable3cf20 module execution_hold,362 authorize execution_hold,3165 main execution_hold,2203 resource_child refuse_quarantined_resource_launch and2563 resource_parent the same refusal. The inline comments attached to those removed statements disappear with their lines. All blank surrounding lines and every other untouched byte remain. Both raising helper definitions and RESOURCE_LAUNCH_HOLD are unchanged; the helpers now have no calls in this candidate. No helper becomes a no-op, and no bypass flag or replacement guard is added.

The one replacement call, immutable3cf2276, is now:

```python
                bands = sim.prepare_acquisition_bands(
                    caller,
                    **prep_options,
                    **OPTICS,
                    linespacing_um=carrier["linespacing_um"],
                    phase_start_angle_rad=carrier["phase_start_angle_rad"],
                )
```

The public preparation call remains at the same stage in resource_child; the actual caller, prep_options filtering, transfer/settings construction, metadata extraction, representation conversion, release order, KEEP ownership, observers and downstream call are unchanged. The public default negative_angle_step=False already equals the selected workflow declaration, so it remains omitted as instructed. This is the entire executable-source delta.

Call removal has a real phase consequence: module import would now reach stdlib imports, LOCAL_COLD_START_NS and ordinary definitions. No statement that the candidate is still unconditionally unimportable is made. The source header's preparation instruction and this role's hard prohibition remain administrative constraints; no import or execution was attempted. Numerical imports and substantive route work still encounter existing loader/authorization/material/environment/qualification/admission checks. Administrative HOLD is not technical isolation, and a removed refusal is not a numerical-window grant.

The main loader remains before route dispatch/raw output; authorize still loads/checks B before numerical imports; resource_parent loads before EVIDENCE access; resource_child calls authorize before numerical setup. Globals ROOT/EVIDENCE/EXPECTED and all None-valued BINDINGS retain their source-unbound initialization. Existing load_bindings alone assigns actual values. BASE and HISTORICAL_EXPECTED are historical facts rather than templates refreshed to current files.

Every genuine check remains byte-identical: independent B digest/schema/fields/path/source/interpreter/profile/material/startup/native/bootstrap/argv checks; exact original/copied grant relations; distinct fresh context; explicit ROOT numerical-window authorization; source/manifest/material/candidate/route/run identities; Ubuntu/per-worktree/thread/backend checks; exact qualification source/manifest and reviewed digest; one-attempt headroom admission; finite lifecycle control release; resource/environment/record/array/branch/clock-related existing logic. The source diff also preserves all native bootstrap/readiness/process identity/exact-PID wait4/reap/signal/deadline paths and their finite bounds. This author neither exercised nor newly qualified any of them.

## Static evidence for scope compliance

The candidate was produced by an awk text transformation that checked exact old text at each of the six immutable line locations and otherwise printed every input line unchanged. The transformation exited0. This reads the source as text; it does not parse/import/compile Python or run any study operation.

A full `diff -u` between the hashed immutable baseline and candidate produced source-delta.patch with six hunks, six deleted lines and seven added lines. Its normal difference status1 was explicitly required by the wrapper, which completed0. Five deletions are the refusal calls; the sixth is the old one-line prepare call; all seven additions are its multiline expansion. Thus there is no seventh changed source region or hidden helper/schema/fixture/guard alteration. The exact patch SHA256 is `b95761e5b462c3bed86afa66b7b774b9ecb9ba196dbecd781f428def4550f7bb`.

Static occurrence inspection finds only the helper definitions for execution_hold and refuse_quarantined_resource_launch, with zero remaining invocation occurrences. The preserved execution_hold definition begins candidate15; resource refusal definition2194; RESOURCE_LAUNCH_HOLD119; source-unbound globals46/50; load_bindings206; authorize359; resource_child2199; expanded preparation2273–2279; resource_parent2564; main3165. None of these textual observations is a runtime refusal/authorization proof.

The immutable source is3356 lines /146116 bytes; candidate3357 lines /145957 bytes. Net change is+1 line/-159 bytes, consistent with five call-line deletions and replacing one line with seven. Full-file SHA256 binds the exact candidate, not a syntax claim. No AST/compile/Ruff/type/test check was run or inferred. No Python interpreter was invoked, including for text manipulation. The final static input integrity pass reported all17 listed input files OK; patch-line counting independently reported6 hunks/6 removed/7 added; occurrence search returned only the two helper definitions.

## Preparation declaration, metadata and actual numerical applicability

Relevant public issue-113 preparation/workflow/known-estimator source was inspected only in the permitted default/declaration locations. These current file byte identities are inputs, not an accepted113 attestation: modes.py `85b3655ed25ed3664b954271e31a9a491ff6326c792e816e3b232d9135f24178`; workflow/reconstruct.py `50a4ce199f0cceca6ba9147a1ee218441b1b5588c03beabecef95828802e28fa`; parameter_estimation.py `527bb3459e295a5cec0a776a464d82723e32b0b6f64e3d47f3eb514529e19b38`.

Public modes.py defaults optics and linespacing toNone, phase_start_angle_rad to1.57193 and negative_angle_step toFalse. Public workflow preparation supplies optics and carrier declarations. Candidate OPTICS remains520nm, NA1.2, immersion1.33; unchanged settings supply spacing0.4um and phase-start0.0rad. The new kwargs therefore correct a concrete setup declaration/recorded-metadata difference before data, while preserving the old discrepancy in historical evidence. They also make preparation validate the supplied optical values and record them. Even for inactive selected drift/off/linked-phase branches, this setup work has timing/allocation scope; no zero-cost claim follows.

No source/paper equation alone establishes admitted raw bits, finite seed identity, prepared/noise/grid/transfer equality, successful known-vector fitting, full/summary compatibility or end-to-end scientific equivalence. generator NumPy trigonometry is not the actual workflow seed; resource_stage's scalar math expression remains unchanged. Diagnostic baseline.initial_carriers and actual resource used-carrier witnesses must be distinguished. For selected known/T1 paths, unchanged public known-branch copying may permit returned carriers to witness the used seed with a documented time-axis mapping, if fresh review accepts actual-parent/default-path/material applicability. This author proposes no equality or searched/reused generalization.

The two resource arms still share the same direct prep declaration and downstream wider operations. Option A does not create complete standalone prepared metadata/trace capture. The seven existing common-output identities, caller identity/statistics and branches remain the only child evidence in that schema; no reference arrays/workflow or generic object traversal were added to the measured child. Mapping to diagnostic H2_PREPARED/wider continuation remains a method/scientific assessment using applicable source, actual identities and qualified reference meaning. A matching image hash alone cannot establish all upstream or trace/ownership premises.

## Preserved finite contract and interpretation limits

The accepted149 nominal inventory remains126 W numerical observations +6 QUALIFY +4 KERNEL +1 CPU +12 selected standalone resource observations. Preserve ten rows, seven numerical W modes and three fresh successful repetitions. All unsuccessful/refused/skipped/unsafe/partial attempts remain visible and do not silently replace a success. The fixed twelve arm order is unchanged: W02 rep1 PREPARED_WIDER then HALF; rep2 HALF then WIDER; rep3 WIDER then HALF; W05 repeats that same order. This author adds no run/order helper, row, repetition, strategy, backend, seed, scale, tolerance or acceptance cutoff.

Unselected standalone resource benefits remain UNMEASURED, not evidence of no benefit. H1 diagnostic lifecycle and each H2 site's separate numerical meaning remain required. CPU promotion and paired float16 storage are not genuine half computation; H3 runtime remains unmeasured/documentary within its original limits. No full-workflow storage/speed/16GiB feasibility claim follows from prepared-stage setup or payload ratios.

Accepted full-grid/upstream obligations and all six complete RM84 common projections are preserved as scientific meaning, without this author silently solving or weakening them. Existing selected two-point replay/phase/forward diagnostics are not renamed complete-grid oracles. The accepted conditional polynomial requires native coefficient indexing, correct per-quadrature conjugation, no Nyquist splitting, unnormalized inverse, signed phase/coordinates and full extents; its finite evaluation must retain uncertainty. Conditioning on actual F/K does not independently certify raw/cast/phase/noise/preparation, safe transfer/filter stencils or estimator/search/reuse/floor/fit decisions. Existing W06/K04 witnesses retain their explicit limited labels.

ROOT may dispose a claim by precise reuse of independently accepted public runtime/math/compatibility evidence when the actual113/default-material/import profile is applicable. Missing independent evidence can remain scoped UNRESOLVED and support a no-activation recommendation. A concrete retained-QUALIFY assessment or full-grid conditional-polynomial materialization is future work only if needed for the intended claim, under a separate ROOT release and fresh affected review, with honest reference uncertainty. An unproved-quantity inventory alone does not demand recreating a complete upstream implementation. No broad oracle framework, new full upstream reference or capture extension was written here.

Successful existing QUALIFY exports full/summary value records and nested arrays, enabling future finite assessments; failed QUALIFY may not export a complete pair. JSON/NPY do not preserve every original live type/readonly/base/alias/no-cache/lifetime fact. Generic RM84 structural/ownership evidence and known/T1 seed inference remain proposed reuse, contingent on independent actual-parent/material applicability. All exact field/array/component/ordered metadata/trace/projection requirements remain distinct from physical usefulness and from resource measurement.

## Minimal remaining ownership and dependencies

1. ROOT owns actual113 acceptance and integration, final default/single boundary applicability, concrete materials/native/environment/headroom and truthful current-phase manifest/provenance. The new map identifies stale unconditional-call prose and Option A declaration updates. Historical accepted files remain immutable. No candidate manifest is included here.
2. A fresh ROOT-launched affected source/method/scientific reviewer assesses this exact candidate and patch, preserved guards/launch method, Option A setup meanings, proposed RM84/known-T1 reuse and any remaining concrete actual-material applicability gap. This author supplies no independent verdict and launches nobody.
3. ROOT freezes the actual source plus reconciled manifest before QUALIFY and creates independent external B, fresh physical C, later one-attempt G, literal argv and L/fresh ROOT recheck. No final HEAD/candidate/selfhash or B/C/G/L cycle is embedded in source. Editing source or manifest after qualification changes exact admission and requires explicit affected refreeze/requalification.
4. Separately released finite controls/QUALIFY/retained-record scientific assessment must supply only concrete evidence needed for claims still unresolved after applicable accepted reuse. This source turn supplies neither an automatic demand for duplicate live captures nor a new framework. If a concrete gap needs source/capture change, ROOT owns named correction/fresh review before admission.
5. Actual study observations, independent SCI, exact full13 Ubuntu gate, fresh D and authorized PR/CI remain later phases. No source completion, hash match, selected diagnostic or historical public gate replaces those outcomes. No new external approval blocker or human quota is identified.

## Completion and accounting boundary

All authored files reside only in the assigned `author/` folder. No source in a worktree, accepted evidence, manifest, Current, task index, B/C/G/L/grant/profile or runtime material was edited. No integration/publication occurred. Eight durable files comprise this handoff; `outputs.sha256` hashes the six payload/provenance files, and DISTINCT `final.txt` records the completed result plus output-manifest hash. Final.txt and the output-manifest hashes are reported externally to avoid self-reference. Neither report nor source embeds its own digest.

`accounting.md` records this one named nonblind author attempt, no delegated/owned role launch and no runtime attempt, preserves all historical charges, discloses shared-filesystem prompt limits and unavailable optional controls, and keeps actual model/effort/token/cache/money/complete-elapsed values UNKNOWN. Human numerical quota remains NOT SET. All own ordinary shell commands exited; no own persistent study process or scratch fixture was created. All delivered artifacts are retained as durable evidence. The final message is substantive and distinct from this detailed completed report.
