# ROOT later integration/invocation/binding checklist — STATIC / NOT READY

All actual values are **PENDING**. This is a concrete invocation recipe/checklist using existing code, not an executable grant, helper or batch runner. Source candidate d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094 has completed fresh conditional SOURCE review22dbed9d21fd8780fda9230f3138a8ea30e001bd5b079851f70fea4511cf5850, with no source repair and open ROOT-owned phase-prose prerequisiteP1. That reviewer did not independently accept this coordinator checklist or any candidate manifest. Actual113/material/method/native/science/execution acceptance remains required. Do not execute these placeholder arrays.

## 1. Preserve ancestry and overlay exact components

- ROOT's actual corrected ancestry fact: W114HEADd5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67 merge-base with accepted115ace06 and current113 is public `b344e41a8b52de76d7cbbf8450319893904c3b8f`, not115. Static local merge-base withace06, rev-list and narrowb344diff independently confirm b344,11 owned commits and ONLY13 added documentation paths. Prior provisional115 descriptions remain historical mistaken context, not a rebase recipe.
- After actual113 acceptance/release, ROOT preserves old W114 reference and rebases the11 owned HP114 commits onto the exact accepted113 parent. Do not apply an ace..W114 whole-tree diff, which would falsely remove campaign parent files. No integration operation is performed here.
- Overlay final SOURCE-accepted latest study.py from current author stage (candidate d423… pending fresh review), based on immutable accepted3cf. Overlay accepted manifest26a3728ca1adecda950e60f9630fb9c4f535d4e56cfeb5036e902496eca32e38 and obligationsa49fb3af7f5215f156e81c20b7051b8956d02d61c26449249bf9fc9bc2f2ae17 into existing owned report paths. Preserve every original external file. ROOT then makes only truthful phase/provenance corrections identified by author map/fresh review: five source quarantines retired, genuine guards/operational hold retained, OptionA explicit prep declarations, no current proof asserted. Freeze the resulting manifest/obligation bytes externally; old26/a49 remain immutable component identities, not automatic hashes for changed prose.
- Exact accepted§8A patch SHAa86bbe9bdb7851c18d8d2281c85219c47be6ed2b162b0a055bc6c75a0c3ad216 contains contract paragraph insertion, manifest standalone replacement, S7 row. Accepted26 manifest already contains the exact replacement: do NOT apply that hunk twice. Verify it unchanged, apply contract/S7 portions only where still absent with exact context, and preserve the preceding lifecycle paragraph/five available meanings. No scope/gate/precision/tolerance change. Current report/recommendation prose must select12, with historical90 labeled history.
- ROOT freezes actual parent/base/head/tree/clean tracked-diff identity plus source/manifest/contract/obligation inputs outside their determining tracked bytes. Do all source/prose changes BEFORE controls/QUALIFY. Later harness/manifest changes invalidate existing diagnostic QUALIFY exact-hash admission; retain old records and reassess/refreeze, never relabel.

## 2. Pre-data exact independent method/applicability scope

The current SOURCE review is not this later actual-bound acceptance. Fresh actual-bound method/scientific assessment must name: actual accepted113/default-double/opt-in-single boundary and new import closure; exact final source/manifest/artifact/spec/material identities; B/C/G/argv/L semantic DAG; interpreter/startup/native provenance; original/copy grant correspondence; fresh exposed physical/cgroup/headroom/disk/pressure/reserves/exclusive window; plain-spawn/setsid/exec/readiness/FD ownership and sole exact-PID wait4/failure/cleanup; scalar clock scopes and partial-record interpretation; selected finite controls with retained-evidence applicability; the row-qualification/retained-record assessment procedure and OptionA consumed-field/prepared-continuation criteria. It must identify concrete remaining gaps/owners, not claim a general native theorem or recreate full upstream implementation. This pre-data scope accepts a concrete method/claim plan and staged controls/QUALIFY releases, not empirical future row values in advance; actual row qualification is assessed after its observations and before its comparisons.

Generic public RM84 structural/type/readonly/nonalias/retention evidence and known/T1 returned-carrier seed witness are proposed reuse only until exact actual-parent/default-material/import applicability is independently accepted. Evaluate retained actual QUALIFY values/arrays first. Missing independent premises may remain UNRESOLVED/noactivation with scoped conclusions. If needed, named finite conditional-polynomial evaluation with honest reference uncertainty gets a separate ROOT release; no reference arrays/workflow in measured children, no broad oracle framework or six automatic duplicate live captures.

## 3. Immutable indexes before B

ROOT prepares exact indexes/evidence; every path/digest below is PENDING:

| Index | Required concrete contents / existing B representation |
| --- | --- |
| Scientific/import materials M | Root-relative path→SHA256 for finalstudy/manifest/contract/obligations/recipe and all relevant public science/import support including actual113 known wrapper/new single_known import, workflow/preparation/estimator/transfer, package/build/lock/version inputs and actual selected installed/import files as applicable. No ignored/untracked import is silently covered by HEAD. Material paths resolve inside explicitROOT. |
| Startup S | Canonical absolute path→SHA256 for interpreter startup/.pth/sitecustomize/usercustomize/coverage/autostart/preload or other actual startup files; explicit environment/allocator/array-API/thread facts and absent/fileless/unsupported dispositions in companion evidence. No invented file hash for a namespace or opaque version. |
| Native N | Required module→{path,sha256}: `numpy.fft._pocketfft_umath`, `scipy.fft._duccfft.pyduccfft`; actual interpreter/shared libraries/route support in companion import/environment evidence. Loaded post-call module paths/hashes must correspond. No unused backend import to manufacture evidence, no native arithmetic/workspace claim from dtype or file identity. |
| Default/single boundary P | Immutable `{path,sha256}` evidence for actual accepted113 default double behavior and explicit supported-single boundary. HP114 invokes no new precision argument or single-profile matrix. Distinguish source semantics, actual accepted runtime/math evidence and unknown native internals. |
| Physical C | Fresh immutable current exposed physical/available/cgroup/swap/events/pressure/CPU/load/disk/headroom/ancestor correspondence, conservative simultaneous-buffer ledger, OS/caller/background reserves and workspace uncertainties. External ancestors unknown_unobservable stay unknown; no old operational limit/product cap/default reserve is reused. C is outside B and never mutated after G hashes it. |

Required interpreter object is exact `{path,resolved,prefix}`; path equals actualsys.executable, resolved actual executable, prefix actualROOT/.venv. Pinned execution environment is Ubuntu24.04.5 container `simrecon-campaign-ubuntu` with per-worktree .venv; host Debian is not qualification. Six pre-start thread variables must be1: OMP_NUM_THREADS,OPENBLAS_NUM_THREADS,MKL_NUM_THREADS,BLIS_NUM_THREADS,VECLIB_MAXIMUM_THREADS,NUMEXPR_NUM_THREADS; SciPy workers1 during calls. Actual PATH, allocator/preload/PYTHONPATH/array-API/startup facts must be frozen, not copied from an old command. No overlapping campaign lane/window.

## 4. B→C→G→literal argv→L, no source/hash cycle

Existing B schema is **HP114-root-binding-v1**, top-level EXACT keys `{schema,bindings,artifacts}`. bindings EXACT keys:

```text
accepted113,parent,integration_base,candidate,default_profile,single_profile,
materials,startup,native,grant,root,evidence,output,source,interpreter,route,
parent_argv_shape,target_argv_shape,manifest,bootstrap_sha256
```

`accepted113={commit,tree}`; candidate includes actualcommit/tree,parent,integration_base,tracked_status=`clean`,tracked_diff_sha256. Actual opaque candidate/profile evidence semantics need independent review, not just loader parsing. `materials=M`, `startup=S`, `native=N`; profile entries each exactpath/SHA. `grant={original,copy}` names paths, no Ghash. `output=evidence/run_id`. `artifacts` EXACT `{harness_sha256,manifest_sha256}`. Source/manifest, B/original/copy/C and determining input paths are distinct as required by loader. Original G is outside attempt; resource copy is output/grant.original.json, a distinct same-byte file created by existing parent. Diagnostic/controls copy=null,target_argv_shape=[].

1. Freeze final determining files/recipes and literal path/route/run/argv SHAPES. B contains immutable materials/recipes only; no physical C, Ghash or Lhash. Hash B independently to obtain Bsha.
2. Capture/freeze fresh C and any prior admission proof; no Bshape/digest backedge needed. G is later, carries authorization=`HP114_NUMERICAL_WINDOW`,environment=`simrecon-campaign-ubuntu`, full unchanged B.bindings, exactcandidate/harness/manifest, `binding_receipt={path:Bpath,sha256:Bsha}`, `context={path:Cpath,sha256:Csha}`, exactruns and applicablequalification_sha256. Resource G names unique run_id, one run triple, resource_admission accepted/rationale/evidence_sha256 and positive finite deadline/startup/TERM-grace/KILL-reap/readiness-byte bounds. Admission evidence precedes G (C or earlier frozen proof), never laterL. No Gselfhash.
3. Expand only the single literal `$ROOT_BINDING_SHA256` operand in each argvshape using Bsha; no general env expansion, source substitution or --grant-sha256 flag. Source/candidate never embed their own determining hashes.
4. Independent L immediately before launch binds complete actual outer+inner argv, originalGhash/B/C identities and fresh ROOT guard/headroom recheck; if C2 exists, bind only inL. Do not modifyC/G or feed Lhash backward. Root receipt is trusted provisioning/audit consistency, not adversarial authentication or a proof of semantic acyclicity.

## 5. Exact inner argv recipes (PENDING operands, NOT commands)

Source parser/binding loader already support these. B.parent_argv_shape must use exactly one digest slot; every other literal resolved before B freeze. L holds expanded actual arrays. Parent/source/interpreter/B path/order must match actual exactly.

```text
BASE = [PENDING_I,PENDING_S,
 "--route",PENDING_ROUTE,"--grant",PENDING_G_ORIGINAL,
 "--binding-receipt",PENDING_B,"--binding-sha256","$ROOT_BINDING_SHA256",
 "--row",PENDING_ROW,"--strategy",PENDING_STRATEGY,
 "--repetition",PENDING_REP,"--run-id",PENDING_UNIQUE_ATTEMPT]

QUALIFY = BASE with route="diagnostic",row=W01..W06,strategy="QUALIFY",rep="1"
COMPARISON = BASE with route="diagnostic",selectedW/mode/rep,
             then ["--qualification",PENDING_APPLICABLE_ROW_QUALIFY_RUN_JSON]
KERNEL = BASE with route="diagnostic",row=K01..K04,strategy="KERNEL",rep="1"
CPU = BASE with route="diagnostic",row="K01",strategy="CPU",rep="1"
CONTROLS = BASE with route="controls",row="K01",strategy="KERNEL",rep="1"
RESOURCE_PARENT = BASE with route="resource",selectedW02/W05,
                  strategy="PREPARED_WIDER"/"PREPARED_HALF",selectedrep

RESOURCE_TARGET = [PENDING_I,PENDING_S,
 "--route","resource-child","--grant",PENDING_OUTPUT+"/grant.original.json",
 "--binding-receipt",PENDING_B,"--binding-sha256","$ROOT_BINDING_SHA256",
 "--row",SAME_ROW,"--strategy",SAME_STRATEGY,
 "--repetition",SAME_REP,"--run-id",SAME_UNIQUE_ATTEMPT]
```

Resource target order above is source-exact; no --qualification goes to resource child. Diagnostic non-QUALIFY parent shape includes its actual --qualification operand so loader compares the entire argv. Outer existing ROOT capture/container invocation binds actualdocker exec user/workdir/container/PATH/sixthreads and exact inner absolute interpreter/source/argv; do not use the historical manifest example lacking B arguments or relative `.venv/bin/python` as READY. ROOT captures stdout/stderr BEFORE parent interpreter startup with existing execution/capture route. No new launcher/waiter/helper is proposed.

## 6. Current controls, retained historical outcomes, minimal missing evidence

Historical controlattempt2 scoped qualification (actual64edcad/source9daa/manifest6ae) remains a real old pass only:7 IEEE scalar,7canonicalhash,4tinyNPY,18raw-generation,16dyadicK03, error/empty/zero/stride, binary16/paired/cancellation,2incomplete-record refusals, boundedCPU FFT16/promotion/unsupportednorm and actual loadedfiles. Its old AS/CPU/wall bounds, admission/C/grant/renderer/PID/maps and startup/native qualification DO NOT transfer to newsource/material/loader/plain-spawn. Controlattempt1 remains INCOMPLETE. Reuse exact mathematical expected values/source-unchanged helper reasoning and old observations with their original scope; do not relabel whole-record/current method PASS.

Before current data, the independent method reviewer must explicitly decide retained applicability and the smallest current selection. Existing `--route controls` is one concrete separately admitted process for current binding/startup/import/serialization/hash/stat/error/raw-generation/K-range/product/cancellation/boundedFFT behavior; it is not one of149primary observations and supplies no W qualification. Because actual loader/material/startup/record clocks changed, at least current bound-route/import/record/provenance correspondence remains unproved by the oldcontrol2. Do not automatically repeat unchanged pure cases solely for labels; do not bypass current missing evidence by reusing its wholeold receipt.

Existing resource-parent negative lifecycle controls are fixed: missing-record→missing child record; malformed-record→parser refusal; oversized-record→size refusal; child-error→retained failure; self-term→signal terminal; timeout→TERM deadline; timeout-ignore-term→KILL/reap. They use exactresource G with method_control/control_release=true and no numerical imports/scientific qualification. Their source was formerly quarantined, so no actual PASS for this plain-spawn route is inherited. Reviewer must select/qualify needed existing cases, derive expected raw statuses/exit/signal/usage/closure from source and retain every attempt. Negative expected behavior is method evidence, not a successful scientific row. A normal positive actual W resource observation still needs applicable row qualification; use an admitted selected slot when appropriate, not an invented extra numerical control.

The seven names alone do not prove B/argv/context/copy/material drift rejection, readiness FD/nonce/session/start identity, startup/normal exactwait4 usage, SIGCHLD/SIGINT cancellation, repeated interruption/marker/observer/ownership-loss recovery or every added clock endpoint/serialization scope. Fresh method review names exact remaining finite external receipt/command/fault observations feasible with existing routes, or keeps that route/gap held. No new fault framework, intentional orphan, fake terminal RSS, automatic retry, sampler or generic reaper. Type/order/units and failure/partial/null meaning of local clocks need actual assessment; unchanged validator does not check new fields. Historical import success alone is not plain-spawn capability.

## 7. Finite source-supported plan/order to freeze before data

Every invocation is a separate ROOT admission, immutable unique run ID and fresh process; this is no shell loop/batch/retry. A literal pre-data order for diagnostics is proposed below; ROOT freezes it before measurements. Only the accepted twelve resource order is already normative.

1. Current selected method controls and actual preflight/import/readiness qualifications, with full closure. Any cheap required failure stops dependent work.
2. Six QUALIFY: W01,W02,W03,W04,W05,W06, each QUALIFY rep1. Status branch-qualified-oracle-review-required is an observation, not acceptance. Assess actual full/summary/raw/array/trace/branch inputs with precise accepted evidence reuse, reference uncertainty and scoped gaps. Failed wider fixture stops its comparisons; no tuning/favorable replacement. No blanket positive theorem required.
3.126diagnostics: rowsW01→W06; within each row modes `[WIDER,H1,H1_PROMOTED,H2_CORRECTED,H2_PREPARED,H2_FILTERED,H2_EMBEDDED]`; within each mode reps1→3, referencing the exact applicable row QUALIFY JSON and final source/manifest. These include18WIDER and108candidate/control/site observations. Every successful W comparison requires three fresh successful repetitions; failed/refused/unsafe/partial attempts stay separately indexed.
4. K01,K02,K03,K04 each KERNEL rep1, then K01 CPU rep1. Intentional overflow/singularity/unsupported meanings retained. Kernel timing unmeaningful at resolution stays unresolved; control-route K cases do not replace these primary observations.
5. Twelve additional matched prepared resources ONLY after appropriate W02/W05 applicability/method/native/safety prerequisites: W02 r1WIDER,HALF; r2HALF,WIDER; r3WIDER,HALF; then W05 in same six-slot order. Abbreviations mean PREPARED_*. One fresh sole direct child, retained caller/result, no reference workflow/arrays, setup/pack/unpack/observer/JSON accounted, no high-water subtraction. All other standalone benefits UNMEASURED. Total nominal primary149; controls and failures are extra evidence, not caps or successes.

## 8. Per-attempt capture, whole closure and stop rule

Before launch: exact final source/manifest/material/startup/native/profile hashes and candidate identity; originalB/C/G/L/argv; fresh guard/headroom/ledger/exclusive window; stdout/stderr capture ready before interpreter, originalgrant path and unique nonexistent output. Resource parent source creates byte-identical grant.original.json before child, then records materials_before/git_before, parentidentity/pre-spawn snapshot, spawn-intent.json, launch/bootstrap/FD plan, owned-child.json, startup-readiness.bin and raw child.stdout/child.stderr. Child emits child.json only when its path reaches that outcome. Parent attempt.json preserves terminal/null, status/failure/signals/ownership/readiness/poll timing, materials_after/git_after and FD closure outcome. Root's external capture/receipt supplies outer/startup/process/cgroup correspondence; missing source artifact remains a meaningful failed/partial outcome, not a fabricated file.

Diagnostic/control run.json retains grant/source/environment/warnings/failure/clock/fullresult and NPY array_index/filehashes when reached; no complete full/summary pair is assumed on an exception before return. Preserve original stdout/stderr, run.json/arrays/file index, loaded-module/provenance and ROOT grant/capture/postflight identities. Observe expected K warnings separately from unexpected errors.

Resource terminal authority is the sole cached `wait4(exact_pid,WNOHANG)` through exit, no Popen waiter/RUSAGE_CHILDREN/tree sum. SamePID bootstrap→setsid→readiness→exec, actualboot/PID/start/group/session/nonce/FD ownership and no competing SIGCHLD reaper must be established. Parent spawn-to-terminal-observed elapsed includes observation delay; pre-exec high-water retention across exec stays unresolved unless actual evidence establishes it. Cumulative snapshots/native terminal RSS/payload/time remain distinct.

Whole-close before the next invocation: collect terminal or explicitly document ownership loss; existing bounded TERM/KILL/reap handling where owned; readiness EOF/raw capture and every opened FD closure; actual exactidentity parent/child/outer controller/proxy/pipes completion/absence correspondence under existing ROOT method; no persistent owned workload; final material/Goriginal-copy/Git checks and immutable outcome index. On marker/wait/observer/ownership loss, ROOT establishes actual identity/termination before another attempt, no stale-PID signaling or inferred absent process. Deadline failure is retained, never success. Source receipt completeness alone does not prove outer closure or current safe admission. No runtime is authorized by this checklist.
