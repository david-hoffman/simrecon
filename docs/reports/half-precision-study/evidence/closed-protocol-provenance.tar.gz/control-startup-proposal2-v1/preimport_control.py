"""One fixed HP114 control invocation; stdlib safety before product imports.

SOURCE PROPOSAL ONLY. No execution is authorized by this file. The proven
source_free_check renderer owns its ordinary command timeout/reap; this wrapper
runs study.py through runpy in the SAME PID. No process-memory measurement.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import resource
import runpy
import signal
import sys
import time

ROOT = Path("/workspace/work/issue-114")
VENV = ROOT / ".venv"
STUDY = ROOT / "docs/reports/half-precision-study/study.py"
MANIFEST = STUDY.with_name("manifest.md")
EVIDENCE = Path("/workspace/work/campaign/evidence/114")
STUDY_SHA = "9daa4744fbb30833f26d8cc249f0db27c26502f3410216fa808910fc09a402c7"
MANIFEST_SHA = "6ae262ce4d228feff8d4dc2e2831dce010bbadd3a156d018402b7cbf272d604d"
GIB = 1024**3
AS_EXTRA = GIB
AS_MAX = 2 * GIB
AS_MIN_GAP = GIB // 2
MIN_HEADROOM = 3 * GIB
MIN_DISK_FREE = 256 * 1024**2
CPU_EXTRA = 30
CPU_MIN_GAP = 5
WALL_SECONDS = 90
CONTEXT_MAX_AGE_SECONDS = 60
RUN_ID = "control-method-K01-attempt1"
REQUIRED_FFT = ("numpy.fft._pocketfft_umath", "scipy.fft._duccfft.pyduccfft")
EXPECTED_FFT = {
    REQUIRED_FFT[0]: (
        VENV / "lib/python3.13/site-packages/numpy/fft/_pocketfft_umath.cpython-313-x86_64-linux-gnu.so",
        "37eea6cf4de15ba3cc9487e704bbd306de65bf804310b1067f1b11d1e50a9de8"),
    REQUIRED_FFT[1]: (
        VENV / "lib/python3.13/site-packages/scipy/fft/_duccfft/pyduccfft.cpython-313-x86_64-linux-gnu.so",
        "f02b18219f6f4da027e3badebb3b6891c3cda415130f02b9e2583f0f69fb013e"),
}
THREADS = ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
           "BLIS_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")


def sha(path):
    value = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024**2), b""):
            value.update(block)
    return value.hexdigest()


def write_new(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def proc_kib(path, key):
    for line in Path(path).read_text().splitlines():
        if line.startswith(key + ":"):
            fields = line.split()
            if len(fields) != 3 or fields[2] != "kB":
                raise RuntimeError("unusable proc units: " + key)
            return int(fields[1]) * 1024
    raise RuntimeError("missing proc value: " + key)


def material_table(path):
    result = {}
    for line in Path(path).read_text().splitlines():
        digest, separator, name = line.partition("  ")
        if not separator or len(digest) != 64 or name in result:
            raise RuntimeError("invalid/duplicate material identity")
        resolved = (ROOT / name).resolve() if not name.startswith("/") else Path(name).resolve()
        if sha(resolved) != digest:
            raise RuntimeError("material changed: " + name)
        result[str(resolved)] = digest
    return result


def loaded_modules(materials):
    rows = {}
    for name, module in tuple(sys.modules.items()):
        if name.split(".")[0] not in ("numpy", "scipy", "h5py", "tifffile", "simrecon"):
            continue
        namespace = getattr(module, "__dict__", {})
        path = namespace.get("__file__")
        row = {"path": path, "sha256": None, "matches_admitted_material": False,
               "version": namespace.get("__version__")}
        if isinstance(path, str):
            resolved = str(Path(path).resolve())
            row.update(resolved=resolved, sha256=sha(resolved))
            row["matches_admitted_material"] = materials.get(resolved) == row["sha256"]
        rows[name] = row
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--admission", required=True)
    args = parser.parse_args()
    admission_path = Path(args.admission).resolve()
    admission = json.loads(admission_path.read_text())
    if admission.get("authorized") is not True or admission.get("case") != "HP114_CONTROL_STARTUP1":
        raise RuntimeError("no root execution authorization")
    if (sys.version_info[:3] != (3, 13, 12) or Path(sys.prefix).resolve() != VENV.resolve()
            or sys.platform != "linux"):
        raise RuntimeError("wrong pinned interpreter/platform")
    if any(os.environ.get(key) != "1" for key in THREADS):
        raise RuntimeError("thread configuration differs")
    if (os.environ.get("PYTHONWARNINGS") != "always"
            or os.environ.get("PYTHONPATH") != str(ROOT / "scripts/source_free_sitecustomize")
            or os.environ.get("LD_PRELOAD") or os.environ.get("SCIPY_ARRAY_API") not in (None, "0")):
        raise RuntimeError("startup diagnostics/backend environment differs")
    if sha(__file__) != admission["wrapper_sha256"]:
        raise RuntimeError("wrapper changed")
    if sha(STUDY) != STUDY_SHA or sha(MANIFEST) != MANIFEST_SHA:
        raise RuntimeError("immutable study/math changed")
    grant = Path(admission["study_grant"]).resolve()
    if sha(grant) != admission["study_grant_sha256"]:
        raise RuntimeError("study grant changed")
    context = Path(admission["root_context"]).resolve()
    age = time.time() - context.stat().st_mtime
    if (admission.get("root_context_reviewed") is not True
            or admission.get("effective_ancestors_resolved") is not True
            or not 0 <= age <= CONTEXT_MAX_AGE_SECONDS
            or sha(context) != admission["root_context_sha256"]):
        raise RuntimeError("fresh reviewed root context missing")
    output = Path(admission["output_dir"]).resolve()
    if output.parent.parent != EVIDENCE or output.name != "wrapper":
        raise RuntimeError("unexpected exclusive output location")
    output.mkdir()  # Outer transport directory exists; wrapper evidence must be new.
    before = {"pid": os.getpid(), "time_ns": time.time_ns(), "python": sys.version,
              "executable": sys.executable, "prefix": sys.prefix,
              "admission_sha256": sha(admission_path), "grant_sha256": sha(grant),
              "root_context_sha256": sha(context)}
    code = 2
    failure = None
    materials = {}
    alarm_fired = False
    def wall_expired(signum, frame):
        nonlocal alarm_fired
        alarm_fired = True
        raise SystemExit(124)  # Bypasses study's Exception catcher; its finally still runs.
    try:
        vm = proc_kib("/proc/self/status", "VmSize")
        available = proc_kib("/proc/meminfo", "MemAvailable")
        ancestors = []
        paths = admission["cgroup_ancestor_paths"]
        if not paths or len(paths) != len(set(paths)):
            raise RuntimeError("effective ancestor list missing/duplicate")
        for name in paths:
            path = Path(name).resolve()
            if not path.is_relative_to(Path("/sys/fs/cgroup")):
                raise RuntimeError("unexpected cgroup path")
            current = int((path / "memory.current").read_text().strip())
            maximum = (path / "memory.max").read_text().strip()
            if current < 0 or (maximum != "max" and int(maximum) - current < MIN_HEADROOM):
                raise RuntimeError("insufficient effective cgroup headroom")
            ancestors.append({"path": str(path), "current": current, "max": maximum})
        disk = os.statvfs(output)
        if available < MIN_HEADROOM or disk.f_bavail * disk.f_frsize < MIN_DISK_FREE:
            raise RuntimeError("insufficient host/disk headroom")
        old_as = resource.getrlimit(resource.RLIMIT_AS)
        cap = min([vm + AS_EXTRA, AS_MAX] + [n for n in old_as if n != resource.RLIM_INFINITY])
        if cap - vm < AS_MIN_GAP:
            raise RuntimeError("existing AS limit leaves insufficient startup allowance")
        resource.setrlimit(resource.RLIMIT_AS, (cap, cap))
        old_cpu = resource.getrlimit(resource.RLIMIT_CPU)
        usage = resource.getrusage(resource.RUSAGE_SELF)
        used = math.ceil(usage.ru_utime + usage.ru_stime)
        cpu_soft = min([used + CPU_EXTRA] + [n for n in old_cpu if n != resource.RLIM_INFINITY])
        if cpu_soft - used < CPU_MIN_GAP:
            raise RuntimeError("existing CPU limit leaves insufficient allowance")
        cpu_hard = min([cpu_soft + 1] + [n for n in old_cpu[1:] if n != resource.RLIM_INFINITY])
        resource.setrlimit(resource.RLIMIT_CPU, (cpu_soft, cpu_hard))
        if (resource.getrlimit(resource.RLIMIT_AS) != (cap, cap)
                or resource.getrlimit(resource.RLIMIT_CPU) != (cpu_soft, cpu_hard)):
            raise RuntimeError("limits not installed exactly")
        if signal.getitimer(signal.ITIMER_REAL) != (0.0, 0.0):
            raise RuntimeError("unexpected existing wall timer")
        before.update(vm_bytes=vm, host_available_bytes=available, ancestors=ancestors,
                      disk_available_bytes=disk.f_bavail * disk.f_frsize,
                      previous_as=old_as, installed_as=[cap, cap], previous_cpu=old_cpu,
                      installed_cpu=[cpu_soft, cpu_hard], wrapper_wall_seconds=WALL_SECONDS,
                      limits_scope="this target PID before product/native imports, not whole startup/aggregate RSS")
        write_new(output / "pre-import.json", before)
        signal.signal(signal.SIGALRM, wall_expired)
        signal.setitimer(signal.ITIMER_REAL, WALL_SECONDS)
        index = Path(admission["material_index"]).resolve()
        if sha(index) != admission["material_index_sha256"]:
            raise RuntimeError("material index changed")
        materials = material_table(index)
        sys.argv = [str(STUDY), "--grant", str(grant), "--route", "controls", "--row", "K01",
                    "--strategy", "KERNEL", "--repetition", "1", "--run-id", RUN_ID]
        runpy.run_path(str(STUDY), run_name="__main__")
        code = 0
    except SystemExit as error:
        code = error.code if type(error.code) is int else 2
    except BaseException as error:
        failure = {"type": type(error).__name__, "message": str(error)}
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0.0)
        try:
            loaded = loaded_modules(materials)  # Actual modules after calls, not pre-FFT guesses.
            required = {name: loaded.get(name) for name in REQUIRED_FFT}
            for name, row in required.items():
                if row:
                    expected_path, expected_sha = EXPECTED_FFT[name]
                    row["exact_expected_fft"] = (row.get("resolved") == str(expected_path.resolve())
                                                  and row["sha256"] == expected_sha)
            missing = [name for name, row in required.items()
                       if not row or not row["path"] or not row["sha256"]
                       or not row["matches_admitted_material"] or not row["exact_expected_fft"]]
            changed = (sha(STUDY) != STUDY_SHA or sha(MANIFEST) != MANIFEST_SHA
                       or sha(grant) != before["grant_sha256"]
                       or sha(admission_path) != before["admission_sha256"])
            if missing or changed or alarm_fired or failure or os.getpid() != before["pid"]:
                code = code or 2
            write_new(output / "post-import.json", {
                "pid": os.getpid(), "same_pid": os.getpid() == before["pid"],
                "loaded_modules_after_calls": loaded, "required_fft_after_calls": required,
                "missing_or_unadmitted_fft": missing, "immutable_inputs_changed": changed,
                "alarm_fired": alarm_fired, "failure": failure, "target_exit": code,
                "status": "observed-pending-root-full-stderr-and-controls-review" if code == 0
                          else "incomplete-or-failed", "time_ns": time.time_ns(),
                "not_scientific_or_memory_qualification": True})
            (output / "maps-after.txt").write_text(Path("/proc/self/maps").read_text())
        except BaseException as error:
            print("HP114 post-observation incomplete: " + type(error).__name__ + ": " + str(error), file=sys.stderr)
            code = code or 2
    return code


if __name__ == "__main__":
    raise SystemExit(main())
