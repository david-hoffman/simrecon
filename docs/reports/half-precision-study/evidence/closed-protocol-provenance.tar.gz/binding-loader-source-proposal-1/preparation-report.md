# HP114 binding-loader SOURCE proposal 1 — finite handoff

2026-11-16. SOURCE ONLY / HOLD. No runtime/check/qualification/scientific verdict.
One fresh nonblind narrow external source-author attempt against immutable R1.
Read-only Git observed clean d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67,
tree b38e1e2f744b21814881a6dec9663b4723124ccc: provisional115, not final113.
No tracked byte, actual binding, command READY, grant, parent or policy was changed.

## Frozen delivery

All nine owned outputs are directly under
/workspace/work/campaign/evidence/114/binding-loader-source-proposal-1/:
study.py, manifest.md, source-delta.patch, binding-receipt-template.json,
pending-invocations.md, preparation-report.md, author-accounting.md,
frozen-inputs.sha256, outputs.sha256. Packet/coordinator records remain immutable.
Source/manifest were finalized before this report and the final output hash index;
their own identities occur only in external reporting, not determining bytes.

- study.py: f8b4a5fcab8ac1049d67f823a5e4f5f07281fdbbf317ea052e190a2ec4d42772
- manifest.md: 9f4626570f266a1bea76b521cbe866f8c0feea23906e29ac12d77c81bd0ea1ed
- source-delta.patch: 796965b755de94705dcac79a1dda7dbe9cba1b8ce51221486f3c6bf54d02db40
- binding-receipt-template.json: f56d764fa4f9ef697d8387a0fe91b41e6f6042c499c2ab004398de9c7dd6c225

The portable patch uses labels R1/study.py -> proposal/study.py and equivalent
manifest labels; it contains only the two changed copied files. The new template
is delivered separately. frozen-inputs.sha256 records literal read-input hashes;
outputs.sha256 records all other owned output bytes and excludes itself. No index
or report purports to hash itself. Coordinator-owned packet hash matches
 dcbb9789ce6c9f65ac48a589cf4f869ece9872360efef19d5d85c5370b55fae2.
Transition literal hash matches
278c77e3b44201b12d92cdf8d201c38766710a52d73b154159b8be4580b1de0a.
R1 study dcb1d5eee748c3cd442def84ae4ddbb362790b7f6fc00d6b0d683a4abac545a6
and manifest db5c9c38ff808ad50fb6f480f674a6eba55d1a6d8f3f568170c4693446f416fc
were verified without changing old evidence. No packet spelling discrepancy arose.

## Changed-functions and retained science

Added binding_hash, binding_path, expanded_binding_argv and load_bindings. These
validate external receipt bytes against an independent bounded argv SHA, explicit
canonical paths, source/sibling manifest, interpreter lexical/resolved/prefix,
actual-parent/profile evidence structure, candidate consistency, named relative
materials/startup/native structure, final external artifact hashes and
correct-route grant/argv. ROOT/EVIDENCE/EXPECTED initialize only after validation.
The loader runs after argparse before route dispatch/raw mkdir; authorize reloads
independently; resource_parent loads before EVIDENCE access on direct entry.

Changed authorize: retain its first unconditional HOLD; load bindings, bound grant
size, exact route and raw binding/candidate equality; require correct original or
copy path and compare original/copied byte streams. Old grant/artifact/material/
environment/scientific admission remains. No independent grant hash is placed in
bindings, so grant duplication cannot hash itself.
G.binding_receipt must match independent actual Bpath/Bsha; G.context binds a
distinct immutable later Cpath/Csha, excluded from B's immutable material paths.
GRANT_CONTEXT retains this later identity for before/after capture; B has no C hash.

Changed resource_materials: explicit source/manifest paths replace any __file__
relative-to-root assumption; include receipt, startup, context/profile and original/
copy grant hashes in before/after snapshots, enforcing independent receipt digest
and original/copy digest equality. Changed resource_parent only by loading before
EVIDENCE and propagating/comparing the independent receipt pair in direct-target
argv. Child body, bootstrap, wait ownership, signals/headroom/lifecycle are verbatim.
Changed main only for required receipt options, load-before-dispatch and diagnostic
before/after material capture with fail-closed drift/observation status. Existing
raw failure object remains recorded if later identity observation also fails.
Manifest adds this design/freeze boundary; the entire R1 manifest follows verbatim.

Text diff leaves all R1 science constants, SHAPES/W01-W06/K01-K04, strategy/precision
meanings, OPTICS, SNAPSHOT_SCOPES, buffer bounds, scientific functions/formulas,
quantization/encoding/hash/stat/error observers and scientific controls verbatim.
Specifically every R1 function other than authorize, resource_materials,
resource_parent and main is unchanged. Scientific bodies inside those changed
route functions are unchanged. All execution_hold/refuse functions and their
unconditional top-level/main/authorize/resource call sites remain unchanged.
This is text-delta evidence only: no parsed, compiled or runtime equivalence claim.

## Portable receipt/grant/argv design and remaining boundary

Final source/manifest freeze first; final candidate/source/manifest identities live
in a later external receipt. Actual template fields remain UNBOUND. The receipt
has no selfhash and lives outside the checkout; expected byte identity comes only
from ROOT's independently attested launch argv. It cannot be obtained from the
receipt or grant as independent proof. There is no cryptographic ROOT-authenticity
claim. ROOT independently binds the original grant digest in its launch receipt.

Each invocation SHAPE has exactly one literal $ROOT_BINDING_SHA256 at exactly the
--binding-sha256 operand. Only that recipe slot completes from the independently
supplied launch value; all other placeholder placement/count is refused. B does
not store complete literal argv. Parent/child are compared with exact complete
argv derived from shape and known identity, full interpreter/source included.
G duplicates unexpanded BINDINGS; G.binding_receipt carries actual Bpath/Bsha.
B binds original/copy paths without grant digests. Parent uses original G and
child copy; both compare streams before admission and paths/digests before/after.
No source edit is needed solely to insert final hashes. Later source changes
require new freeze/review; HOLD release is separately authorized work.

Final dependency order is source/manifest/recipe + actual candidate + immutable
materials -> B -> Bsha; fresh physical context C -> Csha; Bsha/Csha + existing
guards -> immutable G -> Gsha; then complete literal argv and separate ROOT L.
B has no later C/G/L digest. C need not embed Bsha/expanded argv. G has no ownhash
or later Ldigest. L binds complete actual argv and immutable B/C/G identities with
final fresh physical admission/recheck immediately before launch. Recheck facts
are separate L facts or C2 bound only by L, never updates to C after G binds Csha.
No Ldigest feeds B/C/G/literal argv. L independently binds Gsha; no new Ghash argv
operand or additional normalization is introduced.

Exact historical ordering source: transition material table says
"after-command-READY ROOT context/proof"; R1 pending-invocations says context
"only after command READY". Proposed narrow disposition is shapeREADY -> C -> G -> literalcomplete ->
fresh headroom/recheck/L. This does not claim the old ordering fulfilled, qualify
final context/launch policy or create a new human approval requirement. Actual
activation still requires independent affected method review, final binding and
ROOT release. The earlier normalized-context proposal is superseded; the backedge
is removed by moving C identity into later G. Loader excludes direct receipt/grant
path inclusion in B identity fields and C from B material paths; opaque evidence
semantic dependencies still require independent DAG assessment.

Actual accepted113/public signatures/default/supported-single applicability,
material/startup import-bearing closure, candidate ancestry and exact environment
are still UNBOUND and require ROOT reconciliation and independent affected review.
Structure and attestation consistency do not establish semantic truth. Diagnostic
candidate provenance remains ROOT-attested; resource route retains actual Git
before/after comparison. Repeated byte checks are not atomic filesystem snapshots.
Untrusted file modification/races and persistence loss remain limitations.

The unchanged fixed required_fft_provenance insists on both NumPy and SciPy FFT
modules after diagnostics. Whether each is applicable/actually loaded in non-FFT
K rows remains unresolved actual-route qualification; no import was added solely
to manufacture provenance. No K/CPU semantics were changed. Native wait4/exec/FD/
readiness/deadline/signal/cleanup/persistence behavior remains later ROOT runtime
qualification, not established by this source review.

## Smallest proposed changed-binding controls — NOT RUN

Use existing routes/material fixtures and one retained finite attempt at a time,
with ROOT-frozen exact inputs; no new parser/observer/test framework or autobatch:

1. Independent identity mismatch: unchanged receipt bytes with wrong independent
   expected SHA must refuse before global initialization/raw mkdir/imports. A
   receipt-provided/grant-provided matching value cannot rescue it. Also reject
   digest slot in a wrong position, extra slot or duplicate digest option.
   Later G.binding_receipt must match the independent pair; matching B.bindings
   alone cannot rescue a wrong G.binding_receipt.
2. Binding drift: one controlled named receipt or material change after initial
   validation must be retained as changed-identities/identity-observer failure,
   never completed scientific observation; missing after-capture stays incomplete.
   Later C drift must likewise fail; C is immutable after G identifies Csha.
3. Original/copy mismatch: copy differs by one byte or is missing, or parent/child
   is given the wrong path. Admission must refuse before numerical imports/spawn;
   preserve raw original/copy identity facts and do not create a successful retry.
4. Parent/child argv propagation: exact independent pair reaches direct target;
   changed receipt path/digest, source/interpreter, row/strategy/repetition/run-id,
   missing/duplicate parent operands or wrong-route grant refuses. The legitimate
   expansion matches exactly while grant retains the raw slot object.
5. Positive future actual fixture: ROOT's final qualified admitted W resource case
   with exact original/copy bytes and actual bound source/manifest/receipt/argv
   reaches the existing normal observation path and stable before/after materials.
   This is binding evidence only; independent scientific witnesses and existing
   lifecycle/native qualification still determine actual acceptance.

These describe expected outcomes, not an execution plan or launch permission.
ROOT selects the smallest concrete finite controls after affected source review.
Historical control1 remains INCOMPLETE. Control2 receipt
434198b6e10e2df1fd60fd7c20e81fc7225a22e7b5ce21b23457a6b65a42691f
belongs to clean64edcad and its actual materials/time. Unchanged generator/hash/
IEEE/serialization/observer reasoning may retain that limited applicability only
after changed-input review; it does not qualify this new loader, native lifecycle,
resource observation, full scientific result or final candidate. No old helper or
array was rerun/read. Full W/K/scientific witnesses, S1-S8 dispositions, SCI, final
Ubuntu gate and D remain. Resource90 remains proposal, reduced scope needs an
independent S7 contract/design disposition; H3 unavailability or noisy RSS cannot
dispose H1/H2 or justify a scientific negative. No scientific claim follows.

## Attempts, repairs, exposure and ownership

One source-author attempt; draft patches were text only. Initial batched long
reads and one manifest/task combination and R1 diff display truncated; needed
binding/source/instruction/report/index slices were reread narrowly. The entire
scientific body was not reinterpreted; preservation is localized text diff/copy.
Two patch attempts failed context matching: a nonessential manifest capitalization
change (already capitalized), and a combined report patch with a mismatched second
hunk. Neither failed patch changed bytes; each intended substantive paragraph was
applied subsequently with exact context. Other patches succeeded. Refinements tightened grant
path/route and parent operands, profile evidence shape, direct hash-dependency
exclusions and context cycle wording. None was executed. Diff status 1 denotes
expected textual differences, not a failed runtime check. No hidden check retry.

ROOT's final DAG direction superseded an unexecuted draft that still stored Csha
in B and contemplated normalized context identity. Main prior draft byte hashes:
study 28a22ab25c6cc49765d09de895cb717afe9cceef4a74656bb03186dec66dfa78,
manifest cc9fbb4ea16f7bb1706d3f6714bccca76276b79474c3eea21021fc65558c72fc,
patch 2e14f0d5da5bdae87d81e2a79bdd843bbe8059088a6bdd71a92392cbeddc0466,
template f0307d6fcdf02e486c5a770c587c9e3f2f336e5a8bdca32fc3a185ae8489fccd.
These are diagnosed superseded source-draft identities, never final receipts or
accepted/runtime evidence. Draft bytes were replaced in the same nine authorized
outputs; no separate snapshot file was created. The final edit removes B->later-C
identity by moving C to G, not by normalizing additional hash operands. The final
source/manifest were frozen again before final patch/report/index publication.

Only named text/file/hash and read-only Git operations were used. No interpreted
script assessed/transformed source; no Python/AST/compile/import/refusal-path run,
probe/lint/types/test/install/build/native call, science/resource/measurement,
process scan/spawn/signal or delegation occurred. No target/control/helper/agent
was launched by this author; thus no owned active target exists by construction,
without any claim about other roles' processes. No tracked write/commit/restack/
push/publication, actual pin/grant/READY/context activation or acceptance occurred.

Owned artifacts are precisely the nine named external outputs. No additional
scratch, fixture, deletion or cleanup target. Inputs/packet/old evidence retained.
Fresh independent affected SOURCE reviewer follows exact delivery. Runtime release,
actual bound-method qualification and scientific witness review remain ROOT-owned.
All historical charges remain; serving/model/memory-control/metering limitations
and this distinct charge appear in author-accounting.md.
