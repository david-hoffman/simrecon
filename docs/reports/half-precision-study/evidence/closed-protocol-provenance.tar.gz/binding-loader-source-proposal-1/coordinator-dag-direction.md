# ROOT-directed acyclic receipt correction — source proposal only

2026-11-16. This records ROOT follow-up direction after initial author packet; it supersedes that packet's context-in-binding assumption. It does not activate method, generate actual pins/grants/admission or create a competing Current. No human approval is requested: user scope authorizes necessary method/source correction; source pending text is historical method evidence, not new user authority.

Initial author diagnosis found no binding loader in R1 and a possible receipt/argv selfdigest edge. Before exact delivery ROOT directed removal of actual backedges, not a fiction that digest-slot normalization alone resolves receipt ordering:

- Freeze final source/manifest/candidate plus invocation recipe/SHAPE.
- B names immutable material/artifact/path/shape identities only; no later C/G/L hashes.
- C captures physical context and need not contain Bdigest/expanded argv. It is immutable once G binds its digest.
- G binds actual B identity, C identity, source/spec and existing guards; no grant selfhash/later Ldigest. Grant original/copy explicit paths/bytes must agree without selfhash.
- With B/C/G frozen, construct literal command with known identities.
- Separate later ROOT launch attestation L binds complete actual argv+B/C/G identities+last-moment physical admission/recheck. Recheck facts belong only in L or separate C2 bound by L. Never mutate C after G and never put Ldigest into predecessor/literal argv.

Actual source pending wording requires current context after command READY. Proposed narrow sequencing correction is shapeREADY→C→G→literalcommandcomplete→fresh recheck/L. Author must identify old wording and label proposal honestly; no claim old ordering already fulfilled or actual case command ready. Fresh affected source reviewer independently assesses code/DAG/guards and this sequencing proposal, with exact bound acceptance/runtime later required. ROOT alone activates, integrates and releases finite controls. All top-level/main/authorize/resource holds remain; every actual pin stays UNBOUND.

Reviewer receives actual target bytes and requirements, forms own assessment before old opinions. No new generic parser/observer framework, RSS sampler, test/product/policy/dependency/matrix change or scientific result. FFT-native applicability for non-FFT K routes remains separately pending. No H1/H2 disposal from H3 unavailable/noisy RSS; S7 reduction requires independent contract/design disposition. Historical control1/control2 and all charges unchanged. Added source-draft diagnosis/correction is preserved by author accounting, not a new numerical attempt.
