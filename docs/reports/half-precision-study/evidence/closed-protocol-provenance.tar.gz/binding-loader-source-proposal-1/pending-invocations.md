# Pending ROOT binding — SOURCE ONLY / HOLD / NOT READY

2026-11-16. No executable invocation, grant or actual pin is supplied. All actual
inputs remain UNBOUND, including the later physical context C and grant G. The
binding template only fixes schema/option names and an invocation-shape recipe.
Every unconditional R1 import/main/authorize/resource hold remains literal.

Proposed acyclic existing-receipt order, requiring affected independent review
and ROOT's actual final binding/admission/release before activation:

1. Freeze final source/manifest/tracked inputs, actual accepted113-derived candidate,
   immutable materials/interpreter/profile evidence and invocation SHAPE/recipe.
2. Freeze external binding B. It contains immutable material identities, candidate,
   source/manifest artifacts, original/copy grant paths and parent/target SHAPEs.
   B contains no later context C, grant G or launch L digest; then obtain Bsha.
3. Capture fresh physical context C. C need not embed Bsha or expanded argv. Freeze
   C and Csha. G identifies Bpath/Bsha and Cpath/Csha, repeats unexpanded B.bindings,
   candidate/artifact hashes and all existing admission/route/run guards. G has no
   ownhash or later Ldigest. Once G binds Csha, C must never be appended/updated.
4. Complete literal argv using the now known identities; Gsha is independently
   bound in L, with no new --grant-sha256 source option or hash slot required.
5. Immediately before launch, separate ROOT receipt L binds complete actual argv
   and immutable B/C/G identities plus fresh physical guard/recheck. That last
   recheck is an L fact or separate C2 bound only by L; it never modifies C. No
   Ldigest feeds B/C/G or literal argv. No B/G/manifest/source hashes itself.

The historical transition's material table requires "after-command-READY ROOT
context/proof" and R1 pending-invocations says context "only after command READY".
Proposed narrow sequencing disposition is shapeREADY -> C -> G -> literalcomplete
-> fresh headroom/recheck/L. This does not claim the old ordering is fulfilled or
create a new human approval requirement. This SOURCE proposal cannot qualify final
context/launch policy; independent affected method review, actual final binding
and ROOT release remain necessary. No normalized context hash slots are proposed.

Complete parent argv inventory, with every actual operand UNBOUND:

```text
[UNBOUND_INTERPRETER, UNBOUND_TRACKED_SOURCE,
 --route, UNBOUND_ROUTE, --grant, UNBOUND_ORIGINAL_GRANT,
 --binding-receipt, UNBOUND_EXTERNAL_B,
 --binding-sha256, UNBOUND_INDEPENDENT_ROOT_LAUNCH_BSHA,
 --row, UNBOUND_ROW, --strategy, UNBOUND_STRATEGY,
 --repetition, UNBOUND_REPETITION, --run-id, UNBOUND_RUN_ID]
```

B.parent_argv_shape and B.target_argv_shape are recipes, not literal complete argv.
Each has one literal $ROOT_BINDING_SHA256 solely at that option's operand; the
loader completes it using the independent launch digest, compares actual complete
argv exactly and propagates the same pair through the existing bootstrap. The
resource child route is resource-child and its grant is output/grant.original.json;
its argument order is as above, with no --qualification. For diagnostic/controls,
ROOT fills copy=null, target_argv_shape=[] and the exact parent route/qualification
shape. The shipped template selects no actual route/run/value. G duplicates the
unexpanded shape object; G.binding_receipt carries actual Bpath/Bsha acyclically.
Parent uses original G; child uses the exact byte-identical copy. L independently
binds original Gsha. Loader supplies consistency evidence, not ROOT authentication.

The profile entries bind immutable path/SHA256 evidence of actual default and
supported-single boundaries; they add no profile argument or comparison. ROOT must
still reconcile actual accepted113 ancestry/signatures, scientific/import-bearing
closure/lock, interpreter executable/prefix/startup/.pth/coverage conditions,
preload/allocator/array-API/thread settings, unique output/original/copy paths,
context/admission ancestry/headroom/swap/events/pressure/load/workspace/disk and
case-specific readiness/deadline/TERM/reap bounds. External ancestors remain
unknown_unobservable; no old116/control2 bounds or grants transfer automatically.

Fixed required FFT module applicability to non-FFT K routes remains unresolved,
separate from loader SOURCE acceptance. Do not import unused modules for proof.
Fresh affected SOURCE review of exact artifacts follows, then actual bound-method
qualification, ROOT-scoped controls, science/witness review, final Ubuntu full gate
and D. Resource90 remains proposal/no autobatch; reduced scope needs independent
S7 disposition. Historical control1 INCOMPLETE/control2 clean64edcad scope remain.
