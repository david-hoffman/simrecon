# Same independent control-method reviewer2 — affected delta1 only

Root explicitly authorizes continuing your own independent assessment for this
narrow affected delta, with a NEW preserved report/identities. No author history
inherited; your own old verdict context is permitted. Do not repair or execute.
Original review2 packet's read-only source/manual reasoning/control limits apply.
No Python/AST/lint/import/module/dependency/wrapper/control/test/probe/lifecycle
execution, no delegation, no tracked edit or publication.

Old report `control-method-review2.md` SHA
fce5143614f8553bf0f38fef99b50143820dfcc22d291a2e7b8e2f5f5865b55f
is frozen INCOMPLETE. Exact old proposal2v1 is at
`evidence/114/control-startup-proposal2-v1/` plus its external index; old packet
b29894fc remains unchanged. Retain your other source findings/runtime caveats;
unchanged finite math/source9daa4744…02c7/manifest6ae262ce…604d is not reopened.
No new scientific/source/noise witness or resource-launch fix exists.

## New exact frozen delta targets

Under `/workspace/work/campaign/evidence/114/control-startup-proposal2/`:

- preimport_control.py SHA f40898a03c2d80bf942101a432aaea01f66dfb0307aaff161ffb1c681e1adbac
- command-proposal.sh.txt SHA 0cb4766881123e913136c4ba214f3c69d6ddfb662c4437645bd6e87c8cd8d528
- materials.sha256 SHA 9abcf9030880422a3e2a564fb9fa2fc367a654f42db7c036ecc74dc764d408f3
- startup-materials.sha256 SHA 84576726a9784adf4cfbc42de60003266fe3548f461d1f189e0d15314b7d8126
- admission-proposal.json SHA 81469b1d02b860459381d074831b4ff4a16830a1a21eacad225cb4da592c6d15
- method-delta.md SHA f06bdd5f7af169da5d73993fba7c8b1f3c80ace91893e566db0a7f15aee78a56
- external updated control-startup-proposal2-index.sha256; material-paths unchanged.

Allowed extra raw source: actual four venv .pth, _virtualenv.py, pyvenv.cfg and
necessary source from existing allowed startup files. All material hashes and
old/new targets may be rechecked read-only. No claim authenticates a recursively
complete stdlib/system dependency graph; existing concrete hooks are the scope.

## Only affected questions

1. CM-R2-1: six startup identities now pinned (venv config, _virtualenv.py,
   _virtualenv.pth, two editable-path .pth and a1_coverage.pth). Exact Docker
   command empties only COVERAGE_PROCESS_START and COVERAGE_PROCESS_CONFIG before
   BOTH interpreters; wrapper refuses truthy trigger or already-loaded coverage
   and records empty-trigger/preloaded facts. Is this supported by actual hook
   source and sufficient to dispose your named startup gap for this bounded case?
   No blanket COVERAGE* stripping/global gate/hook edit or coverage claim follows.
   Preserve other interpreter/stdlib/native initialization unknowns and raw stderr.
2. Root identified v1's impossible hidden-ancestor certainty. It is removed;
   required external_ancestors literal is unknown_unobservable. Admission binds a
   ROOT-REVIEWED EXPOSED outer/inner same-underlying directory/current/max proof
   file hash, actual captured inner device/inode identities checked by wrapper,
   actual visible ancestor list and fresh observed values. It does not assert
   hidden ancestry resolved or absence of tighter external constraints. Review
   the conditional admission boundary and source consistency, not invent a proof
   of unobservable host ancestry. Root supplies actual exposed proof/context later.
3. Freshness300s instead of60s is explicitly root-authorized for reliable prepared
   command handoff. Context capture must occur AFTER exact command is ready;
   actual root per-case source/environment/headroom/material/visible-domain facts
   and raw startup evidence remain required. Does any wording/branch make a true
   boolean alone substitute for the manual evidence/admission conjunction?

Other AS/CPU/wall, source-free raw capture, samePID, actual post-call loaded FFT
paths/hashes, status/failure/partial-file and root-manual-review requirements are
unchanged. Source-only proposal, no approved admission/grant/context or execution.
Return scoped delta ACCEPT for root's separate concrete fresh admission decision,
actionable findings or INCOMPLETE. State which prior review2 conclusions are
retained and remaining actual-runtime/manual-evidence limits. No need whole audit
restart, unrelated resource-code review or added noise/scientific control.

Write ONLY NEW `/workspace/work/campaign/evidence/114/control-method-review2-delta1.md`.
Never mutate old report or target. Include exact identities, read/command statuses,
retained/affected findings and scope, own scratch/process facts and metering limits.
Notify campaign root and issue coordinator; coordinator yields WAIT after dispatch.
Requested Sol/high continues; unknown serving/effort/meters remain unknown.
This is affected-delta continuation1, not author/new review-session replacement;
prior INCOMPLETE/findings/checks/charges persist. Root's next authorized step after
scoped acceptance is fresh one-case admission, not a new generic permission loop.
FullW/resource quarantine/actual113/material/scientific/gate/D holds unchanged.
