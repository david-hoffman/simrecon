# HP114 native-route applicability preparation 1 — SOURCE ONLY / HOLD

2026-11-16. Fresh issue sub-coordinator `/root/issue_114_native_route_preparation5`.
This finite external preparation is a report to ROOT, not a second Current state,
independent verdict, accepted design, actual binding, runtime grant or command
READY. Sole Current remains `issue-114/docs/tasks/half-precision-study.md`.
ROOT owns integration, restacking, acceptance, runtime release and publication.

## Finding and smallest disposition

**No harness behavior change is needed to make the existing two-module check
applicable to the frozen K routes.** Both named extension modules have eager
import paths through the harness's existing `import scipy.fft`, before route
dispatch. This is a source conclusion about the inspected dependency files,
not an observation that a module loaded in any new interpreter. On K01–K03,
the check can truthfully establish actual loaded module-file identity at the
post-row checkpoint; it cannot establish that either FFT implementation performed
the row's arithmetic. K04 actually calls NumPy FFT, so it is not wholly non-FFT.

The smallest proposed disposition is an applicability paragraph in the eventual
reconciled manifest, with no new import, call, probe, row, guard relaxation,
binding schema or observer. Suggested text:

> The required two-module check records actual loaded extension-file identities
> at the post-row checkpoint for every numerical route. Existing SciPy FFT
> imports eagerly load both named modules in the bound dependency source. For
> K01/KERNEL, K02/KERNEL and K03/KERNEL this is startup/import provenance only;
> neither module is claimed to execute an FFT for these kernels. K04/KERNEL
> calls NumPy ifft; its SciPy FFT identity remains startup/import provenance.
> K01/CPU and controls call both public FFT interfaces. No unused backend is
> imported or called solely to obtain provenance. Actual module presence,
> resolved paths and file hashes must still be observed and match the reviewed
> per-attempt bindings. Missing or differing identities fail the attempt; source
> inspection or a selected on-disk path cannot replace that observation.

This text is a proposal for ROOT's actual-parent reconciliation and affected
method assessment. No existing source/manifest was edited merely to remove a
pending label. The existing manifest's unresolved label is preserved verbatim.

## Concrete source graph

References are literal source line locations in the inspected files. Their byte
identities are recorded in `literal-inputs.sha256`. The issue113 files are the
currently intended public-source snapshot, not a newly accepted113 pin.

1. Corrected dormant `witness-source-correction-1/study.py:3150–3156` imports
   NumPy, SciPy, `scipy.fft` and public `simrecon` before numerical dispatch.
   The resource child repeats that import sequence at lines 2211–2217.
   `environment()` observes `sys.modules` without importing either named
   extension. `required_fft_provenance()` at lines 1971–1983 also only reads
   `sys.modules`, resolves the loaded module's `__file__`, requires a file,
   hashes it and compares the resulting path/hash with `BINDINGS.native`.
   It does not turn a selected path into a loaded-module fact.
2. Installed SciPy `fft/__init__.py:86–89` imports `_basic`.
   `_basic.py:2` imports `scipy._lib._array_api`; that file imports
   `numpy as np_compat` from `scipy._external.array_api_compat` at lines 24–43.
   The vendored `array_api_compat/numpy/__init__.py` explicitly imports its
   `.fft` submodule. That `fft.py:5` calls `clone_module("numpy.fft", globals())`.
   `_internal.py:56–60` implements that call with `importlib.import_module`.
   NumPy `fft/__init__.py:203–205` imports `_pocketfft`, whose line 48 imports
   `_pocketfft_umath as pfu`. This is an eager source path to the first named
   extension, `numpy.fft._pocketfft_umath`; no transform call is needed.
3. SciPy `fft/__init__.py` imports `_backend` and `_duccfft.helper`.
   `_backend.py:3` imports `_basic_backend`; `_basic_backend.py:4` imports
   `_duccfft`; `_duccfft/__init__.py:3` imports `.basic`;
   `basic.py:6` imports `.pyduccfft as pfft`. Independently, `helper.py:13`
   imports `good_size, prev_good_size` from `.pyduccfft`. This is an eager
   source path to `scipy.fft._duccfft.pyduccfft`; no transform call is needed.
4. Intended113 `src/simrecon/__init__.py` eagerly imports the public known-stage
   and new `single_known` facade. Existing `known_parameters.py:26` imports
   `scipy.fft.ifftn`; `optical_transfer.py:19` imports `scipy.fft.rfftn`;
   `single_known.py:20` imports `scipy.fft`. These support the same startup
   dependency, but the harness's own explicit import already suffices. The
   public113 contract §1 preserves omission as `precision="double"` and adds
   no workflow/summary option. Merely importing its facade does not select
   `single-mixed-v1` or require a new study comparison.

The graph above establishes why the two existing modules are applicable as
import provenance. It is not a complete import/native dependency graph, ELF
dependency proof, loader authenticity proof or internal-precision proof. Other
startup modules, site/.pth effects, backend configuration, preload materials,
interpreter identity and actual file closure remain ROOT's existing binding and
qualification obligations. Current on-disk files are not substituted for future
Ubuntu/per-worktree identities.

## Exact row-use distinction

| Route | Actual transform calls in the inspected row source | Meaning of the two-module check |
| --- | --- | --- |
| Diagnostic K01/KERNEL | None. Half representation/encoding, scalar limits, stats/error reductions | Both startup/import provenance only |
| Diagnostic K02/KERNEL | None. Three declared alphas, small pack/promote vectors and stats/error reductions | Both startup/import provenance only |
| Diagnostic K03/KERNEL | None. Dyadic energies/cross sums, vdot and explicit half component ufuncs/reductions | Both startup/import provenance only |
| Diagnostic K04/KERNEL | `np.fft.ifft(quantized, norm="forward")` at study.py:1665; other subcases include linalg condition estimates and exact rational inversion | NumPy loaded-file identity accompanies a real NumPy FFT call; SciPy identity is startup/import provenance only |
| Diagnostic K01/CPU | Public NumPy and SciPy rfft/irfft in `cpu_feasibility()`; expected invalid norm diagnostics | Both interfaces are called; extension identity alone still proves no internal arithmetic precision or complete dispatch |
| Controls | Calls `cpu_feasibility()` as `K01_fft_policy`, alongside frozen finite controls | Both interfaces are called; controls remain method evidence only |
| W diagnostics/resource children | Existing preparation/replay NumPy transforms and known-stage SciPy inverse calls | Preserve current required identities and separate actual route qualification |

K01–K03 helpers `pack`, `stats`, `array_identity` and `error_metrics` were read
as text; their inspected operations do not add an FFT call. K03's vdot and K04's
linalg operations are not assigned to either FFT binary. Hashing these two FFT
files cannot identify every native routine performing those operations.

## Requirements for ROOT's later actual binding

1. Recheck applicability against the actual accepted113/integrated114 and
   provisioned dependency source. Freeze the relevant eager import-bearing
   files as materials. Record renewed source identities rather than converting
   this report's observed source hashes into future actual pins.
2. Keep the two existing names in the per-attempt native index for these
   unchanged import paths. Bind actual resolved extension-file paths/hashes
   from the provisioned environment. The post-row function must still obtain
   them from loaded module objects and match those bindings; selected file facts,
   package version strings and optional pre-call nulls are insufficient.
3. Preserve the existing failure behavior if the expected loaded module is
   missing or differs. Diagnose a changed import closure or environment; do not
   force an unused FFT import/call/probe or silently exempt the row to make it
   pass. If actual-parent source changes this eager closure, route a concrete
   applicability correction for fresh affected source/method assessment first.
4. Qualify the claim actually made: module-file provenance at a checkpoint.
   Source closure plus an observed loaded file is not proof that an FFT call
   dispatched through that extension, that startup registered no other backend,
   or that internal multipliers/accumulators/workspaces use any precision.
   Preserve the existing startup/backend/array-API qualification obligations
   for routes making transforms; no global precision proof is commissioned here.
   Floating-environment and native wait4 qualification likewise remain future
   ROOT obligations, unaffected by this applicability disposition.
5. `resource_materials()` does not itself loop over the native index; its
   before/after snapshots must not be described as native-file snapshots merely
   because the receipt contains native pins. The separate loaded-module
   post-call comparison performs the existing native-file check. Broader atomic
   or adversarial drift guarantees remain unproved and are not proposed.

## Preservation, checks and accounting

Read-only Git observed issue114 clean HEAD
`d5d6ff0e6ed62b869ebc2b1e01b20c12165f3c67`, tree
`b38e1e2f744b21814881a6dec9663b4723124ccc`. This remains provisional115
ancestry, not actual accepted113. The corrected dormant source remains
`bf82fb7ba4f23b6f5026e5391e3ae893737f3b2831c9846f5acd8012778eb7c2`.
All unconditional HOLDs and UNBOUND bindings remain. Historical failed/partial
controls and source acceptances retain their original identities and meanings.
All ten rows, three fresh successful-W repetitions and resource90 planning
remain unchanged; no resource-reduction proposal or RSS sampler was added.

This activity used only filesystem text/filename reads, SHA256 checks, read-only
Git identity/status and writing this new external preparation directory.
Some initial combined displays truncated and were narrowed. Mistyped candidate
contract/compat-source paths produced ordinary missing-file diagnostics; the
actual files were located and read. One report-only patch failed its context
check and was corrected; no target/source bytes were affected. No Python/AST/compile/import/refusal-path,
lint/types/tests, Docker, process scan/launch/signal, install/build, numerical,
resource or full-gate attempt occurred. No tracked file edit, commit, restack,
grant, hold release, worker/reviewer launch or independent acceptance occurred.
Actual bindings/method+witness qualification/study/SCI/full13/D/PR remain future
ROOT work. Requested role setting is Sol/high; actual serving attribution and
token/cache/cost/time/owner-wait meters remain unknown; human quota is NOT SET.

Created only this report and its literal input/output hash indices. No owned
target/worker/process was created; no claim is made about other roles' processes.
No fixture, cleanup or deletion. HOLD pending ROOT's actual113 transition.
