# HP114 — fresh independent CONTROL-METHOD review 1

You are the already-assigned fresh report-only reviewer. Do not delegate, repair,
execute/import study.py, run tests/controls or produce scientific/B/D acceptance.
Apply `.agents/skills/review-work/SKILL.md` independent scientific-method/oracle
principles in this explicitly scoped report-only mode. Root authorizes this
preparation review before final113; workflow/resource trials stay held.

## Freshness, authority and exact scope

Fresh tool route `fork_turns=none`, requested gpt-6.1-sol/high (project conservative
scientific choice), accepted PR109 fresh-tool policy. No author/implementation
conversation inherited. Same-model independent reasoning is allowed; no model
quality claim. Optional separate memory/delegation-disable/read-only controls
unavailable; restrictions are prompts on shared filesystem/permissions, not
engineered isolation. Serving attribution/effort and missing meters unknown.
Report any forbidden exposure and stop affected independent work.

Review only proposed `--route controls --row K01 --strategy KERNEL --repetition 1`
in safe source hold349bf30d6820482b787de8211b65580bd1019c81,
tree8e5cc9bede8a074590adc987958558843756d511, public baselineb344e41.
No finalparent rebase. Bind exact study.py9daa4744fbb30833f26d8cc249f0db27c26502f3410216fa808910fc09a402c7
and manifest6ae262ce4d228feff8d4dc2e2831dce010bbadd3a156d018402b7cbf272d604d.
Coordinator may refresh task/ledger status only during review; no target source
change is permitted. Review frozen archived source, reconcile live bytes by hash.
Any target change invalidates the affected review; no self-repair.

Allowed inputs:
- `/workspace/work/issue-114/AGENTS.md`, relevant PROJECT and role-launch/model
  guidance; review-work skill. Contract half-precision-feasibility-v1 scientific
  definitions/boundaries only; not author reports/tasks/history/lessons.
- Frozen `/workspace/work/campaign/evidence/114/control-method-inputs1/study.py`
  and manifest.md, constants-source.txt, observer-source.txt and control-input-source.txt.
  Full source is authoritative; slices are inspection aids. All control observers,
  constants and input vectors are bound by the full source hash.
- Same directory command-proposal.json, grant-proposal.json,
  material-identities.sha256 and external control-method-inputs1-index.sha256.
  Proposal is deliberately NOT_GRANTED/control_release=false, not execution authority.
- Needed current raw source files under issue114 product/dependencies to trace
  import/call boundaries or primary numerical/API meaning, including __init__.py,
  original preparation/noise/phase source, NumPy FFT and SciPy_duccfft helper/backend.
  Read source only, no product/dependency/module import/execution.
- Opened primary math/IEEE and official Python/NumPy/SciPy definitions where needed.
  Derive finite numerical expectations independently, not by running the harness.

Do NOT read coordinator source-inspection.md, Current state, role ledger, author
completion/check reports, raw numerical candidates, conversations, existing lessons
or116 reports. No data/verdict adoption. You may use read-only shell/Git/hash source
inspection. Tiny exact stdlib arithmetic if genuinely needed may use the existing
pinned Ubuntu interpreter, only your explicitly written integer/Fraction arithmetic;
never load/parse/exec the harness or import product/NumPy/SciPy. No installation,
AST/lint/format/tests, lifecycle/helper probe, benchmark or numerical trial. Prefer
independent mathematical derivation; record every permitted command/status.

## Independent questions and admission boundaries

1. Trace main→authorize→imports/environment/guard→finite_controls→export. Confirm
   this exact route never calls reconstruct/prepare/estimate/workflow/stage replay,
   resource_parent/resource_child, subprocess or unsupported launcher, including
   transitive import effects where relevant. Both resource entry guards must remain
   unconditional/unbypassable before writes/spawn. main currently imports the
   simrecon facade even for controls: assess whether that boundary requires a
   bounded correction or additional admission, without executing it.
2. Check finite payload/loop/input bounds and root receipt/thread/version/source
   admission. Six W generator identity controls create raw arrays only, not W
   scientific calls. K01 ranges, K03 length≤4096 dyadic variants, 16-point FFTs,
   tiny wire/NPY/hash/parser examples and observer export are the entire scope.
   KEEP/ARRAYS retain diagnostic operands and serialization adds cost. Is W05
   diagnostic-envelope admission honest/sufficiently bounded for later concrete
   per-case live headroom inspection? Unknown workspace/metadata is not zero.
   No process-RSS/performance/storage benefit or16GiB inference is allowed.
3. Independently derive binary16 max/normal/subnormal/ties/overflow and explicit
   `[2048,1,-2048]` left-associated half vs wider result conditional on RNE.
   Distinguish quantized operands, explicit half ufunc output and reduction policy
   from native FFT half arithmetic. Check warnings/nonfinite and zero-sign meaning,
   source-version/rounding/flush assumptions and whether controls can expose them.
4. Recalculate error max/RMS/relative-L2 and zero/empty semantics, paired-stride
   alignment, canonical C-order/endian/shape/dtype/signed-zero hash expectations,
   JSON IEEE component tags, tiny NPY roundtrip and incomplete-record rejection.
   Can any missing field, wrong expectation or swallowed failure look qualified?
   Exit0/controls-observed-pending-review is observation only; root must inspect
   every expected/actual outcome and warnings after a separately granted run.
5. Assess independent phase/noise-observer formulas insofar as source mathematics
   supports them, but determine exactly what is actually reached: this controls
   route has no call to oracle_checks/noise witness. State remaining noise/phase
   qualification gaps and whether descriptions overclaim coverage. Do not add a
   new control or change meaning to fill a gap in your review.
6. Assess NumPy/SciPy public rfft/irfft length16 norm=backward, threads/workers,
   version/source/binary identity and unsupported dtype/norm diagnostics. A
   roundtrip/dtype observation does not establish FFT accuracy, physical recovery,
   transform multiplier/accumulator precision or genuine half/complex32 support.
   SciPy source is_duccfft; native internal precision remains unknown.
7. Give a concrete source/control-method verdict: ACCEPT only the named static
   subset/method as suitable for root's later per-case execution decision, or
   actionable findings/INCOMPLETE. Separate mathematical defect, source/protocol
   defect, documentation gap and unexecuted environment/runtime question. No
   product repair authority or blanket study/resource qualification follows.

## Output and preservation

Write ONLY `/workspace/work/campaign/evidence/114/control-method-review1.md` as
new report (never overwrite an existing verdict), then return a distinct final
message. Include exact reviewed digests, independent oracle reasoning, scope/call
mapping, finite bounds/authority controls, findings/risk dispositions, command
statuses, assumptions/remaining runtime gaps and own scratch/process facts. No
tracked candidate file edit, commit/rebase/push/PR/merge/release/issue closure.
Root will require scoped acceptance plus concrete per-case inspection before any
actual tiny control execution. FullW scientific/resource/report acceptance,
working116 launch/material reconciliation, finalaccepted113, full Ubuntu gate
and D are separate remaining obligations.

This is independent review1; I1/S1 author history/failed checks/charges remain
elsewhere, not reset. Actual numeric human limits not set. Unknown tokens/cache/
cost/time/serving attribution stay unknown. Notify both campaign root `/root`
and issue coordinator on completion; coordinator yields WAIT after dispatch to
preserve capacity. No child delegation.
