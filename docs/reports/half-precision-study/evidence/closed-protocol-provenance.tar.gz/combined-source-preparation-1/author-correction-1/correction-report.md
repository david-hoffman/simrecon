# Completed HP114 author correction F1/F2 — SOURCE ONLY / HOLD

2026-11-17 UTC. This is the completed narrow correction by the same named
nonblind source author. It supplies a full standalone corrected candidate and
both requested diffs for fresh affected independent review. It is not a partial
handoff, independent acceptance, runtime/native/bound-method/scientific result,
actual113 integration or an execution release. final.txt is a distinct final
artifact; outputs.sha256 freezes the complete set and excludes itself.

## Authorized inputs and preserved rejected target

The correction packet author-correction-packet-1.md explicitly authorizes exactly
F1/F2, static-only, with writes restricted to this new author-correction-1 folder.
The original completed author and reviewer folders were preserved unchanged.
Their byte identities and this packet are captured in inputs.sha256. The original
author outputs.sha256 remains
353b56fbb5b81befd4dbd4c4d7fec4817323e530aedb633a5f6f6b5a6a2206c3;
its eight indexed files passed a static sha256sum --check after the correction.
Original study.py and manifest.md remain respectively
8daf384d93f77da29160e2aa57004a73d1b4dc0c2d4c3924fd98241c3d75520a and
21de23590e42ef37f040f4dbb8823c366f3ff2be9ec7f2b6b4208955d437ae04.

The completed independent review and DISTINCT final were read in full and their
hashes matched the packet:

- source-method-review.md:
  4dbd8ecd007cc4643ad6e2afe6627349e0a4b107c9d23403570b08d27c6a4223.
- reviewer/final.txt:
  0fa6d876f4e6252214a8626a0d06a7c9f5eb9090f735c8419830fde9444725c2.

That completed SOURCE NOT ACCEPTED verdict is retained. The original author's
claim that its unchanged timing design was complete is superseded for F1/F2;
neither the old report nor this correction supplies independent acceptance.
The reviewer found the exact8A selection/applicability design and preserved
science/loader/native aspects suitable within source-only limits, but those
findings do not establish actual qualification or excuse the two defects.

## F1 — corrected setup endpoint, with unchanged operations and guards

Frozen resource-plan.md §4 line215 assigns construction/packing/identity checks
to the caller/setup interval, ending before pre_call. The prior candidate set
setup_end_ns before KEEP retention, array_identity, statistics and the finite
scan. That excluded checks from setup_seconds and was a source conformance defect,
not an observed timing error: no measurement existed.

In corrected study.py:2308, the SAME existing
record["setup_end_ns"] = time.monotonic_ns() statement is moved after caller
identity/statistics and successful finite checks, immediately before
record["snapshots"]["pre_call"]. This is the ONLY Python source difference from
the completed author1 candidate. No call, arithmetic, check, failure category,
timer API, return, retention action, guard, allowlist, bound or validator changes.
Existing setup_start, setup_pack endpoints, setup_seconds arithmetic and
setup_to_call endpoints remain. The move makes setup_seconds include construction,
public preparation/packing, retention, identity/statistics and finite checks as
required. setup_to_call was already inclusive and stays so. If finite checks
fail, setup_end remains absent and the existing failure status is retained;
missing completion is not zero elapsed or successful qualification.

Affected caller path: existing main resource-child dispatch and existing
resource_parent fixed bootstrap target enter resource_child; neither caller nor
launcher is edited. The endpoint applies to the resource child's existing caller
branches without commissioning any unselected arm. Diagnostic run_workflow's
separately scoped setup boundary is unchanged.

Corrected manifest.md:88–104 explicitly includes caller identity/statistics/finite
checks in setup, with end immediately before pre_call. Corrected qualification-
obligations.md:136–138 requires that same placement; its existing clock ordering
and missing-evidence obligations remain. No alternative timing design or new
automated gate was introduced. This is an authored correction for review, not
proof of actual clock type/order/elapsed conformance in a future run.

## F2 — corrected elapsed versus terminal native RSS wording

The old leading manifest merged raw terminal peak/time coverage and affirmatively
included bootstrap. That contradicted the source's already precise unresolved
exec-transition high-water premise. The corrected manifest:105–111 separates:

- Parent spawn-to-terminal-observed elapsed includes bootstrap/exec, setup,
  output/JSON/teardown, exit and delayed wait observation; it is not exact child
  death time.
- Terminal native RSS is the sole cached exact-PID wait4 direct-child usage
  through JSON/teardown/exit, excluding parent/observer memory. Bootstrap/pre-exec
  peak retention across exec remains UNRESOLVED; same PID and elapsed coverage
  do not prove it.

The qualification preface at143–149 repeats that distinction instead of a broad
whole-lifecycle memory assertion. The later manifest terminal-rusage explanation
at890–891 now explicitly repeats the unresolved bootstrap/pre-exec premise.
Existing accurate same-PID caveats in the retained historical layer remain.
This report supersedes the original preparation-report's broader pre-exec/
whole-child peak implication. No peak magnitude, loss across exec, behavior of
Linux/CPython or actual bootstrap measurement is inferred here.

There is NO source/native/launcher change for F2: resource_parent's native
terminal scope at2681–2684 and parent elapsed field/scope at2938–2945 remain byte-
identical. No experiment, bootstrap probe, signal, wait, sampler or fallback was
performed or commissioned by this correction.

## Complete candidate, diffs and invariant scope

This directory contains the complete corrected study.py, manifest.md,
qualification-obligations.md and the byte-identical proposed-contract-manifest.patch.
The latter remains SHA256
a86bbe9bdb7851c18d8d2281c85219c47be6ed2b162b0a055bc6c75a0c3ad216,
so the original exact8A contract paragraph, manifest replacement and proposed S7
row have not changed. No tracked scenario or worktree document was edited.
The preceding contract5 lifecycle paragraph and five available-resource meanings
remain intact. Historical resource90 proposals are still historical.

correction-delta.patch compares the three changed candidate files with completed
author1. Its full textual diff was inspected: one existing source statement is
moved, and only the F1 timing/F2 memory-scope derivative prose changes.
source-delta.patch separately compares these complete corrected files against
the original immutable witness baseline. The original+correction lineage is
retained without rewriting either baseline. No helper or test/check framework
was written; both files are plain unified text patches, not applied tracked edits.

All scientific settings/arithmetic, generator/pack/replay/compose/oracle/K/CPU
recipes, transfer K1/K64 correction, full-index conditional witness and separate
upstream premises, full six-row RM84 common-projection/structural/lifetime
obligations remain. Detailed raw/actual seed/prepared metadata/operation/output
identity plus independent error/decision/trace applicability procedure remains
literal HOLD; no scalar/vector trig equality or tolerance is fabricated.

The exact fixed selected 12 order remains W02 then W05, each rep1 wider-half,
rep2 half-wider, rep3 wider-half. All 149 nominal primary scopes remain: 126 W
numerical, 6 QUALIFY, 4 K, 1 CPU, 12 resource. All ten rows and three fresh successful
W repetitions remain; every failed/refused/unsafe/skipped/partial attempt stays
separate. Other standalone benefits stay UNMEASURED, never proof of no benefit.

Every original top-level/main/authorize/resource refusal HOLD and actual
ROOT/EVIDENCE/EXPECTED/BINDINGS UNBOUND literal remains. Binding B/C/G/L loader,
material/argv checks, native bootstrap/sole exact-PID wait4/lifecycle/status/
ownership/recovery/validators/allowlists/bounds/guards are byte-identical to
author1. Actual accepted113 is still pending and no candidate/parent/material/
profile/native/binding/grant is guessed or populated. Module/source clock calls
remain unreachable behind unconditional holds. No runtime action is READY.

## Affected-evidence route and accounting

ROOT freezes this complete correction and obtains a FRESH affected independent
source review of F1 endpoint conformance and F2 derivative wording, including
preservation of all other bytes. This author launches no reviewer and self-
accepts nothing. Later actual clock evidence still needs independent type/order/
scope/seconds assessment; native bootstrap/pre-exec peak retention remains an
explicit unresolved runtime qualification premise. No prior timing/RSS result
is requalified or treated as measured by static text correction.

Actual113 integration/material and default-versus-single profile reconciliation,
exact B/C/G/L/current headroom, native/ownership/lifecycle/method controls, all
six full-grid/upstream scientific/RM84 assessments and W02/W05 applicability
remain ROOT-held. Later independent study runs/report/SCI, exact clean Ubuntu
all 13 make verify and fresh post-gate D remain pending. No new scenario, gate,
bound, allowlist, arm, backend, reserve, tolerance or numeric quota follows.

Only cat/sed/rg, mkdir/cp, apply_patch, diff and sha256sum static file/text/byte
operations were used. Ordinary transient shell/text-tool processes are not study
children. No Python/runtime/import/AST/compile/probe/native launch/install/Docker/
benchmark/control/RSS sampler/test/fullgate/numerical work or raw array read
occurred. Initial combined search output truncated only the second search; exact
resource-plan/source/manifest/qualification ranges were reread in a bounded call.
The full completed review/final were untruncated. Diff exit1 denotes intentional
text differences, not a failed runtime check. Input/output hashes are byte checks.

Writes were confined to this new correction folder. No scratch, temporary fixture,
NPY/raw data, grant, helper or persistent study process was created in this
correction. No other role's processes/scratch or global cleanup were inspected.
Original rejected author bytes and reviewer bytes are retained; all historical
failed/partial/exposed/control/static attempts and cumulative charges retain
their original meaning. This correction adds one author correction attempt and
does not reset that history or relabel nonacceptance as acceptance.

Requested model/effort: gpt-6.1-sol/high under the original fresh fork-none role.
Actual exposed model/effort/input/cached/output tokens/cache/money/complete
elapsed/owner-wait/check time: UNKNOWN. Human numerical quota: NOT SET. Optional
memory/read-only/delegation-disable controls remain unavailable; shared filesystem
and prompt restrictions do not establish engineered isolation. No delegation.
