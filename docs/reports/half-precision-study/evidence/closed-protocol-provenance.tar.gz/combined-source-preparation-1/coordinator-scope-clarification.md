# Narrow source ownership clarification

The author reported that the witness baseline already includes loader2, and proposed selected12 guard/order metadata alongside clocks/applicability work. Before any completed output was accepted, coordinator clarified ROOT's explicit no tests/gates/scenarios/allowlists/bounds/newhelperframework restriction: do not introduce a 12-slot admission guard or order framework; leave existing B/C/G/L/native guards unchanged. Exact selected12/fixed-order text belongs in manifest/proposed contract. A guard change thought necessary must remain a reported HOLD/obligation for ROOT.

The standalone path must retain one caller/one result and no reference arrays/reference workflow. Any applicability comparisons belong only in the existing QUALIFY diagnostic path or explicit future qualification obligation/HOLD; no extra reference lifetime is permitted in matched children. Hash identity by itself is no numerical adequacy verdict.

This record is nonblind coordinator routing, not a reviewer input before independent primary assessment. No runtime or source edit by coordinator; no completed candidate/verdict yet.
