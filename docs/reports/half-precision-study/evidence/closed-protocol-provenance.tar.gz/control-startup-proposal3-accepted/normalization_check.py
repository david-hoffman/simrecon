"""Focused stdlib-only checks of the new metadata/JSON boundary; no controls run."""
import hashlib
import json
from pathlib import Path
import runpy
import sys
from types import ModuleType

HERE = Path(__file__).resolve().parent
WRAPPER = HERE / "preimport_control.py"
OUTPUT = Path("/workspace/work/campaign/evidence/114/wrapper-serialization-check1")
EXPECTED_WRAPPER = "c90997a584654e9f8c6b208e6f234bad3166c995a8fba4323be04c8745c0dd51"
FORBIDDEN = ("numpy", "scipy", "h5py", "tifffile", "simrecon")
assert not any(name in sys.modules for name in FORBIDDEN), "product/dependency unexpectedly preloaded"
source_sha = hashlib.sha256(WRAPPER.read_bytes()).hexdigest()
assert source_sha == EXPECTED_WRAPPER
namespace = runpy.run_path(str(WRAPPER), run_name="HP114_METADATA_FUNCTION_CHECK_ONLY")
assert not any(name in sys.modules for name in FORBIDDEN), "wrapper imported a product/dependency"
normalize = namespace["text_attribute"]
write_new = namespace["write_new"]

class NoReprModule(ModuleType):
    def __repr__(self):
        raise AssertionError("arbitrary repr must never be called")

rows = []
for key in ("__version__", "__file__"):
    for case, supplied, expected, state, kind in (
        ("string", {key: "literal"}, "literal", "string", "str"),
        ("none", {key: None}, None, "none", "NoneType"),
        ("absent", {}, None, "absent", None),
        ("module", {key: ModuleType("unsupported_attribute")}, None, "unsupported", "module"),
        ("no-repr-module", {key: NoReprModule("never_repr")}, None, "unsupported", "NoReprModule"),
    ):
        value, fact = normalize(supplied, key)
        assert value == expected and fact == {"present": case != "absent", "state": state, "type": kind}, case
        row = {"attribute": key, "case": case, "value": value, "fact": fact}
        assert json.loads(json.dumps(row, allow_nan=False)) == row
        rows.append(row)

fake_name = "simrecon.__hp114_synthetic_metadata_only"
assert fake_name not in sys.modules
fake = ModuleType(fake_name)
fake.__file__ = str(WRAPPER)
fake.__version__ = ModuleType("unsupported_version")
try:
    sys.modules[fake_name] = fake  # Synthetic object only; no product module import.
    loaded = namespace["loaded_modules"]({str(WRAPPER.resolve()): source_sha})
    assert set(loaded) == {fake_name}
    first = loaded[fake_name]
    assert first["version"] is None and first["version_attribute"] == {
        "present": True, "state": "unsupported", "type": "module"}
    assert first["matches_admitted_material"] is True and first["path"] == str(WRAPPER)
    fake.__file__ = ModuleType("unsupported_path")
    loaded_bad_path = namespace["loaded_modules"]({})
    second = loaded_bad_path[fake_name]
    assert second["path"] is None and second["sha256"] is None
    assert second["matches_admitted_material"] is False and second["path_attribute"] == {
        "present": True, "state": "unsupported", "type": "module"}
finally:
    del sys.modules[fake_name]
assert not any(name in sys.modules for name in FORBIDDEN)

payloads = OUTPUT / "payloads"
payloads.mkdir()
valid = payloads / "normalized.json"
payload = {"cases": rows, "loaded_valid_path": first, "loaded_unsupported_path": second}
write_new(valid, payload)
assert json.loads(valid.read_text()) == payload
invalid = payloads / "serialization-must-not-create.json"
try:
    write_new(invalid, {"unhandled_object": NoReprModule("unsupported")})
except TypeError:
    pass
else:
    raise AssertionError("unsupported raw object did not fail")
assert not invalid.exists(), "serialization failed only after creating final sidecar"
original = valid.read_bytes()
try:
    write_new(valid, {"overwrite": "forbidden"})
except FileExistsError:
    pass
else:
    raise AssertionError("exclusive-write boundary failed")
assert valid.read_bytes() == original
result = {
    "wrapper_sha256": source_sha,
    "check_source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "attribute_cases": len(rows), "attribute_roundtrips": True,
    "actual_loaded_modules_helper_cases": 2,
    "version_module_explicit_type": True, "unsupported_path_explicit_type": True,
    "arbitrary_repr_called": False, "complete_json_before_open": True,
    "failed_serialization_final_file_absent": True, "exclusive_existing_bytes_preserved": True,
    "forbidden_top_level_modules_absent": True,
    "scope": "pure-stdlib own-wrapper functions only; no main/control/product/native scientific import or run",
}
with (OUTPUT / "result.json").open("x") as stream:
    json.dump(result, stream, indent=2, allow_nan=False)
    stream.write("\n")
print("metadata normalization/JSON boundary checks passed; no product or NumPy/SciPy import")
