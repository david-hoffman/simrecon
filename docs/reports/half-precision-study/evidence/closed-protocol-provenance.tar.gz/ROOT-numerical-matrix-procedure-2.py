"""ROOT finite131-case invocation procedure; no science imports or retry.

Requires separate completed ROOT release record before any case runs. Each case
has fresh B/C/G/L and closed unique capture. Native collection is conventional
GNUtime, not this procedure; source remains unchanged.
"""
from pathlib import Path
import copy, hashlib, json, math, subprocess, time

E=Path('/workspace/work/campaign/evidence/114')
W=Path('/workspace/work/issue-114')
METHOD=E/'current-method-attempts-1/M01-current-controls-attempt1'
PREFIX=json.loads((METHOD/'launch.json').read_text())['cleared_prefix']
PY=str(W/'.venv/bin/python');SRC=str(W/'docs/reports/half-precision-study/study.py')
PROTO=json.loads((E/'actual-bound-instance-2/binding-prototype.json').read_text())
FORMAT='{"native_ru_maxrss":%M,"native_units":"Linux KiB","exit_code":%x,"elapsed_seconds":%e,"user_seconds":%U,"system_seconds":%S}'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):
 with Path(p).open('x') as f: json.dump(d,f,indent=2,sort_keys=True);f.write('\n')
def strict(text):
 def pairs(v):
  d={}
  for k,x in v:
   assert k not in d,k
   d[k]=x
  return d
 return json.loads(text,object_pairs_hook=pairs,parse_constant=lambda x:(_ for _ in ()).throw(ValueError(x)))

release=json.loads((E/'ROOT-numerical-matrix-release-2.json').read_text())
assert release['runtime_released'] is True and release['procedure_sha256']==sha(__file__)
expected=[[f'W{i:02}',mode,rep] for i in range(1,7) for mode in ['WIDER','H1','H1_PROMOTED','H2_CORRECTED','H2_PREPARED','H2_FILTERED','H2_EMBEDDED'] for rep in [1,2,3]]+[[f'K{i:02}','KERNEL',1] for i in range(1,5)]+[['K01','CPU',1]]
assert release['cases']==expected
BASE=E/'current-numerical-captures-2';BASE.mkdir(exist_ok=False)
CONTEXT_CODE=(E/'actual-integrated-environment-2/C-observation-code.txt').read_text()
OBSERVER_CODE=(METHOD/'identity-observation-code.txt').read_text()
for row,strategy,rep in release['cases']:
 runid=f'N2-{row}-{strategy}-r{rep}-attempt1';K=BASE/runid;K.mkdir(exist_ok=False);R=E/'current-runs-2'/runid
 assert not R.exists()
 B=copy.deepcopy(PROTO);b=K/'binding.json';c=K/'context.json';g=K/'grant.json'
 def git(*args):return subprocess.check_output(['git','-C',str(W),*args]).decode().strip()
 candidate=B['bindings']['candidate'];assert git('rev-parse','HEAD')==candidate['commit'] and git('rev-parse','HEAD^{tree}')==candidate['tree'] and git('rev-parse','HEAD^')==candidate['parent'] and not git('status','--porcelain','--untracked-files=no')
 assert hashlib.sha256(subprocess.check_output(['git','-C',str(W),'diff','--binary','HEAD'])).hexdigest()==candidate['tracked_diff_sha256']
 shape=[PY,SRC,'--route','diagnostic','--grant',str(g),'--binding-receipt',str(b),'--binding-sha256','$ROOT_BINDING_SHA256','--row',row,'--strategy',strategy,'--repetition',str(rep),'--run-id',runid]
 qualification=None
 if row.startswith('W'):
  qualification=release['qualification_records'][row];assert sha(qualification['path'])==qualification['sha256']
  shape += ['--qualification',qualification['path']]
 B['bindings'].update(route='diagnostic',output=str(R),grant={'original':str(g),'copy':None},parent_argv_shape=shape,target_argv_shape=[])
 write(b,B);bh=sha(b)
 context_code=CONTEXT_CODE.replace('per-M01','per-'+runid)
 cp=subprocess.run(PREFIX+[PY,'-c',context_code],capture_output=True,timeout=30)
 (K/'C.stdout').write_bytes(cp.stdout);(K/'C.stderr').write_bytes(cp.stderr);assert cp.returncode==0,cp.stderr
 C=json.loads(cp.stdout);assert C['sigint_default'] and C['sigchld_default']
 C.update(scope='Fresh per-case Root admission for ONE small fixed unchanged numerical diagnostic. Existing source-derived W05 payload ledger covers selected six rows; all unknown reserve/native/pressure/ancestor caveats retained, no16GiBfit. Other roles retained-data only.',admission_rationale='Actual visible charged headroom and disk greatly exceed the source-derived conservative W05 modeled payload. W04 doubles T at 16x16, below W05 at32x32; others <=W02/W05. Full+summary diagnostic retained data and observer/native/metadata overhead are conditional, not zero. Source repeats own row guard before allocation. No other local numerical work. Admit only '+runid,binding_sha256=bh,row=row)
 write(c,C)
 G={'authorization':'HP114_NUMERICAL_WINDOW','environment':'simrecon-campaign-ubuntu','route':'diagnostic','bindings':B['bindings'],'candidate':B['bindings']['candidate'],'binding_receipt':{'path':str(b),'sha256':bh},'context':{'path':str(c),'sha256':sha(c)},'harness_sha256':B['artifacts']['harness_sha256'],'manifest_sha256':B['artifacts']['manifest_sha256'],'runs':[[row,strategy,rep]],'run_id':runid}
 if qualification is not None:G['qualification_sha256']={row:qualification['sha256']}
 write(g,G)
 inner=[bh if x=='$ROOT_BINDING_SHA256' else x for x in shape]
 usage=K/'terminal-native-usage.txt';time_argv=['/usr/bin/time','--quiet','-f',FORMAT,'-o',str(usage),'--']+inner
 L={'scope':'ROOT separately releases this ONE of131 fixed numerical observations. No additional/resource release or scientific acceptance. Preserve unexpected results/stop; no automatic retry. Ordinary qualified GNUtime directPython terminal route; Root read-only identity observer, no RSS sampling/source change/competingwaiter.','run_id':runid,'runtime_released':True,'release_path':str(E/'ROOT-numerical-matrix-release-2.json'),'release_sha256':sha(E/'ROOT-numerical-matrix-release-2.json'),'binding':{'path':str(b),'sha256':bh},'context':{'path':str(c),'sha256':sha(c)},'grant':{'path':str(g),'sha256':sha(g)},'cleared_prefix':PREFIX,'inner_argv':inner,'time_argv':time_argv,'outer_argv':PREFIX+time_argv,'time_binary_sha256':C['tool_sha256'],'time_format':FORMAT,'capture_directory':str(K),'source_output_absent':not R.exists(),'usage_file_absent':not usage.exists(),'release_time_unix_ns':time.time_ns()}
 write(K/'launch.json',L)
 observer_code=OBSERVER_CODE.replace(str(METHOD),str(K));(K/'identity-observation-code.txt').write_text(observer_code)
 print('START',runid,flush=True)
 start=time.time_ns()
 with (K/'observer.stdout').open('xb') as oo,(K/'observer.stderr').open('xb') as oe:
  observer=subprocess.Popen(PREFIX+[PY,'-c',observer_code],stdin=subprocess.DEVNULL,stdout=oo,stderr=oe)
  ready_deadline=time.monotonic()+20
  while not (K/'identity-observer-ready.json').exists() and observer.poll() is None and time.monotonic()<ready_deadline:time.sleep(.01)
  assert (K/'identity-observer-ready.json').exists(),'identity observer not ready; target NOTstarted'
  assert not R.exists() and not usage.exists()
  with (K/'stdout.txt').open('xb') as so,(K/'stderr.txt').open('xb') as se:
   target=subprocess.Popen(L['outer_argv'],stdin=subprocess.DEVNULL,stdout=so,stderr=se)
   rc=target.wait()
  orc=observer.wait()
 write(K/'ROOT-target-terminal.json',{'scope':'Actual outer target closed; collection only, no scientific verdict','returncode':rc,'start_unix_ns':start,'finish_unix_ns':time.time_ns(),'stdout_sha256':sha(K/'stdout.txt'),'stderr_sha256':sha(K/'stderr.txt'),'terminal_usage_sha256':sha(usage)})
 write(K/'ROOT-identity-observer-terminal.json',{'returncode':orc,'stdout_sha256':sha(K/'observer.stdout'),'stderr_sha256':sha(K/'observer.stderr'),'finish_unix_ns':time.time_ns()})
 record=json.loads((R/'run.json').read_text());u=strict(usage.read_text());ident=json.loads((K/'process-identities.json').read_text())
 assert rc==0 and orc==0 and ident['complete'],(rc,orc,record.get('status'))
 assert record['status']=='completed',record.get('failure')
 assert set(u)=={'native_ru_maxrss','native_units','exit_code','elapsed_seconds','user_seconds','system_seconds'}
 assert type(u['native_ru_maxrss']) is int and u['native_ru_maxrss']>0 and u['native_units']=='Linux KiB' and u['exit_code']==0
 assert all(isinstance(u[k],(int,float)) and math.isfinite(u[k]) and u[k]>=0 for k in ['elapsed_seconds','user_seconds','system_seconds'])
 assert u['native_ru_maxrss']>=max(record['pre_call_high_water_rss_kib'],record['native_peak_rss_kib_before_export'],record['native_peak_rss_kib_after_export'])
 assert record['materials_before']==record['materials_after'] and record['grant']==G
 for name,d in record['array_index'].items():
  p=R/d['path'];assert p.stat().st_size==d['nbytes'] and sha(p)==d['sha256'],name
 close_code="from pathlib import Path\nimport json\nD=json.loads(Path("+repr(str(K/'process-identities.json'))+").read_text());boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();out={}\nfor name,v in D['found'].items():\n try:\n  f=(Path('/proc')/str(v['pid'])/'stat').read_text().rsplit(')',1)[1].split();out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'current_start':int(f[19]),'original_identity_absent':boot!=v['boot_id'] or int(f[19])!=v['start_ticks']}\n except FileNotFoundError:out[name]={'pid':v['pid'],'old_start':v['start_ticks'],'original_identity_absent':True}\nassert all(x['original_identity_absent'] for x in out.values()),out\nprint(json.dumps(out))\n"
 cp=subprocess.run(PREFIX+[PY,'-c',close_code],capture_output=True,timeout=20);(K/'postclose.stdout').write_bytes(cp.stdout);(K/'postclose.stderr').write_bytes(cp.stderr);assert cp.returncode==0,cp.stderr
 write(K/'ROOT-closed-collection-summary.json',{'scope':'Collected exact one numerical diagnostic, no independent scientific acceptance or additional/resource release','row':row,'run_id':runid,'run_sha256':sha(R/'run.json'),'status':record['status'],'indexed_arrays_checked':len(record['array_index']),'usage':u,'source_snapshots_KiB':{k:record[k] for k in ['pre_call_high_water_rss_kib','native_peak_rss_kib_before_export','native_peak_rss_kib_after_export']},'postclose_identities':json.loads(cp.stdout),'material_grant_unchanged':True,'finish_unix_ns':time.time_ns()})
 files={}
 for root in [K,R]:
  for p in sorted(root.rglob('*')):
   if p.is_file():files[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
 write(K/'ROOT-closed-raw-inventory.json',{'files':files,'scope':'Closed actual raw files, collection inventory only; excludes this self record'})
 print('CLOSED',runid,'arrays',len(record['array_index']),'terminal_KiB',u['native_ru_maxrss'],flush=True)
print('NUMERICAL131_COLLECTED_CLOSED; actual scientific acceptance pending; NOresource release',flush=True)
