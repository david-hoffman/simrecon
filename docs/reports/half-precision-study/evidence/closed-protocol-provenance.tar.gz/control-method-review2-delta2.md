# HP114 CONTROL-METHOD review2 — affected continuation2

## Scoped verdict

**ACCEPT** for the exact proposal3 post-observation serialization and new-attempt identity delta, suitable for root's separate next one-case admission decision. No new actionable finding in this affected scope. The actual known ModuleType-valued metadata failure is addressed without fabricating a textual version or permitting a missing required FFT identity. The focused pure-stdlib evidence supports the changed helper boundary and does not substitute for an actual native/control run.

Attempt1 remains renderer-exit2/incomplete, with its truncated post JSON and missing maps. No partial historical observation or new helper pass retrospectively qualifies it. Root must supply an exact new material/grant freeze, fresh context and exposed-domain proof, and explicit once release for attempt2. No automatic retry, limit increase or execution authorization follows from this report.

## Exact reviewed identities

| Input | SHA256 |
| --- | --- |
| Continuation2 packet | `a7453756d18aa813c2c3177937b16e461cc4eb1d01b8743de57a635c6039213a` |
| Prior accepted delta1 report | `6bce728874351ca00c71564c74e0cdabe1814d0dfacbc9a6bce43c4e39fd5c04` |
| Proposal3 wrapper | `c90997a584654e9f8c6b208e6f234bad3166c995a8fba4323be04c8745c0dd51` |
| Proposal3 command | `198794e6b711075d17d44346ef5f1c66bfc432eb1455bf9238a9ca78f123e9d7` |
| Proposal3 materials.sha256 | `c2bca1dcd75366dfbc6bdf99f535023b78c422b551f31c8a47dd2ce985b832d4` |
| Unchanged startup manifest | `84576726a9784adf4cfbc42de60003266fe3548f461d1f189e0d15314b7d8126` |
| Proposal3 admission proposal | `32bae8d063a9f8a0c3528698544653fe2a0d9417084116222068caf13bfe4aa6` |
| Proposal3 study-grant proposal | `2d587a223d356dffc7bbf33dd1dd5713dc729aa88e1d3181ce635c2e41091df1` |
| serialization-delta.md | `c85cd701ff7c43a93390954cbceaeefa398ebe977e05e58f4c79d147a0b55cc9` |
| Focused normalization_check.py | `249f1706990819158d28b768055042cf71b4ecaa21183cad30a2f4602f3496b6` |
| Proposal3 external index | `1e71b9eabcb6eb868227088721c28f5f00f404da6fefb1ce67f38cd6231dc5e3` |
| Focused check result.json | `f957c89129141ad89af10bff72ee40289d0cbf31826ad46cc8db1162178a03c7` |
| Focused normalized payload | `621f4d3890b8fe59112260478057a98f28f2253ab42009e2b06274285d2bb59e` |
| Attempt1 raw startup stderr | `3304fcb0c81762325e3628c3cf409341892689e55f49370a7fbce1f20ad062fb` |
| Attempt1 partial post JSON | `441c958cbbb0a4584802f692cba682ed7396b04189fd696d1e613390920bbddd` |

All explicit hashes matched. Proposal3 material verification using `sha256sum --quiet -c` from the issue-114 root was silent and exited0. This includes unchanged study `9daa4744fbb30833f26d8cc249f0db27c26502f3410216fa808910fc09a402c7` and manifest `6ae262ce4d228feff8d4dc2e2831dce010bbadd3a156d018402b7cbf272d604d`. No whole-study/math re-review occurred. Old executed wrapper and command were compared directly with the new siblings; only the stated helper/metadata and bounded path/run-id changes appeared.

## Affected source and evidence assessment

**Known failure diagnosis.** Raw attempt1 stderr is `HP114 post-observation incomplete: TypeError: Object of type module is not JSON serializable`. The permitted bounded text tail stops at numpy.f2py.cfuncs's version value. Installed cfuncs.py imports `from . import __version__`, retaining that module as its `__version__` attribute; its separate `f2py_version` accesses `__version__.version`. Installed __version__.py imports the string version from numpy.version. Thus the original wrapper's unconditional `namespace.get("__version__")` can indeed place a module object in its JSON payload. That is a wrapper metadata/serialization defect, not numerical failure evidence. The permitted serialization-delta document also contains historical partial numerical summaries; I did not adopt or independently assess them and did not open numerical run.json/array candidates.

**Honest JSON-safe attributes.** New `text_attribute` returns an unchanged value only when its exact type is str, or null for explicit None, absent or unsupported values. Separate facts distinguish presence, state and type. It never calls str/repr on the arbitrary value. For the observed ModuleType version, output is null with present:true/state:unsupported/type:module, rather than a forged version. Both version and __file__ use this helper in the actual loaded_modules path. Optional missing/unsupported version metadata stays a disclosed limitation; it is not a claimed version match.

A non-string path now yields null path/hash and false matches_admitted_material, with explicit unsupported type facts. The unchanged required-FFT predicate short-circuits on missing path/hash and forces incomplete/nonzero. String paths still go through actual resolution/hash/admitted-material matching and exact expected FFT matching. This correction does not weaken required identity or invent a path from arbitrary repr text. Unexpected further metadata/hash/IO failures still follow the existing incomplete path; the source does not promise all possible runtime module values are harmless.

**Pre-serialization boundary.** `write_new` now completes `json.dumps(..., allow_nan=False)` plus newline before opening the destination with mode x. A serialization TypeError/ValueError cannot create this final-named file through that helper, including the actual known unsupported-object case. Exclusive open still refuses an existing file. The change is not an atomic filesystem writer: a later open/write/close/transport failure can leave partial bytes and remains incomplete. Building the complete string adds a finite metadata allocation under the same existing target limits; it changes no numerical buffer policy or operating-limit constant. The retained renderer/complete-file conjunction remains essential.

**Focused helper evidence.** Read the exact 100-line check source and retained command/stdout/stderr/exit/result/normalized payload. The check invokes the actual wrapper definitions with non-main runpy name, verifies the wrapper hash, and obtains the actual text_attribute/write_new/loaded_modules functions. The wrapper's main guard is not entered. The check's imports are stdlib only; it asserts the five actual product/numerical top-level packages are absent before and after loading definitions. Its synthetic simrecon-prefixed ModuleType sys.modules row is not a product import and is removed in finally.

Ten attribute cases exercise both keys across exact string, None, absent, ModuleType and a ModuleType subclass whose repr raises. Two synthetic loaded_modules calls exercise admitted real string path plus module version, and unsupported module path. JSON roundtrips use the normalized actual rows. A raw unsupported module sent to write_new must raise TypeError before the final file exists; a second write to an existing payload must raise FileExistsError and preserve bytes. These are meaningful checks of the observed metadata failure and write boundary, not mirrored scientific oracles or product-red evidence. The retained result binds the exact wrapper/check hashes, reports all ten/two cases, and exit.json records0; stdout reports success and stderr is empty. I inspected that existing proof only and did not rerun it. It establishes this narrow helper behavior in the recorded run, not native imports, overall post-sidecar completion or numerical qualification.

**New bounded identity.** Fixed RUN_ID is now control-method-K01-attempt2. Exact command points to proposal3's wrapper/admission and control-startup-attempt2 transport files; proposed grant/context/proof/output paths likewise use the new sibling/attempt identity. Grant is deliberately NOT_GRANTED_REVIEW_ONLY with control_release:false; admission authorized:false and placeholder hashes remain nonauthorizing. Source retains exclusive wrapper output creation, exclusive sidecars and study attempt directory creation. Existing attempt1 outputs/receipts are not rewritten by the proposed new paths. Actual new grant/admission/context/proof must be frozen and reviewed afresh; attempt1 facts are not automatically reusable fresh admission.

## Retained conclusions and limits

Prior finite arithmetic/representation assessment remains applicable only under unchanged study9daa/manifest6ae; CM3 phase/noise remains absent. Prior CM-R2-1 disposition, six startup inputs, named coverage preconditions, same-PID runpy, AS/CPU/wall/renderer timeout scopes, raw startup capture, exposed outer/inner proof and actual visible list with unknown_unobservable external ancestors,300s fresh-context manual ordering, exact loaded FFT paths/hashes, non-FFT manual identity inventory, and failure/partial-file/manual-review caveats remain in force. The source diff gives no reason to reopen unrelated resource or scientific code.

Root acceptance after separately released actual execution still requires successful actual transport AND complete valid pre/post/maps/study/array outputs AND correct same-PID/limits/identity facts AND full raw stderr/warnings/every control-outcome review AND actual fresh material/context/proof applicability. A pending status or file existence alone cannot pass. Startup/native initializer effects, arithmetic precision, complete native runtime behavior and the next overall attempt outcome remain unobserved by this review. Full W/diagnostic matrix, resource quarantine/working116 acceptance, final113/material reconciliation, scientific acceptance and full verification/D holds remain separate. No old failure/partial evidence is erased.

## Commands and accounting

Only read-only shell cat, sha256sum, rg, tail, nl, sed and diff were used. Relevant packet/proposal/proof/old-report hashes and the new full material index were checked; material verification exited0 without errors. One source-inspection shell exited1 because its final diff correctly reported changed old/new command bytes; other inspection shells exited0. No reviewer Python, AST/compile/lint/test, import/module/product/dependency/wrapper/control execution, probe, repair, delegation, tracked edit, commit, publication or cleanup operation occurred.

This is reviewer2 affected continuation2, following the preserved original INCOMPLETE and continuation1 scoped acceptance. Actual attempt1 failure and all prior author/check/repair/failed-patch charges remain; the focused own-helper check is existing separately authorized evidence, not a new reviewer run. Created only this new report with noclobber. No scratch files, child agents or background processes were created; nothing needs cleanup. Requested Sol/high continues; actual serving attribution/effort and unavailable token/cache/cost/time meters remain unknown. Shared filesystem/prompt-only restrictions and unavailable optional isolation controls remain as disclosed previously. No prohibited numerical candidate contents were opened.
