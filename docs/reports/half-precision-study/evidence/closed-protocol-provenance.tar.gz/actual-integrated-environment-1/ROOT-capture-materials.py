"""Finite Root readiness metadata, never a study observation or admission."""
from pathlib import Path
import hashlib
import importlib.metadata
import json
import os
import platform
import site
import subprocess
import sys
import time
import numpy
import scipy
import scipy.fft
import h5py
import simrecon

W = Path('/workspace/work/issue-114')
O = Path('/workspace/work/campaign/evidence/114/actual-integrated-environment-1')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name, value):
    (O / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')
def optional(p):
    try:
        return Path(p).read_text()
    except OSError as error:
        return {'unavailable': type(error).__name__}

head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert head == 'b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d'
assert not subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=W)
paths = subprocess.check_output(['git', 'ls-files', 'src', 'scripts', 'devtools/src', 'docs/contracts', 'docs/packets/half-precision-study', 'docs/reports/half-precision-study', 'docs/tasks/half-precision-study.md', 'tests/test_reconstruction_summary.py', 'tests/test_single_known_boundary.py', 'tests/test_single_known_precision.py', 'pyproject.toml', 'uv.lock', 'Makefile', 'setup.py', 'setup.cfg', '.python-version'], cwd=W, text=True).splitlines()
materials = {p: sha(W / p) for p in paths if (W / p).is_file()}
startup_paths = {Path(site.__file__).resolve(), (W / '.venv/pyvenv.cfg').resolve(), Path(sys.executable).resolve()}
for folder in site.getsitepackages():
    startup_paths.update(p.resolve() for p in Path(folder).glob('*.pth'))
for name in ('sitecustomize', 'usercustomize'):
    module = sys.modules.get(name)
    if module is not None and getattr(module, '__file__', None):
        startup_paths.add(Path(module.__file__).resolve())
startup = {str(p): sha(p) for p in sorted(startup_paths) if p.is_file()}
native = {}
for key, folder, pattern in [('numpy.fft._pocketfft_umath', Path(numpy.__file__).parent / 'fft', '_pocketfft_umath*.so'), ('scipy.fft._duccfft.pyduccfft', Path(scipy.__file__).parent / 'fft/_duccfft', 'pyduccfft*.so')]:
    found = list(folder.glob(pattern))
    assert len(found) == 1, (key, found)
    p = found[0].resolve()
    native[key] = {'path': str(p), 'sha256': sha(p), 'loaded_in_readiness': key in sys.modules}
loaded = {}
for name, module in list(sys.modules.items()):
    value = getattr(module, '__file__', None)
    if isinstance(value, str) and Path(value).is_file():
        p = Path(value).resolve()
        loaded[name] = {'path': str(p), 'sha256': sha(p)}
selected_env = ['PATH', 'VIRTUAL_ENV', 'PYTHONPATH', 'PYTHONHOME', 'PYTHONOPTIMIZE', 'PYTHONNOUSERSITE', 'PYTHONSAFEPATH', 'PYTEST_PLUGINS', 'COVERAGE_PROCESS_START', 'COVERAGE_RCFILE', 'COVERAGE_FILE', 'LD_PRELOAD', 'LD_LIBRARY_PATH', 'MALLOC_ARENA_MAX', 'PYTHONMALLOC', 'SCIPY_ARRAY_API', 'OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS', 'BLIS_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS', 'NUMEXPR_NUM_THREADS']
physical = {p: optional(p) for p in ['/proc/meminfo', '/proc/pressure/memory', '/proc/pressure/cpu', '/proc/self/cgroup', '/proc/self/mountinfo', '/proc/sys/kernel/random/boot_id', '/sys/fs/cgroup/memory.max', '/sys/fs/cgroup/memory.current', '/sys/fs/cgroup/memory.peak', '/sys/fs/cgroup/memory.events', '/sys/fs/cgroup/memory.swap.max', '/sys/fs/cgroup/memory.swap.current', '/sys/fs/cgroup/cpu.max', '/sys/fs/cgroup/cpuset.cpus.effective']}
write('materials.json', materials)
write('startup.json', startup)
write('native-files.json', native)
write('loaded-module-files.json', loaded)
write('readiness-environment-and-physical.json', {'scope': 'Cheap actual readiness metadata ONLY; not scientific data, current per-attempt headroom admission, whole native authenticity or control qualification. Native file lookup is not backend execution. Fresh physical C/L required before each future attempt; hidden ancestors/outside actors unknown.', 'head': head, 'time_unix_ns': time.time_ns(), 'python': {'path': sys.executable, 'resolved': str(Path(sys.executable).resolve()), 'prefix': str(Path(sys.prefix).resolve())}, 'versions': {n: importlib.metadata.version(n) for n in ['numpy', 'scipy', 'h5py', 'coverage', 'pytest', 'pytest-xdist', 'ruff', 'pyright', 'simrecon']}, 'os_release': optional('/etc/os-release'), 'platform': platform.platform(), 'selected_environment': {k: os.environ.get(k) for k in selected_env}, 'sys_path': sys.path, 'flags': str(sys.flags), 'user_site_enabled': site.ENABLE_USER_SITE, 'fft_default_workers': scipy.fft.get_workers(), 'physical_snapshot': physical, 'disk': list(os.statvfs(W))})
print(json.dumps({'scope': 'metadata completed; no study/control invocation', 'head': head, 'material_count': len(materials), 'startup_count': len(startup), 'native': native, 'loaded_module_file_count': len(loaded)}))
