"""ROOT operational health check; no scientific workload or product edits."""
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

root = Path('/workspace/work/issue-114')
expected_head = sys.argv[1]
assert sys.version_info[:3] == (3, 13, 12)
assert __debug__ and sys.flags.optimize == 0 and sys.platform == 'linux'
assert Path(sys.prefix).resolve() == root / '.venv'
exe = Path(sys.executable).resolve()
assert hashlib.sha256(exe.read_bytes()).hexdigest() == 'fed567fcbdacc14612dddd5f29a3203fbe5c93f50b926f15e7a926cf668822a5'
import numpy
import scipy
import scipy.fft
import h5py
import simrecon
assert Path(simrecon.__file__).resolve() == root / 'src/simrecon/__init__.py'
expected = {'numpy': '2.5.3', 'scipy': '1.18.1', 'h5py': '3.16.0', 'coverage': '7.16.2', 'pytest': '9.1.1', 'pytest-xdist': '3.8.0', 'ruff': '0.16.9', 'pyright': '1.1.414'}
versions = {name: importlib.metadata.version(name) for name in expected}
assert versions == expected
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip()
tree = subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain=v1', '--untracked-files=all'], cwd=root, text=True)
assert head == expected_head and not status
java = '/workspace/.simrecon-tools/jdk-21.0.7+6/bin/java'
assert os.environ['SIMRECON_JAVA'] == java
j = subprocess.run([java, '-version'], capture_output=True, text=True, timeout=15)
assert j.returncode == 0 and '21.0.7' in j.stderr
u = subprocess.run(['/workspace/.simrecon-tools/uv-env/bin/uv', '--version'], capture_output=True, text=True, timeout=15)
assert u.returncode == 0 and u.stdout.startswith('uv 0.12.19')
assert importlib.metadata.version('simrecon') == '0.1.0'
print(json.dumps({'scope': 'Cheap actual final candidate health only; no scientific call or full gate', 'head': head, 'tree': tree, 'FULL_status': status, 'python': str(exe), 'platform': platform.platform(), 'debug': __debug__, 'optimize': sys.flags.optimize, 'versions': versions, 'fft_default_workers': scipy.fft.get_workers(), 'java': {'path': java, 'stderr': j.stderr}, 'uv': u.stdout.strip(), 'product_version': '0.1.0'}, sort_keys=True))
