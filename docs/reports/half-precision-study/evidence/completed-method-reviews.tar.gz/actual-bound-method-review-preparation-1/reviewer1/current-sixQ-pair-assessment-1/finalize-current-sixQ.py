"""One-off six-row raw closure supplements and completed output bookkeeping."""
import hashlib,json
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');O=B/'actual-bound-method-review-preparation-1/reviewer1/current-sixQ-pair-assessment-1';P=B/'actual-bound-method-review-preparation-1/current-sixQ-pair-followup-1';S=Path('/workspace/work/issue-114')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
primary=O/'current-sixQ-raw-primary.md';assert h(primary)=='7f7261328c5b470a571c94812f16718007b262182ac90763d9612169f57d7254'
projections=load(O/'six-projection-results.json');finite=load(O/'six-finite-reference-provenance-results.json')
supplement=[];eligibility=[]
for p,a in zip(projections,finite):
    assert p['row']==a['row'];K=B/'current-qualification-captures-2'/a['run_id'];R=B/'current-runs-2'/a['run_id']
    c=load(K/'context.json');rawc=load(K/'C.stdout');obs=load(K/'ROOT-identity-observer-terminal.json')
    assert all(c[k]==v for k,v in rawc.items() if k not in ['scope','admission_rationale'])
    assert obs['returncode']==0 and obs['stdout_sha256']==h(K/'observer.stdout') and obs['stderr_sha256']==h(K/'observer.stderr')
    assert (K/'observer.stderr').read_bytes()==b'' and (K/'C.stderr').read_bytes()==b''
    supplement.append({'row':a['row'],'raw_C_observation_fields_match_bound_C':True,'C_additional_fields':'row/B binding and ROOT admission/scope prose','observer_terminal_and_streams_verified':True,'scope':'supplemental raw metadata verification after primary; no probe/reap or new numerical quantity'})
    eligibility.append({'row':a['row'],'run_id':a['run_id'],'qualification_path':str(R/'run.json'),'qualification_sha256':h(R/'run.json'),
      'source_sha256':'246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635',
      'common_projection':'COMPLETE_32_FIELDS_ALL_ORIGINAL_VALUES_AND_ORDER_WITH_APPLICABLE_ACCEPTED_RM84_GENERIC_TYPE_STRUCTURE_OWNERSHIP_RETENTION',
      'mapping_entries':p['mapping_rows'],'common_numerical_arrays_direct_byte_equal':10,'actual_branches':a['branches'],
      'descriptive_row_comparison_eligibility':'ELIGIBLE for its seven nominal W modes x three fresh successful repetitions relative to actual wider; ROOT must separately grant/admit/observe/dispose each attempt',
      'independent_fullgrid_upstream_science':'UNRESOLVED_NOACTIVATION',
      'selected12_prepared_eligibility':'CONDITIONALLY_ELIGIBLE_SEPARATE_ROOT_ADMISSION' if a['row'] in ['W02','W05'] else 'NOT_SELECTED_RESOURCE_ROW',
      'prepared_raw_seed_metadata_consumed_operation_argument':a['resource_applicability'],
      'future_guards':'fresh exact C/B/G/L/source/material/default/native/admission; reviewed qualification hash; actual caller/unpack/outputs/stats/branches/wait4/terminal/closure; corresponding wider/H2_PREPARED continuation and finite scientific/error disposition',
      'runtime_or_future_value_preacceptance':False})
write('supplemental-raw-metadata-checks.json',supplement);write('row-eligibility.json',eligibility)
new=load(B/'actual-integrated-environment-2/materials.json');old=load(B/'actual-integrated-environment-1/materials.json')
assert len(new)==len(old)==143 and set(new)==set(old)
diff={k:{'old':old[k],'current':new[k]} for k in new if new[k]!=old[k]}
assert set(diff)=={'docs/reports/half-precision-study/study.py','docs/tasks/half-precision-study.md'}
assert load(B/'actual-integrated-environment-2/startup.json')==load(B/'actual-integrated-environment-1/startup.json')
assert load(B/'actual-integrated-environment-2/native-index.json')==load(B/'actual-integrated-environment-1/native-index.json')
write('current-material-applicability.json',{'materials':143,'old_to_current_changes':diff,'startup7_native2_index_bytes_equivalent_as_records':True,'public_materials_sha256':h(O/'accepted-public-materials.sha256'),'scope':'actual retained index/ordinary raw observations; no new SOURCE gate or live native imports'})
inputs={}
for line in (O/'raw-inputs-verified.sha256').read_text().splitlines():
    expected,name=line.split('  ',1);assert h(Path(name))==expected;inputs[name]=expected
extra=[P/'reviewer-packet-1.md',P/'current-sixQ-raw-inputs.sha256',B/'W02-direct-preparation-type-correction-1/author/study.py',B/'actual-bound-source-preparation-1/author/study.py',B/'actual-bound-metadata-preparation-1/author/manifest.md',B/'actual-bound-metadata-preparation-1/author/qualification-obligations.md',B/'ROOT-source2-integration-and-freeze-1/ROOT-integration-and-material-freeze.json']
extra += [B/'actual-integrated-environment-2'/name for name in ['candidate.json','materials.json','native-index.json','startup.json','C-observation-code.txt']]
extra += [B/'actual-integrated-environment-1'/name for name in ['materials.json','native-index.json','startup.json','default-profile.json','single-profile.json']]
extra += [S/'docs/contracts'/name for name in ['reconstruction-memory-v1.md','c-equivalence-workflow-v1.md','c-equivalence-acquisition-modes-v1.md','c-equivalence-carrier-modulation-v1.md','c-equivalence-known-parameters-v1.md','c-equivalence-optical-transfer-v1.md','half-precision-feasibility-v1.md']]
extra += [O.parent/'report.md',O.parent/'M01-actual-assessment-1/report.md',O.parent/'M01-actual-assessment-1/file-arithmetic-results.json',O.parent/'historical-W01-pair-assessment-1/report.md',O.parent/'historical-W01-pair-assessment-1/W01-retained-analysis.py']
for line in (O/'accepted-public-materials.sha256').read_text().splitlines():
    expected,name=line.split('  ',1);assert h(Path(name))==expected;extra.append(Path(name))
for p in extra:inputs[str(p)]=h(p)
assert h(B/'ROOT-source2-integration-and-freeze-1/ROOT-integration-and-material-freeze.json')=='a98362575b8a30046d2d8d1f28647908e4d22bfd12412399cbbfc47d93ff178e'
(O/'inputs.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(inputs.items())))
write('read-ledger.json',{'ordering':'accepted public applicability+allowed current context/raw -> six-row own primary SHA freeze -> six ROOT summaries/inventories as attributed comparisons -> supplemental raw C/observer checks',
 'raw':load(O/'raw-read-ledger.json'),'phase2':load(O/'phase2-read-ledger.json'),
 'additional':[{'path':str(p),'sha256':h(p),'scope':'public/source/context identity and relevant inert text; same-reviewer prior accepted proof/mapping aid as explicitly described; no target execution'} for p in extra],
 'exposure_limits':'ROOT integration freeze contains accepted source-application reference as commissioning context; no active author/reviewer correctness opinions or current Q ROOT summary body before primary. No separate K5/CPU file or coordinator failed-overbroad filter file read.',
 'historical_code_aid':'prior W01 one-off read as TEXT to author NEW fixed-six script only; never imported/run as reusable comparator library. Original historical bytes unchanged.'})
write('reference-and-claim-dispositions.json',{'per_row':[{'row':a['row'],'complete_compatibility':True,'actual_branch_evidence':a['branches'],
 'independent_finite_supported':['nearest-even actual analytic64-to-raw32 cast','alpha and rounded corrected source','all finite centered coordinate bits','complete artificial caller/consumed H_m table','signed finite actual output and full stage stacking','uniform noise1 where applicable'],
 'conditional_or_recorded_only':['selected non-DC forward sums use actual separators','W06 finite inverse-row energy/noise arithmetic conditions on actual separator','stored replay/two-point witnesses use actual F/K/native transforms','complete search/fit/filter trace projection is actual decision evidence, not independent numerical interpretation'],
 'UNRESOLVED':['complete analytic specimen/illumination trig reference uncertainty','all prepared Fourier coefficients/finite error','all transfer/filter stencils/support/cutoffs/denominators/recombination','complete fit/search/adjustment floating interpretation','all conditional assembly expected grid values and justified uncertainty'],
 'eligibility':'descriptive relative-to-wider row comparisons; W02/W05 conditional selected12 only','no_scientific_activation':True} for a in finite],
 'owner':'ROOT owns any concrete additional finite claim/need/release and all admission; final SCI DIFFERENT fresh session after complete exact whole-study evidence',
 'new_experiment_polynomial_framework_capture_gate_commissioned':False})
write('disposition.json',{'completed':True,'same_reviewer':True,'source_sha256':'246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635','candidate':'c43913c75446272c5fc9c63aeb007dd9644568d0','tree':'d8810579d7b4a93d9bb2b1dd924b2ba0ebb5a350','actual_direct_parent':'b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d','accepted113_integration_base':'274c71912afba4f976f0b7ec248af6347c2addde',
 'raw_primary_sha256':h(primary),'current_pairs':6,'provided_raw_files':1111,'original_NPYs':985,'required_field_instances':192,'complete_mapping_entries':23490,'common_numerical_arrays_byte_equal':60,'common_projection_missing_or_discrepancies':0,
 'verdict':'COMPLETE_CURRENT_COMMON_PROJECTIONS; DESCRIPTIVE_ROW126_ELIGIBILITY; CONDITIONAL_W02_W05_SELECTED12_ELIGIBILITY; SCIENCE_UNRESOLVED_NOACTIVATION',
 'concrete_blocking_issue':False,'extra_source_control_capture_framework_preliminary_gate_required':False,'future_child_values_metadata_trace_branches_preaccepted':False,
 'normal_native_direct_python_terminal_and_named_closure':'SUPPORTED_ACTUAL_EACH_SIX_WITH_SCOPE_LIMITS','ROOT_runtime_grant_global149_SCI_D_publication':False,'ROOT_acceptance':False})
commands=[{'argv':['python3','-I','-S',str(O/name)],'code_sha256':h(O/name),'scope':scope,'exit_code':0} for name,scope in [
 ('prepare-fixed-six-analysis-text.py','new text authorship from prior mapping aid; no historical module execution'),
 ('six-current-Q2-retained-analysis.py','exact1111 hash/read,985 NPY header/components,23490 complete mapping comparisons'),
 ('six-current-Q2-finite-and-provenance.py','139008 finite cast/corrected values, scalar/reference/branch/provenance and conditional resource applicability'),
 ('six-current-Q2-phase2-comparison.py','post-primary6 attributed summary+1105 inventory comparisons'),
 ('finalize-current-sixQ.py','supplemental raw C/observer/current material-index checks and output/input/read/hash bookkeeping')]]
write('accounting.json',{'same_available_reviewer':True,'delegation':False,'current_Q2_observations_assessed':6,'current_NPYs':985,'canonical_Q2_raw_inputs':1111,'all_inputs':len(inputs),'command_identities':commands,
 'authorized_scope':'isolated stdlib -I -S retained-file JSON/NPY/IEEE/component/projection/Fraction/hash arithmetic actually performed; distinct from prior static-only clarifications',
 'exploratory_commands':'Exact inline python3 -I -S schema/metadata/value projections and cat/sed/rg/hash reads are in tool transcript. Initial source2 prepbase path was nonexistent; correct immutable114 path then used. No data/source error or repair inferred.',
 'not_performed':['product/source/study-helper/native/NumPy/SciPy execution/import','AST/compile/eval/pickle','experiments/new polynomial','new general comparator/oracle/upstream/capture framework','live probes/signals/wait/reap','Docker/tests/installs/repairs','parallel correction/source gate','automatic retry','K5/CPU file reads','delegation'],
 'prior_costs_failures':'all preserved; old W01/failed old W02/method failures remain extras, no relabel/replacement','original_149_tenrows_fixed12_three_successfulW_reps_full13_freshD_publication':'unchanged, ROOT-owned',
 'actual_serving_model':'UNKNOWN','actual_effort':'UNKNOWN','actual_tokens':'UNKNOWN','actual_cache':'UNKNOWN','actual_money':'UNKNOWN','complete_elapsed':'UNKNOWN','human_numerical_quota':'NOT SET',
 'output_write_scope':'ONLY NEW reviewer1/current-sixQ-pair-assessment-1; all prior original bytes unchanged'})
reportsha=h(O/'report.md');rowsha=h(O/'row-eligibility.json')
final=('Completed SAME-reviewer current source2 six-Q2 assessment. All six complete common projections pass: 1,111 raw files, 985 NPYs, 192 required field instances, 23,490 mapping checks and 60 original numerical array byte comparisons; zero discrepancies.\n\n'
 'No concrete blocking issue. Actual branch/baseline/reference evidence supports descriptive row-dependent126 comparison eligibility and conditional W02/W05 selected12 prepared eligibility, subject to fresh ROOT grants/admission and actual future caller/output/branch/guard/terminal/closure evidence. Independent full-grid/upstream science remains UNRESOLVED/noactivation for every row. No source/capture/framework/control/polynomial/preliminary gate or automatic retry is commissioned.\n\n'
 'This is not a runtime/global149/SCI/D/publication grant or ROOT acceptance. Final SCI is a DIFFERENT fresh session. Old runs/failures/costs remain extras and unchanged; human numerical quota NOT SET, serving/meters/money/complete elapsed UNKNOWN.\n\n'
 'Report SHA256: '+reportsha+'\nFrozen raw-primary SHA256: '+h(primary)+'\nExact row eligibility/bindings SHA256: '+rowsha+'\nDisposition SHA256: '+h(O/'disposition.json')+'\nInputs ledger SHA256: '+h(O/'inputs.sha256')+'\n\n'
 'Detailed report.md, six per-row complete-common-projection-mapping.json files, reference/eligibility/disposition/read/accounting/input/output ledgers and this DISTINCT final constitute the completed handoff. outputs.sha256 pins every output except its own recursive digest.\n')
(O/'final-message.md').write_text(final)
outputs=sorted(p for p in O.rglob('*') if p.is_file() and p.name!='outputs.sha256')
(O/'outputs.sha256').write_text(''.join(h(p)+'  '+str(p)+'\n' for p in outputs))
print(json.dumps({'completed':True,'inputs':len(inputs),'outputs_pinned':len(outputs),'report_sha256':reportsha,'final_sha256':h(O/'final-message.md'),'row_eligibility_sha256':rowsha,'outputs_sha256':h(O/'outputs.sha256')}))
