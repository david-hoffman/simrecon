"""One-off retained six-row finite/provenance/applicability analysis, no target calls."""
import hashlib,itertools,json,math,struct
from fractions import Fraction
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114')
O=B/'actual-bound-method-review-preparation-1/reviewer1/current-sixQ-pair-assessment-1'
S=Path('/workspace/work/issue-114')
SOURCE=B/'W02-direct-preparation-type-correction-1/author/study.py'
OLD=B/'actual-bound-source-preparation-1/author/study.py'
SPECS=[('W01','Q2-W01-QUALIFY-r1-attempt2',1024),('W02','Q2-W02-QUALIFY-r1-attempt2',12288),('W03','Q2-W03-QUALIFY-r1-attempt1',12288),('W04','Q2-W04-QUALIFY-r1-attempt1',12288),('W05','Q2-W05-QUALIFY-r1-attempt1',49152),('W06','Q2-W06-QUALIFY-r1-attempt1',12288)]
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sha(v):return hashlib.sha256(v).hexdigest()
def load(p):return json.loads(p.read_text())
assert h(SOURCE)=='246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635'
newtext=SOURCE.read_text();oldtext=OLD.read_text()
unchanged={}
for name,nextname in [('encode','numeric_chunks'),('generator','settings'),('settings','make_transfer'),('make_transfer','workflow'),('resource_caller','resource_stage'),('resource_stage','refuse_quarantined_resource_launch')]:
    block=lambda text:text.split('def '+name+'(',1)[1].split('\ndef '+nextname+'(',1)[0]
    assert block(newtext)==block(oldtext)
    unchanged[name]=sha(block(newtext).encode())
m01=load(O.parent/'M01-actual-assessment-1/file-arithmetic-results.json')
m01raw={x['row']:x for x in m01['raw_generation'] if x['strategy']=='WIDER'}
allresults=[];productfiles={}
for ROW,NAME,DENOM in SPECS:
    R=B/'current-runs-2'/NAME;K=B/'current-qualification-captures-2'/NAME
    j=load(R/'run.json');f=j['result']['wider'];projection=load(O/ROW/'pair-projection-results.json')
    inv={x['key']:x for x in load(O/ROW/'array-inventory.json')};cache={}
    def arr(v):
        key=v['array'] if isinstance(v,dict) else v
        if key in cache:return cache[key]
        meta=inv[key];raw=Path(meta['path']).read_bytes();n=2 if raw[6]==1 else 4;off=8+n+int.from_bytes(raw[8:8+n],'little');data=raw[off:];dtype=meta['dtype'];kind=dtype[1];width=int(dtype[2:]);shape=meta['shape']
        if meta['fortran_order']:
            strides=[];q=1
            for d in shape:strides.append(q);q*=d
            data=b''.join(data[sum(i*t for i,t in zip(ix,strides))*width:sum(i*t for i,t in zip(ix,strides))*width+width] for ix in itertools.product(*(range(x) for x in shape)))
        cw=width//2 if kind=='c' else width
        code={('f',2):'e',('f',4):'f',('f',8):'d',('c',4):'f',('c',8):'d',('i',8):'q',('i',4):'i',('u',8):'Q',('u',4):'I',('b',1):'?'}[(kind,cw)]
        vals=[x[0] for x in struct.iter_unpack('<'+code,data)];cache[key]=(meta,data,vals);return cache[key]
    raw=arr('generator.raw32');analytic=arr('generator.analytic64');corrected=arr('corrected.source');alpha=float(Fraction(1,DENOM));bg=128 if ROW=='W06' else 256
    assert struct.pack('>d',f['bands']['input_scale'])==struct.pack('>d',alpha)
    maxcast=Fraction();ties=0;correctedchecks=0
    for i,(a,v) in enumerate(zip(analytic[2],raw[2])):
        a=Fraction(a);v=Fraction(v);err=abs(a-v);maxcast=max(maxcast,err);bits=int.from_bytes(raw[1][4*i:4*i+4],'little')
        for delta in [-1,1]:
            neighbor=struct.unpack('<f',(bits+delta).to_bytes(4,'little'))[0];ne=abs(a-Fraction(neighbor));assert err<=ne
            if err==ne:assert bits%2==0;ties+=1
        expected=float((v-bg)*Fraction(alpha))
        assert struct.pack('<d',expected)==corrected[1][8*i:8*i+8]
        correctedchecks+=1
    shape=raw[0]['shape'];T,D,P,Z,Y,X=shape;coords={}
    for field,N,center,pitch in [('x_um',2*X,X,0.05),('y_um',2*Y,Y,0.05),('z_um',Z,Z//2,0.0 if ROW=='W01' else 0.2)]:
        expected=b''.join(struct.pack('<d',float(Fraction(i-center)*Fraction(pitch))) for i in range(N));actual=arr(f[field]);assert expected==actual[1];coords[field]=actual[0]['content_sha256']
    table=arr(f['transfer']['samples']);caller=arr('transfer.caller');OCOUNT=2 if ROW=='W01' else 3;AXIAL=1 if ROW=='W01' else 64
    assert table[0]['shape']==caller[0]['shape']==[OCOUNT,64,AXIAL]
    for aa in [table,caller]:
        for i in range(len(aa[2])//2):
            order=i//(64*AXIAL);assert aa[2][2*i]==1-order/8 and aa[2][2*i+1]==order/32
    assert f['transfer']['layout']=='radial' and f['transfer']['dkr_cyc_um']==f['transfer']['dkz_cyc_um']==0.25
    bands=arr(f['bands']['quadratures']);initial=arr(f['initial_carriers_cyc_um']);used=arr(f['parameters']['carriers_cyc_um']);nominal=arr(j['result']['nominal_generator_carriers_cyc_um']);image=arr(f['image'])
    branches=f['parameters']['branches'];expectedbranches=[['searched']*D,['time0-reused']*D] if ROW=='W04' else [['searched']*D] if ROW=='W03' else [['known']*D]
    assert branches==expectedbranches
    assert b''.join(arr(x['image'])[1] for x in f['reconstructions'])==image[1]
    for time,known in enumerate(f['reconstructions']):
        assert arr(known['carriers_cyc_um'])[1]==used[1][time*D*2*8:(time+1)*D*2*8]
    adjustments=[];reuses=[]
    for event in f['parameters']['trace']:
        details=dict(event['details'])
        if event['kind']=='adjustment':adjustments.append({'t':event['time_index'],'d':event['direction_index'],**details})
        if event['kind']=='reuse':reuses.append({'t':event['time_index'],'d':event['direction_index'],**details})
    if ROW=='W03':
        assert len(adjustments)==D*2
        assert all(e['floor']==(0.75 if e['order']==1 else 0.5) and e['phase_replaced']==(e['order']==2) for e in adjustments)
    else:assert all(e['floor'] is None and e['floor_applied'] is False and e['phase_replaced'] is False for e in adjustments)
    if ROW=='W04':
        assert used[1][:D*2*8]==used[1][D*2*8:] and len(reuses)==D
        md=arr(f['parameters']['modulation']);assert md[1][:D*2*16]!=md[1][D*2*16:]
    noise=arr(f['bands']['noise_variance_factors']);noise_residuals=[]
    if ROW!='W06':assert all(x==1.0 for x in noise[2])
    else:
        sep=arr(f['bands']['separation_matrices'])[2];Q=5
        for d in range(D):
            last=((d*Z+(Z-1))*Q*P)
            for order,rows in [(0,[0]),(1,[1,2]),(2,[3,4])]:
                exact=sum((Fraction(sep[last+r*P+p])**2 for r in rows for p in range(P)),Fraction())/P
                observed=noise[2][d*3+order];noise_residuals.append({'d':d,'order':order,'exact_actual_separator_row_energy_over_P':[exact.numerator,exact.denominator],'observed':observed,'absolute_residual':float(abs(exact-Fraction(observed))),'scope':'conditional on actual finite separator, not independent ideal nonuniform factorization/trig uncertainty'})
    def wirefloat(v):return struct.unpack('>d',bytes.fromhex(v['float64_bits_be']))[0] if isinstance(v,dict) and 'float64_bits_be'in v else v
    recorded_sums=[]
    for sample in j['result']['independent_oracles']['finite_forward_sums']:
        d,q=sample['direction'],sample['slot'];z,y,x=sample['index'];flat=(((d*(2*OCOUNT-1)+q)*Z+z)*Y+y)*(X//2+1)+x
        actual=bands[2][2*flat:2*flat+2];recorded=[wirefloat(sample['prepared'][k]) for k in ['real','imag']]
        assert all(struct.pack('>d',v)==struct.pack('>d',w) for v,w in zip(actual,recorded))
        expected=[wirefloat(sample['finite_sum'][k]) for k in ['real','imag']]
        recorded_sums.append({'d':d,'slot':q,'index':sample['index'],'component_residual':[actual[c]-expected[c] for c in range(2)],'scope':'recorded selected scalar-trig sum uses actual public separators; not full independent Fourier truth'})
    dc=[]
    # Order-zero DC is independent of trig/separator: q0 sums all admitted corrected phases/voxels.
    if ROW!='W06':
        for t in range(T):
            for d in range(D):
                start=((t*D+d)*P*Z*Y*X);exact=sum((Fraction(x) for x in corrected[2][start:start+P*Z*Y*X]),Fraction())
                bindex=(t*D+d)*(2*OCOUNT-1)*Z*Y*(X//2+1)*2;observed=bands[2][bindex]
                dc.append({'t':t,'d':d,'exact_corrected_q0_sum':[exact.numerator,exact.denominator],'observed':observed,'absolute_residual':float(abs(exact-Fraction(observed))),'imaginary':bands[2][bindex+1]})
    # Fresh raw route/provenance records, not ROOT summary opinions.
    bb,cc,gg,ll,tt=[load(K/name) for name in ['binding.json','context.json','grant.json','launch.json','ROOT-target-terminal.json']];bound=bb['bindings'];bs,cs,gs=[h(K/name) for name in ['binding.json','context.json','grant.json']]
    assert gg==j['grant'] and gs==j['grant_sha256'] and gg['bindings']==bound and gg['binding_receipt']['sha256']==bs and gg['context']['sha256']==cs
    assert cc['binding_sha256']==bs and ll['binding']['sha256']==bs and ll['context']['sha256']==cs and ll['grant']['sha256']==gs
    assert ll['runtime_released'] and ll['source_output_absent'] and ll['usage_file_absent'] and gg['runs']==[[ROW,'QUALIFY',1]]
    assert bound['candidate']['commit']=='c43913c75446272c5fc9c63aeb007dd9644568d0' and bound['candidate']['tree']=='d8810579d7b4a93d9bb2b1dd924b2ba0ebb5a350' and bound['parent']==bound['candidate']['parent']=='b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d'
    assert bound['accepted113']['commit']==bound['integration_base']=='274c71912afba4f976f0b7ec248af6347c2addde'
    assert j['materials_before']==j['materials_after'] and j['materials_before'][bound['source']]==h(SOURCE)
    assert cc['time_unix_ns']<=ll['release_time_unix_ns']<=tt['start_unix_ns']<tt['finish_unix_ns']
    assert cc['materials_unchanged']==143 and cc['startup_files_unchanged']==7 and cc['native_files_unchanged']==2 and not any(cc['coverage_keys_present'].values()) and set(cc['threads'].values())=={'1'}
    assert cc['current_visible_cgroup_headroom_bytes']>cc['modeled_payload_bytes'] and cc['sigchld_default'] and cc['sigint_default'] and all(cc['fds'][str(i)]['open'] for i in range(3))
    assert ll['inner_argv']==[bs if x=='$ROOT_BINDING_SHA256' else x for x in bound['parent_argv_shape']]
    outer=ll['outer_argv'];pos=outer.index('/usr/bin/env');assert outer[pos:pos+5]==['/usr/bin/env','-u','COVERAGE_PROCESS_START','-u','COVERAGE_PROCESS_CONFIG'] and outer[-len(ll['inner_argv']):]==ll['inner_argv']
    facts=load(K/'process-identities.json');assert facts['complete'];py,ti=facts['found']['python'],facts['found']['time']
    assert py['argv']==ll['inner_argv'] and ti['argv']==ll['time_argv'] and py['ppid']==ti['pid'] and py['boot_id']==ti['boot_id'] and py['state']!='Z' and ti['state']!='Z'
    assert py['executable']==bound['interpreter']['resolved'] and py['executable_sha256']==bound['startup'][py['executable']] and ti['executable_sha256']==ll['time_binary_sha256']==cc['tool_sha256']
    for proc in [py,ti]:assert all(x not in proc['selected_environment'] for x in ['COVERAGE_PROCESS_START','COVERAGE_PROCESS_CONFIG']) and set(proc['fds'])=={'0','1','2'} and proc['fds']['0']=='/dev/null'
    close=load(K/'postclose.stdout')
    for role,proc in [('python',py),('time',ti)]:assert close[role]=={'pid':proc['pid'],'old_start':proc['start_ticks'],'original_identity_absent':True}
    assert (K/'stderr.txt').read_bytes()==b'' and (K/'postclose.stderr').read_bytes()==b''
    assert tt['returncode']==0 and tt['stdout_sha256']==h(K/'stdout.txt') and tt['stderr_sha256']==h(K/'stderr.txt') and tt['terminal_usage_sha256']==h(K/'terminal-native-usage.txt')
    assert load(K/'stdout.txt')['sha256']==h(R/'run.json')
    usage=load(K/'terminal-native-usage.txt');assert usage['exit_code']==0 and usage['native_units']=='Linux KiB' and usage['native_ru_maxrss']>=j['native_peak_rss_kib_after_export']>=j['native_peak_rss_kib_before_export']>=j['pre_call_high_water_rss_kib']
    assert j['native_peak_rss_bytes_after_export']==j['native_peak_rss_kib_after_export']*1024 and j['native_peak_rss_bytes_before_export']==j['native_peak_rss_kib_before_export']*1024
    for timer in j['timings']:assert timer['seconds']==(timer['end_ns']-timer['start_ns'])/1e9 and timer['end_ns']>=timer['start_ns']
    assert j['numerical_import_seconds']==(j['numerical_import_end_ns']-j['numerical_import_start_ns'])/1e9 and j['operation_seconds']==(j['operation_end_ns']-j['operation_start_ns'])/1e9 and j['local_cold_to_operation_end_seconds']==(j['operation_end_ns']-j['local_cold_start_ns'])/1e9
    assert j['environment']['internal_fft_arithmetic_precision']=='unknown' and j['environment']['scipy_fft_workers']==1
    for module,entry in bound['native'].items():assert j['required_fft_after_call'][module]['sha256']==j['environment']['loaded_fft_binary_modules'][module]['sha256']==entry['sha256']
    for path,expected in bound['materials'].items():
        if path.startswith('src/') or path=='tests/test_reconstruction_summary.py':assert h(S/path)==expected;productfiles[str(S/path)]=expected
    scalarfloats=[]
    def scanfloat(v):
        if type(v) is float:assert math.isfinite(v) and struct.pack('>d',json.loads(json.dumps(v)))==struct.pack('>d',v);scalarfloats.append(v)
        elif isinstance(v,dict):
            for x in v.values():scanfloat(x)
        elif isinstance(v,list):
            for x in v:scanfloat(x)
    scanfloat(f);scanfloat(j['result']['summary'])
    resource=None
    if ROW in ['W02','W05']:
        assert raw[0]['content_sha256']==m01raw[ROW]['sha256'] and raw[0]['shape']==m01raw[ROW]['shape']
        assert initial[0]['shape']==[D,2] and used[0]['shape']==[1,D,2] and initial[1]==used[1]
        resource={'raw_original_identity':raw[0],'M01_accepted_raw_branch_identity':m01raw[ROW],'known_T1_initial_vs_returned_C_component_bytes_equal':True,'mapping':'initial(D,2) vs returned[0,:,:](1,D,2), same C bytes/dtype; no nominal substitution','initial_identity':initial[0],'returned_identity':used[0],'nominal_generator_bits_equal_used':nominal[1]==used[1], 'prepared_caller_baseline_identity':bands[0],
        'metadata_consumed_fields':['noise_variance_factors','input_shape','input_scale','acquisition_mode','dxy_um','dz_um','lateral_zoom','axial_zoom','source_revision','reference_sha256'],
        'source_argument':'unchanged same public preparation and estimation/known functions with identical raw, native default, optics/spacing/start/defaultFalse; scalar seed operation aligns with observed actual initial; metadata original full record is fully retained here, future seven outputs do not directly export it',
        'eligibility':'SCOPED_SELECTED12_MAY_BE_SEPARATELY_ROOT_ADMITTED; future actual caller/finite unpack/output/known branch/source/material/C/B/G/L/terminal/closure checks mandatory; no future value preaccepted','unobserved':'actual standalone prepared setup metadata/trace and seven output values for every future child; full trace equality is not newly observed from future child hashes'}
    result={'row':ROW,'run_id':NAME,'original_raw_shape':shape,'raw_cast_samples_checked':len(raw[2]),'raw_cast_midpoint_ties':ties,'max_analytic64_to_raw32_absolute_error':float(maxcast),'alpha_binary64':alpha,'alpha_denominator':DENOM,'corrected_samples_checked':correctedchecks,'coordinate_content_sha256':coords,
      'image':{'shape':image[0]['shape'],'negative':sum(x<0 for x in image[2]),'minimum':min(image[2]),'maximum':max(image[2]),'stage_stack_all_component_bytes_equal':True},'branches':branches,'adjustments':adjustments,'reuse_events':reuses,'noise_conditional_residuals':noise_residuals,'selected_forward_samples':recorded_sums,'uniform_q0_DC':dc,'transfer_complete_samples':len(table[2])//2,
      'Bsha':bs,'Csha':cs,'Gsha':gs,'usage':usage,'terminal_peak_bytes':usage['native_ru_maxrss']*1024,'source_snapshots_KiB':{q:j[q] for q in ['pre_call_high_water_rss_kib','native_peak_rss_kib_before_export','native_peak_rss_kib_after_export']},'clock_seconds':{q:j[q] for q in ['numerical_import_seconds','operation_seconds','local_cold_to_operation_end_seconds']},'timings':j['timings'],'postclose':close,'python_identity':{q:py[q] for q in ['pid','ppid','boot_id','start_ticks','executable_sha256']},'time_identity':{q:ti[q] for q in ['pid','ppid','boot_id','start_ticks','executable_sha256']},'nonzero_JSON_float_roundtrips':len(scalarfloats),'resource_applicability':resource,
      'scope':'independent bounded retained-data anchors plus recorded selected conditional witnesses; full-grid/upstream science/reference uncertainty UNRESOLVED; descriptive relative-to-wider eligibility does not grant runtime/activation'}
    (O/ROW/'finite-reference-provenance-results.json').write_text(json.dumps(result,indent=2)+'\n');allresults.append(result)
(O/'six-finite-reference-provenance-results.json').write_text(json.dumps(allresults,indent=2)+'\n')
(O/'accepted-public-materials.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(productfiles.items())))
(O/'unchanged-scoped-method-text-blocks.json').write_text(json.dumps(unchanged,indent=2)+'\n')
print(json.dumps([{'row':r['row'],'samples':r['raw_cast_samples_checked'],'nativeKiB':r['usage']['native_ru_maxrss'],'negative':r['image']['negative'],'floor_true':sum(x['floor_applied'] for x in r['adjustments']),'phase_replaced':sum(x['phase_replaced'] for x in r['adjustments']),'resource_nominal_equals_used':r['resource_applicability']['nominal_generator_bits_equal_used'] if r['resource_applicability'] else None} for r in allresults]))
