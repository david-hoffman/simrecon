"""One-off attributed ROOT comparisons after six-row primary freeze."""
import hashlib,json
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');O=B/'actual-bound-method-review-preparation-1/reviewer1/current-sixQ-pair-assessment-1'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
assert h(O/'current-sixQ-raw-primary.md')=='7f7261328c5b470a571c94812f16718007b262182ac90763d9612169f57d7254'
rows=load(O/'six-finite-reference-provenance-results.json');results=[];reads=[]
for a in rows:
    K=B/'current-qualification-captures-2'/a['run_id'];R=B/'current-runs-2'/a['run_id'];j=load(R/'run.json')
    s=load(K/'ROOT-closed-collection-summary.json');iv=load(K/'ROOT-closed-raw-inventory.json')
    assert s['run_sha256']==h(R/'run.json') and s['status']==j['status']
    assert s['indexed_arrays_checked']==len(j['array_index']) and s['usage']==a['usage'] and s['postclose_identities']==a['postclose']
    assert s['material_grant_unchanged'] is True
    assert all(j[k]==v for k,v in s['source_snapshots_KiB'].items())
    for name,e in iv['files'].items():
        p=Path(name);assert '/Q2-'+a['row']+'-QUALIFY-r1-' in name
        assert h(p)==e['sha256'] and len(p.read_bytes())==e['bytes']
    assert str(K/'ROOT-closed-raw-inventory.json') not in iv['files']
    for name in ['ROOT-closed-collection-summary.json','ROOT-closed-raw-inventory.json']:
        reads.append({'path':str(K/name),'sha256':h(K/name),'phase':'phase2 body AFTER own six-row primary hash; attributed collection comparison'})
    results.append({'row':a['row'],'summary_and_raw_consistent':True,'inventory_entries_independently_verified':len(iv['files']),'scope':'collection facts only; own projection/reference conclusions not derived from ROOT labels'})
(O/'phase2-comparison-results.json').write_text(json.dumps(results,indent=2)+'\n')
(O/'phase2-read-ledger.json').write_text(json.dumps(reads,indent=2)+'\n')
print(json.dumps({'completed_comparisons':len(results),'inventory_entries':sum(x['inventory_entries_independently_verified'] for x in results),'primary_unchanged':True,'discrepancies':0}))
