"""Author NEW finite-six analysis text from prior mapping design; never import it."""
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114/actual-bound-method-review-preparation-1/reviewer1')
old=(B/'historical-W01-pair-assessment-1/W01-retained-analysis.py').read_text()
O=B/'current-sixQ-pair-assessment-1'
header='''"""One-off exact six CURRENT Q2 retained-data analysis. No external API/target execution."""
import hashlib,itertools,json,math,re,struct
from fractions import Fraction
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114')
P=B/'actual-bound-method-review-preparation-1/current-sixQ-pair-followup-1'
OUT=B/'actual-bound-method-review-preparation-1/reviewer1/current-sixQ-pair-assessment-1'
SPECS=[('W01','Q2-W01-QUALIFY-r1-attempt2',70),('W02','Q2-W02-QUALIFY-r1-attempt2',146),('W03','Q2-W03-QUALIFY-r1-attempt1',209),('W04','Q2-W04-QUALIFY-r1-attempt1',286),('W05','Q2-W05-QUALIFY-r1-attempt1',137),('W06','Q2-W06-QUALIFY-r1-attempt1',137)]
'''
utilities=old[old.index('def sha(raw)'):old.index('readledger = []')]
setup='''readledger=[];inputs={};allresults=[]
allowed=set(name for row,name,count in SPECS)
for line in (P/'current-sixQ-raw-inputs.sha256').read_text().splitlines():
    expected,name=line.split('  ',1);p=Path(name);raw=p.read_bytes()
    assert p.parts[-2] in allowed or p.parts[-3] in allowed
    assert '/current-runs-2/Q2-' in name or '/current-qualification-captures-2/Q2-' in name
    assert sha(raw)==expected
    inputs[name]=expected;defer=p.name.startswith('ROOT-closed-')
    readledger.append({'path':name,'sha256':expected,'phase':'identity-hash-only-body-deferred' if defer else 'own-raw-primary','bytes':len(raw)})
    if p.suffix=='.json' and not defer:decode(raw)
assert len(inputs)==1111
for ROW,NAME,EXPECTED_ARRAYS in SPECS:
    R=B/'current-runs-2'/NAME;K=B/'current-qualification-captures-2'/NAME;O=OUT/ROW;O.mkdir(exist_ok=False)
'''
core=old[old.index("j=load(R/'run.json')"):old.index('simple=[]')]
core=core.replace("j['row']=='W01'","j['row']==ROW")
core=core.replace('d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094','246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635')
core=core.replace('assert len(arrays)==70','assert len(arrays)==EXPECTED_ARRAYS')
declarations='''captured_ids={x['name']:x for x in f['input_identities']}
declarations={};declarationproof=[]
if ROW=='W03':
    identity=captured_ids['carrier.amplitude_floors'];bits=struct.pack('<dd',0.75,0.5)
    assert identity['shape']==[2] and identity['dtype']=='<f8' and identity['sha256']==sha(bits)
    declarations['resolved_settings.carrier.amplitude_floors']=identity
    declarationproof.append({'input':'carrier.amplitude_floors','identity':identity,'source':'frozen settings W03 np.array([0.75,0.5]); original dtype/shape from captured identity + accepted default construction, exact dyadic bytes independently checked','original_NPY':'not separately retained; no dtype guessed from JSON lists','projection':'resolved_settings.carrier.amplitude_floors'})
if ROW=='W06':
    identity=captured_ids['acquisition.phases_rad'];aa=array(f['bands']['phase_angles_rad']);assert aa[3]==(1,3,4,5)
    pieces=[]
    for d in range(3):
        part=aa[1][d*4*5*8:d*4*5*8+5*8]
        assert all(aa[1][(d*4+z)*5*8:(d*4+z+1)*5*8]==part for z in range(4))
        pieces.append(part)
    assert identity['shape']==[3,5] and identity['dtype']=='<f8' and identity['sha256']==sha(b''.join(pieces))
    declarations['resolved_settings.acquisition.phases_rad']=identity
    declarationproof.append({'input':'acquisition.phases_rad','identity':identity,'source':'frozen supplied phases_for(W06) call; original identity matches actual retained phase bytes at every z; no drift/phase adjustment; selected original shape3,5 comes from identity','retained_NPY':aa[0]['path'],'projection':'resolved_settings.acquisition.phases_rad'})
'''
core=core.replace('origins={}; mapping=[];',declarations+'\norigins={}; mapping=[];')
core=core.replace('def project(v,sp,fp,logical):\n','''def project(v,sp,fp,logical):
    if logical in declarations:
        identity=declarations[logical];result={**identity,'name':logical}
        reg(result,sp,fp,'ORIGINAL caller ndarray identity BEFORE CE07 array-to-list snapshot; frozen call + captured input identity + exact retained/declared bytes',{'original_input_identity':identity})
        return result
''')
core=core.replace('assert set(ids)==set(identity_bindings)',"assert set(ids)==set(identity_bindings)|({'carrier.amplitude_floors'} if ROW=='W03' else {'acquisition.phases_rad'} if ROW=='W06' else set())")
footer='''
    # Every checked container also needs an explicit actual full locator.
    filled=0
    for item in mapping:
        if item.get('full_path'):continue
        p=item['summary_path'].split('.');root=p[1];tail=p[2:]
        if root in ['preparation','estimation','transfer']:
            names,base={'preparation':(PREP,'wider.bands'),'estimation':(EST,'wider.parameters'),'transfer':(TRANSFER,'wider.transfer')}[root];fp=base+'.'+names[int(tail[0])]
        elif root=='filtering':fp='wider.reconstructions.'+tail[0]+('.'+FILTER[int(tail[1])] if len(tail)>1 else '')
        elif root=='overlap_builds':fp='wider.parameters.overlaps.'+'.'.join(tail)
        elif root in ['search_trace','preparation_trace']:fp=('wider.parameters.trace' if root=='search_trace' else 'wider.bands.trace')+'.'+'.'.join(tail)
        elif root=='filtering_trace':fp='wider.reconstructions.'+tail[0]+'.mode_trace'+('.'+'.'.join(tail[1:]) if len(tail)>1 else '')
        else:raise AssertionError(item)
        item['full_path']=fp;item['rule']='actual public-field/event container locator; ordered children retain exact checked values';filled+=1
    assert all(x.get('full_path') and x.get('rule') for x in mapping)
    assert not issues,issues[:1]
    result={'row':ROW,'run_id':NAME,'run_sha256':sha((R/'run.json').read_bytes()),'arrays':len(arrays),'descriptor_occurrences':len(descriptors),'summary_fields':len(covered),'mapping_rows':len(mapping),'mapping_discrepancies':issues,'common_arrays_byte_equal':len(arraycomparisons),'container_locators_completed':filled,'original_declaration_proof':declarationproof,'trace_counts':{'preparation':len(f['bands']['trace']),'search':len(f['parameters']['trace']),'filtering':[len(k['mode_trace']) for k in f['reconstructions']],'workflow':len(f['trace']),'overlap_builds':len(overlap),'precise_query_groups':groups},'actual_spatial_detail_omissions':omissions,'original_input_bindings':identity_bindings}
    for filename,value in [('array-inventory.json',inventory),('descriptor-mapping.json',descriptors),('complete-common-projection-mapping.json',mapping),('pair-projection-results.json',result)]:
        (O/filename).write_text(json.dumps(value,indent=2)+'\\n')
    allresults.append(result)
(OUT/'raw-read-ledger.json').write_text(json.dumps(readledger,indent=2)+'\\n')
(OUT/'raw-inputs-verified.sha256').write_text(''.join(h+'  '+p+'\\n' for p,h in sorted(inputs.items())))
(OUT/'six-projection-results.json').write_text(json.dumps(allresults,indent=2)+'\\n')
print(json.dumps([{'row':r['row'],'arrays':r['arrays'],'mapping_rows':r['mapping_rows'],'fields':r['summary_fields'],'discrepancies':len(r['mapping_discrepancies'])} for r in allresults]))
'''
script=header+utilities+setup+''.join('    '+line+'\n' if line else '\n' for line in core.splitlines())+footer
(O/'six-current-Q2-retained-analysis.py').write_text(script)
print('Wrote NEW explicitly fixed-six analysis text; prior one-off is only authorship text, never imported/executed as library.')
