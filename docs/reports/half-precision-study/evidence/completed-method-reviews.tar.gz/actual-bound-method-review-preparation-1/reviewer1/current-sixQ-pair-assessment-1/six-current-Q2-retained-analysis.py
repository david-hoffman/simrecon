"""One-off exact six CURRENT Q2 retained-data analysis. No external API/target execution."""
import hashlib,itertools,json,math,re,struct
from fractions import Fraction
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114')
P=B/'actual-bound-method-review-preparation-1/current-sixQ-pair-followup-1'
OUT=B/'actual-bound-method-review-preparation-1/reviewer1/current-sixQ-pair-assessment-1'
SPECS=[('W01','Q2-W01-QUALIFY-r1-attempt2',70),('W02','Q2-W02-QUALIFY-r1-attempt2',146),('W03','Q2-W03-QUALIFY-r1-attempt1',209),('W04','Q2-W04-QUALIFY-r1-attempt1',286),('W05','Q2-W05-QUALIFY-r1-attempt1',137),('W06','Q2-W06-QUALIFY-r1-attempt1',137)]
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pairs(items):
    d = {}
    for k,v in items:
        if k in d: raise ValueError('duplicate JSON key')
        d[k] = v
    return d
def bad(s): raise ValueError('nonstandard JSON '+s)
def decode(raw): return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad)
def load(p): return decode(p.read_bytes())
readledger=[];inputs={};allresults=[]
allowed=set(name for row,name,count in SPECS)
for line in (P/'current-sixQ-raw-inputs.sha256').read_text().splitlines():
    expected,name=line.split('  ',1);p=Path(name);raw=p.read_bytes()
    assert p.parts[-2] in allowed or p.parts[-3] in allowed
    assert '/current-runs-2/Q2-' in name or '/current-qualification-captures-2/Q2-' in name
    assert sha(raw)==expected
    inputs[name]=expected;defer=p.name.startswith('ROOT-closed-')
    readledger.append({'path':name,'sha256':expected,'phase':'identity-hash-only-body-deferred' if defer else 'own-raw-primary','bytes':len(raw)})
    if p.suffix=='.json' and not defer:decode(raw)
assert len(inputs)==1111
for ROW,NAME,EXPECTED_ARRAYS in SPECS:
    R=B/'current-runs-2'/NAME;K=B/'current-qualification-captures-2'/NAME;O=OUT/ROW;O.mkdir(exist_ok=False)
    j=load(R/'run.json'); f=j['result']['wider']; s=j['result']['summary']
    assert j['status']==j['result']['status']=='branch-qualified-oracle-review-required'
    assert j['row']==ROW and j['strategy']=='QUALIFY' and j['repetition']==1
    assert j['materials_before']==j['materials_after']
    assert j['identities']['harness']=='246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635'
    arrays={}; inventory=[]
    for key,entry in j['array_index'].items():
        path=R/entry['path']; raw=path.read_bytes()
        assert sha(raw)==entry['sha256'] and len(raw)==entry['nbytes']
        assert raw[:6]==b'\x93NUMPY'
        major,minor=raw[6:8]
        assert (major,minor) in [(1,0),(2,0)]
        n=2 if major==1 else 4; start=8+n
        hlen=int.from_bytes(raw[8:start],'little'); header=raw[start:start+hlen].decode('latin1')
        m=re.fullmatch(r"\{'descr': '([<>=|][bifu c][0-9]+)', 'fortran_order': (False|True), 'shape': \(([0-9, ]*)\), \}[ \n]*",header)
        assert m,(key,header)
        dtype,fort,shape=m.groups(); shape=tuple(int(x.strip()) for x in shape.split(',') if x.strip()); count=math.prod(shape)
        endian,kind,width=dtype[0],dtype[1],int(dtype[2:]); data=raw[start+hlen:]
        assert endian in '<|' and len(data)==count*width
        if fort=='True':
            strides=[]; q=1
            for dim in shape: strides.append(q); q*=dim
            data=b''.join(data[sum(i*t for i,t in zip(ix,strides))*width:sum(i*t for i,t in zip(ix,strides))*width+width] for ix in itertools.product(*(range(x) for x in shape)))
        components = 2 if kind=='c' else 1
        cw=width//components
        code={('f',2):'e',('f',4):'f',('f',8):'d',('c',4):'f',('c',8):'d',('i',8):'q',('i',4):'i',('u',8):'Q',('u',4):'I',('b',1):'?'}[(kind,cw)]
        values=[x[0] for x in struct.iter_unpack('<'+code,data)]
        assert all(math.isfinite(x) for x in values)
        zeros=sum(x==0 for x in values); nz=sum(x==0 and data[q*cw+cw-1]&128!=0 for q,x in enumerate(values)) if kind in 'fc' else 0
        d={'key':key,'path':str(path),'file_sha256':sha(raw),'shape':list(shape),'dtype':dtype,'content_sha256':sha(data),'payload_bytes':len(data),'components':len(values),'negative_zero_components':nz,'zero_components':zeros,'minimum_component':min(values) if values else None,'maximum_component':max(values) if values else None,'fortran_order':fort=='True'}
        inventory.append(d); arrays[key]=(d,data,values,shape,kind,cw)
    assert len(arrays)==EXPECTED_ARRAYS
    descriptors=[]
    def scan(v,path):
        if isinstance(v,dict) and set(v)=={'array','shape','dtype'}:
            d=arrays[v['array']][0]; assert v['shape']==d['shape'] and v['dtype']==d['dtype']
            descriptors.append({'json_path':path,'key':v['array'],'npy':d['path'],'file_sha256':d['file_sha256'],'content_sha256':d['content_sha256']})
        elif isinstance(v,dict):
            for k,x in v.items(): scan(x,path+'.'+k)
        elif isinstance(v,list):
            for i,x in enumerate(v): scan(x,path+'.'+str(i))
    scan(j,'record')
    def array(v): return arrays[v['array']]
    def wire(v):
        if type(v) is float and v==0: return {'float64_bits_be':struct.pack('>d',v).hex()}
        return v
    captured_ids={x['name']:x for x in f['input_identities']}
    declarations={};declarationproof=[]
    if ROW=='W03':
        identity=captured_ids['carrier.amplitude_floors'];bits=struct.pack('<dd',0.75,0.5)
        assert identity['shape']==[2] and identity['dtype']=='<f8' and identity['sha256']==sha(bits)
        declarations['resolved_settings.carrier.amplitude_floors']=identity
        declarationproof.append({'input':'carrier.amplitude_floors','identity':identity,'source':'frozen settings W03 np.array([0.75,0.5]); original dtype/shape from captured identity + accepted default construction, exact dyadic bytes independently checked','original_NPY':'not separately retained; no dtype guessed from JSON lists','projection':'resolved_settings.carrier.amplitude_floors'})
    if ROW=='W06':
        identity=captured_ids['acquisition.phases_rad'];aa=array(f['bands']['phase_angles_rad']);assert aa[3]==(1,3,4,5)
        pieces=[]
        for d in range(3):
            part=aa[1][d*4*5*8:d*4*5*8+5*8]
            assert all(aa[1][(d*4+z)*5*8:(d*4+z+1)*5*8]==part for z in range(4))
            pieces.append(part)
        assert identity['shape']==[3,5] and identity['dtype']=='<f8' and identity['sha256']==sha(b''.join(pieces))
        declarations['resolved_settings.acquisition.phases_rad']=identity
        declarationproof.append({'input':'acquisition.phases_rad','identity':identity,'source':'frozen supplied phases_for(W06) call; original identity matches actual retained phase bytes at every z; no drift/phase adjustment; selected original shape3,5 comes from identity','retained_NPY':aa[0]['path'],'projection':'resolved_settings.acquisition.phases_rad'})

    origins={}; mapping=[]; issues=[]; covered=set(); arraycomparisons=[]
    def reg(v,sp,fp,rule,extra=None):
        origins[sp]={'full_path':fp,'rule':rule,**(extra or {})}
        if isinstance(v,dict):
            for k,x in v.items(): reg(x,sp+'.'+k,fp,rule,extra)
        elif isinstance(v,list):
            for i,x in enumerate(v): reg(x,sp+'.'+str(i),fp,rule,extra)
    def scalar_array(v,sp,fp):
        d,data,values,shape,kind,cw=array(v)
        vals=[{'real':wire(values[i]),'imag':wire(values[i+1])} for i in range(0,len(values),2)] if kind=='c' else [wire(x) for x in values]
        def build(dims,offset):
            if not dims: return vals[offset]
            stride=math.prod(dims[1:]);return [build(dims[1:],offset+i*stride) for i in range(dims[0])]
        result=build(shape,0)
        reg(result,sp,fp,'original ndarray -> nested scalar tuples; original component bits/kinds',{'array_key':v['array'],'npy':d['path'],'content_sha256':d['content_sha256']})
        return result
    def project(v,sp,fp,logical):
        if logical in declarations:
            identity=declarations[logical];result={**identity,'name':logical}
            reg(result,sp,fp,'ORIGINAL caller ndarray identity BEFORE CE07 array-to-list snapshot; frozen call + captured input identity + exact retained/declared bytes',{'original_input_identity':identity})
            return result
        if isinstance(v,dict) and set(v)=={'array','shape','dtype'}:
            d=array(v)[0]; result={'name':logical,'shape':d['shape'],'dtype':d['dtype'],'sha256':d['content_sha256']}
            reg(result,sp,fp,'original ndarray -> ArrayIdentity; name from SUMMARY logical path',{'array_key':v['array'],'npy':d['path'],'file_sha256':d['file_sha256']})
            return result
        origins[sp]={'full_path':fp,'rule':'retain exact scalar kind/component bits and sequence/order'}
        if isinstance(v,list):
            named=bool(v) and all(isinstance(x,list) and len(x)==2 and type(x[0]) is str for x in v)
            result=[]
            for i,x in enumerate(v):
                if named:
                    origins[sp+'.'+str(i)]={'full_path':fp+'.'+str(i),'rule':'ordered named pair; preserve key at actual position'}
                    origins[sp+'.'+str(i)+'.0']={'full_path':fp+'.'+str(i)+'.0','rule':'exact ordered key'}
                    result.append([x[0],project(x[1],sp+'.'+str(i)+'.1',fp+'.'+str(i)+'.1',logical+'.'+x[0])])
                else:result.append(project(x,sp+'.'+str(i),fp+'.'+str(i),logical+'.'+str(i)))
            return result
        if isinstance(v,dict):
            return {k:project(x,sp+'.'+k,fp+'.'+k,logical+'.'+k) for k,x in v.items()}
        return v
    def compare(actual,expected,sp,fp=None,rule=None):
        o=origins.get(sp,{'full_path':fp,'rule':rule}); kind=type(expected).__name__
        if isinstance(expected,dict): ok=isinstance(actual,dict) and list(actual)==list(expected); value={'ordered_keys':list(expected)}
        elif isinstance(expected,list):ok=isinstance(actual,list) and len(actual)==len(expected);value={'length':len(expected)}
        elif type(expected) is float:ok=type(actual) is float and struct.pack('>d',actual)==struct.pack('>d',expected);value={'float64_bits_be':struct.pack('>d',expected).hex()}
        else:ok=type(actual) is type(expected) and actual==expected;value=expected
        mapping.append({'summary_path':sp,**o,'expected_kind':kind,'expected':value,'outcome':'EXACT' if ok else 'DISCREPANCY'})
        if not ok:issues.append({'summary_path':sp,'expected':expected,'actual':actual});return
        if isinstance(expected,dict):
            for k in expected:compare(actual[k],expected[k],sp+'.'+k)
        elif isinstance(expected,list):
            for i,x in enumerate(expected):compare(actual[i],x,sp+'.'+str(i))
    def direct(name,fullpath,value):
        sp='summary.'+name; expected=project(value,sp,fullpath,name)
        compare(s[name],expected,sp);covered.add(name)
    def direct_array(name,fullpath,v):
        aa=array(v);bb=array(s[name]); da,db=aa[0],bb[0]
        ok=da['shape']==db['shape'] and da['dtype']==db['dtype'] and aa[1]==bb[1]
        row={'summary_path':'summary.'+name,'full_path':fullpath,'rule':'same original dtype/shape/ALL canonical C-order component bytes, including signed zeros','outcome':'EXACT' if ok else 'DISCREPANCY','full_array':da,'summary_array':db}
        arraycomparisons.append(row);mapping.append(row);covered.add(name)
        if not ok: issues.append(row)
    for name in ['image','x_um','y_um','z_um','initial_carriers_cyc_um','phase_linkage_carriers_cyc_um','effective_wiener']:
        direct_array(name,'wider.'+name,f[name])
    for name in ['carriers_cyc_um','modulation','raw_modulation']:
        direct_array(name,'wider.parameters.'+name,f['parameters'][name])
    for name in ['intensity_unit','intensity_semantics','input_identities','source_declarations','resolved_settings','calibration','layout','trace','source_revision','reference_sha256','limitations']:
        direct(name,'wider.'+name,f[name])
    direct('branches','wider.parameters.branches',f['parameters']['branches'])
    PREP='noise_variance_factors separation_matrices phase_angles_rad phase_policies frame_sums equalization_gains off_frame_sums off_equalization_gains background_after slope_after sentinel_frames between_displacements_pixels exposure_displacements_pixels header_timestamps_after input_shape input_scale acquisition_mode storage_order dxy_um dz_um lateral_zoom axial_zoom resolved_settings source_revision reference_sha256'.split()
    EST='carriers_cyc_um modulation raw_modulation initial_carriers_cyc_um branches radial_cutoff_cyc_um axial_cutoff_bins resolved_settings source_revision reference_sha256'.split()
    FILTER='carriers_cyc_um modulation radial_cutoff_cyc_um axial_cutoffs_bins resolved_settings source_revision reference_sha256'.split()
    TRANSFER='samples layout dkr_cyc_um dkz_cyc_um norders source_revision reference_sha256'.split()
    def compact(name,v,fp,names,logical):
        sp='summary.'+name; result=[]
        for i,key in enumerate(names):
            reg(key,sp+'.'+str(i)+'.0',fp+'.'+key,'public-table field order/name')
            result.append([key,project(v[key],sp+'.'+str(i)+'.1',fp+'.'+key,logical+'.'+key)])
        compare(s[name],result,sp,fp,'public-table compact record order');covered.add(name)
    assert set(f['bands'])-{'quadratures','off_quadratures','trace'}==set(PREP)
    assert set(f['parameters'])-{'overlaps','trace'}==set(EST)
    assert set(f['transfer'])==set(TRANSFER)
    compact('preparation',f['bands'],'wider.bands',PREP,'preparation')
    compact('estimation',f['parameters'],'wider.parameters',EST,'estimation')
    compact('transfer',f['transfer'],'wider.transfer',TRANSFER,'transfer')
    expectedfilter=[]
    for t,known in enumerate(f['reconstructions']):
        assert set(known)-{'image','filtered_quadratures','x_um','y_um','z_um','mode_trace'}==set(FILTER)
        row=[]
        for i,key in enumerate(FILTER):
            sp=f'summary.filtering.{t}.{i}';fp=f'wider.reconstructions.{t}.{key}'
            reg(key,sp+'.0',fp,'public-table field order/name');row.append([key,project(known[key],sp+'.1',fp,f'filtering.{t}.{key}')])
        expectedfilter.append(row)
    compare(s['filtering'],expectedfilter,'summary.filtering','wider.reconstructions','public-table fields in effective time order');covered.add('filtering')
    overlap=[]
    for i,v in enumerate(f['parameters']['overlaps']):
        assert v['index']==i
        sp='summary.overlap_builds.'+str(i);fp='wider.parameters.overlaps.'+str(i)
        result={k:v[k] for k in ['index','time_index','direction_index','purpose','orders']}
        result['carrier_cyc_um']=scalar_array(v['carrier_cyc_um'],sp+'.carrier_cyc_um',fp+'.carrier_cyc_um')
        for k in result:
            if k!='carrier_cyc_um':reg(result[k],sp+'.'+k,fp+'.'+k,'one descriptor per actual build in position order')
        overlap.append(result)
    compare(s['overlap_builds'],overlap,'summary.overlap_builds','wider.parameters.overlaps','no deduplication');covered.add('overlap_builds')
    omissions=[]
    SPATIAL={'between-build':{'centers','fourier'},'drift-correlation':{'cross_spectrum','correlation','absolute_correlation'},'exposure-correction':{'phase_multiplier'},'between-correction':{'phase_multiplier'},'off-combination':{'quadratures_after'}}
    def event(v,sp,fp,search=False):
        result={}
        for k,x in v.items():
            if k=='details':
                detail=[]
                for n,(key,value) in enumerate(x):
                    omit = search and v['kind']=='coarse' and key in {'correlation_complex','correlation_power'} or not search and key in SPATIAL.get(v['kind'],set())
                    if omit: omissions.append({'full_path':fp+'.details.'+str(n),'reason':'explicit RM84 spatial detail omission'});continue
                    ds=sp+'.details.'+str(len(detail));df=fp+'.details.'+str(n)
                    reg(key,ds+'.0',df+'.0','ordered event detail key')
                    expected=scalar_array(value,ds+'.1',df+'.1') if isinstance(value,dict) and 'array' in value else project(value,ds+'.1',df+'.1',key)
                    detail.append([key,expected])
                result[k]=detail
            else:result[k]=project(x,sp+'.'+k,fp+'.'+k,k)
        return result
    for name,events,fp,search in [('search_trace',f['parameters']['trace'],'wider.parameters.trace',True),('preparation_trace',f['bands']['trace'],'wider.bands.trace',False)]:
        expected=[event(v,'summary.'+name+'.'+str(i),fp+'.'+str(i),search) for i,v in enumerate(events)]
        compare(s[name],expected,'summary.'+name,fp,'every event/index/detail in operation order');covered.add(name)
        if search:
            for v in events:
                d=dict(v['details'])
                if 'overlap_index' in d:
                    build=overlap[d['overlap_index']];assert build['time_index']==v['time_index'] and build['direction_index']==v['direction_index']
    filterevents=[]; groups=[]
    for t,known in enumerate(f['reconstructions']):
        events=known['mode_trace'];result=[];n=0
        while n<len(events):
            v=events[n];sp=f'summary.filtering_trace.{t}.{len(result)}';fp=f'wider.reconstructions.{t}.mode_trace.{n}'
            if v['kind']!='precise-query':result.append(event(v,sp,fp));n+=1;continue
            indices=[v[k] for k in ['time_index','direction_index','z_index','phase_index']];end=n+1
            while end<len(events) and events[end]['kind']=='precise-query' and [events[end][k] for k in ['time_index','direction_index','z_index','phase_index']]==indices:end+=1
            z=dict(v);z['kind']='precise-query-count';z['details']=[['count',end-n]];reg(z,sp,fp,'maximal consecutive precise-query run with identical indices');result.append(z);groups.append({'time':t,'start':n,'stop':end,'count':end-n});n=end
        filterevents.append(result)
    compare(s['filtering_trace'],filterevents,'summary.filtering_trace','wider.reconstructions.*.mode_trace','per-time consecutive precise-query grouping');covered.add('filtering_trace')
    direct('diagnostics','public RM84 contract','summary')
    direct('omitted_diagnostics','public RM84 contract',['stage-images','quadratures','overlap-arrays','correlation-arrays','camera-maps','transfer-samples','calibration-arrays','layout-pixels','precise-query-events'])
    SUMMARY='image x_um y_um z_um intensity_unit intensity_semantics carriers_cyc_um modulation raw_modulation initial_carriers_cyc_um phase_linkage_carriers_cyc_um effective_wiener branches input_identities source_declarations resolved_settings preparation estimation filtering transfer calibration layout overlap_builds search_trace preparation_trace filtering_trace trace diagnostics omitted_diagnostics source_revision reference_sha256 limitations'.split()
    assert list(s)==SUMMARY and covered==set(SUMMARY)
    assert f['calibration'] is None and f['layout'] is None
    assert [x['name'] for x in f['input_identities']]==sorted(x['name'] for x in f['input_identities'])
    ids={x['name']:x for x in f['input_identities']}
    identity_bindings={'specimen':'generator.raw32','selected_specimen':'generator.raw32','consumed_transfer':f['transfer']['samples']['array'],'transfer.samples':f['transfer']['samples']['array'],'prepared_quadratures':f['bands']['quadratures']['array']}
    assert set(ids)==set(identity_bindings)|({'carrier.amplitude_floors'} if ROW=='W03' else {'acquisition.phases_rad'} if ROW=='W06' else set())
    for name,key in identity_bindings.items():
        d=arrays[key][0];assert ids[name]=={'name':name,'shape':d['shape'],'dtype':d['dtype'],'sha256':d['content_sha256']}

    # Every checked container also needs an explicit actual full locator.
    filled=0
    for item in mapping:
        if item.get('full_path'):continue
        p=item['summary_path'].split('.');root=p[1];tail=p[2:]
        if root in ['preparation','estimation','transfer']:
            names,base={'preparation':(PREP,'wider.bands'),'estimation':(EST,'wider.parameters'),'transfer':(TRANSFER,'wider.transfer')}[root];fp=base+'.'+names[int(tail[0])]
        elif root=='filtering':fp='wider.reconstructions.'+tail[0]+('.'+FILTER[int(tail[1])] if len(tail)>1 else '')
        elif root=='overlap_builds':fp='wider.parameters.overlaps.'+'.'.join(tail)
        elif root in ['search_trace','preparation_trace']:fp=('wider.parameters.trace' if root=='search_trace' else 'wider.bands.trace')+'.'+'.'.join(tail)
        elif root=='filtering_trace':fp='wider.reconstructions.'+tail[0]+'.mode_trace'+('.'+'.'.join(tail[1:]) if len(tail)>1 else '')
        else:raise AssertionError(item)
        item['full_path']=fp;item['rule']='actual public-field/event container locator; ordered children retain exact checked values';filled+=1
    assert all(x.get('full_path') and x.get('rule') for x in mapping)
    assert not issues,issues[:1]
    result={'row':ROW,'run_id':NAME,'run_sha256':sha((R/'run.json').read_bytes()),'arrays':len(arrays),'descriptor_occurrences':len(descriptors),'summary_fields':len(covered),'mapping_rows':len(mapping),'mapping_discrepancies':issues,'common_arrays_byte_equal':len(arraycomparisons),'container_locators_completed':filled,'original_declaration_proof':declarationproof,'trace_counts':{'preparation':len(f['bands']['trace']),'search':len(f['parameters']['trace']),'filtering':[len(k['mode_trace']) for k in f['reconstructions']],'workflow':len(f['trace']),'overlap_builds':len(overlap),'precise_query_groups':groups},'actual_spatial_detail_omissions':omissions,'original_input_bindings':identity_bindings}
    for filename,value in [('array-inventory.json',inventory),('descriptor-mapping.json',descriptors),('complete-common-projection-mapping.json',mapping),('pair-projection-results.json',result)]:
        (O/filename).write_text(json.dumps(value,indent=2)+'\n')
    allresults.append(result)
(OUT/'raw-read-ledger.json').write_text(json.dumps(readledger,indent=2)+'\n')
(OUT/'raw-inputs-verified.sha256').write_text(''.join(h+'  '+p+'\n' for p,h in sorted(inputs.items())))
(OUT/'six-projection-results.json').write_text(json.dumps(allresults,indent=2)+'\n')
print(json.dumps([{'row':r['row'],'arrays':r['arrays'],'mapping_rows':r['mapping_rows'],'fields':r['summary_fields'],'discrepancies':len(r['mapping_discrepancies'])} for r in allresults]))
