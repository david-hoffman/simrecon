"""One-off comparison of fixed retained ROOT summaries after primary freeze."""
import hashlib
import json
from pathlib import Path
B = Path('/workspace/work/campaign/evidence/114')
O = B/'actual-bound-method-review-preparation-1/reviewer1/negative-controls-actual-assessment-1'
primary = O/'negative-raw-primary-assessment.md'
assert hashlib.sha256(primary.read_bytes()).hexdigest() == '733099d699135e4a90621e130108efac164bfb4310b2b87c8007bb709d9de58f'
cases = json.loads((O/'raw-audit-results.json').read_text())['cases']
reads = []
results = []
for a in cases:
    k = B/'current-method-attempts-1'/a['case']
    paths = list(k.glob('ROOT-*collection-summary.json')) + list(k.glob('*diagnosis-and-closure.json'))
    assert len(paths) == 1
    path = paths[0]; raw = path.read_bytes(); j = json.loads(raw)
    reads.append({'path':str(path),'sha256':hashlib.sha256(raw).hexdigest(),'phase':'phase2-body-after-primary-freeze'})
    if a['case'].startswith('M09-'):
        close = j['postclose']['identities']
        for role in ['python','time']:
            assert close[role]['original_identity_absent'] is True
            assert close[role]['original_pid'] == a[role+'_identity']['pid']
            assert close[role]['original_start_ticks'] == a[role+'_identity']['start_ticks']
        assert j['source_output_absent'] is True
    else:
        assert j.get('status',j.get('source_status',j.get('actual_status'))) == a['status']
        assert j.get('terminal',j.get('child_terminal')) == a['terminal']
        if 'attempt_sha256' in j:
            assert j['attempt_sha256'] == hashlib.sha256((B/'current-runs-1'/a['case']/'attempt.json').read_bytes()).hexdigest()
        if a['case'].endswith('sigint-attempt1'):
            close = j['postclose_and_capability']['postclose']
            for role, identity in [('parent',a['parent_identity']),('child',a['owned_child'])]:
                assert close[role]['old_identity_absent'] is True
                assert close[role]['old_pid'] == identity['pid'] and close[role]['old_start'] == identity['start_ticks']
            assert j['signal_sent'] is False
        else:
            close = j['postclose_identities']
            for role, identity in [('parent',a['parent_identity']),('child',a['owned_child'])]:
                assert close[role]['original_identity_absent'] is True
                assert close[role]['pid'] == identity['pid'] and close[role]['old_start'] == identity['start_ticks']
            if 'raw_postclose' in a:
                assert close == a['raw_postclose']
    results.append({'case':a['case'],'ROOT_summary_consistent_with_own_raw_predicate':True,
                    'exact_original_birth_identity_absence_recorded':True,
                    'closure_evidence_scope':'attributed ROOT retained postclose facts; reviewer performed no live probe'})
(O/'phase2-comparison-results.json').write_text(json.dumps(results,indent=2)+'\n')
(O/'phase2-read-ledger.json').write_text(json.dumps(reads,indent=2)+'\n')
print(json.dumps({'summaries_or_diagnoses_compared':len(results),'all_explicit_comparisons_passed':True,'primary_unchanged':True}))
