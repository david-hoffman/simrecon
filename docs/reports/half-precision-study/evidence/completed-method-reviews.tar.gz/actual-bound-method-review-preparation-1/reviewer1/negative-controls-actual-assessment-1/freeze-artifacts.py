"""One-off output bookkeeping for this completed retained-data assessment."""
import hashlib
import json
from pathlib import Path
B = Path('/workspace/work/campaign/evidence/114')
P = B/'actual-bound-method-review-preparation-1/negative-controls-actual-followup-1'
O = B/'actual-bound-method-review-preparation-1/reviewer1/negative-controls-actual-assessment-1'
S = Path('/workspace/work/issue-114')
def h(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    (O/name).write_text(json.dumps(value,indent=2)+'\n')
assert h(O/'negative-raw-primary-assessment.md') == '733099d699135e4a90621e130108efac164bfb4310b2b87c8007bb709d9de58f'
inputs = {}
for line in (O/'provided-inputs-verified.sha256').read_text().splitlines():
    expected, name = line.split('  ',1); p = Path(name)
    assert h(p) == expected
    inputs[name] = expected
extra = [P/x for x in ['reviewer-continuation-packet-1.md','M10-completed-supplement-1.md','M02-M09-actual-inputs.sha256','M10-supplemental-actual-inputs.sha256']]
extra += [S/x for x in ['docs/reports/half-precision-study/study.py','docs/reports/half-precision-study/manifest.md','docs/reports/half-precision-study/qualification-obligations.md','docs/contracts/half-precision-feasibility-v1.md']]
erratum = B/'current-method-attempts-1/M10-single-sigint-attempt3/ROOT-external-grant-rationale-prose-erratum.json'
assert h(erratum) == '12ed21b01af828e36c58cf13d93fd492446c08b942a8f1d52ad863ff93fc4389'
extra.append(erratum)
for p in extra:
    inputs[str(p)] = h(p)
(O/'inputs.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(inputs.items())))
raw = json.loads((O/'raw-read-ledger.json').read_text())
phase2 = json.loads((O/'phase2-read-ledger.json').read_text())
phase2 += [{'path':str(erratum),'sha256':h(erratum),'phase':'late-phase2-body-after-primary-and-substantive-comparison'}]
extra_reads = [{'path':str(p),'sha256':h(p),'phase':'commissioning-packet' if p.parent==P else 'frozen-public-source-contract-prior-and-current-text-inspection'} for p in extra if p != erratum]
write('read-ledger.json',{'ordering':'raw body primary first; ROOT summaries/diagnoses body only after primary SHA frozen; late erratum last',
                         'raw':raw,'phase2':phase2,'additional_inputs':extra_reads,
                         'limits':'hashing deferred summary bytes before primary was identity only. Inert orchestration included exposed diagnostic literal; no new blind-role claim. Prior completed review concepts reused from same reviewer history; original outputs unchanged.'})
audits = []
for n in range(1,4):
    p = O/('retained-data-audit-pass'+str(n)+'.py')
    audits.append({'command':['python3','-I','-S',str(O/'retained-data-audit.py')],
                   'code_snapshot':p.name,'code_sha256':h(p),'returncode':1,
                   'result_record':'audit-pass'+str(n)+'-result.json'})
audits += [{'command':['python3','-I','-S',str(O/'retained-data-audit.py')],'code_sha256':h(O/'retained-data-audit.py'),'returncode':0,'stdout':'214 provided files verified; 11 fixed cases; all explicit assertions passed'},
           {'command':['python3','-I','-S',str(O/'phase2-retained-comparison.py')],'code_sha256':h(O/'phase2-retained-comparison.py'),'returncode':0,'stdout':'11 summaries/diagnoses compared; all comparisons passed; primary unchanged'},
           {'command':['python3','-I','-S',str(O/'freeze-artifacts.py')],'code_sha256':h(O/'freeze-artifacts.py'),'scope':'output/input/hash/accounting writes and retained-file reads only'}]
write('accounting.json',{
    'review_role':'same independent actual-bound method/scientific reviewer; no delegation',
    'scope':'ROOT-authorized isolated stdlib retained-file JSON/hash/integer-arithmetic analysis; unlike earlier static-only clarifications, data-read interpreter commands actually executed',
    'actual_negative_attempts':11,'M01_actual_attempts':1,'total_actual_method_attempts':12,
    'intended_selected_cases':10,'failed_SIGINT_extras':2,'human_numerical_quota':'NOT SET',
    'actual_serving_model':'UNKNOWN','actual_effort':'UNKNOWN','actual_tokens':'UNKNOWN','actual_cache':'UNKNOWN','actual_money':'UNKNOWN','complete_elapsed':'UNKNOWN',
    'historical_costs_failures':'preserved; no refunds/normalization/disappearance inferred',
    'command_identities':audits,
    'other_data_reads':'Exploratory python3 -I -S inline projections and ordinary cat/sed/rg/hash reads appear in exact tool transcript; no target code executed. They read the same retained named inputs and inert text. A directory-key projection also displayed previously assessed M01 context keys; no new M01 oracle or experiment was commissioned.',
    'reader_failure_errata':['Pass1 assumed whole C.stdout=C; C enriches binding/case/scope. Observed fields agree.','Pass2 assumed resource_admission for controls M09; no such field required.','Pass3 assumed optional source_output_absent in M10a1/a2 L. Absent, not renamed; early failure record phrase output_absent corrected by report and primary.'],
    'prohibited_operations_performed':False,
    'not_performed':['target/study/product/helper/source-module/native numerical execution or import','NumPy/SciPy imports','AST/source compilation','experiments','live process probes','signals','wait/reap','Docker','tests','installs','repairs','new framework','automatic retry','delegation'],
    'source_and_historical_artifacts':'all unchanged; writes only new reviewer1/negative-controls-actual-assessment-1 outputs',
    'raw_provided_inputs':214,'additional_commissioning_source_ledger_erratum_inputs':len(extra),'all_input_files':len(inputs)})
cases = json.loads((O/'raw-audit-results.json').read_text())['cases']
write('disposition.json',{
    'completed':True,'verdict':'QUALIFIED_FINITE_SELECTED_NEGATIVE_AND_SINGLE_SIGINT_METHOD_BEHAVIOR',
    'blocking_source_correction':False,'additional_control_required_by_this_review':False,
    'primary_sha256':h(O/'negative-raw-primary-assessment.md'),
    'cases':[{'case':a['case'],'actual_status':a.get('status','load_bindings identity refusal; Python/outer exit1'),
              'disposition':'FAILED_INTENDED_SIGINT_PRESERVED' if a['case'] in ['M10-single-sigint-attempt1','M10-single-sigint-attempt2'] else 'QUALIFIED_SELECTED_PREDICATE',
              'whole_closure':'exact original named births absent in retained ROOT postclose facts; no reviewer live probe',
              'native_scope':'M09 abnormal GNUtime raw UNQUALIFIED' if a['case'].startswith('M09-') else 'direct-child terminal native adverse-method fact; no scientific benefit/exec-inheritance theorem'} for a in cases],
    'nonblocking_erratum':{'field':'a3 resource_admission.rationale inherited attempt2 prose label','late_ROOT_erratum_sha256':h(erratum),'original_G_unchanged':True},
    'remaining_claim_limits':['ordinary descriptors and one interruption only','readiness before exec; no sleep-entry proof','guarded os.kill still check-to-signal race','sole exact-child wait4; no global process-tree/FD/security theorem','finite policy windows not wall-clock response guarantee','native precision/scientific outputs/future data not accepted'],
    'fresh_future_obligation':'existing ROOT fresh C/B/G/L/admission/identity/terminal/closure/source guards per separately authorized unchanged route',
    'release_for_next_case_QUALIFY_149_retry_SCI_D':False,'ROOT_acceptance':False})
reporthash = h(O/'report.md')
final = ('Completed independent actual negative/SIGINT assessment: finite M02–M09 predicates and M10a3 single ordinary observer interruption QUALIFIED. M10a1/a2 remain failed intended SIGINT timeouts; no blocking source correction or additional control required. All214 supplied raw hashes and eleven closure comparisons passed.\n\n'
         'The inherited a3 rationale label is a nonblocking documented erratum; original G and all history remain unchanged. No QUALIFY/149/retry/SCI/D release, universal cleanup/security or native-precision claim follows. Twelve actual method attempts include M01; human quota NOT SET.\n\n'
         'Detailed report: report.md\nReport SHA256: '+reporthash+'\nFrozen raw-primary SHA256: '+h(O/'negative-raw-primary-assessment.md')+'\nDisposition SHA256: '+h(O/'disposition.json')+'\nInputs SHA256: '+h(O/'inputs.sha256')+'\n\n'
         'This DISTINCT final summarizes the completed detailed report; it is not ROOT acceptance. outputs.sha256 pins this final and every other output (except its own recursive digest).\n')
(O/'final-message.md').write_text(final)
outputfiles = sorted(p for p in O.iterdir() if p.is_file() and p.name != 'outputs.sha256')
(O/'outputs.sha256').write_text(''.join(h(p)+'  '+str(p)+'\n' for p in outputfiles))
print(json.dumps({'completed':True,'inputs':len(inputs),'outputs_pinned':len(outputfiles),'report_sha256':reporthash,'final_sha256':h(O/'final-message.md'),'outputs_sha256':h(O/'outputs.sha256'),'primary_sha256':h(primary) if (primary:=O/'negative-raw-primary-assessment.md') else None}))
