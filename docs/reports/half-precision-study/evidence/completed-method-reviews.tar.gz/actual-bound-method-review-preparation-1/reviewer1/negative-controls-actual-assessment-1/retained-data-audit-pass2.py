"""One-off fixed eleven-case retained-file review; never import or run target code."""
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/work/campaign/evidence/114')
OUT = BASE / 'actual-bound-method-review-preparation-1/reviewer1/negative-controls-actual-assessment-1'
PACK = BASE / 'actual-bound-method-review-preparation-1/negative-controls-actual-followup-1'
NAMES = ['M02-missing-record-attempt1', 'M03-malformed-record-attempt1',
         'M04-oversized-record-attempt1', 'M05-child-error-attempt1',
         'M06-self-term-attempt1', 'M07-timeout-attempt1',
         'M08-timeout-ignore-term-attempt1', 'M09-wrong-binding-digest-attempt1',
         'M10-single-sigint-attempt1', 'M10-single-sigint-attempt2',
         'M10-single-sigint-attempt3']
EXPECTED = ['missing-child-record', 'malformed-or-incomplete-child-record',
            'oversized-child-record', 'child-nonzero-exit: child-operation-or-observer-failure',
            'child-signaled', 'timeout', 'timeout', None, 'timeout', 'timeout', 'observer-cancelled']
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def pairs(items):
    result = {}
    for key, value in items:
        if key in result:
            raise ValueError('duplicate key')
        result[key] = value
    return result
def bad(value):
    raise ValueError('nonstandard constant: ' + value)
def decode(raw):
    return json.loads(raw, object_pairs_hook=pairs, parse_constant=bad)
def readj(path):
    return decode(path.read_bytes())
inputs = {}
reads = []
for ledger in ['M02-M09-actual-inputs.sha256', 'M10-supplemental-actual-inputs.sha256']:
    for line in (PACK / ledger).read_text().splitlines():
        expected, name = line.split('  ', 1)
        path = Path(name)
        raw = path.read_bytes()
        assert sha(raw) == expected, name
        inputs[name] = expected
        deferred = ('ROOT-closed-collection-summary' in name or 'diagnosis-and-closure' in name)
        reads.append({'path': name, 'sha256': expected,
                      'phase': 'identity-hash-only-body-deferred' if deferred else 'raw-primary',
                      'bytes': len(raw)})
        if not deferred and path.suffix == '.json':
            if path.name == 'child.json' and path.parent.name.startswith(('M03-', 'M04-')):
                pass
            else:
                decode(raw)
    reads.append({'path': str(PACK / ledger), 'sha256': sha((PACK / ledger).read_bytes()), 'phase': 'raw-primary-ledger'})
results = []
for index, name in enumerate(NAMES):
    k = BASE / 'current-method-attempts-1' / name
    r = BASE / 'current-runs-1' / name
    b, c, g, l, t = [readj(k / x) for x in ['binding.json', 'context.json', 'grant.json', 'launch.json', 'ROOT-target-terminal.json']]
    bs, cs, gs = [sha((k / x).read_bytes()) for x in ['binding.json', 'context.json', 'grant.json']]
    bb = b['bindings']
    assert len((k/'binding.json').read_bytes()) < 4*1024*1024
    assert bb['candidate']['commit'] == 'b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d'
    assert bb['candidate']['tree'] == '76edc6e8ee178d3a1c125a11e3cd290231816fd7'
    assert bb['candidate']['parent'] == bb['parent'] == '1e25db68e262708e27f1ea5f6f88b0de01280449'
    assert bb['candidate']['tracked_status'] == 'clean'
    assert bb['accepted113']['commit'] == bb['integration_base'] == '274c71912afba4f976f0b7ec248af6347c2addde'
    assert g['bindings'] == bb and g['candidate'] == bb['candidate']
    assert g['binding_receipt'] == {'path':str(k/'binding.json'), 'sha256': bs}
    assert g['context'] == {'path':str(k/'context.json'), 'sha256':cs}
    assert c['binding_sha256'] == bs
    raw_c = decode((k/'C.stdout').read_bytes())
    assert all(c[q] == value for q, value in raw_c.items() if q != 'scope')
    assert (k/'C.stderr').read_bytes() == b''
    assert l['Csha'] == cs and l['Gsha'] == gs and l['runtime_released'] is True and l['source_output_absent'] is True
    assert c['materials_unchanged'] == 143 and c['native_files_unchanged'] == 2 and c['startup_files_unchanged'] == 7
    assert not any(c['coverage_keys_present'].values()) and set(c['threads'].values()) == {'1'}
    assert c['sigchld_default'] and c['sigint_default']
    assert all(c['fds'][str(x)]['open'] for x in range(3))
    assert c['current_visible_cgroup_headroom_bytes'] > c['modeled_payload_bytes'] > 0
    assert g['resource_admission']['accepted'] and g['resource_admission']['evidence_sha256'] == cs
    outer = l['outer_argv']; pos = outer.index('/usr/bin/env')
    assert outer[pos:pos+5] == ['/usr/bin/env','-u','COVERAGE_PROCESS_START','-u','COVERAGE_PROCESS_CONFIG']
    assert t['stdout_sha256'] == sha((k/'stdout.txt').read_bytes())
    assert t['stderr_sha256'] == sha((k/'stderr.txt').read_bytes())
    result = {'case':name, 'Bsha':bs, 'Csha':cs, 'Gsha':gs,
              'binding_bytes':len((k/'binding.json').read_bytes()), 'outer_returncode': t['returncode'],
              'headroom_bytes':c['current_visible_cgroup_headroom_bytes'], 'C_time_unix_ns': c['time_unix_ns'],
              'L_time_unix_ns':l['time_unix_ns'], 'start_unix_ns':t['start_unix_ns'], 'finish_unix_ns':t['finish_unix_ns']}
    assert c['time_unix_ns'] <= l['time_unix_ns'] <= t['start_unix_ns'] < t['finish_unix_ns']
    if index == 7:
        good = l['normal_inner_argv']; wrong = l['inner_argv']
        diffs = [i for i,(x,y) in enumerate(zip(good,wrong)) if x != y]
        assert len(good) == len(wrong) and diffs == [9]
        assert good[8] == '--binding-sha256' and good[9] == bs and wrong[9] == '0'*64
        assert l['actual_Bsha'] == bs and g['route'] == 'controls' and g['runs'] == [['K01','KERNEL',1]]
        assert not r.exists() and t['returncode'] == 1
        assert b'external binding receipt exceeds bound or independent identity differs' in (k/'stderr.txt').read_bytes()
        facts = readj(k/'process-identities.json')['found']; py = facts['python']; ti = facts['time']
        assert py['argv'] == wrong and ti['argv'] == l['time_argv'] and py['ppid'] == ti['pid']
        assert py['boot_id'] == ti['boot_id'] and py['state'] != 'Z' and ti['state'] != 'Z'
        assert py['executable'] == bb['interpreter']['resolved']
        assert ti['executable_sha256'] == c['tool_sha256']
        assert not any(x in py['selected_environment'] for x in ['COVERAGE_PROCESS_START','COVERAGE_PROCESS_CONFIG'])
        result.update({'wrong_digest_only_operand':True, 'source_output_absent_now':True,
                       'python_identity':{q:py[q] for q in ['pid','ppid','boot_id','start_ticks']},
                       'time_identity':{q:ti[q] for q in ['pid','ppid','boot_id','start_ticks']},
                       'raw_abnormal_usage_UNQUALIFIED':readj(k/'terminal-native-usage.txt')})
    else:
        a = readj(r/'attempt.json'); intent = readj(r/'spawn-intent.json'); owned = readj(r/'owned-child.json')
        assert a['status'] == EXPECTED[index] and t['returncode'] == 2
        assert t['attempt_sha256'] == sha((r/'attempt.json').read_bytes()) and t['terminal'] == a['terminal']
        assert a['grant'] == g and a['grant_sha256'] == gs
        assert (r/'grant.original.json').read_bytes() == (k/'grant.json').read_bytes()
        assert g['route'] == 'resource' and g['runs'] == [['W02','PREPARED_WIDER',1]] and g['control_release'] is True
        assert a['git_before'] == a['git_after']
        assert all(a['git_before'][q] == bb['candidate'][q] for q in a['git_before'])
        assert a['materials_before'] == a['materials_after']
        assert a['materials_before'][str(k/'binding.json')] == bs
        assert a['materials_before'][str(k/'context.json')] == cs
        assert a['materials_before'][str(k/'grant.json')] == gs
        assert a['materials_before'][str(r/'grant.original.json')] == gs
        assert intent['parent'] == a['parent_identity'] and intent['grant_sha256'] == gs
        assert intent['argv'] == l['inner_argv'][1:]
        assert owned == a['owned_child'] and owned['boot_id'] == a['parent_identity']['boot_id']
        launch = a['launch']; bootstrap = launch['bootstrap_argv']; fd = launch['fd_plan']
        assert len(set(fd.values())) == 3 and min(fd.values()) >= 3
        assert bootstrap[3] == str(fd['destination']) and bootstrap[6] == str(g['readiness_bytes'])
        assert sha(bootstrap[2].encode()) == launch['bootstrap_sha256'] == bb['bootstrap_sha256']
        assert decode(bootstrap[5]) == launch['target_argv']
        expand = lambda v: [bs if x == '$ROOT_BINDING_SHA256' else x for x in v]
        assert expand(bb['parent_argv_shape']) == l['inner_argv']
        assert expand(bb['target_argv_shape']) == launch['target_argv']
        readyraw = (r/'startup-readiness.bin').read_bytes(); ready = decode(readyraw)
        assert readyraw.count(b'\n') == 1 and readyraw.endswith(b'\n') and len(readyraw) <= g['readiness_bytes']
        assert ready == a['readiness']
        assert ready == dict(pid=owned['pid'], ppid=a['parent_identity']['pid'],process_group=owned['pid'],
                            session=owned['pid'],nonce=bootstrap[4],executable=bb['interpreter']['resolved'])
        assert a['readiness_observed_monotonic']*1e9 < a['spawn_call_start_ns'] + g['startup_seconds']*1e9
        assert a['wait_ownership_lost'] is False and a['coordinator_recovery_required'] is False
        assert not any(q in a for q in ['cleanup_failure','readiness_failure','identity_changed'])
        terminal = a['terminal']; raw = terminal['raw_wait_status']
        low = raw & 127
        exitcode = (raw >> 8)&255 if low == 0 else None
        sig = low if low not in (0,127) else None
        assert terminal['pid'] == owned['pid'] and terminal['exit_code'] == exitcode and terminal['signal'] == sig
        assert terminal['native_units'] == 'Linux KiB' and terminal['multiplier_to_bytes'] == 1024
        assert terminal['terminal_child_peak_bytes'] == terminal['native_ru_maxrss']*1024
        assert terminal['native_ru_maxrss'] > 0
        childpath = r/'child.json'
        childraw = childpath.read_bytes() if childpath.exists() else None
        if index == 1:
            assert childraw == b'{' and a['failure']['exception'] == 'JSONDecodeError'
        elif index == 2:
            assert childraw == b' '*(4*1024*1024+1)
            assert 'child_record_sha256' not in a and 'failure' not in a
        elif index == 3:
            ch = decode(childraw)
            assert ch['status'] == 'child-operation-or-observer-failure' and ch['failure']['exception'] == 'ValueError'
            assert ch['failure']['message'] == 'intentional finite lifecycle-control failure'
            assert ch['materials_before'] == ch['materials_after'] == a['materials_before']
            assert ch['grant_sha256_after'] == gs and a['child_record_sha256'] == sha(childraw)
            assert all(ch['identity'][q] == owned[q] for q in ['pid','boot_id','start_ticks'])
            assert ch['identity']['process_group'] == ch['identity']['session'] == owned['pid']
            assert ch['snapshots'] == {} and not ch['qualification_receipt_loaded'] and not ch['reference_workflow_loaded']
        else:
            assert childraw is None
        signals = a.get('signals',[])
        times = [s['monotonic_ns'] for s in signals]
        assert all(s['delivery'] == 'direct-pid-sent' for s in signals)
        assert times == sorted(times) and all(x <= terminal['reaped_monotonic_ns'] for x in times)
        result.update({'status':a['status'],'stop_reason':a.get('stop_reason'),'failure':a.get('failure'),
                       'method_control':g['method_control'],'parent_identity':a['parent_identity'],
                       'owned_child':owned,'readiness':ready,'terminal':terminal,'signals':signals,
                       'bounds':{q:g[q] for q in ['deadline_seconds','startup_seconds','term_grace_seconds','kill_reap_seconds','readiness_bytes']},
                       'child_record_bytes':len(childraw) if childraw is not None else None,
                       'child_record_sha256':sha(childraw) if childraw is not None else None,
                       'material_entries':len(a['materials_before']), 'fd_plan':fd,
                       'readiness_after_spawn_seconds':a['readiness_observed_monotonic']-a['spawn_call_start_ns']/1e9,
                       'spawn_to_reap_seconds':(terminal['reaped_monotonic_ns']-a['spawn_call_start_ns'])/1e9,
                       'signal_after_spawn_seconds':[(x-a['spawn_call_start_ns'])/1e9 for x in times],
                       'signal_to_reap_seconds':[(terminal['reaped_monotonic_ns']-x)/1e9 for x in times],
                       'largest_observed_poll_gap_seconds':a['largest_observed_poll_gap_ns']/1e9})
        if (k/'postclose.stdout').exists():
            result['raw_postclose'] = readj(k/'postclose.stdout')
        if index == 10:
            ss = readj(k/'ROOT-single-SIGINT.json')
            result['ROOT_single_SIGINT'] = ss
            assert ss['signal'] == 2 and ss['signal_sent_once'] is True
    results.append(result)
(OUT/'raw-audit-results.json').write_text(json.dumps({'input_files':len(inputs),'cases':results},indent=2)+'\n')
(OUT/'raw-read-ledger.json').write_text(json.dumps(reads,indent=2)+'\n')
(OUT/'provided-inputs-verified.sha256').write_text(''.join(h+'  '+p+'\n' for p,h in sorted(inputs.items())))
print(json.dumps({'provided_files_verified':len(inputs),'fixed_cases_audited':len(results),'all_explicit_assertions_passed':True}))
