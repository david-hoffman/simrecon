"""One-off M01 retained-file audit only. No target/library imports or execution."""
import hashlib, json, math, re, struct
from fractions import Fraction as F
from pathlib import Path
O=Path('/workspace/work/campaign/evidence/114/actual-bound-method-review-preparation-1/reviewer1/M01-actual-assessment-1')
K=Path('/workspace/work/campaign/evidence/114/current-method-attempts-1/M01-current-controls-attempt1')
R=Path('/workspace/work/campaign/evidence/114/current-runs-1/M01-current-controls-attempt1')
def pairs(items):
 d={}
 for k,v in items:
  assert k not in d, ('duplicate key',k)
  d[k]=v
 return d
def readj(p):
 return json.loads(p.read_text(),object_pairs_hook=pairs,parse_constant=lambda x: (_ for _ in ()).throw(ValueError(x)))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
run=readj(R/'run.json'); r=run['result']; b=readj(K/'binding.json');g=readj(K/'grant.json');l=readj(K/'launch.json')
def scalar(x):
 if isinstance(x,dict) and set(x)=={'float64_bits_be'}:return struct.unpack('>d',bytes.fromhex(x['float64_bits_be']))[0]
 if isinstance(x,dict) and set(x)=={'real','imag'}:return complex(scalar(x['real']),scalar(x['imag']))
 return x
def bits(x):return struct.pack('<d',x)
arrays={}; headers=[]
def npy(p):
 data=p.read_bytes();assert data[:6]==b'\x93NUMPY';v=tuple(data[6:8]);assert v in ((1,0),(2,0),(3,0))
 n=2 if v==(1,0) else 4;size=int.from_bytes(data[8:8+n],'little');h=data[8+n:8+n+size].decode('utf8' if v==(3,0) else 'latin1').strip()
 m=re.fullmatch(r"\{'descr': '([<>|][fciub][0-9]+)', 'fortran_order': (False|True), 'shape': \(([0-9, ]*)\), \}",h)
 assert m, h
 dtype,order,shape=m.groups();shape=tuple(int(x) for x in shape.split(',') if x.strip());assert order=='False'
 width=int(dtype[2:]);count=math.prod(shape);payload=data[8+n+size:];assert len(payload)==count*width
 assert dtype[1] in 'fc' and width in (2,4,8,16)
 unit=width//2 if dtype[1]=='c' else width
 code={2:'e',4:'f',8:'d'}[unit];endian='>' if dtype[0]=='>' else '<'
 vals=[x[0] for x in struct.iter_unpack(endian+code,payload)]
 canonical=payload if endian=='<' else b''.join(payload[i:i+unit][::-1] for i in range(0,len(payload),unit))
 ident={'shape':list(shape),'canonical_dtype':'<'+dtype[1:],'content_sha256':hashlib.sha256(canonical).hexdigest()}
 return {'dtype':dtype,'shape':shape,'values':vals,'canonical':canonical,'identity':ident,'version':v}
for key,item in run['array_index'].items():
 p=R/item['path'];assert sha(p)==item['sha256'] and p.stat().st_size==item['nbytes']
 a=npy(p);arrays[key]=a;headers.append({'key':key,'path':item['path'],'dtype':a['dtype'],'shape':a['shape'],'file_sha256':sha(p),'canonical_sha256':a['identity']['content_sha256']})
assert len(arrays)==74
descriptors=0
def descriptors_walk(v):
 global descriptors
 if isinstance(v,dict):
  if set(v)=={'array','shape','dtype'}:
   a=arrays[v['array']];assert list(a['shape'])==v['shape'] and a['dtype']==v['dtype'];descriptors+=1
  else:
   for x in v.values():descriptors_walk(x)
 elif isinstance(v,list):
  for x in v:descriptors_walk(x)
descriptors_walk(run)
direct=[]
for i,row in enumerate(r['numpy_serialization']):
 p=R/f'control-array-{i}.npy';a=npy(p);assert sha(p)==row['file_sha256'];assert a['identity']==row['original']==row['roundtrip'];direct.append({'dtype':a['dtype'],'shape':a['shape'],'values_bits':[bits(v).hex() for v in a['values']]})
assert direct[0]['values_bits']==[bits(x).hex() for x in [0.,-0.,1.,-2.]]
assert direct[1]['dtype']=='>f4' and direct[2]['dtype']=='>c16' and direct[3]['shape']==(0,2)
v=npy(R/'control-array-1.npy')['values'];assert bits(v[0])==bits(0.) and bits(v[1])==bits(-0.) and math.isinf(v[2]) and v[2]>0 and math.isnan(v[3])
assert direct[2]['values_bits']==[bits(v).hex() for v in [-0.,1.,2.,-0.]]
wire_expected=['0000000000000000','8000000000000000','3ff4000000000000','7ff0000000000000','fff0000000000000','7ff8000000000000']
wire=[]
for i,row in enumerate(r['scalar_wire']):
 v=scalar(json.loads(row['wire']));parts=[v.real,v.imag] if isinstance(v,complex) else [v]
 got=[struct.pack('>d',x).hex() for x in parts];expected=[wire_expected[i]] if i<6 else ['8000000000000000','7ff0000000000000'];assert got==expected;wire.append(got)
expectedhash=hashlib.sha256(struct.pack('<4d',0.,-0.,1.,-2.)).hexdigest()
for row in r['canonical_hashes']:
 kind=row['case'];shape={'empty':[0,2],'scalar':[],'reshaped':[2,2],'transposed-storage':[2,2]}.get(kind,[4]);digest=hashlib.sha256(b'').hexdigest() if kind=='empty' else hashlib.sha256(struct.pack('<d',-0.)).hexdigest() if kind=='scalar' else expectedhash
 assert row['identity']=={'shape':shape,'canonical_dtype':'<f8','content_sha256':digest};assert row['expected_content_sha256']==digest
raw=[]
for row in r['raw_generation']:
 assert row['expected']==row['observed'];assert row['expected']['canonical_dtype']=={'WIDER':'<f4','H1':'<f2','H1_PROMOTED':'<f8'}[row['strategy']]
 raw.append({'row':row['row'],'strategy':row['strategy'],'shape':row['expected']['shape'],'sha256':row['expected']['content_sha256']})
assert len(raw)==18 and len({(x['row'],x['strategy']) for x in raw})==18
assert next(x for x in raw if x['row']=='W06' and x['strategy']=='WIDER')['sha256']==arrays['generator.raw32']['identity']['content_sha256']
def halfword(x):
 # Exact RN-even IEEE binary16 expectation, finite source only; integer arithmetic.
 sign=0x8000 if math.copysign(1,x)<0 else 0;a=F(abs(x))
 if not a:return sign
 if a>=F(65520):return sign|0x7c00
 if a<F(1,1<<14):e=-14;step=F(1,1<<24);base=0
 else:
  e=a.numerator.bit_length()-a.denominator.bit_length()
  if a<F(2)**e:e-=1
  step=F(2)**(e-10);base=(e+15)<<10
 q=a/step;n=q.numerator//q.denominator;rest=q-n
 if rest>F(1,2) or (rest==F(1,2) and n%2):n+=1
 if a<F(1,1<<14):return sign|n
 return sign|(base+n-1024)
kr=r['K01_range'];orig=arrays[kr['values']['array']]['values'];expected=[0.,-0.,2**-25,-2**-25,2**-24,-2**-24,2**-14,-2**-14,1.,-1.,65504.,-65504.,65520.,-65520.,70000.,-70000.]
assert [bits(x) for x in orig]==[bits(x) for x in expected]
k01={}
for kind,origvals in [('real',orig),('complex',arrays[kr['complex_values']['array']]['values'])]:
 p=arrays[f'K01.{kind}.packed'];prom=arrays[f'K01.{kind}.promoted'];words=list(struct.unpack('<'+'H'*(len(p['canonical'])//2),p['canonical']));assert words==[halfword(x) for x in origvals]
 decoded=[struct.unpack('<e',struct.pack('<H',w))[0] for w in words];assert [bits(x) for x in decoded]==[bits(x) for x in prom['values']]
 k01[kind]={'half_words_hex':[f'{w:04x}' for w in words],'nonfinite':sum(not math.isfinite(x) for x in decoded),'negative_zeros':sum(x==0 and math.copysign(1,x)<0 for x in decoded),'nonzero_to_zero':sum(x!=0 and y==0 for x,y in zip(origvals,decoded))}
assert kr['half_limits']=={'maximum':65504.,'smallest_normal':2**-14,'smallest_subnormal':2**-24,'epsilon':2**-10}
raw06=arrays['generator.raw32'];analytic06=arrays['generator.analytic64'];assert b''.join(struct.pack('<f',v) for v in analytic06['values'])==raw06['canonical']
half06=b''.join(struct.pack('<H',halfword(v)) for v in raw06['values']);prom06=b''.join(struct.pack('<d',x[0]) for x in struct.iter_unpack('<e',half06))
for strategy,payload in [('H1',half06),('H1_PROMOTED',prom06)]:assert next(x for x in raw if x['row']=='W06' and x['strategy']==strategy)['sha256']==hashlib.sha256(payload).hexdigest()
assert kr['real_error']['finite_pairs']==12 and kr['real_error']['status']=='nonfinite' and kr['paired_error']['status']=='nonfinite'
k03=[]
for row in r['K03_products']:
 n=row['n'];a=F(row['magnitude']);alternating=row['pattern']=='alternating';sx=n*(a*a+(a/8)**2);cr=(0 if alternating else n)*(3*a*a/4-a*a/128);ci=(0 if alternating else n)*(-a*a/16-3*a*a/32)
 for key in ('exact_sx','original_sx','quantized_operands_wide_sx'):assert F(scalar(row[key]))==sx
 for key in ('exact_cross','original_cross','quantized_operands_wide_cross'):
  v=scalar(row[key]);assert F(v.real)==cr and F(v.imag)==ci
 label=f'K03.{n}.{float(a)}.{row["pattern"]}'
 for part in ('lower','higher'):
  expect=[]
  for j in range(n):
   sign=-1 if alternating and j%2 else 1
   expect.extend([float(a),float(a/8)] if part=='lower' else [float(sign*3*a/4),float(-sign*a/16)])
  for form in ('packed','promoted'):assert arrays[f'{label}.{part}.{form}']['values']==expect
 energy=scalar(row['explicit_half_energy']);cross=scalar(row['explicit_half_real_cross'])
 target_energy=float(n*F(1,1<<24)) if a==F(1,4096) else float(sx) if a==1 else float('inf')
 target_cross=0. if alternating else float(n*F(1,1<<24)) if a==F(1,4096) else float(cr) if a==1 else float('inf')
 if alternating and a==1024:assert math.isnan(cross)
 else:assert cross==target_cross
 assert energy==target_energy
 k03.append({'n':n,'magnitude':float(a),'pattern':row['pattern'],'exact_sx':str(sx),'exact_cross':[str(cr),str(ci)],'half_energy':'inf' if math.isinf(energy) else energy,'half_real_cross':'nan' if math.isnan(cross) else 'inf' if math.isinf(cross) else cross})
assert len(k03)==16
c=r['K03_cancellation'];assert arrays[c['values']['array']]['values']==[2048.,1.,-2048.];assert c['exact_dyadic_sum']==c['quantized_operands_wider']==1 and scalar(c['explicit_half_left_association'])==0
# 2049 is exactly halfway between binary16 2048 and2050, nearest-even is2048.
assert halfword(2049.)==halfword(2048.)
err=r['error_observer'];obs=err['observed'];assert obs['max_absolute']==1 and obs['relative_l2']==.5 and obs['rms']==math.sqrt(F(5,12))
for name in ('zero_rule','empty_rule','strided_same_values','transposed_storage_same_values'):
 for key in ('max_absolute','rms','relative_l2'):assert scalar(err[name][key])==0
assert all(x['disposition']!='observed-pending-independent-scientific-qualification' for x in r['incomplete_record_controls'])
fft=r['K01_fft_policy'];fft_summary={}
inputhalf=hashlib.sha256(struct.pack('<16e',*range(-7,9))).hexdigest()
for name in ('numpy.fft','scipy.fft'):
 x=fft[name];assert x['input']['canonical_identity']['content_sha256']==inputhalf
 assert x['input']['dtype']=='<f2' and x['forward']['real']['dtype']==x['forward']['imag']['dtype']=='<f4' and x['inverse']['dtype']=='<f4'
 assert x['forward']['real']['shape']==[9] and x['inverse']['shape']==[16]
 assert x['unsupported_norm']['exception']=='ValueError' and x['scipy_effective_workers']==1
 fft_summary[name]={'input_dtype':x['input']['dtype'],'complex_component_dtype':x['forward']['real']['dtype'],'inverse_dtype':x['inverse']['dtype'],'recorded_inverse_error_max':x['reconstruction']['max_absolute'],'arithmetic_internal':'unknown','actual_fft_values_retained':False}
assert fft['complex32_dtype']['exception']=='TypeError'
assert g['bindings']==b['bindings'] and g['candidate']==b['bindings']['candidate'] and g['authorization']=='HP114_NUMERICAL_WINDOW' and g['runs']==[['K01','KERNEL',1]]
assert l['binding']['sha256']==sha(K/'binding.json')==g['binding_receipt']['sha256'];assert l['grant']['sha256']==sha(K/'grant.json')==run['grant_sha256'];assert g['context']['sha256']==sha(K/'context.json')==l['context']['sha256']
argv=[sha(K/'binding.json') if x=='$ROOT_BINDING_SHA256' else x for x in b['bindings']['parent_argv_shape']];assert argv==l['inner_argv']
assert run['materials_before']==run['materials_after']
for name,digest in b['bindings']['materials'].items():assert run['materials_before'][name]==digest
assert run['grant']==g and run['required_fft_after_call']==b['bindings']['native']
inventory=readj(K/'ROOT-closed-raw-file-identities.json')
for path,item in inventory.items():assert sha(Path(path))==item['sha256'] and Path(path).stat().st_size==item['bytes']
assert readj(K/'stdout.txt')=={'run':str(R/'run.json'),'sha256':sha(R/'run.json'),'status':run['status']}
assert readj(K/'ROOT-target-terminal.json')['returncode']==readj(K/'ROOT-identity-observer-terminal.json')['returncode']==0
assert run['local_cold_start_ns']<=run['entry_start_ns']<=run['numerical_import_start_ns']<=run['numerical_import_end_ns']<=run['operation_start_ns']<=run['operation_end_ns']
for a,z,key in [('numerical_import_start_ns','numerical_import_end_ns','numerical_import_seconds'),('operation_start_ns','operation_end_ns','operation_seconds'),('local_cold_start_ns','operation_end_ns','local_cold_to_operation_end_seconds'),('local_cold_start_ns','operation_start_ns','cold_to_operation_start_seconds')]:assert run[key]==float(F(run[z]-run[a],10**9))
usage=readj(K/'terminal-native-usage.txt');assert set(usage)=={'native_ru_maxrss','native_units','exit_code','elapsed_seconds','user_seconds','system_seconds'} and usage['exit_code']==0 and usage['native_units']=='Linux KiB'
assert type(usage['native_ru_maxrss']) is int and all(math.isfinite(usage[x]) and usage[x]>=0 for x in ['elapsed_seconds','user_seconds','system_seconds'])
assert usage['native_ru_maxrss']>=max(run['pre_call_high_water_rss_kib'],run['native_peak_rss_kib_before_export'],run['native_peak_rss_kib_after_export'])>0
p=readj(K/'process-identities.json');py=p['found']['python'];tm=p['found']['time'];assert py['ppid']==tm['pid'] and py['argv']==l['inner_argv'] and tm['argv']==l['time_argv'];assert tm['executable_sha256']==l['time_binary_sha256'];assert py['boot_id']==tm['boot_id'];assert all(readj(K/'ROOT-postclose-identities.json')['actual']['identities'][name]['original_identity_absent'] for name in ('time','python'))
for x in (py,tm):assert 'COVERAGE_PROCESS_START' not in x['selected_environment'] and 'COVERAGE_PROCESS_CONFIG' not in x['selected_environment'] and x['selected_environment']['LC_ALL']=='C.UTF-8'
audit={'scope':'M01 retained data only; no harness/product/numerical library execution','array_index_count':len(arrays),'all_descriptor_count':descriptors,'all_NPY_headers':headers,'direct_serialization':direct,'wire_component_bits':wire,'canonical_expected_sha256':expectedhash,'raw_generation':raw,'raw_scope':'18 recorded original identities agree; W06 retained raw recomputed. Other generated resource callers not separately retained; no independent trig/analytic truth asserted.','K01':k01,'K03':k03,'error_observer_expected_rms':math.sqrt(F(5,12)),'FFT':fft_summary,'terminal':dict(usage,bytes=usage['native_ru_maxrss']*1024),'source_snapshot_KiB':[run['pre_call_high_water_rss_kib'],run['native_peak_rss_kib_before_export'],run['native_peak_rss_kib_after_export']],'python_identity':{'pid':py['pid'],'start_ticks':py['start_ticks'],'ppid':py['ppid']},'time_identity':{'pid':tm['pid'],'start_ticks':tm['start_ticks']},'all_checks':'completed_assertions_not_substitute_for_scope_limits'}
(O/'file-arithmetic-results.json').write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:audit[k] for k in ('array_index_count','all_descriptor_count','K01','terminal','source_snapshot_KiB','python_identity','time_identity')},indent=2))
