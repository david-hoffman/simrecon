"""One-off analysis of exactly the historical d423 W01 retained pair, not a library."""
import hashlib
import itertools
import json
import math
import re
import struct
from fractions import Fraction
from pathlib import Path
B = Path('/workspace/work/campaign/evidence/114')
P = B/'actual-bound-method-review-preparation-1/historical-W01-pair-followup-1'
O = B/'actual-bound-method-review-preparation-1/reviewer1/historical-W01-pair-assessment-1'
R = B/'current-runs-1/Q-W01-QUALIFY-r1-attempt1'
K = B/'current-qualification-captures-1/Q-W01-QUALIFY-r1-attempt1'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pairs(items):
    d = {}
    for k,v in items:
        if k in d: raise ValueError('duplicate JSON key')
        d[k] = v
    return d
def bad(s): raise ValueError('nonstandard JSON '+s)
def decode(raw): return json.loads(raw,object_pairs_hook=pairs,parse_constant=bad)
def load(p): return decode(p.read_bytes())
readledger = []
inputledger = {}
for line in (P/'historical-W01-raw-inputs.sha256').read_text().splitlines():
    expected,name = line.split('  ',1); path=Path(name); raw=path.read_bytes()
    assert sha(raw)==expected
    deferred = path.name.startswith('ROOT-closed-')
    readledger.append({'path':name,'sha256':expected,'bytes':len(raw),'phase':'identity-only-body-deferred' if deferred else 'own-raw-primary'})
    inputledger[name]=expected
    if path.suffix=='.json' and not deferred: decode(raw)
assert len(inputledger)==91
j=load(R/'run.json'); f=j['result']['wider']; s=j['result']['summary']
assert j['status']==j['result']['status']=='branch-qualified-oracle-review-required'
assert j['row']=='W01' and j['strategy']=='QUALIFY' and j['repetition']==1
assert j['materials_before']==j['materials_after']
assert j['identities']['harness']=='d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094'
arrays={}; inventory=[]
for key,entry in j['array_index'].items():
    path=R/entry['path']; raw=path.read_bytes()
    assert sha(raw)==entry['sha256'] and len(raw)==entry['nbytes']
    assert raw[:6]==b'\x93NUMPY'
    major,minor=raw[6:8]
    assert (major,minor) in [(1,0),(2,0)]
    n=2 if major==1 else 4; start=8+n
    hlen=int.from_bytes(raw[8:start],'little'); header=raw[start:start+hlen].decode('latin1')
    m=re.fullmatch(r"\{'descr': '([<>=|][bifu c][0-9]+)', 'fortran_order': (False|True), 'shape': \(([0-9, ]*)\), \}[ \n]*",header)
    assert m,(key,header)
    dtype,fort,shape=m.groups(); shape=tuple(int(x.strip()) for x in shape.split(',') if x.strip()); count=math.prod(shape)
    endian,kind,width=dtype[0],dtype[1],int(dtype[2:]); data=raw[start+hlen:]
    assert endian in '<|' and len(data)==count*width
    if fort=='True':
        strides=[]; q=1
        for dim in shape: strides.append(q); q*=dim
        data=b''.join(data[sum(i*t for i,t in zip(ix,strides))*width:sum(i*t for i,t in zip(ix,strides))*width+width] for ix in itertools.product(*(range(x) for x in shape)))
    components = 2 if kind=='c' else 1
    cw=width//components
    code={('f',2):'e',('f',4):'f',('f',8):'d',('c',4):'f',('c',8):'d',('i',8):'q',('i',4):'i',('u',8):'Q',('u',4):'I',('b',1):'?'}[(kind,cw)]
    values=[x[0] for x in struct.iter_unpack('<'+code,data)]
    assert all(math.isfinite(x) for x in values)
    zeros=sum(x==0 for x in values); nz=sum(x==0 and data[q*cw+cw-1]&128!=0 for q,x in enumerate(values)) if kind in 'fc' else 0
    d={'key':key,'path':str(path),'file_sha256':sha(raw),'shape':list(shape),'dtype':dtype,'content_sha256':sha(data),'payload_bytes':len(data),'components':len(values),'negative_zero_components':nz,'zero_components':zeros,'minimum_component':min(values) if values else None,'maximum_component':max(values) if values else None,'fortran_order':fort=='True'}
    inventory.append(d); arrays[key]=(d,data,values,shape,kind,cw)
assert len(arrays)==70
descriptors=[]
def scan(v,path):
    if isinstance(v,dict) and set(v)=={'array','shape','dtype'}:
        d=arrays[v['array']][0]; assert v['shape']==d['shape'] and v['dtype']==d['dtype']
        descriptors.append({'json_path':path,'key':v['array'],'npy':d['path'],'file_sha256':d['file_sha256'],'content_sha256':d['content_sha256']})
    elif isinstance(v,dict):
        for k,x in v.items(): scan(x,path+'.'+k)
    elif isinstance(v,list):
        for i,x in enumerate(v): scan(x,path+'.'+str(i))
scan(j,'record')
def array(v): return arrays[v['array']]
def wire(v):
    if type(v) is float and v==0: return {'float64_bits_be':struct.pack('>d',v).hex()}
    return v
origins={}; mapping=[]; issues=[]; covered=set(); arraycomparisons=[]
def reg(v,sp,fp,rule,extra=None):
    origins[sp]={'full_path':fp,'rule':rule,**(extra or {})}
    if isinstance(v,dict):
        for k,x in v.items(): reg(x,sp+'.'+k,fp,rule,extra)
    elif isinstance(v,list):
        for i,x in enumerate(v): reg(x,sp+'.'+str(i),fp,rule,extra)
def scalar_array(v,sp,fp):
    d,data,values,shape,kind,cw=array(v)
    vals=[{'real':wire(values[i]),'imag':wire(values[i+1])} for i in range(0,len(values),2)] if kind=='c' else [wire(x) for x in values]
    def build(dims,offset):
        if not dims: return vals[offset]
        stride=math.prod(dims[1:]);return [build(dims[1:],offset+i*stride) for i in range(dims[0])]
    result=build(shape,0)
    reg(result,sp,fp,'original ndarray -> nested scalar tuples; original component bits/kinds',{'array_key':v['array'],'npy':d['path'],'content_sha256':d['content_sha256']})
    return result
def project(v,sp,fp,logical):
    if isinstance(v,dict) and set(v)=={'array','shape','dtype'}:
        d=array(v)[0]; result={'name':logical,'shape':d['shape'],'dtype':d['dtype'],'sha256':d['content_sha256']}
        reg(result,sp,fp,'original ndarray -> ArrayIdentity; name from SUMMARY logical path',{'array_key':v['array'],'npy':d['path'],'file_sha256':d['file_sha256']})
        return result
    origins[sp]={'full_path':fp,'rule':'retain exact scalar kind/component bits and sequence/order'}
    if isinstance(v,list):
        named=bool(v) and all(isinstance(x,list) and len(x)==2 and type(x[0]) is str for x in v)
        result=[]
        for i,x in enumerate(v):
            if named:
                origins[sp+'.'+str(i)]={'full_path':fp+'.'+str(i),'rule':'ordered named pair; preserve key at actual position'}
                origins[sp+'.'+str(i)+'.0']={'full_path':fp+'.'+str(i)+'.0','rule':'exact ordered key'}
                result.append([x[0],project(x[1],sp+'.'+str(i)+'.1',fp+'.'+str(i)+'.1',logical+'.'+x[0])])
            else:result.append(project(x,sp+'.'+str(i),fp+'.'+str(i),logical+'.'+str(i)))
        return result
    if isinstance(v,dict):
        return {k:project(x,sp+'.'+k,fp+'.'+k,logical+'.'+k) for k,x in v.items()}
    return v
def compare(actual,expected,sp,fp=None,rule=None):
    o=origins.get(sp,{'full_path':fp,'rule':rule}); kind=type(expected).__name__
    if isinstance(expected,dict): ok=isinstance(actual,dict) and list(actual)==list(expected); value={'ordered_keys':list(expected)}
    elif isinstance(expected,list):ok=isinstance(actual,list) and len(actual)==len(expected);value={'length':len(expected)}
    elif type(expected) is float:ok=type(actual) is float and struct.pack('>d',actual)==struct.pack('>d',expected);value={'float64_bits_be':struct.pack('>d',expected).hex()}
    else:ok=type(actual) is type(expected) and actual==expected;value=expected
    mapping.append({'summary_path':sp,**o,'expected_kind':kind,'expected':value,'outcome':'EXACT' if ok else 'DISCREPANCY'})
    if not ok:issues.append({'summary_path':sp,'expected':expected,'actual':actual});return
    if isinstance(expected,dict):
        for k in expected:compare(actual[k],expected[k],sp+'.'+k)
    elif isinstance(expected,list):
        for i,x in enumerate(expected):compare(actual[i],x,sp+'.'+str(i))
def direct(name,fullpath,value):
    sp='summary.'+name; expected=project(value,sp,fullpath,name)
    compare(s[name],expected,sp);covered.add(name)
def direct_array(name,fullpath,v):
    aa=array(v);bb=array(s[name]); da,db=aa[0],bb[0]
    ok=da['shape']==db['shape'] and da['dtype']==db['dtype'] and aa[1]==bb[1]
    row={'summary_path':'summary.'+name,'full_path':fullpath,'rule':'same original dtype/shape/ALL canonical C-order component bytes, including signed zeros','outcome':'EXACT' if ok else 'DISCREPANCY','full_array':da,'summary_array':db}
    arraycomparisons.append(row);mapping.append(row);covered.add(name)
    if not ok: issues.append(row)
for name in ['image','x_um','y_um','z_um','initial_carriers_cyc_um','phase_linkage_carriers_cyc_um','effective_wiener']:
    direct_array(name,'wider.'+name,f[name])
for name in ['carriers_cyc_um','modulation','raw_modulation']:
    direct_array(name,'wider.parameters.'+name,f['parameters'][name])
for name in ['intensity_unit','intensity_semantics','input_identities','source_declarations','resolved_settings','calibration','layout','trace','source_revision','reference_sha256','limitations']:
    direct(name,'wider.'+name,f[name])
direct('branches','wider.parameters.branches',f['parameters']['branches'])
PREP='noise_variance_factors separation_matrices phase_angles_rad phase_policies frame_sums equalization_gains off_frame_sums off_equalization_gains background_after slope_after sentinel_frames between_displacements_pixels exposure_displacements_pixels header_timestamps_after input_shape input_scale acquisition_mode storage_order dxy_um dz_um lateral_zoom axial_zoom resolved_settings source_revision reference_sha256'.split()
EST='carriers_cyc_um modulation raw_modulation initial_carriers_cyc_um branches radial_cutoff_cyc_um axial_cutoff_bins resolved_settings source_revision reference_sha256'.split()
FILTER='carriers_cyc_um modulation radial_cutoff_cyc_um axial_cutoffs_bins resolved_settings source_revision reference_sha256'.split()
TRANSFER='samples layout dkr_cyc_um dkz_cyc_um norders source_revision reference_sha256'.split()
def compact(name,v,fp,names,logical):
    sp='summary.'+name; result=[]
    for i,key in enumerate(names):
        reg(key,sp+'.'+str(i)+'.0',fp+'.'+key,'public-table field order/name')
        result.append([key,project(v[key],sp+'.'+str(i)+'.1',fp+'.'+key,logical+'.'+key)])
    compare(s[name],result,sp,fp,'public-table compact record order');covered.add(name)
assert set(f['bands'])-{'quadratures','off_quadratures','trace'}==set(PREP)
assert set(f['parameters'])-{'overlaps','trace'}==set(EST)
assert set(f['transfer'])==set(TRANSFER)
compact('preparation',f['bands'],'wider.bands',PREP,'preparation')
compact('estimation',f['parameters'],'wider.parameters',EST,'estimation')
compact('transfer',f['transfer'],'wider.transfer',TRANSFER,'transfer')
expectedfilter=[]
for t,known in enumerate(f['reconstructions']):
    assert set(known)-{'image','filtered_quadratures','x_um','y_um','z_um','mode_trace'}==set(FILTER)
    row=[]
    for i,key in enumerate(FILTER):
        sp=f'summary.filtering.{t}.{i}';fp=f'wider.reconstructions.{t}.{key}'
        reg(key,sp+'.0',fp,'public-table field order/name');row.append([key,project(known[key],sp+'.1',fp,f'filtering.{t}.{key}')])
    expectedfilter.append(row)
compare(s['filtering'],expectedfilter,'summary.filtering','wider.reconstructions','public-table fields in effective time order');covered.add('filtering')
overlap=[]
for i,v in enumerate(f['parameters']['overlaps']):
    assert v['index']==i
    sp='summary.overlap_builds.'+str(i);fp='wider.parameters.overlaps.'+str(i)
    result={k:v[k] for k in ['index','time_index','direction_index','purpose','orders']}
    result['carrier_cyc_um']=scalar_array(v['carrier_cyc_um'],sp+'.carrier_cyc_um',fp+'.carrier_cyc_um')
    for k in result:
        if k!='carrier_cyc_um':reg(result[k],sp+'.'+k,fp+'.'+k,'one descriptor per actual build in position order')
    overlap.append(result)
compare(s['overlap_builds'],overlap,'summary.overlap_builds','wider.parameters.overlaps','no deduplication');covered.add('overlap_builds')
omissions=[]
SPATIAL={'between-build':{'centers','fourier'},'drift-correlation':{'cross_spectrum','correlation','absolute_correlation'},'exposure-correction':{'phase_multiplier'},'between-correction':{'phase_multiplier'},'off-combination':{'quadratures_after'}}
def event(v,sp,fp,search=False):
    result={}
    for k,x in v.items():
        if k=='details':
            detail=[]
            for n,(key,value) in enumerate(x):
                omit = search and v['kind']=='coarse' and key in {'correlation_complex','correlation_power'} or not search and key in SPATIAL.get(v['kind'],set())
                if omit: omissions.append({'full_path':fp+'.details.'+str(n),'reason':'explicit RM84 spatial detail omission'});continue
                ds=sp+'.details.'+str(len(detail));df=fp+'.details.'+str(n)
                reg(key,ds+'.0',df+'.0','ordered event detail key')
                expected=scalar_array(value,ds+'.1',df+'.1') if isinstance(value,dict) and 'array' in value else project(value,ds+'.1',df+'.1',key)
                detail.append([key,expected])
            result[k]=detail
        else:result[k]=project(x,sp+'.'+k,fp+'.'+k,k)
    return result
for name,events,fp,search in [('search_trace',f['parameters']['trace'],'wider.parameters.trace',True),('preparation_trace',f['bands']['trace'],'wider.bands.trace',False)]:
    expected=[event(v,'summary.'+name+'.'+str(i),fp+'.'+str(i),search) for i,v in enumerate(events)]
    compare(s[name],expected,'summary.'+name,fp,'every event/index/detail in operation order');covered.add(name)
    if search:
        for v in events:
            d=dict(v['details'])
            if 'overlap_index' in d:
                build=overlap[d['overlap_index']];assert build['time_index']==v['time_index'] and build['direction_index']==v['direction_index']
filterevents=[]; groups=[]
for t,known in enumerate(f['reconstructions']):
    events=known['mode_trace'];result=[];n=0
    while n<len(events):
        v=events[n];sp=f'summary.filtering_trace.{t}.{len(result)}';fp=f'wider.reconstructions.{t}.mode_trace.{n}'
        if v['kind']!='precise-query':result.append(event(v,sp,fp));n+=1;continue
        indices=[v[k] for k in ['time_index','direction_index','z_index','phase_index']];end=n+1
        while end<len(events) and events[end]['kind']=='precise-query' and [events[end][k] for k in ['time_index','direction_index','z_index','phase_index']]==indices:end+=1
        z=dict(v);z['kind']='precise-query-count';z['details']=[['count',end-n]];reg(z,sp,fp,'maximal consecutive precise-query run with identical indices');result.append(z);groups.append({'time':t,'start':n,'stop':end,'count':end-n});n=end
    filterevents.append(result)
compare(s['filtering_trace'],filterevents,'summary.filtering_trace','wider.reconstructions.*.mode_trace','per-time consecutive precise-query grouping');covered.add('filtering_trace')
direct('diagnostics','public RM84 contract','summary')
direct('omitted_diagnostics','public RM84 contract',['stage-images','quadratures','overlap-arrays','correlation-arrays','camera-maps','transfer-samples','calibration-arrays','layout-pixels','precise-query-events'])
SUMMARY='image x_um y_um z_um intensity_unit intensity_semantics carriers_cyc_um modulation raw_modulation initial_carriers_cyc_um phase_linkage_carriers_cyc_um effective_wiener branches input_identities source_declarations resolved_settings preparation estimation filtering transfer calibration layout overlap_builds search_trace preparation_trace filtering_trace trace diagnostics omitted_diagnostics source_revision reference_sha256 limitations'.split()
assert list(s)==SUMMARY and covered==set(SUMMARY)
assert f['calibration'] is None and f['layout'] is None
assert [x['name'] for x in f['input_identities']]==sorted(x['name'] for x in f['input_identities'])
ids={x['name']:x for x in f['input_identities']}
identity_bindings={'specimen':'generator.raw32','selected_specimen':'generator.raw32','consumed_transfer':f['transfer']['samples']['array'],'transfer.samples':f['transfer']['samples']['array'],'prepared_quadratures':f['bands']['quadratures']['array']}
assert set(ids)==set(identity_bindings)
for name,key in identity_bindings.items():
    d=arrays[key][0];assert ids[name]=={'name':name,'shape':d['shape'],'dtype':d['dtype'],'sha256':d['content_sha256']}
simple=[]
def check(label,ok,details):
    simple.append({'claim':label,'outcome':'SUPPORTED' if ok else 'DISCREPANCY','details':details})
    assert ok,label
raw=arrays['generator.raw32'];analytic=arrays['generator.analytic64']; corrected=arrays['corrected.source'];half=arrays['boundary.half']
check('all analytic64 -> raw32 samples nearest-even',all(abs(Fraction(a)-Fraction(v))<=min(abs(Fraction(a)-Fraction(struct.unpack('<f',struct.pack('<I',int.from_bytes(raw[1][4*i:4*i+4],'little')+delta))[0])) for delta in [-1,1]) for i,(a,v) in enumerate(zip(analytic[2],raw[2]))),'768 original binary64 samples against exact neighboring binary32 values; ties retain even low bit')
cast_errors=[abs(Fraction(a)-Fraction(v)) for a,v in zip(analytic[2],raw[2])]
check('corrected source alpha(raw32-B)',all(Fraction(v)==(Fraction(a)-256)/1024 for a,v in zip(raw[2],corrected[2])),'all768 exact dyadic results; alpha1/(16*16*1*4*1*1)=1/1024')
for name in ['boundary.strided','boundary.readonly']:
    check(name+' same original raw component bytes',arrays[name][1]==raw[1],'serialization does not itself prove live stride/writeability')
half_errors=[]
for i,(a,v) in enumerate(zip(raw[2],half[2])):
    bits=int.from_bytes(half[1][2*i:2*i+2],'little');err=abs(Fraction(a)-Fraction(v)); neighbors=[struct.unpack('<e',(bits+d).to_bytes(2,'little'))[0] for d in [-1,1]]
    assert all(err<=abs(Fraction(a)-Fraction(x)) for x in neighbors)
    if any(err==abs(Fraction(a)-Fraction(x)) for x in neighbors): assert bits%2==0
    half_errors.append(err)
check('boundary half raw nearest-even',True,'all768 binary32 samples checked against retained binary16 and adjacent values')
for name in ['strided-readonly','contiguous-readonly']:
    check(name+' image same full original bits',array(j['result']['public_boundaries'][name])[1]==array(f['image'])[1],'all1024 float64 values; no live alias inference')
coords={}
for name in ['x_um','y_um']:
    actual=array(f[name]); expected=b''.join(struct.pack('<d',float(Fraction(i-16)*Fraction(0.05))) for i in range(32))
    check(name+' independent centered finite coordinates',actual[1]==expected,'public finite binary64 dxy/L=0.05 then integer multiplication; all32 values incl +0')
check('z_um dz0 native Z1',array(f['z_um'])[1]==b'\0'*8,'A1, Z1, centered index0, positive zero')
check('alpha independent',f['bands']['input_scale']==1/1024,'exact binary64 dyadic 2^-10')
check('known native 2D/O2/P3 branch',f['parameters']['branches']==[['known']] and array(f['bands']['quadratures'])[0]['shape']==[1,1,3,1,16,9],'one known (0,1) build, no search or time reuse branch')
for name in ['transfer.caller',f['transfer']['samples']['array']]:
    aa=arrays[name];vals=aa[2];assert aa[0]['shape']==[2,64,1]
    check(name+' independent full constant K1 table',all(vals[2*i]==1-(i//64)/8 and vals[2*i+1]==(i//64)/32 for i in range(128)),'128 complex samples; H0=1+0i,H1=7/8+i/32; original c8 vs consumed c16')
check('consumed increments and layout',f['transfer']['layout']=='radial' and f['transfer']['dkr_cyc_um']==0.25 and f['transfer']['dkz_cyc_um']==0.25 and f['transfer']['norders']==2,'all declared radial increments retained; native K1 acceptance is actual successful call, not a 3D extension')
check('noise factors uniform ones',all(x==1.0 for x in array(f['bands']['noise_variance_factors'])[2]),'exact public uniform noise1; no supplied-phase inversion claim')
check('no sentinel/no off/native metadata',f['bands']['sentinel_frames']==[] and f['bands']['off_quadratures'] is None and f['bands']['off_frame_sums'] is None and f['bands']['header_timestamps_after'] is None,'actual declared bypasses, not absence of finite public validation')
stats={name:{'negative':sum(x<0 for x in array(f[name])[2]),'minimum':min(array(f[name])[2]),'maximum':max(array(f[name])[2])} for name in ['image']}
check('signed finite image',stats['image']['negative']>0 and all(math.isfinite(x) for x in array(f['image'])[2]),stats['image'])
check('stage stack equals workflow original bits',array(f['reconstructions'][0]['image'])[1]==array(f['image'])[1],'T1 complete1024 values, explicit same-bit stack; memory disjointness from accepted RM84 only')
check('nominal/initial/used known vector values',array(f['parameters']['carriers_cyc_um'])[2]==[1.25,0.0] and array(f['initial_carriers_cyc_um'])[2]==[1.25,0.0],'known D1 angle0/linespacing0.8, separate nominal/seed arrays retain their own identity')
prep=array(f['bands']['quadratures']);sep=array(f['bands']['separation_matrices']);dc=[]
for q in range(3):
    exact=sum((Fraction(sep[2][q*3+p])*Fraction(corrected[2][p*256+pix]) for p in range(3) for pix in range(256)),Fraction())
    observed=prep[2][q*16*9*2]
    dc.append({'slot':q,'exact_finite_sum_fraction':[exact.numerator,exact.denominator],'actual_prepared_real':observed,'absolute_real_residual':float(abs(exact-Fraction(observed))),'actual_imaginary':prep[2][q*16*9*2+1],'scope':'DC complete raw sum conditional on retained finite separator; q0 separator independently all1; not all Fourier coefficients or trig bound'})
check('uniform separator first row',sep[2][:3]==[1.0,1.0,1.0],'P3 zeroth row exactly ones')
assert not issues,issues[:1]
output={'raw_files':91,'arrays':70,'descriptor_occurrences':len(descriptors),'summary_fields':len(covered),'mapping_rows':len(mapping),'mapping_discrepancies':issues,'direct_common_arrays':len(arraycomparisons),'all_component_bytes_equal':True,'precise_query_groups':groups,'actual_trace_counts':{'preparation':len(f['bands']['trace']),'search':len(f['parameters']['trace']),'filtering':len(f['reconstructions'][0]['mode_trace']),'workflow':len(f['trace']),'builds':len(overlap)},'original_identity_bindings':identity_bindings,'independent_or_conditional_finite_checks':simple,'max_analytic64_to_raw32_absolute_error':float(max(cast_errors)),'max_raw32_to_boundaryhalf_absolute_error':float(max(half_errors)),'DC_finite_sum_checks':dc,'scope':'complete actual common projection; generic runtime types/ownership from separately accepted unchanged RM84 proof, not serialized objects. Independent whole-grid/upstream scientific truth UNRESOLVED; no new polynomial evaluation.'}
for name,value in [('array-inventory.json',inventory),('descriptor-mapping.json',descriptors),('complete-common-projection-mapping.json',mapping),('pair-analysis-results.json',output),('raw-read-ledger.json',readledger)]:
    (O/name).write_text(json.dumps(value,indent=2)+'\n')
(O/'raw-inputs-verified.sha256').write_text(''.join(h+'  '+p+'\n' for p,h in sorted(inputledger.items())))
print(json.dumps({k:output[k] for k in ['raw_files','arrays','descriptor_occurrences','summary_fields','mapping_rows','direct_common_arrays','actual_trace_counts','max_analytic64_to_raw32_absolute_error','max_raw32_to_boundaryhalf_absolute_error']}))
