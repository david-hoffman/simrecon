"""One-off post-primary collection comparison and completed output bookkeeping."""
import hashlib
import json
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114')
P=B/'actual-bound-method-review-preparation-1/historical-W01-pair-followup-1'
O=B/'actual-bound-method-review-preparation-1/reviewer1/historical-W01-pair-assessment-1'
R=B/'current-runs-1/Q-W01-QUALIFY-r1-attempt1'
K=B/'current-qualification-captures-1/Q-W01-QUALIFY-r1-attempt1'
S=Path('/workspace/work/issue-114')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
primary=O/'historical-W01-raw-primary.md'
assert h(primary)=='6a01cd2417361d0eb1c3ab62fc7ba8bc40338ab22bcbe0528e5dea294cad90e5'
j=load(R/'run.json');a=load(O/'pair-analysis-results.json');prov=load(O/'provenance-and-projection-completion-results.json')
summary=load(K/'ROOT-closed-collection-summary.json');inventory=load(K/'ROOT-closed-raw-inventory.json')
assert summary['run_sha256']==h(R/'run.json') and summary['status']==j['status']
assert summary['indexed_arrays_checked']==70 and summary['usage']==prov['normal_terminal_usage']
assert summary['postclose_identities']==prov['postclose'] and summary['material_grant_unchanged'] is True
assert all(summary['source_snapshots_KiB'][key]==j[key] for key in summary['source_snapshots_KiB'])
for name,e in inventory['files'].items():
    p=Path(name);assert h(p)==e['sha256'] and len(p.read_bytes())==e['bytes']
assert str(K/'ROOT-closed-raw-inventory.json') not in inventory['files']
phase2=[{'path':str(K/name),'sha256':h(K/name),'phase':'ROOT collection body read after independent raw-primary freeze; attributed comparison only'} for name in ['ROOT-closed-collection-summary.json','ROOT-closed-raw-inventory.json']]
write('phase2-comparison.json',{'completed':True,'primary_unchanged':True,'run_usage_snapshot_closure_consistent':True,'inventory_entries_verified':len(inventory['files']),'inventory_excludes_itself':True,'reads':phase2})
reference=[
 ('historical_full_summary_common_projection','COMPLETE','32 fields,1208 complete mapping checks,10 common arrays exact original bytes; every required metadata/event/identity leaf checked','historical d423 only; generic original types/ownership use unchanged accepted RM84 proof'),
 ('generic_RM84_structure_type_frozen_ownership_retention','APPLICABLE_ACCEPTED_PUBLIC_REUSE','30 public material files match B; same accepted default environment; inspected source/contracts/tests','not live W01 object-flag/alias observation; no new runtime tests'),
 ('native2D_K1_O2_P3_known_and_public_boundaries','SUPPORTED_ACTUAL','one known build; actual same-value readonly/strided images; half public acceptance; exact invalid records','no search/reuse/order2/nonuniform/half-solver claim'),
 ('raw32_and_boundary_half_casts','SUPPORTED_INDEPENDENT_FINITE','all768 nearest-even conversions each; exact Fraction neighbor checks and preserved original bits','analytic64 values themselves do not prove independent real generator'),
 ('analytic_specimen_illumination_with_trig_uncertainty','UNRESOLVED','exact manifest equations and retained analytic64/source specimen bound','no independent whole-grid generator recomputation or rigorous trig bound'),
 ('alpha_corrected_raw_and_coordinates','SUPPORTED_INDEPENDENT_FINITE','alpha2^-10; all768 exact corrected dyadics; complete32+32+1 finite coordinate vectors','declared native no-map/no-edge/equalization bypass only'),
 ('phase_and_noise','PARTIAL','uniform noise exactly1, separator row0 ones; full recorded phase/matrix/noise projected','nonzero scalar-trig ideal/finite uncertainty and full transform error unresolved'),
 ('prepared_Fourier_coefficients','PARTIAL_CONDITIONAL','exact3 DC sums; q0 independent row1 and q1/q2 conditional on returned separators; all actual arrays finite/retained','remaining full432 expected complex coefficients and uncertainty UNRESOLVED'),
 ('complete_constant_transfer_table','SUPPORTED_INDEPENDENT_FINITE','all128 complex caller+consumed samples equal independent H_m; shape2,64,1 and declared increments','actual complete stencils/weights/filter traversal not independently established'),
 ('known_fits_filtering_and_upstream','UNRESOLVED_INDEPENDENT_SCIENCE','all actual finite fit/adjustment/filter metadata/arrays bound and exact pair projection','returned overlaps/H/F and flags do not establish independent regression/filter arithmetic truth'),
 ('signed_image_stage_stack','SUPPORTED_OBSERVATION_AND_COMPATIBILITY','all1024 actual finite signed image/stage-stack values;653negative; original common bits equal','independent full-grid expected signed image and reference uncertainty UNRESOLVED'),
 ('complete_conditional_assembly_polynomial','UNRESOLVED_NOT_EVALUATED','d02 complete finite equation; existing replay/four selected inverse witnesses retained','no extra polynomial commissioned; concrete future claim/need plus ROOT release required'),
 ('normal_native_terminal_route_and_clocks','SUPPORTED_SCOPED_HISTORICAL','raw normal GNUtime83744KiB; direct Python actual argv/birth/exe/PPID; exact postclose; clocks recomputed','no native precision, resource benefit, causal delta or future-value acceptance')]
write('reference-dispositions.json',{'claims':[{'quantity':q,'disposition':d,'evidence':e,'limit':l} for q,d,e,l in reference],
     'remaining_owner':'ROOT decides any concrete additional finite claim/release; final SCI is a DIFFERENT fresh independent session after complete whole-study evidence',
     'new_polynomial_framework_capture_or_gate_commissioned':False,'scientific_activation':False})
inputs={}
for line in (O/'raw-inputs-verified.sha256').read_text().splitlines():
    expected,name=line.split('  ',1);assert h(Path(name))==expected;inputs[name]=expected
extra=[P/'reviewer-packet-1.md',P/'historical-W01-raw-inputs.sha256',
       B/'actual-bound-source-preparation-1/author/study.py',B/'actual-bound-metadata-preparation-1/author/manifest.md',B/'actual-bound-metadata-preparation-1/author/qualification-obligations.md']
extra += [S/'docs/contracts'/name for name in ['reconstruction-memory-v1.md','c-equivalence-workflow-v1.md','c-equivalence-acquisition-modes-v1.md','c-equivalence-carrier-modulation-v1.md','c-equivalence-known-parameters-v1.md','c-equivalence-optical-transfer-v1.md','half-precision-feasibility-v1.md']]
extra += [Path(x['path']) for x in prov['public_material_reuse']]
extra += [B/'actual-integrated-environment-1/default-profile.json',B/'actual-integrated-environment-1/single-profile.json',O.parent/'report.md']
bound=load(K/'binding.json')['bindings']
assert h(B/'actual-integrated-environment-1/default-profile.json')==bound['default_profile']['sha256']
assert h(B/'actual-integrated-environment-1/single-profile.json')==bound['single_profile']['sha256']
for p in extra:inputs[str(p)]=h(p)
assert str(S/'docs/reports/half-precision-study/study.py') not in inputs
(O/'inputs.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(inputs.items())))
extra_reads=[{'path':str(p),'sha256':h(p),'phase':'frozen public/material/commissioning input identity; source/contract/test relevant text inspected as described in report, not executed' if p!=O.parent/'report.md' else 'same reviewer prior accepted generic proof reused from history; identity hashed'} for p in extra]
write('read-ledger.json',{'ordering':'allowed public contracts/source/tests and actual raw files -> raw primary freeze -> ROOT collection summary/inventory body; no correction opinions/other Q rows',
       'raw':load(O/'raw-read-ledger.json'),'phase2':phase2,'additional':extra_reads,
       'serialized_data_and_inert_text':'JSON/NPY/IEEE components and provided observer/bootstrap/orchestration text are data; none imported/run as target code',
       'current_source_boundary':'old d423 external copy supplies historical method; current tracked study.py deliberately absent as an input identity'})
commands=[{'argv':['python3','-I','-S',str(O/'W01-retained-analysis.py')],'code_sha256':h(O/'W01-retained-analysis.py'),'exit_code':0,'scope':'one-off91-file/70-NPY/1208-value mapping and finite Fraction data reads'},
          {'argv':['python3','-I','-S',str(O/'W01-provenance-projection-completion.py')],'code_snapshot':'W01-provenance-completion-pass1.py','code_sha256':h(O/'W01-provenance-completion-pass1.py'),'exit_code':1,'scope':'reader field-schema assumption failed; no target operation'},
          {'argv':['python3','-I','-S',str(O/'W01-provenance-projection-completion.py')],'code_sha256':h(O/'W01-provenance-projection-completion.py'),'exit_code':0,'scope':'fills89 explicit container locators; historical provenance/normal native/clock/ties/132 scalar roundtrip/30 product-hash data checks'},
          {'argv':['python3','-I','-S',str(O/'finalize-historical-W01.py')],'code_sha256':h(O/'finalize-historical-W01.py'),'scope':'post-primary retained ROOT summary/inventory comparison and output/hash bookkeeping'}]
write('accounting.json',{'same_reviewer':True,'delegation':False,'historical_W01_extra_diagnostic_observations_assessed':1,
       'prior_actual_method_attempts':12,'categories_not_relabelled':'one old-source extra historical W01 diagnostic does not replace any new current-source Q and is not another method control',
       'raw_provided_files':91,'retained_NPYs':70,'all_input_files':len(inputs),'command_identities':commands,
       'additional_read_commands':'Exploratory isolated python3 -I -S inline schema/value projections and ordinary cat/sed/rg/sha256sum text/data reads are retained in exact tool transcript. One initial cat used a nonexistent provided-inputs.sha256 name; correct historical-W01-raw-inputs.sha256 was then used. No source/data execution follows from such reader errors.',
       'authorized_operations_performed':'isolated stdlib retained-file JSON/NPY-header/struct/Fraction/hash/integer arithmetic; distinct from prior static-only clarifications',
       'not_performed':['product/study/helper/native execution/imports','NumPy/SciPy','AST/compile/eval/pickle','new experiments/polynomial/upstream/reference/comparator framework','live process probe/signal/wait/reap','Docker/tests/install/repairs','correction review','automatic retry','delegation'],
       'artifact_preservation':'all prior inputs/reports/primaries/clarifications/costs unchanged; writes only this NEW reviewer directory',
       'actual_serving_model':'UNKNOWN','actual_effort':'UNKNOWN','actual_tokens':'UNKNOWN','actual_cache':'UNKNOWN','actual_money':'UNKNOWN','complete_elapsed':'UNKNOWN','human_numerical_quota':'NOT SET',
       'historical_model_request':'preserved as history; not an observed serving model/effort or token/money meter'})
write('disposition.json',{'completed':True,'historical_target':'old d423 Q-W01-QUALIFY-r1-attempt1','raw_primary_sha256':h(primary),
       'common_projection':'COMPLETE_EXACT_VALUES_AND_DECISIONS_WITH_APPLICABLE_ACCEPTED_PUBLIC_RM84_GENERIC_TYPES_STRUCTURE_OWNERSHIP_RETENTION',
       'summary_fields':32,'complete_mapping_entries':1208,'common_original_arrays_byte_equal':10,'projection_missing_or_discrepancies':0,
       'original_declaration_identity_gap':False,'normal_historical_native_capture_and_named_birth_closure':'SUPPORTED_SCOPED',
       'independent_scientific_fullgrid_upstream':'UNRESOLVED_NOACTIVATION','new_source_qualification':False,'source_or_projection_fix_required':False,
       'new_control_capture_framework_gate_required_by_this_review':False,'new_conditional_polynomial_commissioned':False,
       'all_future_runtime_data_retry_resource_SCI_D_release':False,'ROOT_acceptance':False,'final_SCI':'DIFFERENT fresh independent session after complete exact whole-study evidence'})
reporthash=h(O/'report.md');mappinghash=h(O/'complete-common-projection-mapping-final.json')
final=('Completed historical d423 W01 assessment: all 32 common summary fields and 1,208 mapping checks match, including ten original numerical arrays byte for byte. Applicable accepted-public RM84 generic structural/type/ownership proof is explicitly scoped.\n\n'
       'Normal historical provenance/native terminal capture/whole closure are supported. Independent full-grid/upstream scientific interpretation remains UNRESOLVED/noactivation. This old W01 remains extra and cannot qualify new source or replace any of six new Q. No new framework, capture, gate, polynomial, run or SCI/D release is commissioned.\n\n'
       'Report SHA256: '+reporthash+'\nFrozen raw-primary SHA256: '+h(primary)+'\nComplete projection mapping SHA256: '+mappinghash+'\nDisposition SHA256: '+h(O/'disposition.json')+'\nInputs ledger SHA256: '+h(O/'inputs.sha256')+'\n\n'
       'Detailed report.md, complete-common-projection-mapping-final.json, reference-dispositions.json and read/accounting/input/output ledgers constitute the completed handoff. This DISTINCT final is not ROOT acceptance. Human numerical quota NOT SET; actual serving/meters/cost/complete elapsed UNKNOWN. All original artifacts and historical costs remain unchanged.\n')
(O/'final-message.md').write_text(final)
outputs=sorted(p for p in O.iterdir() if p.is_file() and p.name!='outputs.sha256')
(O/'outputs.sha256').write_text(''.join(h(p)+'  '+str(p)+'\n' for p in outputs))
print(json.dumps({'completed':True,'inputs':len(inputs),'output_files_pinned':len(outputs),'phase2_inventory_entries_verified':len(inventory['files']),
                  'report_sha256':reporthash,'final_sha256':h(O/'final-message.md'),'mapping_sha256':mappinghash,'outputs_sha256':h(O/'outputs.sha256')}))
