"""One-off completion of this W01 mapping locators and historical provenance."""
import hashlib
import json
import math
import struct
from fractions import Fraction
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114')
O=B/'actual-bound-method-review-preparation-1/reviewer1/historical-W01-pair-assessment-1'
R=B/'current-runs-1/Q-W01-QUALIFY-r1-attempt1'
K=B/'current-qualification-captures-1/Q-W01-QUALIFY-r1-attempt1'
S=Path('/workspace/work/issue-114')
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
j=load(R/'run.json');f=j['result']['wider'];su=j['result']['summary']
m=load(O/'complete-common-projection-mapping.json')
PREP='noise_variance_factors separation_matrices phase_angles_rad phase_policies frame_sums equalization_gains off_frame_sums off_equalization_gains background_after slope_after sentinel_frames between_displacements_pixels exposure_displacements_pixels header_timestamps_after input_shape input_scale acquisition_mode storage_order dxy_um dz_um lateral_zoom axial_zoom resolved_settings source_revision reference_sha256'.split()
EST='carriers_cyc_um modulation raw_modulation initial_carriers_cyc_um branches radial_cutoff_cyc_um axial_cutoff_bins resolved_settings source_revision reference_sha256'.split()
FILT='carriers_cyc_um modulation radial_cutoff_cyc_um axial_cutoffs_bins resolved_settings source_revision reference_sha256'.split()
TR='samples layout dkr_cyc_um dkz_cyc_um norders source_revision reference_sha256'.split()
completed=0
for row in m:
    if row.get('full_path'):continue
    p=row['summary_path'].split('.');root=p[1];tail=p[2:]
    if root in ['preparation','estimation','transfer']:
        names,base={'preparation':(PREP,'wider.bands'),'estimation':(EST,'wider.parameters'),'transfer':(TR,'wider.transfer')}[root]
        fp=base+'.'+names[int(tail[0])]
    elif root=='filtering':fp='wider.reconstructions.'+tail[0]+('.'+FILT[int(tail[1])] if len(tail)>1 else '')
    elif root=='overlap_builds':fp='wider.parameters.overlaps.'+'.'.join(tail)
    elif root in ['search_trace','preparation_trace']:
        base='wider.parameters.trace' if root=='search_trace' else 'wider.bands.trace';fp=base+'.'+'.'.join(tail)
    elif root=='filtering_trace':fp='wider.reconstructions.'+tail[0]+'.mode_trace'+('.'+'.'.join(tail[1:]) if len(tail)>1 else '')
    else:raise AssertionError(row)
    row['full_path']=fp;row['rule']='explicit actual public-field/event container locator; children retain checked ordered values and their detailed locator rules';completed+=1
assert all(x.get('full_path') and x.get('rule') for x in m)
(O/'complete-common-projection-mapping-final.json').write_text(json.dumps(m,indent=2)+'\n')
bb,cc,gg,ll,tt=[load(K/x) for x in ['binding.json','context.json','grant.json','launch.json','ROOT-target-terminal.json']]
bs,cs,gs=[h(K/x) for x in ['binding.json','context.json','grant.json']]
bound=bb['bindings'];assert gg==j['grant'] and gs==j['grant_sha256']
assert gg['bindings']==bound and gg['binding_receipt']['sha256']==bs and gg['context']['sha256']==cs
assert cc['binding_sha256']==bs and ll['binding']['sha256']==bs and ll['context']['sha256']==cs and ll['grant']['sha256']==gs and ll['runtime_released'] is True
assert ll['source_output_absent'] and ll['usage_file_absent'] and gg['runs']==[['W01','QUALIFY',1]] and gg['route']=='diagnostic'
assert bound['candidate']['commit']=='b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d' and bound['parent']=='1e25db68e262708e27f1ea5f6f88b0de01280449'
assert bound['candidate']['tree']=='76edc6e8ee178d3a1c125a11e3cd290231816fd7'
assert bound['accepted113']['commit']==bound['integration_base']=='274c71912afba4f976f0b7ec248af6347c2addde'
assert cc['time_unix_ns']<=ll['release_time_unix_ns']<=tt['start_unix_ns']<tt['finish_unix_ns']
assert all(v is False for v in cc['coverage_keys_present'].values()) and set(cc['threads'].values())=={'1'}
assert cc['materials_unchanged']==143 and cc['startup_files_unchanged']==7 and cc['native_files_unchanged']==2
assert cc['current_visible_cgroup_headroom_bytes']>cc['modeled_payload_bytes']>0
assert all(cc['fds'][str(i)]['open'] for i in range(3))
assert cc['sigchld_default'] and cc['sigint_default']
assert ll['inner_argv']==[bs if v=='$ROOT_BINDING_SHA256' else v for v in bound['parent_argv_shape']]
outer=ll['outer_argv']; pos=outer.index('/usr/bin/env')
assert outer[pos:pos+5]==['/usr/bin/env','-u','COVERAGE_PROCESS_START','-u','COVERAGE_PROCESS_CONFIG']
assert outer[-len(ll['inner_argv']):]==ll['inner_argv']
facts=load(K/'process-identities.json');assert facts['complete'] is True
py,ti=facts['found']['python'],facts['found']['time']
assert py['argv']==ll['inner_argv'] and ti['argv']==ll['time_argv']
assert py['ppid']==ti['pid'] and py['boot_id']==ti['boot_id'] and py['state']!='Z' and ti['state']!='Z'
assert py['executable']==bound['interpreter']['resolved'] and ti['executable_sha256']==cc['tool_sha256']
assert py['executable_sha256']==bound['startup'][py['executable']]
for proc in [py,ti]:
    assert all(x not in proc['selected_environment'] for x in ['COVERAGE_PROCESS_START','COVERAGE_PROCESS_CONFIG'])
    assert set(proc['fds'])=={'0','1','2'} and proc['fds']['0']=='/dev/null'
close=load(K/'postclose.stdout')
for role,proc in [('python',py),('time',ti)]:
    assert close[role]=={'pid':proc['pid'],'old_start':proc['start_ticks'],'original_identity_absent':True}
assert (K/'postclose.stderr').read_bytes()==b'' and (K/'stderr.txt').read_bytes()==b''
assert tt['returncode']==0 and tt['stdout_sha256']==h(K/'stdout.txt') and tt['stderr_sha256']==h(K/'stderr.txt') and tt['terminal_usage_sha256']==h(K/'terminal-native-usage.txt')
stdout=load(K/'stdout.txt');assert stdout['sha256']==h(R/'run.json') and stdout['status']==j['status']
usage=load(K/'terminal-native-usage.txt');assert usage['native_units']=='Linux KiB' and usage['exit_code']==0
assert usage['native_ru_maxrss']>=j['native_peak_rss_kib_after_export']>=j['native_peak_rss_kib_before_export']>=j['pre_call_high_water_rss_kib']
assert j['native_peak_rss_bytes_after_export']==1024*j['native_peak_rss_kib_after_export'] and j['native_peak_rss_bytes_before_export']==1024*j['native_peak_rss_kib_before_export']
for timer in j['timings']:
    assert timer['end_ns']>=timer['start_ns'] and timer['seconds']==(timer['end_ns']-timer['start_ns'])/1e9
assert j['operation_seconds']==(j['operation_end_ns']-j['operation_start_ns'])/1e9
assert j['numerical_import_seconds']==(j['numerical_import_end_ns']-j['numerical_import_start_ns'])/1e9
assert j['local_cold_to_operation_end_seconds']==(j['operation_end_ns']-j['local_cold_start_ns'])/1e9
assert j['environment']['internal_fft_arithmetic_precision']=='unknown' and j['environment']['scipy_fft_workers']==1
for key,v in bound['native'].items():
    assert j['required_fft_after_call'][key]['sha256']==v['sha256'] and j['environment']['loaded_fft_binary_modules'][key]['sha256']==v['sha256']
immutable=B/'actual-bound-source-preparation-1/author/study.py';assert h(immutable)=='d4239c63c26e4acf418f9edf1bbbb44f01d628783930d331e015abc91dc5d094'
assert j['materials_before'][bound['source']]==h(immutable)
product=[]
for path,expected in bound['materials'].items():
    if path.startswith('src/') or path=='tests/test_reconstruction_summary.py':
        actual=h(S/path);assert actual==expected;product.append({'path':str(S/path),'sha256':actual,'scope':'unchanged accepted-public material applicability; file hashing, no execution'})
finitefloatcount=0
def floats(v):
    global finitefloatcount
    if type(v) is float:
        assert math.isfinite(v) and struct.pack('>d',json.loads(json.dumps(v)))==struct.pack('>d',v)
        finitefloatcount+=1
    elif isinstance(v,dict):
        for x in v.values():floats(x)
    elif isinstance(v,list):
        for x in v:floats(x)
floats(f);floats(su)
inv=load(O/'array-inventory.json'); arrays={x['key']:x for x in inv}
def data(key):
    p=Path(arrays[key]['path']);raw=p.read_bytes();n=2 if raw[6]==1 else 4;offset=8+n+int.from_bytes(raw[8:8+n],'little');return raw[offset:]
analytic=list(struct.iter_unpack('<d',data('generator.analytic64')));raw=data('generator.raw32'); ties=0
for i,(a,) in enumerate(analytic):
    bits=int.from_bytes(raw[i*4:i*4+4],'little');v=struct.unpack('<f',raw[i*4:i*4+4])[0];err=abs(Fraction(a)-Fraction(v))
    for d in [-1,1]:
        neighbor=struct.unpack('<f',(bits+d).to_bytes(4,'little'))[0];ne=abs(Fraction(a)-Fraction(neighbor));assert err<=ne
        if err==ne: assert bits%2==0;ties+=1
summary={'completed_missing_container_locators':completed,'mapping_rows':len(m),'every_row_has_actual_full_locator_and_rule':True,
         'Bsha':bs,'Csha':cs,'Gsha':gs,'normal_terminal_usage':usage,'terminal_native_peak_bytes':usage['native_ru_maxrss']*1024,
         'source_pre_call_KiB':j['pre_call_high_water_rss_kib'],'source_before_export_KiB':j['native_peak_rss_kib_before_export'],'source_after_export_KiB':j['native_peak_rss_kib_after_export'],
         'python_identity':{k:py[k] for k in ['pid','ppid','boot_id','start_ticks','executable','executable_sha256']},
         'time_identity':{k:ti[k] for k in ['pid','ppid','boot_id','start_ticks','executable','executable_sha256']},
         'postclose':close,'timings':j['timings'],'finite_nonzero_JSON_float_roundtrip_leaves':finitefloatcount,'raw32_cast_midpoint_ties':ties,
         'scalar_roundtrip_premise':'Decoded finite nonzero floats roundtrip binary64 exactly. Original-runtime scalar kind/bits follow inspected encoder plus ordinary Python JSON roundtrip and accepted public types; files alone do not prove tuple/frozen/live flags.',
         'historical_binding_limit':'Old source path is a recorded fact. Immutable external d423 copy supplies old bytes; no requirement to rehash that soon-mutating current tracked source or compare new candidate to old measurement.',
         'public_material_reuse':product,'scope':'historical actual W01 ordinary normal route only; no speed/benefit/native precision/activation/new-source or future-value acceptance'}
(O/'provenance-and-projection-completion-results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'mapping_rows':len(m),'filled_container_locators':completed,'unchanged_public_material_files':len(product),'JSON_float_roundtrips':finitefloatcount,'terminal_native_KiB':usage['native_ru_maxrss'],'terminal_native_bytes':usage['native_ru_maxrss']*1024}))
