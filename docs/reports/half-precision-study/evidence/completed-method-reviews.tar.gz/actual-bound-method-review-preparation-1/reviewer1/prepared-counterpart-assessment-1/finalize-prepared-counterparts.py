"""One-off completed counterpart handoff accounting and immutable output hashes."""
import hashlib,json
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');O=B/'actual-bound-method-review-preparation-1/reviewer1/prepared-counterpart-assessment-1';P=B/'actual-bound-method-review-preparation-1/W02-prepared-counterpart-followup-1'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
p1=O/'W02-H2PREPARED-raw-primary.md';p2=O/'added-nine-raw-primary.md'
assert h(p1)=='579cd2a3440d078c6c9b2d52ddff08cf1a2296b174c333726e0c18e54acfea3e' and h(p2)=='08ded2966afffce6c5d17eab668f8ba3b0f108a4faa6fc7d90fcb5466831a2aa'
cases=load(O/'combined-twelve-counterpart-results.json');mapping=load(O/'actual-twelve-counterpart-map.json');assert len(cases)==len(mapping)==12
assert sum(x['NPYs'] for x in cases)==2244 and all(not x['baseline_vs_Q2_differences'] for x in cases)
inputs={}
for filename in ['W02-inputs-verified.sha256','added-inputs-verified.sha256']:
 for line in (O/filename).read_text().splitlines():
  expected,name=line.split('  ',1)
  if name in inputs:assert inputs[name]==expected
  inputs[name]=expected
extras=[P/name for name in ['reviewer-packet-1.md','actual-W02-H2PREPARED-inputs.sha256','reviewer-scope-append-both-rows-1.md','actual-both-prepared-wide-counterparts-inputs.sha256']]
extras += [B/'W02-direct-preparation-type-correction-1/author/study.py',B/'actual-bound-metadata-preparation-1/author/manifest.md',B/'actual-bound-metadata-preparation-1/author/qualification-obligations.md']
extras += [O.parent/'current-sixQ-pair-assessment-1'/name for name in ['report.md','disposition.json','row-eligibility.json','reference-and-claim-dispositions.json']]
extras += [O.parent/'M01-actual-assessment-1/report.md']
for p in extras:inputs[str(p)]=h(p)
assert h(B/'W02-direct-preparation-type-correction-1/author/study.py')=='246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635'
(O/'inputs.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(inputs.items())))
write('read-ledger.json',{'ordering':'initial627 raw -> initial own primary freeze -> explicitly released added2496 raw/nine new case arithmetic -> additive own primary freeze -> all12 ROOT summary/inventory bodies -> requested map/closure supplements',
 'initial_raw':load(O/'W02-raw-read-ledger.json'),'combined_raw':load(O/'added-raw-read-ledger.json'),'phase2':load(O/'combined-phase2-read-ledger.json'),
 'accepted_Q2_context':'Q2W02 and Q2W05 original runs and all their original NPY files read as already accepted explicit baseline context; hashes are in inputs. Other current Q/K/CPU/resource or partial data not read.',
 'additional':[{'path':str(p),'sha256':h(p),'scope':'explicit packet/append or pinned method text/accepted same-reviewer context, not executed'} for p in extras],
 'ROOT_a82_context':'accepted context per explicit ROOT packet; no invented file path/body read or source-role duplication',
 'live_or_target_operations':False})
write('disposition.json',{'completed':True,'same_reviewer':True,'scope':'actual W02/W05 WIDER/H2_PREPARED x3 closed diagnostic references only','source_sha256':'246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635','candidate':'c43913c75446272c5fc9c63aeb007dd9644568d0','tree':'d8810579d7b4a93d9bb2b1dd924b2ba0ebb5a350','direct_parent':'b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d','accepted113_integration_base':'274c71912afba4f976f0b7ec248af6347c2addde',
 'initial_raw_primary_sha256':h(p1),'added_raw_primary_sha256':h(p2),'provided_combined_raw_files':2496,'diagnostic_cases':12,'new_original_NPYs':2244,
 'verdict':'COMPLETE_FINITE_ACTUAL_PREPARED_COUNTERPARTS; NO_BLOCKING_COUNTERPART_PREREQUISITE_FOR_SEPARATE_ROOT_CONDITIONAL_SELECTED12_ADMISSION',
 'baseline_vs_Q2_checks':14952,'baseline_vs_Q2_differences':0,'unchanged_nonquadrature_metadata_checks':4692,'candidate_vs_wider_complete_checks':14952,
 'caller_map_entries':12,'seven_output_map_entries':84,'map_sha256':h(O/'actual-twelve-counterpart-map.json'),
 'WIDER_provenance':'frozen candidate=baseline snapshot; no separate prepared-stage execution. Wider full workflow performed underlying public stages, used with accepted same-operation consumed-field argument',
 'H2_provenance':'actual RN-even packed/promoted q, frozen wider metadata, newly computed public estimator/known outputs; not full half workflow or phase/noise recomputation',
 'actual_W05_half_image_nonzero_sign_changes_each_rep':4,'source_vs_exact_file_metric_rounding_differences':'retained with exact energy fractions; no new tolerance',
 'blocking_source_capture_helper_framework_control_gate_required':False,'independent_fullgrid_upstream_science_nativeprecision_optimized_resource_benefit':'UNRESOLVED_NOACTIVATION',
 'future_child_values_metadata_traces_outputs_branches_nativepeaks_preaccepted':False,'future_runtime_retry_global149_SCI_D_publication_grant':False,'ROOT_acceptance':False,
 'minimum_future_obligations':'fresh ROOT percase C/B/G/L/Gcopy/source/material/default/native/qualification/admission/exclusive window; actual caller/finite unpack/seven outputs/stats/known branches against exact row-arm-rep map; unwrapped sole exact-child wait4/readiness/identity/clock/native terminal/wholeclose; preserve mismatches/failures without tuning/retry; no in-child reference',
 'final_SCI':'DIFFERENT fresh independent session on completed whole-study evidence'})
commands=[{'argv':['python3','-I','-S',str(O/name)],'code_sha256':h(O/name),'scope':scope,'exit_code':0} for name,scope in [
 ('W02-retained-counterpart-analysis.py','initial three W02 actual byte/IEEE/Fraction/complete baseline/metadata/params/known/output/native data'),
 ('prepare-added-nine-analysis-text.py','new explicitly finite added-case analysis TEXT authoring; never import earlier script'),
 ('added-nine-retained-counterpart-analysis.py','nine explicitly added closed references; own original-data analysis, no target/source execution'),
 ('combined-phase2-and-expected-map.py','post-primary12 attributed summaries/2484 inventory entries,96 exact caller+output NPY locators and raw route supplements'),
 ('finalize-prepared-counterparts.py','completed read/input/account/disposition/final/output hash bookkeeping')]]
write('accounting.json',{'same_reviewer':True,'delegation':False,'initial_provided_raw_files':627,'combined_provided_raw_files':2496,'closed_diagnostic_counterparts':12,'new_NPYs':2244,'expected_resource_callers':12,'expected_resource_outputs':84,'all_inputs':len(inputs),'command_identities':commands,
 'operations_performed':'explicit isolated stdlib -I -S retained JSON/NPY/header/IEEE/component/Fraction/hash arithmetic and finite projection; source/observer text is inert',
 'not_performed':['product/source/study-helper/native/NumPy/SciPy execution/import','AST/compile/eval/pickle','experiments/new polynomial/upstream/oracle/comparator/capture framework','live probes/signals/wait/reap','Docker/tests/installs/repairs/source changes','partial W05/unrelated mode/new K/CPU/resource inputs','delegation','automatic retry'],
 'metadata_snapshot_limit':'WIDER candidate frozen baseline; H2 bands metadata frozen wider with only q replacement; full standalone resource metadata/trace not directly observed/exported',
 'scientific_limit':'all independent fullgrid/upstream/physical/nativeprecision/optimized resource benefit unresolved; no acceptance threshold invented',
 'output_scope':'ONLY NEW reviewer1/prepared-counterpart-assessment-1; first primary/code/results and all historical/current source/raw/report bytes unchanged',
 'historical_costs_failures':'preserved, diagnostic12 never relabelled resource12','actual_serving_model':'UNKNOWN','actual_effort':'UNKNOWN','actual_tokens':'UNKNOWN','actual_cache':'UNKNOWN','actual_money':'UNKNOWN','complete_elapsed':'UNKNOWN','human_numerical_quota':'NOT SET',
 'exclusive_window':'ROOT stated none running during this analysis; any later ROOT exclusive benchmark pause signal will suspend heavy reads/arithmetic'})
reportsha=h(O/'report.md');mapsha=h(O/'actual-twelve-counterpart-map.json')
final=('COMPLETED finite actual W02/W05 counterpart assessment: twelve closed WIDER/H2_PREPARED diagnostics, 2,496 raw files and 2,244 original NPYs. Every wider baseline exactly matches its reviewed current Q2 row; all non-q metadata is wider-frozen exact. Actual half words/promoted signed zeros, full params/ordered traces/known/image/xyz and repetition-specific expected values are assessed.\n\n'
 'No blocking counterpart prerequisite for separate ROOT conditional selected12 admission. Exact map supplies 12 prepared callers and 84 outputs with original NPY paths/full-file SHA/dtype/shape/content identities. WIDER is a frozen baseline snapshot, not a separate prepared execution; H2 recomputes downstream on quantized q with frozen metadata. Nonzero errors and W05 four image sign changes per half repetition remain explicit.\n\n'
 'Future child caller/outputs/branches/metadata/clock/native wait4/closure are NOT accepted in advance. Science/fullgrid/upstream/nativeprecision/optimized benefit remains UNRESOLVED/noactivation; no runtime/retry/global149/SCI/D grant, extra source/helper/capture/framework/control/polynomial/tolerance/gate or ROOT acceptance.\n\n'
 'Report SHA256: '+reportsha+'\nExact caller+seven-output map SHA256: '+mapsha+'\nDisposition SHA256: '+h(O/'disposition.json')+'\nInitial raw-primary SHA256: '+h(p1)+'\nAdded raw-primary SHA256: '+h(p2)+'\nInputs ledger SHA256: '+h(O/'inputs.sha256')+'\n\n'
 'Detailed report.md, actual-twelve-counterpart-map.json/.md, disposition/read/accounting/input/output ledgers and this DISTINCT final constitute the completed handoff. Original scopes/artifacts/failures/costs preserved. Human numerical quota NOT SET; serving/meters/money/complete elapsed UNKNOWN. Final SCI DIFFERENT fresh independent session.\n')
(O/'final-message.md').write_text(final)
outputs=sorted(p for p in O.rglob('*') if p.is_file() and p.name!='outputs.sha256')
(O/'outputs.sha256').write_text(''.join(h(p)+'  '+str(p)+'\n' for p in outputs))
print(json.dumps({'completed':True,'inputs':len(inputs),'outputs_pinned':len(outputs),'report_sha256':reportsha,'final_sha256':h(O/'final-message.md'),'map_sha256':mapsha,'disposition_sha256':h(O/'disposition.json'),'outputs_sha256':h(O/'outputs.sha256')}))
