"""One-off exactly nine added CLOSED W02/W05 WIDER/H2_PREPARED retained-file cases."""
import hashlib,itertools,json,math,re,struct
from fractions import Fraction
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');OUT=B/'actual-bound-method-review-preparation-1/reviewer1/prepared-counterpart-assessment-1';P=B/'actual-bound-method-review-preparation-1/W02-prepared-counterpart-followup-1'
SPECS=[(row,arm,rep,f'N2-{row}-{arm}-r{rep}-attempt1') for row in ['W02','W05'] for arm in ['WIDER','H2_PREPARED'] for rep in [1,2,3]]
NAMES=[x[3] for x in SPECS]
ADDED=[x for x in SPECS if not(x[0]=='W02' and x[1]=='H2_PREPARED')]
Q=B/'current-runs-2/Q2-W02-QUALIFY-r1-attempt2'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def h(p):return sha(p.read_bytes())
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate key')
  d[k]=v
 return d
def bad(s):raise ValueError('nonstandard JSON '+s)
def load(p):return json.loads(p.read_bytes(),object_pairs_hook=pairs,parse_constant=bad)
rawreads=[];inputs={}
for line in (P/'actual-both-prepared-wide-counterparts-inputs.sha256').read_text().splitlines():
 expected,name=line.split('  ',1);p=Path(name);raw=p.read_bytes();assert p.parts[-2] in NAMES or p.parts[-3] in NAMES
 assert '/current-runs-2/N2-W' in name or '/current-numerical-captures-2/N2-W' in name
 assert sha(raw)==expected;inputs[name]=expected;defer=p.name.startswith('ROOT-closed-')
 rawreads.append({'path':name,'sha256':expected,'bytes':len(raw),'phase':'identity-hash-only-ROOT-body-deferred' if defer else 'own-raw-primary'})
 if p.suffix=='.json' and not defer:load(p)
assert len(inputs)==2496
def retained_run(path):
 j=load(path/'run.json'); arrays={}; inventory=[]
 for key,entry in j['array_index'].items():
  p=path/entry['path'];raw=p.read_bytes();assert h(p)==entry['sha256'] and len(raw)==entry['nbytes'];assert raw[:6]==b'\x93NUMPY'
  assert tuple(raw[6:8]) in [(1,0),(2,0)];n=2 if raw[6]==1 else 4;off=8+n;size=int.from_bytes(raw[8:off],'little');header=raw[off:off+size].decode('latin1')
  m=re.fullmatch(r"\{'descr': '([<|][bifuc][0-9]+)', 'fortran_order': (True|False), 'shape': \(([0-9, ]*)\), \}[ \n]*",header);assert m,header
  dtype,fort,dims=m.groups();shape=[int(x.strip()) for x in dims.split(',') if x.strip()];kind=dtype[1];width=int(dtype[2:]);data=raw[off+size:];assert len(data)==math.prod(shape)*width
  if fort=='True':
   strides=[];q=1
   for dim in shape:strides.append(q);q*=dim
   data=b''.join(data[sum(i*t for i,t in zip(ix,strides))*width:sum(i*t for i,t in zip(ix,strides))*width+width] for ix in itertools.product(*(range(x) for x in shape)))
  cw=width//2 if kind=='c' else width;code={('f',2):'e',('f',4):'f',('f',8):'d',('c',4):'f',('c',8):'d',('i',8):'q',('i',4):'i',('u',8):'Q',('u',4):'I',('b',1):'?'}[(kind,cw)]
  vals=[v[0] for v in struct.iter_unpack('<'+code,data)];assert all(math.isfinite(v) for v in vals)
  meta={'array_key':key,'path':str(p),'file_sha256':h(p),'shape':shape,'canonical_dtype':dtype,'content_sha256':sha(data),'components':len(vals),'payload_bytes':len(data),'fortran_file_order':fort=='True'}
  arrays[key]=(meta,data,vals,cw,kind);inventory.append(meta)
  if path==Q:inputs[str(p)]=h(p)
 descriptors=[]
 def visit(v,where):
  if isinstance(v,dict) and set(v)=={'array','shape','dtype'}:
   a=arrays[v['array']];assert v['shape']==a[0]['shape'] and v['dtype']==a[0]['canonical_dtype'];descriptors.append({'json_path':where,**a[0]})
  elif isinstance(v,dict):
   for k,x in v.items():visit(x,where+'.'+k)
  elif isinstance(v,list):
   for i,x in enumerate(v):visit(x,where+'.'+str(i))
 visit(j,'record');return j,arrays,inventory,descriptors
qcontexts={};accepted={x['row']:x for x in load(OUT.parent/'current-sixQ-pair-assessment-1/row-eligibility.json')}
for row in ['W02','W05']:
 Q=B/'current-runs-2'/('Q2-'+row+'-QUALIFY-r1-'+('attempt2' if row=='W02' else 'attempt1'))
 qcontexts[row]=retained_run(Q);inputs[str(Q/'run.json')]=h(Q/'run.json');assert h(Q/'run.json')==accepted[row]['qualification_sha256']
def rnd(n,d):
 a,r=divmod(n,d);return a+(2*r>d or (2*r==d and a%2==1))
def halfword(v,sign):
 x=abs(Fraction(v))
 if not x:return sign<<15
 if x<Fraction(1,16384):return (sign<<15)|rnd(x.numerator*(1<<24),x.denominator)
 e=x.numerator.bit_length()-x.denominator.bit_length()
 if x < (Fraction(1<<e) if e>=0 else Fraction(1,1<<(-e))):e-=1
 scaled=x*(Fraction(1<<(10-e)) if 10-e>=0 else Fraction(1,1<<(e-10)));m=rnd(scaled.numerator,scaled.denominator)
 if m==2048:e+=1;m=1024
 if e>15:return (sign<<15)|0x7c00
 return (sign<<15)|((e+15)<<10)|(m-1024)
def ident(a):return {k:a[0][k] for k in ['shape','canonical_dtype','content_sha256']}
def statistics(a):
 vals=a[2];cw=a[3];data=a[1]
 return {'components':len(vals),'nonfinite':sum(not math.isfinite(v) for v in vals),'negative':sum(v<0 for v in vals),'zeros':sum(v==0 for v in vals),'negative_zeros':sum(v==0 and bool(data[i*cw+cw-1]&128) for i,v in enumerate(vals)) if a[4] in 'fc' else 0,'minimum_component':min(vals),'maximum_component':max(vals),'half_subnormal_component_range':sum(0<abs(v)<2**-14 for v in vals)}
def compare(v,w,aa,bb,lp,rp,records):
 if isinstance(v,dict) and set(v)=={'array','shape','dtype'}:
  a,b=aa[v['array']],bb[w['array']];ok=a[0]['shape']==b[0]['shape'] and a[0]['canonical_dtype']==b[0]['canonical_dtype'] and a[1]==b[1]
  records.append({'left':lp,'right':rp,'kind':'original ndarray ALL canonical components incl signedzeros','outcome':'EXACT' if ok else 'DIFFERENT','left_identity':ident(a),'right_identity':ident(b)});return
 if isinstance(v,dict):
  ok=isinstance(w,dict) and list(v)==list(w);records.append({'left':lp,'right':rp,'kind':'ordered record keys','outcome':'EXACT' if ok else 'SCHEMA_MISMATCH','keys':list(v)})
  if not ok:return
  for k,x in v.items():compare(x,w[k],aa,bb,lp+'.'+k,rp+'.'+k,records)
 elif isinstance(v,list):
  ok=isinstance(w,list) and len(v)==len(w);records.append({'left':lp,'right':rp,'kind':'ordered sequence length','outcome':'EXACT' if ok else 'SCHEMA_MISMATCH','length':len(v)})
  if not ok:return
  for i,x in enumerate(v):compare(x,w[i],aa,bb,lp+'.'+str(i),rp+'.'+str(i),records)
 else:
  ok=type(v) is type(w) and (struct.pack('>d',v)==struct.pack('>d',w) if type(v) is float else v==w)
  records.append({'left':lp,'right':rp,'kind':type(v).__name__,'outcome':'EXACT' if ok else 'DIFFERENT','left_value':v,'right_value':w})
def metrics(a,b):
 assert a[0]['shape']==b[0]['shape'] and a[4]==b[4]
 comps=2 if a[4]=='c' else 1;count=len(a[2])//comps;energy=Fraction();squared=Fraction();maxsq=Fraction();loss=[0]*comps;signchange=[0]*comps
 for i in range(count):
  ds=Fraction()
  for c in range(comps):
   x,y=a[2][i*comps+c],b[2][i*comps+c];xx,yy=Fraction(x),Fraction(y);ds+=(yy-xx)**2;energy+=xx**2;loss[c]+=x!=0 and y==0;signchange[c]+=x!=0 and y!=0 and ((x<0)!=(y<0))
  squared+=ds;maxsq=max(maxsq,ds)
 return {'exact_squared_error_fraction':[squared.numerator,squared.denominator],'exact_reference_energy_fraction':[energy.numerator,energy.denominator],'max_absolute':math.sqrt(float(maxsq)),'rms':math.sqrt(float(squared/count)),'relative_l2':math.sqrt(float(squared/energy)) if energy else (0.0 if not squared else None),'nonzero_loss_components':loss,'nonzero_sign_changes':signchange,'scope':'exact retained dyadic energy sums then stdlib sqrt rounding, not a new scientific tolerance/native observer'}
allresults=[];seven=[]
for ROW,ARM,REP,NAME in ADDED:
 Q=B/'current-runs-2'/('Q2-'+ROW+'-QUALIFY-r1-'+('attempt2' if ROW=='W02' else 'attempt1'));qj,qa,qi,qd=qcontexts[ROW];qf=qj['result']['wider']
 R=B/'current-runs-2'/NAME;K=B/'current-numerical-captures-2'/NAME;O=OUT/('added-'+ROW+'-'+ARM+'-r'+str(REP));O.mkdir(exist_ok=False)
 j,aa,inventory,descriptors=retained_run(R);a=j['result']['baseline'];c=j['result']['candidate'];assert len(aa)==(188 if ARM=='H2_PREPARED' else 186)
 assert j['status']==j['result']['status']=='completed' and j['row']==ROW and j['strategy']==ARM and j['repetition']==REP
 assert j['identities']['harness']=='246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635' and j['materials_before']==j['materials_after']
 assert j['grant']['qualification_sha256'][ROW]==h(Q/'run.json')
 sourceq=aa[a['bands']['quadratures']['array']];candidateq=aa[c['bands']['quadratures']['array']];zerosign_mismatches=0
 if ARM=='H2_PREPARED':
  packed=aa['prepared.packed'];promoted=aa['prepared.promoted']
  assert packed[0]['shape']==sourceq[0]['shape']+[2] and packed[0]['canonical_dtype']=='<f2' and promoted[0]['canonical_dtype']==candidateq[0]['canonical_dtype']=='<c16'
  assert promoted[0]['shape']==candidateq[0]['shape']==sourceq[0]['shape']
  for i,value in enumerate(sourceq[2]):
   sign=sourceq[1][8*i+7]>>7;expected=halfword(value,sign);observed=int.from_bytes(packed[1][2*i:2*i+2],'little');assert observed==expected
   expected64=struct.pack('<d',struct.unpack('<e',packed[1][2*i:2*i+2])[0]);assert promoted[1][8*i:8*i+8]==expected64
   if value==0 and ((observed>>15)!=sign):zerosign_mismatches+=1
  assert zerosign_mismatches==0 and promoted[1]==candidateq[1]
 else:
  packed=None;promoted=candidateq;assert sourceq[1]==candidateq[1]
 baseline_map=[];expect={k:qf[k] for k in ['image','bands','parameters','reconstructions']}
 compare(expect,a,qa,aa,'Q2W02.wider','counterpart.baseline',baseline_map)
 baseline_differences=[x for x in baseline_map if x['outcome']!='EXACT']
 metadata_map=[]
 compare({k:v for k,v in a['bands'].items() if k!='quadratures'},{k:v for k,v in c['bands'].items() if k!='quadratures'},aa,aa,'baseline.bands_except_q','candidate.bands_except_q',metadata_map)
 assert all(x['outcome']=='EXACT' for x in metadata_map)
 candidate_map=[];compare(a,c,aa,aa,'counterpart.baseline','counterpart.candidate',candidate_map)
 assert not any(x['outcome']=='SCHEMA_MISMATCH' for x in candidate_map)
 assert a['parameters']['branches']==c['parameters']['branches']==[['known']*3]
 initial=aa[a['parameters']['initial_carriers_cyc_um']['array']];used=aa[c['parameters']['carriers_cyc_um']['array']]
 assert initial[0]['shape']==[3,2] and used[0]['shape']==[1,3,2] and initial[1]==used[1]==qa[qf['initial_carriers_cyc_um']['array']][1]
 assert aa[c['parameters']['initial_carriers_cyc_um']['array']][1]==initial[1]
 for p in [a['parameters'],c['parameters']]:
  for i,build in enumerate(p['overlaps']):assert build['index']==i and build['time_index']==0 and build['direction_index'] in range(3)
  for event in p['trace']:
   details=dict(event['details'])
   if 'overlap_index'in details:
    build=p['overlaps'][details['overlap_index']];assert build['time_index']==event['time_index'] and build['direction_index']==event['direction_index']
   if event['kind']=='adjustment':assert details['floor'] is None and details['floor_applied'] is False and details['phase_replaced'] is False
 assert aa[c['image']['array']][1]==b''.join(aa[k['image']['array']][1] for k in c['reconstructions'])
 for t,k in enumerate(c['reconstructions']):
  assert aa[k['carriers_cyc_um']['array']][1]==used[1] and aa[k['modulation']['array']][1]==aa[c['parameters']['modulation']['array']][1]
  for field in ['x_um','y_um','z_um']:assert aa[k[field]['array']][1]==qa[qf[field]['array']][1]
 decision_names={'stage','orders','integer_peak_xy','x_offset_status','y_offset_status','alias_decisions','branch','strict_improvement','status','order','floor_applied','phase_replaced','source_time','remake_overlaps'}
 def decisions(p):return {'branches':p['branches'],'ordered_events':[{'kind':e['kind'],'time':e['time_index'],'direction':e['direction_index'],'details':{k:v for k,v in e['details'] if k in decision_names}} for e in p['trace']]}
 actual_decisions=[decisions(p) for p in [a['parameters'],c['parameters']]];assert actual_decisions[0]==actual_decisions[1]
 assert j['result']['parameters']['decisions_reference']==actual_decisions[0] and j['result']['parameters']['decisions_candidate']==actual_decisions[1] and j['result']['parameters']['decisions_equal'] is True
 fields={'image':c['image'],**{k:c['reconstructions'][0][k] for k in ['x_um','y_um','z_um']},**{k:c['parameters'][k] for k in ['carriers_cyc_um','modulation','raw_modulation']}}
 expectedoutputs={k:{'identity':ident(aa[v['array']]),'statistics':statistics(aa[v['array']]),'NPY':aa[v['array']][0]} for k,v in fields.items()}
 observedmetrics={};targets=[('prepared_error',sourceq,promoted),('image_error_count_units',aa[a['image']['array']],aa[c['image']['array']])]
 for label,x,y in targets:
  m=metrics(x,y);recorded=j['result'][label];m['source_reported']={k:(struct.unpack('>d',bytes.fromhex(recorded[k]['float64_bits_be']))[0] if isinstance(recorded[k],dict) else recorded[k]) for k in ['max_absolute','rms','relative_l2']};m['file_reference_minus_source']={k:m[k]-m['source_reported'][k] for k in ['max_absolute','rms','relative_l2']};observedmetrics[label]=m
 for label,field in [('noise_error','noise_variance_factors'),('frame_sum_error','frame_sums'),('gain_error','equalization_gains'),('phase_matrix_error','separation_matrices')]:
  assert aa[a['bands'][field]['array']][1]==aa[c['bands'][field]['array']][1]
  for k in ['max_absolute','rms','relative_l2']:
   v=j['result'][label][k];assert v=={'float64_bits_be':'0000000000000000'} or v==0.0
 # Actual normal route: same C/B/G/L/qualification association, no ROOT summary consumed.
 bb,cc,gg,ll,tt=[load(K/name) for name in ['binding.json','context.json','grant.json','launch.json','ROOT-target-terminal.json']];bound=bb['bindings'];bs,cs,gs=[h(K/name) for name in ['binding.json','context.json','grant.json']]
 assert gg==j['grant'] and gs==j['grant_sha256'] and gg['binding_receipt']['sha256']==bs and gg['context']['sha256']==cs and gg['bindings']==bound
 assert ll['binding']['sha256']==bs and ll['context']['sha256']==cs and ll['grant']['sha256']==gs and ll['runtime_released'] and ll['source_output_absent'] and ll['usage_file_absent']
 assert gg['runs']==[[ROW,ARM,REP]] and cc['binding_sha256']==bs
 assert bound['candidate']['commit']=='c43913c75446272c5fc9c63aeb007dd9644568d0' and bound['candidate']['tree']=='d8810579d7b4a93d9bb2b1dd924b2ba0ebb5a350' and bound['parent']=='b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d'
 assert ll['inner_argv']==[bs if x=='$ROOT_BINDING_SHA256' else x for x in bound['parent_argv_shape']]
 argv=ll['inner_argv'];assert argv[argv.index('--qualification')+1]==str(Q/'run.json')
 assert cc['time_unix_ns']<=ll['release_time_unix_ns']<=tt['start_unix_ns']<tt['finish_unix_ns']
 assert cc['materials_unchanged']==143 and cc['startup_files_unchanged']==7 and cc['native_files_unchanged']==2 and not any(cc['coverage_keys_present'].values()) and set(cc['threads'].values())=={'1'}
 rawc=load(K/'C.stdout');assert all(cc[k]==v for k,v in rawc.items() if k not in ['scope','admission_rationale'])
 facts=load(K/'process-identities.json');assert facts['complete'];py,ti=facts['found']['python'],facts['found']['time']
 assert py['argv']==ll['inner_argv'] and ti['argv']==ll['time_argv'] and py['ppid']==ti['pid'] and py['boot_id']==ti['boot_id'] and py['executable']==bound['interpreter']['resolved'] and py['executable_sha256']==bound['startup'][py['executable']]
 assert ti['executable_sha256']==ll['time_binary_sha256']==cc['tool_sha256']
 close=load(K/'postclose.stdout')
 for role,proc in [('python',py),('time',ti)]:assert close[role]=={'pid':proc['pid'],'old_start':proc['start_ticks'],'original_identity_absent':True}
 assert tt['returncode']==0 and tt['stdout_sha256']==h(K/'stdout.txt') and tt['stderr_sha256']==h(K/'stderr.txt') and tt['terminal_usage_sha256']==h(K/'terminal-native-usage.txt')
 assert load(K/'stdout.txt')['sha256']==h(R/'run.json') and (K/'stderr.txt').read_bytes()==(K/'postclose.stderr').read_bytes()==b''
 ot=load(K/'ROOT-identity-observer-terminal.json');assert ot['returncode']==0 and ot['stdout_sha256']==h(K/'observer.stdout') and ot['stderr_sha256']==h(K/'observer.stderr')
 usage=load(K/'terminal-native-usage.txt');assert usage['exit_code']==0 and usage['native_units']=='Linux KiB' and usage['native_ru_maxrss']>=j['native_peak_rss_kib_after_export']>=j['native_peak_rss_kib_before_export']>=j['pre_call_high_water_rss_kib']
 for timer in j['timings']:assert timer['seconds']==(timer['end_ns']-timer['start_ns'])/1e9
 result={'row':ROW,'diagnostic_strategy':ARM,'repetition':REP,'run_id':NAME,'run_sha256':h(R/'run.json'),'qualification_path':str(Q/'run.json'),'qualification_sha256':h(Q/'run.json'),'NPYs':len(aa),'descriptor_occurrences':len(descriptors),'baseline_vs_current_Q2_checks':len(baseline_map),'baseline_vs_Q2_differences':baseline_differences,'all_wider_metadata_except_q_preserved_checks':len(metadata_map),'candidate_vs_baseline_complete_checks':len(candidate_map),'candidate_changed_entries':[x for x in candidate_map if x['outcome']!='EXACT'],'caller_original':ident(sourceq),'caller_packed':ident(packed) if packed else None,'caller_promoted':ident(promoted),'caller_statistics':{'original':statistics(sourceq),'packed':statistics(packed) if packed else None,'promoted':statistics(promoted)},'all_half_words_RN_even_verified':len(sourceq[2]) if packed else 0,'all_promoted_component_bits_verified':len(promoted[2]),'original_zero_sign_mismatches':zerosign_mismatches,'parameters_branches':c['parameters']['branches'],'ordered_decisions':actual_decisions[1],'seed_original_identity':ident(initial),'seed_known_T1_all_signed_component_bytes_equal':True,'metrics':observedmetrics,'usage':usage,'terminal_peak_bytes':usage['native_ru_maxrss']*1024,'source_snapshots_KiB':{k:j[k] for k in ['pre_call_high_water_rss_kib','native_peak_rss_kib_before_export','native_peak_rss_kib_after_export']},'postclose':close,'Bsha':bs,'Csha':cs,'Gsha':gs,'timings':j['timings'],'local_clocks':j['result']['local_clocks'],'scope':'H2_PREPARED actually recomputes estimate/known on quantized q with frozen wider metadata; WIDER candidate is frozen baseline snapshot, not a separate prepared-stage execution. Complete relative-to-wider counterpart, no independent fullgrid/upstream/nativeprecision/science approval or future child preacceptance'}
 for name,value in [('array-inventory.json',inventory),('descriptor-mapping.json',descriptors),('baseline-vs-Q2-complete-mapping.json',baseline_map),('candidate-metadata-preservation-mapping.json',metadata_map),('candidate-vs-wider-complete-mapping.json',candidate_map),('counterpart-results.json',result),('seven-expected-outputs.json',expectedoutputs)]:
  (O/name).write_text(json.dumps(value,indent=2)+'\n')
 allresults.append(result);seven.append({'row':ROW,'diagnostic_strategy':ARM,'repetition':REP,'run_id':NAME,'run_sha256':h(R/'run.json'),'qualification_sha256':h(Q/'run.json'),'caller_original':ident(sourceq),'caller_packed':ident(packed) if packed else None,'caller_promoted':ident(promoted),'outputs':expectedoutputs,'branches':c['parameters']['branches']})
(OUT/'added-raw-read-ledger.json').write_text(json.dumps(rawreads,indent=2)+'\n')
(OUT/'added-inputs-verified.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(inputs.items())))
(OUT/'added-nine-counterpart-results.json').write_text(json.dumps(allresults,indent=2)+'\n')
(OUT/'added-nine-repetition-specific-expected-outputs.json').write_text(json.dumps(seven,indent=2)+'\n')
print(json.dumps([{'row':r['row'],'arm':r['diagnostic_strategy'],'rep':r['repetition'],'NPYs':r['NPYs'],'baseline_Q2_differences':len(r['baseline_vs_Q2_differences']),'candidate_changed_entries':len(r['candidate_changed_entries']),'caller_packed':r['caller_packed'],'stats':r['caller_statistics'],'image_metrics':r['metrics']['image_error_count_units'],'nativeKiB':r['usage']['native_ru_maxrss']} for r in allresults]))
