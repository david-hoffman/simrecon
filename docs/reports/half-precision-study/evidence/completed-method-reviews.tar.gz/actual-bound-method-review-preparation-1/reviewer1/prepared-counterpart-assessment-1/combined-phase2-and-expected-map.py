"""One-off post-primary twelve collection comparisons and explicit requested map."""
import hashlib,json
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');O=B/'actual-bound-method-review-preparation-1/reviewer1/prepared-counterpart-assessment-1'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
assert h(O/'W02-H2PREPARED-raw-primary.md')=='579cd2a3440d078c6c9b2d52ddff08cf1a2296b174c333726e0c18e54acfea3e'
assert h(O/'added-nine-raw-primary.md')=='08ded2966afffce6c5d17eab668f8ba3b0f108a4faa6fc7d90fcb5466831a2aa'
initial=load(O/'W02-three-counterpart-results.json');added=load(O/'added-nine-counterpart-results.json')
cases=[{**x,'diagnostic_strategy':'H2_PREPARED','analysis_directory':'W02-r'+str(x['repetition'])} for x in initial]+[{**x,'analysis_directory':'added-'+x['row']+'-'+x['diagnostic_strategy']+'-r'+str(x['repetition'])} for x in added]
cases=sorted(cases,key=lambda x:(x['row'],x['diagnostic_strategy'],x['repetition']))
reads=[];comparisons=[];table=[];nativechecks=[]
for a in cases:
 K=B/'current-numerical-captures-2'/a['run_id'];R=B/'current-runs-2'/a['run_id'];j=load(R/'run.json')
 s=load(K/'ROOT-closed-collection-summary.json');iv=load(K/'ROOT-closed-raw-inventory.json')
 assert s['run_sha256']==h(R/'run.json') and s['status']==j['status']=='completed' and s['indexed_arrays_checked']==a['NPYs'] and s['usage']==a['usage'] and s['postclose_identities']==a['postclose'] and s['material_grant_unchanged'] is True
 assert all(j[k]==v for k,v in s['source_snapshots_KiB'].items())
 for name,e in iv['files'].items():
  p=Path(name);assert '/'+a['run_id']+'/' in name and h(p)==e['sha256'] and len(p.read_bytes())==e['bytes']
 assert str(K/'ROOT-closed-raw-inventory.json') not in iv['files']
 for name in ['ROOT-closed-collection-summary.json','ROOT-closed-raw-inventory.json']:reads.append({'path':str(K/name),'sha256':h(K/name),'phase':'ROOT collection body AFTER initial and additive own raw-primary freezes'})
 comparisons.append({'run_id':a['run_id'],'raw_summary_consistent':True,'inventory_entries_verified':len(iv['files']),'scope':'attributed collection facts, not numerical acceptance'})
 cc=load(K/'context.json');ll=load(K/'launch.json');facts=load(K/'process-identities.json')
 outer=ll['outer_argv'];pos=outer.index('/usr/bin/env');assert outer[pos:pos+5]==['/usr/bin/env','-u','COVERAGE_PROCESS_START','-u','COVERAGE_PROCESS_CONFIG'] and outer[-len(ll['inner_argv']):]==ll['inner_argv']
 assert cc['current_visible_cgroup_headroom_bytes']>cc['modeled_payload_bytes'] and cc['sigchld_default'] and cc['sigint_default'] and all(cc['fds'][str(i)]['open'] for i in range(3))
 for proc in facts['found'].values():assert proc['state']!='Z' and all(k not in proc['selected_environment'] for k in ['COVERAGE_PROCESS_START','COVERAGE_PROCESS_CONFIG']) and set(proc['fds'])=={'0','1','2'}
 assert j['native_peak_rss_bytes_before_export']==1024*j['native_peak_rss_kib_before_export'] and j['native_peak_rss_bytes_after_export']==1024*j['native_peak_rss_kib_after_export']
 assert j['numerical_import_seconds']==(j['numerical_import_end_ns']-j['numerical_import_start_ns'])/1e9 and j['operation_seconds']==(j['operation_end_ns']-j['operation_start_ns'])/1e9
 nativechecks.append({'run_id':a['run_id'],'fresh_outer_coverage_prefix_target_environment_ordinary_FDs_headroom_source_clock_units_checked':True,'terminal_peak_bytes':a['terminal_peak_bytes'],'scope':'normal diagnostic direct GNUtime/Python only; future resource wait4 remains unobserved'})
 inv={x['array_key']:x for x in load(O/a['analysis_directory']/'array-inventory.json')};base=j['result']['baseline'];candidate=j['result']['candidate'];half=a['diagnostic_strategy']=='H2_PREPARED'
 original=inv[base['bands']['quadratures']['array']];caller=inv['prepared.packed'] if half else original;promoted=inv['prepared.promoted'] if half else None
 outputs=load(O/a['analysis_directory']/'seven-expected-outputs.json');assert set(outputs)=={'image','x_um','y_um','z_um','carriers_cyc_um','modulation','raw_modulation'}
 entry={'row':a['row'],'resource_arm':'PREPARED_HALF' if half else 'PREPARED_WIDER','repetition':a['repetition'],'diagnostic_strategy':a['diagnostic_strategy'],'diagnostic_run_id':a['run_id'],'diagnostic_run_path':str(R/'run.json'),'diagnostic_run_sha256':h(R/'run.json'),'qualification_path':a['qualification_path'],'qualification_sha256':a['qualification_sha256'],
 'source_sha256':'246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635','candidate_commit':'c43913c75446272c5fc9c63aeb007dd9644568d0',
 'expected_resource_caller':{'identity':{k:caller[k] for k in ['shape','canonical_dtype','content_sha256']},'original_NPY':caller,'interpretation':'actual retained real-then-imag component half words' if half else 'actual retained wider band quadratures; NOT diagnostic raw32 caller'},
 'original_wider_quadratures_NPY':original,'promoted_after_unpack_NPY':promoted,'expected_seven_outputs':outputs,'expected_branches':a['parameters_branches'],
 'seed_identity':a['seed_original_identity'],'actual_seed_mapping':'baseline initial(3,2) -> candidate carriers[0,:,:](1,3,2), ALL signed component bytes equal',
 'provenance':'H2 actually runs pack/unpack, public estimate and public known with frozen wider metadata' if half else 'WIDER candidate is frozen baseline record; baseline full workflow contains public stages, no separate prepared continuation executed',
 'future_value_preacceptance':False,'claim_limit':'finite relative-to-wider counterpart; full standalone metadata/trace not directly exported; science/upstream/nativeprecision/optimized resource benefit UNRESOLVED'}
 table.append(entry)
groups=[]
for row in ['W02','W05']:
 for arm in ['PREPARED_WIDER','PREPARED_HALF']:
  group=[x for x in table if x['row']==row and x['resource_arm']==arm];assert [x['repetition'] for x in group]==[1,2,3]
  base=group[0]
  groups.append({'row':row,'resource_arm':arm,'three_fresh_completed_repetitions':True,'actual_caller_content_identities_equal_across_repetitions':all(x['expected_resource_caller']['identity']==base['expected_resource_caller']['identity'] for x in group),'actual_all_seven_output_content_identities_equal_across_repetitions':all(all(x['expected_seven_outputs'][k]['identity']==base['expected_seven_outputs'][k]['identity'] for k in base['expected_seven_outputs']) for x in group),'scope':'observed repeat equality, not future native determinism theorem'})
for filename,value in [('combined-phase2-comparison-results.json',comparisons),('combined-phase2-read-ledger.json',reads),('supplemental-normal-route-checks.json',nativechecks),('actual-twelve-counterpart-map.json',table),('actual-repeat-content-consistency.json',groups),('combined-twelve-counterpart-results.json',cases)]:
 (O/filename).write_text(json.dumps(value,indent=2)+'\n')
md=['# Exact actual twelve-counterpart file map','', 'The JSON map is authoritative for original dtype/shape/content identities, full NPY file SHA256/statistics/provenance and exact run/qualification bindings. These are expected comparison data, never a future-child grant or preacceptance.','', '| Row / resource arm / repetition | Caller original NPY / whole-file SHA256 | Seven actual original NPYs / whole-file SHA256 |','|---|---|---|']
for x in table:
 caller=x['expected_resource_caller']['original_NPY'];fields='<br>'.join(k+': '+v['NPY']['path']+' / '+v['NPY']['file_sha256'] for k,v in x['expected_seven_outputs'].items())
 md.append('| '+x['row']+' / '+x['resource_arm']+' / '+str(x['repetition'])+' | '+caller['path']+' / '+caller['file_sha256']+' | '+fields+' |')
(O/'actual-twelve-counterpart-map.md').write_text('\n'.join(md)+'\n')
print(json.dumps({'completed_cases':len(cases),'inventory_entries_verified':sum(x['inventory_entries_verified'] for x in comparisons),'expected_callers':len(table),'expected_outputs':sum(len(x['expected_seven_outputs']) for x in table),'full_original_NPY_locators_in_primary_map':len(table)*8,'map_sha256':h(O/'actual-twelve-counterpart-map.json'),'groups':groups}))
