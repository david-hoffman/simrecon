"""Author a NEW bounded added-nine analysis; prior W02 script is TEXT only."""
from pathlib import Path
O=Path('/workspace/work/campaign/evidence/114/actual-bound-method-review-preparation-1/reviewer1/prepared-counterpart-assessment-1')
s=(O/'W02-retained-counterpart-analysis.py').read_text()
s=s.replace('One-off exactly CLOSED W02 H2_PREPARED r1/r2/r3 retained-file analysis.','One-off exactly nine added CLOSED W02/W05 WIDER/H2_PREPARED retained-file cases.')
s=s.replace("NAMES=['N2-W02-H2_PREPARED-r1-attempt1','N2-W02-H2_PREPARED-r2-attempt1','N2-W02-H2_PREPARED-r3-attempt1']","SPECS=[(row,arm,rep,f'N2-{row}-{arm}-r{rep}-attempt1') for row in ['W02','W05'] for arm in ['WIDER','H2_PREPARED'] for rep in [1,2,3]]\nNAMES=[x[3] for x in SPECS]\nADDED=[x for x in SPECS if not(x[0]=='W02' and x[1]=='H2_PREPARED')]")
s=s.replace("P/'actual-W02-H2PREPARED-inputs.sha256'","P/'actual-both-prepared-wide-counterparts-inputs.sha256'")
s=s.replace("assert '/current-runs-2/N2-W02-H2_PREPARED-' in name or '/current-numerical-captures-2/N2-W02-H2_PREPARED-' in name","assert '/current-runs-2/N2-W' in name or '/current-numerical-captures-2/N2-W' in name")
s=s.replace('assert len(inputs)==627','assert len(inputs)==2496')
s=s.replace("qj,qa,qi,qd=retained_run(Q);inputs[str(Q/'run.json')]=h(Q/'run.json');qf=qj['result']['wider']\nassert h(Q/'run.json')=='e1a6c8b7682ee85c9a9a07a6304d0c69ea6205c3d1815acd9f7df3876bdd65e4'",'''qcontexts={};accepted={x['row']:x for x in load(OUT.parent/'current-sixQ-pair-assessment-1/row-eligibility.json')}
for row in ['W02','W05']:
 Q=B/'current-runs-2'/('Q2-'+row+'-QUALIFY-r1-'+('attempt2' if row=='W02' else 'attempt1'))
 qcontexts[row]=retained_run(Q);inputs[str(Q/'run.json')]=h(Q/'run.json');assert h(Q/'run.json')==accepted[row]['qualification_sha256']''')
s=s.replace("for REP,NAME in enumerate(NAMES,1):\n R=B/'current-runs-2'/NAME;K=B/'current-numerical-captures-2'/NAME;O=OUT/('W02-r'+str(REP));O.mkdir(exist_ok=False)","for ROW,ARM,REP,NAME in ADDED:\n Q=B/'current-runs-2'/('Q2-'+ROW+'-QUALIFY-r1-'+('attempt2' if ROW=='W02' else 'attempt1'));qj,qa,qi,qd=qcontexts[ROW];qf=qj['result']['wider']\n R=B/'current-runs-2'/NAME;K=B/'current-numerical-captures-2'/NAME;O=OUT/('added-'+ROW+'-'+ARM+'-r'+str(REP));O.mkdir(exist_ok=False)")
s=s.replace('assert len(aa)==188',"assert len(aa)==(188 if ARM=='H2_PREPARED' else 186)")
s=s.replace("j['row']=='W02' and j['strategy']=='H2_PREPARED'","j['row']==ROW and j['strategy']==ARM")
s=s.replace("['qualification_sha256']['W02']","['qualification_sha256'][ROW]")
start=s.index(" sourceq=aa[a['bands']['quadratures']['array']]")
end=s.index(' baseline_map=[]',start)
block=''' sourceq=aa[a['bands']['quadratures']['array']];candidateq=aa[c['bands']['quadratures']['array']];zerosign_mismatches=0
 if ARM=='H2_PREPARED':
  packed=aa['prepared.packed'];promoted=aa['prepared.promoted']
  assert packed[0]['shape']==sourceq[0]['shape']+[2] and packed[0]['canonical_dtype']=='<f2' and promoted[0]['canonical_dtype']==candidateq[0]['canonical_dtype']=='<c16'
  assert promoted[0]['shape']==candidateq[0]['shape']==sourceq[0]['shape']
  for i,value in enumerate(sourceq[2]):
   sign=sourceq[1][8*i+7]>>7;expected=halfword(value,sign);observed=int.from_bytes(packed[1][2*i:2*i+2],'little');assert observed==expected
   expected64=struct.pack('<d',struct.unpack('<e',packed[1][2*i:2*i+2])[0]);assert promoted[1][8*i:8*i+8]==expected64
   if value==0 and ((observed>>15)!=sign):zerosign_mismatches+=1
  assert zerosign_mismatches==0 and promoted[1]==candidateq[1]
 else:
  packed=None;promoted=candidateq;assert sourceq[1]==candidateq[1]
'''
s=s[:start]+block+s[end:]
s=s.replace("gg['runs']==[['W02','H2_PREPARED',REP]]","gg['runs']==[[ROW,ARM,REP]]")
s=s.replace("'row':'W02'","'row':ROW,'diagnostic_strategy':ARM")
s=s.replace('ident(packed)',"ident(packed) if packed else None")
s=s.replace('statistics(packed)',"statistics(packed) if packed else None")
s=s.replace("'all_half_words_RN_even_verified':len(sourceq[2])","'all_half_words_RN_even_verified':len(sourceq[2]) if packed else 0")
s=s.replace("m['source_reported']={k:recorded[k] for k in ['max_absolute','rms','relative_l2']};m['file_reference_minus_source']={k:m[k]-recorded[k] for k in ['max_absolute','rms','relative_l2']}","m['source_reported']={k:(struct.unpack('>d',bytes.fromhex(recorded[k]['float64_bits_be']))[0] if isinstance(recorded[k],dict) else recorded[k]) for k in ['max_absolute','rms','relative_l2']};m['file_reference_minus_source']={k:m[k]-m['source_reported'][k] for k in ['max_absolute','rms','relative_l2']}")
s=s.replace("'scope':'complete actual relative-to-wider prepared-half stage counterpart; metadata frozen wider by design; no independent fullgrid/upstream/nativeprecision/science approval or future child preacceptance'","'scope':'H2_PREPARED actually recomputes estimate/known on quantized q with frozen wider metadata; WIDER candidate is frozen baseline snapshot, not a separate prepared-stage execution. Complete relative-to-wider counterpart, no independent fullgrid/upstream/nativeprecision/science approval or future child preacceptance'")
s=s.replace("'W02-raw-read-ledger.json'","'added-raw-read-ledger.json'").replace("'W02-inputs-verified.sha256'","'added-inputs-verified.sha256'").replace("'W02-three-counterpart-results.json'","'added-nine-counterpart-results.json'").replace("'W02-repetition-specific-expected-outputs.json'","'added-nine-repetition-specific-expected-outputs.json'")
s=s.replace("{'rep':r['repetition'],'NPYs'","{'row':r['row'],'arm':r['diagnostic_strategy'],'rep':r['repetition'],'NPYs'")
(O/'added-nine-retained-counterpart-analysis.py').write_text(s)
print('NEW fixed nine-case retained-data analysis text authored; original W02 script/primary/outputs preserved.')
