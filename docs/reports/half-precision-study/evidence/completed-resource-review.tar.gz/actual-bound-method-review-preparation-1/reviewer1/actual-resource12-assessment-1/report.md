# Completed actual selected12 resource assessment

**All twelve actual resource observations support their finite, conditional own-counterpart interpretation. No blocking caller/output/statistic/branch/source/copy/readiness/wait-ownership/terminal/closure mismatch was found.** Every actual caller and all seven output shape/canonical-dtype/content identities match their OWN row/arm/repetition diagnostic reference; all independently checked numeric statistics agree. Three fresh completed method successes exist per W02/W05×PREPARED_WIDER/PREPARED_HALF, in the prescribed counterbalanced order.

This is an assessment of completed actual data, not a future grant or ROOT acceptance. Independent full-grid/upstream science, physical recovery, internal native arithmetic precision, optimized causal speed/RAM benefit,16GiB/full-workflow feasibility and any broad positive/negative conclusion remain UNRESOLVED/noactivation. No extra source/helper/capture/framework/control/tolerance/polynomial/preliminary gate or automatic retry is commissioned. Final SCI must be a DIFFERENT fresh independent session; ROOT retains all Current/integration/final-gate/SCI/D/publication authority.

## Scope, primary and evidence order

Own RAW primary resource12-raw-primary.md SHA256 `9d5f1f382d7a8531b177d1f7b8372bb7a8086aade36233266b29e98e097e1463` froze before any ROOT collection-summary or actual-counterpart-comparison BODY. Their initial hash reads were identity only. Commissioning complete/wholeclosed/window-ended facts were exposed, not outcome acceptance. This is the same independent reviewer, not a newly blind role. No other W/K/CPU run or live process was inspected.

Packet `68cb57fa56cd3fc62e6ee8a0cea2212b8ed542ce64240a8099d8fb3223ff1d5c` and canonical264-file ledger `0186f26fd5c2b6136ce232bda6cf04d15c6765fdda70b6d4ac5fceb6f964da45` identify exactly R2-W02/W05-PREPARED_WIDER/PREPARED_HALF-r1/r2/r3-attempt1 in current-runs-2/current-resource-captures-2. All264 hashes match. Own accepted diagnostic map `5e340a9a3268fb40307d47961738436903bd1adde7d59e1c18557cb6bad0d0aa` supplies expected data, not actual result proof. Its96 original expected caller/output NPYs were independently decoded/hashed for statistical expectations. Resource children retain recorded identities/statistics, **not resource output NPYs or complete metadata/trace**; no missing resource array file or live heap observation was fabricated.

Immutable current source246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635/candidatec43913c75446272c5fc9c63aeb007dd9644568d0/treed8810579d7b4a93d9bb2b1dd924b2ba0ebb5a350/directparentb4c600a4a8ee5a2b1645308a4a775dfe651bcb8d stays unchanged, distinct from accepted113/integration_base274c71912afba4f976f0b7ec248af6347c2addde. Manifestddf/obligationsd02/contract9367 and accepted default/public/method observer scopes remain applicable. This review does not repeat a SOURCE/retention gate or infer scientific/native precision from representation types.

## Actual identities, numeric statistics and branch correspondence

The independent raw audit checks **96 actual caller/output identities and1,638 numeric-statistic fields**, with ZERO mismatches. Each expected record is selected by exact row, resource arm and repetition, bound to its original diagnostic filename/full NPY SHA, content identity and current qualification. Half is compared with its actual H2_PREPARED continuation, wider with its actual wider-stage reference; half==wider is never required or assumed.

Every scalar-stat group checks original dtype/shape/payload/canonical identity/content SHA, minimum/maximum, nonfinite, negative, zeros/positive and negative zero, and binary16-subnormal counts. Complex arrays are independently checked as canonical real/imag component views. The actual packed-half caller zero/sign/subnormal counts and finite values agree with independently decoded counterpart bytes; no complex reconstruction normalizes signs. Every caller and output is finite and all branches are known×3. Actual output identities match the exact quantized image/modulation/raw-modulation reference as well as carrier/xyz. The previously observed W05 four nonzero image sign changes and quantization losses relative to wider remain part of that half reference, not hidden by the successful own-counterpart match.

Producer-recorded strides/aligned/own/writeable fields are preserved and type/shape-checked separately. They are not fresh live-heap/alias observations or a requirement to have the same allocation policy as a diagnostic snapshot. For example a concatenated resource image can be writable while a public full-workflow snapshot is readonly. Numeric equality and that deliberate lifecycle property are distinct. Ordinary SHA collision/qualified-observer assumptions remain explicit; there is no actual resource NPY byte comparison because those arrays are deliberately not exported.

All copied G bytes/hashes equal original G. Each source parent/child before/after material map agrees and contains exact B/C/G/copy bindings; Git is the clean exact current candidate. Fresh C/B/G/L bind one run/arm/rep, current qualification SHA, material/default/native/startup/interpreter and ROOT admission, with exact expanded parent/target argv. C raw observation fields match bound C; row/B/admission prose is distinguished.143M/7S/2N, Ubuntu24.04 family, CPython3.13.12/NumPy2.5.3/SciPy1.18.1, actual venv path/prefix/native module hashes, six threads1, worker1, locale '.', ordinary open0/1/2/default signals and coverage START/CONFIG cleared before Python agree with accepted material. Visible headroom exceeds modeled payload; unknown ancestors/workspaces/uncharged reserves remain conditional.

Actual prepared caller identity and seven outputs now substantiate the prior M01-raw/currentQ2/actual known-T1 scalar-seed/OptionA same-public-preparation/transfer/consumed-operation argument. They do not newly export an independent initial array, full standalone metadata/trace or original flags. WIDER diagnostic candidate was a frozen baseline snapshot; H2 recomputed downstream on quantized q with frozen wider metadata. Those limits remain intact. Finite half→complex128 promotion follows checked finite packed values and unchanged source conversion; the working unpacked intermediate is not separately hashed/exported here. The child loads no qualification receipt or reference workflow/arrays under the inspected source and actual flags; expected NPYs were read only by this reviewer after the window, never by the resource child.

## Exact owned lifecycle, native usage and closure

All parent statuses are observed-pending-independent-scientific-qualification, child statuses observed-pending-scientific-qualification; outer/parent returns0 and exact child terminal raw status0/exit0/signalNone. These are completed method observations, not independent scientific success labels. Source collect() is the sole exact-PID wait4 owner and caches terminal usage; no Popen child waiter, GNUtime wrapper, RSS sampler or observer sum is substituted. wait_ownership_lost/coordinator_recovery_required are false, with no signals, failure, cleanup/readiness/identity-drift flag.

Spawn intent binds actual parent birth/sys.argv and grant; expanded parent and direct-child argv agree with B. Owned child boot/PID/start matches child entry and reaped PID. Readiness is one newline-bounded<=4096-byte message with actual nonce/bootstrap digest/executable/parent PPID/child-own group/session, observed before10s startup bound. Early owned marker may share parent group/session before setsid; later readiness/entry has child session. This is the expected transition, not identity drift. FD reserve descriptors are distinct>=3; accepted unchanged ordinary bootstrap/source closes readiness before exec, redirects0/1/2, drains/closes tracked descriptors and archives bytes. Readiness itself is PREexec; actual bound child entry/material/result supplies postexec source evidence, not an independent live cmdline probe.

G bounds are deadline60s/startup10s/TERM grace2s/KILL-reap5s/readiness4096. No cleanup signal was required. Each raw target receipt binds attempt/child/streams and terminal; postclose stdout records exact original child and parent births absent, matching identities-to-close. Child and outer stdout/stderr are empty. Scope is these ordinary owned processes/streams, not all-host FD/process absence, arbitrary recovery, repeated interruption, atomic PID-reuse safety or engineered isolation. Nominal50ms sleep is not a response-time/reap-delay bound.

Every terminal is positive native LinuxKiB with exact×1024 conversion and≥pre_call/call_end/post_observation cumulative snapshots. Source post_observation is preJSON/teardown; terminal covers the observed direct child through death/JSON/teardown and excludes the external observer. Exec/bootstrap/inherited/descendant/namespace high-water limits remain; internal FFT arithmetic precision is unknown. No parent subtraction, sum, causal peak difference, process-tree/cgroup aggregate or stage-local allocation conclusion is drawn. This resource route is unwrapped wait4, distinct from prior GNUtime diagnostic capture.

## All twelve observations and fixed order

Actual C/L/outer times establish nonoverlapping starts in fixed§8A order: W02r1 wider/half,r2 half/wider,r3 wider/half, then W05 in the same order. This is counterbalancing, not randomization. All repetitions remain separately identified.

| Actual order: row/arm/rep | Native KiB | Exact terminal bytes | Reachable retained bytes | Call-only seconds |
|---|---:|---:|---:|---:|
| W02 wider1 |83,228|85,225,472|859,224|3.499587488|
| W02 half1 |83,624|85,630,976|893,784|3.240047609|
| W02 half2 |83,396|85,397,504|893,784|2.440417051|
| W02 wider2 |83,316|85,315,584|859,224|3.117395654|
| W02 wider3 |83,308|85,307,392|859,224|3.327501377|
| W02 half3 |83,480|85,483,520|893,784|3.135113773|
| W05 wider1 |85,920|87,982,080|3,053,144|7.773603177|
| W05 half1 |86,120|88,186,880|3,183,704|9.873679981|
| W05 half2 |86,160|88,227,840|3,183,704|7.686116151|
| W05 wider2 |86,044|88,109,056|3,053,144|8.979323786|
| W05 wider3 |85,980|88,043,520|3,053,144|10.289590758|
| W05 half3 |86,296|88,367,104|3,183,704|8.062996887|

| Row/arm | Median terminal bytes [minimum, maximum] | Median call-only s [minimum, maximum] | Median conversion+call s | Median setup→call END s |
|---|---|---|---:|---:|
| W02 wider |85,307,392 [85,225,472,85,315,584]|3.327501377 [3.117395654,3.499587488]|3.327528945|3.398015324|
| W02 half |85,483,520 [85,397,504,85,630,976]|3.135113773 [2.440417051,3.240047609]|3.135298314|3.200541831|
| W05 wider |88,043,520 [87,982,080,88,109,056]|8.979323786 [7.773603177,10.289590758]|8.979349649|9.068337222|
| W05 half |88,227,840 [88,186,880,88,367,104]|8.062996887 [7.686116151,9.873679981]|8.063123644|8.151881026|

Retained payload is constant across the three reps per arm:90 backing allocations for wider,91 for half. It is a qualified producer reachable-array observation, **not** whole native RSS; metadata/allocator overhead remainsNone. Half packed caller and required promoted work coexist under declared source lifetime. These four finite medians/ranges describe only these two selected tiny workloads/method/defaults. They do not demonstrate causal speed, optimized storage benefit, a general negative,16GiB fit or physical feasibility. No diagnostic full-reference retention/clock is used as a matched resource result.

## Clock and scientific interpretation limits

Recorded-endpoint intervals independently recompute: import, local-source-cold→setup, setup, optional setup-pack, call-only, conversion+call, setup→call END, local-source-cold→call end and source spawn→reap. **setup_to_call_seconds ends at call_end**, not call_start; it contains setup plus operation. Half setup pack is within setup; working promotion is before call_start and inside conversion+call. Wider pack endpoints/seconds areNone. pre_call/call_end/post_observation snapshot timestamps bracket these scopes correctly. Whole-child-until-JSON is a producer interval without serialized exact start/end pair; it is not independently recomputed as terminal/process birth. Local source cold excludes interpreter/earlier stdlib; spawn→reap adds bootstrap/monitoring/scheduling/poll delay; outer Docker timing is broader still. Output observers/JSON follow operation endpoints. No sampled maximum, clock subtraction, or interchangeable interval meaning is implied.

These exact actual records close the finite caller/output/statistic/known-branch/native-lifecycle correspondence required for conditional selected12 interpretation. Independent complete analytic trig/preparation/transfer/filter/fit/assembly reference and floating uncertainty remain unresolved as prior current6/counterpart assessment. Complete standalone trace/metadata/live-ownership is not directly exported by seven hashes. No claim upgrades representation into internal native-half arithmetic, physical recovery, optimized performance/large-workflow fit or broad impossibility. Any further scientific proposal must retain these exact limits and receive the later fresh final SCI.

## Attributed phase2 comparison and accounting

After raw primary freeze, all24 ROOT summary/counterpart-comparison bodies were whole-read and independently compared: ROOT actual/expected caller+seven+branches match own raw/map values; child/attempt/comparison hashes, statuses, terminal and exact postclose births agree. ZERO discrepancies. Their PASS labels did not decide the primary; the independent1,638-statistic check is additional evidence. No further gate or new controls are required by this completed scope.

Only isolated stdlib-I-S retained file/JSON/hash/NPY-header/component/clock arithmetic ran after ROOT’s exclusive window ended. No product/source/study-helper/native/NumPy/SciPy import/execution, AST/compile/eval/pickle, experiment/upstream/oracle/comparator/capture/framework/epochs/tolerance/guard change, live probe/signal/wait/reap/Docker/test/install/repair/delegation occurred. Shared prompt/filesystem restrictions are not engineered isolation. All original scope/primary/report/source/raw bytes, failed/historical attempts and costs remain unchanged. Human numerical quota NOT SET; serving/model/effort/tokens/cache/money/complete elapsed UNKNOWN. Completed report+DISTINCT final/disposition/read/input/output/account ledgers are the verdict; ROOT alone applies it and owns final integration/gates/SCI/D/publication.
