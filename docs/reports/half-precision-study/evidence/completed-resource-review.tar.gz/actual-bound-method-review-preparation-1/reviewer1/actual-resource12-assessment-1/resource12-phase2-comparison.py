"""One-off attributed ROOT comparisons only after own resource RAW primary froze."""
import hashlib,json
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');O=B/'actual-bound-method-review-preparation-1/reviewer1/actual-resource12-assessment-1'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
assert h(O/'resource12-raw-primary.md')=='9d5f1f382d7a8531b177d1f7b8372bb7a8086aade36233266b29e98e097e1463'
expected={(x['row'],x['resource_arm'],x['repetition']):x for x in load(O.parent/'prepared-counterpart-assessment-1/actual-twelve-counterpart-map.json')}
reads=[];results=[]
for a in load(O/'actual-twelve-resource-results.json'):
 K=B/'current-resource-captures-2'/a['run_id'];R=B/'current-runs-2'/a['run_id'];e=expected[(a['row'],a['resource_arm'],a['repetition'])]
 s=load(K/'ROOT-closed-collection-summary.json');c=load(K/'ROOT-actual-counterpart-identity-comparison.json')
 actual={'caller':a['caller_identity'],'outputs':{k:v['identity'] for k,v in a['seven_outputs'].items()},'branches':a['branches']}
 exp={'caller':e['expected_resource_caller']['identity'],'outputs':{k:v['identity'] for k,v in e['expected_seven_outputs'].items()},'branches':e['expected_branches']}
 assert c['actual']==actual and c['expected']==exp and c['child_record_sha256']==h(R/'child.json')
 assert c['all_expected_identities_equal'] is True and c['evaluated'] is True and c['native_collection_matched'] is True
 assert s['run_id']==a['run_id'] and s['attempt_sha256']==h(R/'attempt.json') and s['counterpart_identity_comparison_sha256']==h(K/'ROOT-actual-counterpart-identity-comparison.json')
 assert s['status']=='observed-pending-independent-scientific-qualification' and s['terminal']==a['native_terminal'] and s['postclose_identities']==a['postclose'] and s['material_git_grant_unchanged'] is True
 results.append({'run_id':a['run_id'],'ROOT_collection_and_counterpart_bodies_consistent':True,'scope':'attributed comparison after own96identity+1638statistic checks, not correctness authority'})
 for name in ['ROOT-closed-collection-summary.json','ROOT-actual-counterpart-identity-comparison.json']:reads.append({'path':str(K/name),'sha256':h(K/name),'phase':'phase2 BODY after independent resource RAW primary SHA freeze'})
(O/'phase2-comparison-results.json').write_text(json.dumps(results,indent=2)+'\n')
(O/'phase2-read-ledger.json').write_text(json.dumps(reads,indent=2)+'\n')
print(json.dumps({'completed_cases_compared':len(results),'ROOT_body_files':len(reads),'primary_unchanged':True,'discrepancies':0}))
