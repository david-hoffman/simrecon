"""One-off exact twelve CLOSED resources; retained files only, no target execution."""
import hashlib,itertools,json,math,re,statistics,struct
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');O=B/'actual-bound-method-review-preparation-1/reviewer1/actual-resource12-assessment-1';P=B/'actual-bound-method-review-preparation-1/actual-resource12-followup-1'
MAP=B/'actual-bound-method-review-preparation-1/reviewer1/prepared-counterpart-assessment-1/actual-twelve-counterpart-map.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def h(p):return sha(p.read_bytes())
def pairs(items):
 d={}
 for k,v in items:
  if k in d:raise ValueError('duplicate JSON key')
  d[k]=v
 return d
def bad(s):raise ValueError('nonstandard JSON '+s)
def load(p):return json.loads(p.read_bytes(),object_pairs_hook=pairs,parse_constant=bad)
assert h(MAP)=='5e340a9a3268fb40307d47961738436903bd1adde7d59e1c18557cb6bad0d0aa'
expected={(x['row'],x['resource_arm'],x['repetition']):x for x in load(MAP)}
ORDER=[(row,arm,rep) for row in ['W02','W05'] for rep in [1,2,3] for arm in (['PREPARED_HALF','PREPARED_WIDER'] if rep==2 else ['PREPARED_WIDER','PREPARED_HALF'])]
NAMES=[f'R2-{row}-{arm}-r{rep}-attempt1' for row,arm,rep in ORDER]
inputs={};reads=[]
for line in (P/'actual-resource12-inputs.sha256').read_text().splitlines():
 expectedsha,name=line.split('  ',1);p=Path(name);raw=p.read_bytes();assert p.parts[-2] in NAMES
 assert '/current-runs-2/R2-' in name or '/current-resource-captures-2/R2-' in name
 assert sha(raw)==expectedsha;inputs[name]=expectedsha
 defer=p.name in ['ROOT-closed-collection-summary.json','ROOT-actual-counterpart-identity-comparison.json']
 reads.append({'path':name,'sha256':expectedsha,'bytes':len(raw),'phase':'identity-hash-only-ROOT-body-deferred' if defer else 'own-raw-primary'})
 if p.suffix=='.json' and not defer:load(p)
assert len(inputs)==264
cache={};expectedreads=[]
def expected_array(meta):
 p=Path(meta['path'])
 if str(p) in cache:return cache[str(p)]
 raw=p.read_bytes();assert sha(raw)==meta['file_sha256'];assert raw[:6]==b'\x93NUMPY' and tuple(raw[6:8]) in [(1,0),(2,0)]
 n=2 if raw[6]==1 else 4;off=8+n;size=int.from_bytes(raw[8:off],'little');header=raw[off:off+size].decode('latin1')
 m=re.fullmatch(r"\{'descr': '([<|][fc][0-9]+)', 'fortran_order': (True|False), 'shape': \(([0-9, ]*)\), \}[ \n]*",header);assert m,header
 dtype,fort,dims=m.groups();shape=[int(x.strip()) for x in dims.split(',') if x.strip()];kind=dtype[1];width=int(dtype[2:]);data=raw[off+size:];assert len(data)==math.prod(shape)*width
 assert dtype==meta['canonical_dtype'] and shape==meta['shape']
 if fort=='True':
  strides=[];q=1
  for dim in shape:strides.append(q);q*=dim
  data=b''.join(data[sum(i*t for i,t in zip(ix,strides))*width:sum(i*t for i,t in zip(ix,strides))*width+width] for ix in itertools.product(*(range(x) for x in shape)))
 assert sha(data)==meta['content_sha256'];cw=width//2 if kind=='c' else width
 code={2:'e',4:'f',8:'d'}[cw];vals=[v[0] for v in struct.iter_unpack('<'+code,data)];assert all(math.isfinite(v) for v in vals)
 result=(meta,data,vals,cw,kind);cache[str(p)]=result;inputs[str(p)]=sha(raw);expectedreads.append({'path':str(p),'sha256':sha(raw),'phase':'OWN previously accepted expected counterpart context NPY decode; resource has no output NPY'})
 return result
def wirefloat(x):
 if isinstance(x,dict) and set(x)=={'float64_bits_be'}:return struct.unpack('>d',bytes.fromhex(x['float64_bits_be']))[0]
 return x
statchecks=[];identitychecks=[];layout=[];issues=[]
def scalarstats(actual,data,dtype,shape,where,expectedmeta):
 cw=int(dtype[2:]);code={2:'e',4:'f',8:'d'}[cw];vals=[v[0] for v in struct.iter_unpack('<'+code,data)]
 exp={'dtype':dtype,'shape':shape,'payload_bytes':len(data),'sha256':sha(data),'canonical_identity':{'shape':shape,'canonical_dtype':dtype,'content_sha256':sha(data)},'minimum':min(vals),'maximum':max(vals),'nonfinite':0,'negative':sum(x<0 for x in vals),'zeros':sum(x==0 for x in vals),'negative_zeros':sum(x==0 and bool(data[i*cw+cw-1]&128) for i,x in enumerate(vals)),'positive_zeros':sum(x==0 and not bool(data[i*cw+cw-1]&128) for i,x in enumerate(vals)),'binary16_subnormal_range':sum(0<abs(x)<2**-14 for x in vals)}
 assert set(actual)==set(exp)|{'strides','aligned','own','writeable'}
 for k,v in exp.items():
  av=actual[k];ok=type(wirefloat(av)) is float and struct.pack('>d',wirefloat(av))==struct.pack('>d',v) if type(v) is float else av==v
  statchecks.append({'actual_path':where+'.'+k,'expected_NPY':expectedmeta['path'],'expected_file_sha256':expectedmeta['file_sha256'],'expected':v,'actual':av,'outcome':'EXACT' if ok else 'MISMATCH'})
  if not ok:issues.append(statchecks[-1])
 assert all(type(actual[k]) is bool for k in ['aligned','own','writeable']) and len(actual['strides'])==len(shape) and all(type(x) is int and x>=0 for x in actual['strides'])
 layout.append({'actual_path':where,'strides':actual['strides'],'aligned':actual['aligned'],'own':actual['own'],'writeable':actual['writeable'],'scope':'producer-recorded actual layout/ownership, not directly observed heap or required to equal frozen diagnostic allocation'})
def check(actualidentity,actualstats,meta,where):
 aa=expected_array(meta);eid={k:meta[k] for k in ['shape','canonical_dtype','content_sha256']};ok=actualidentity==eid
 identitychecks.append({'actual_path':where,'actual_identity':actualidentity,'expected_identity':eid,'expected_NPY':meta['path'],'expected_file_sha256':meta['file_sha256'],'outcome':'EXACT' if ok else 'MISMATCH'})
 if not ok:issues.append(identitychecks[-1])
 if aa[4]=='c':
  assert set(actualstats)=={'real','imag'}
  for component,i in [('real',0),('imag',1)]:
   data=b''.join(aa[1][q*16+i*8:q*16+i*8+8] for q in range(len(aa[2])//2));scalarstats(actualstats[component],data,'<f8',meta['shape'],where+'.statistics.'+component,meta)
 else:scalarstats(actualstats,aa[1],meta['canonical_dtype'],meta['shape'],where+'.statistics',meta)
results=[]
for INDEX,(ROW,ARM,REP) in enumerate(ORDER,1):
 NAME=f'R2-{ROW}-{ARM}-r{REP}-attempt1';R=B/'current-runs-2'/NAME;K=B/'current-resource-captures-2'/NAME;e=expected[(ROW,ARM,REP)]
 a=load(R/'attempt.json');c=load(R/'child.json');b,ctx,g,l,t=[load(K/x) for x in ['binding.json','context.json','grant.json','launch.json','ROOT-target-terminal.json']];bound=b['bindings'];bs,cs,gs=[h(K/x) for x in ['binding.json','context.json','grant.json']]
 assert a['status']=='observed-pending-independent-scientific-qualification' and c['status']=='observed-pending-scientific-qualification' and c['row']==a['row']==ROW and c['strategy']==a['strategy']==ARM and c['repetition']==a['repetition']==REP
 assert a['run_id']==g['run_id']==l['run_id']==NAME and g['runs']==[[ROW,ARM,REP]] and g['route']=='resource' and 'method_control' not in g
 assert g['qualification_sha256'][ROW]==e['qualification_sha256'] and e['source_sha256']==g['harness_sha256']=='246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635'
 assert bound['candidate']['commit']=='c43913c75446272c5fc9c63aeb007dd9644568d0' and bound['candidate']['tree']=='d8810579d7b4a93d9bb2b1dd924b2ba0ebb5a350' and bound['candidate']['parent']==bound['parent']=='b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d'
 assert bound['candidate']['tracked_status']=='clean' and bound['accepted113']['commit']==bound['integration_base']=='274c71912afba4f976f0b7ec248af6347c2addde'
 assert g['bindings']==bound and a['grant']==g and a['grant_sha256']==c['grant_sha256_after']==gs and (R/'grant.original.json').read_bytes()==(K/'grant.json').read_bytes()
 assert g['binding_receipt']=={'path':str(K/'binding.json'),'sha256':bs} and g['context']=={'path':str(K/'context.json'),'sha256':cs}
 assert l['Bsha']==ctx['binding_sha256']==bs and l['Csha']==cs and l['Gsha']==gs and l['runtime_released'] and l['source_output_absent']
 assert ctx['time_unix_ns']<=l['time_unix_ns']<=t['start_unix_ns']<t['finish_unix_ns']
 assert ctx['materials_unchanged']==143 and ctx['startup_files_unchanged']==7 and ctx['native_files_unchanged']==2 and not any(ctx['coverage_keys_present'].values()) and set(ctx['threads'].values())=={'1'}
 assert ctx['sigchld_default'] and ctx['sigint_default'] and ctx['locale_decimal_point']=='.' and all(ctx['fds'][str(i)]['open'] for i in range(3)) and ctx['current_visible_cgroup_headroom_bytes']>ctx['modeled_payload_bytes']>0
 assert g['resource_admission']['accepted'] is True and g['resource_admission']['evidence_sha256']==cs and g['resource_admission']['rationale']
 rawctx=load(K/'C.stdout');assert all(ctx[k]==v for k,v in rawctx.items() if k not in ['scope','admission_rationale'])
 for name in ['deadline_seconds','startup_seconds','term_grace_seconds','kill_reap_seconds']:assert type(g[name]) in [int,float] and math.isfinite(g[name]) and g[name]>0
 assert [g[k] for k in ['deadline_seconds','startup_seconds','term_grace_seconds','kill_reap_seconds','readiness_bytes']]==[60.0,10.0,2.0,5.0,4096]
 expand=lambda v:[bs if x=='$ROOT_BINDING_SHA256' else x for x in v]
 assert l['inner_argv']==expand(bound['parent_argv_shape']) and a['launch']['target_argv']==expand(bound['target_argv_shape'])
 outer=l['outer_argv'];pos=outer.index('/usr/bin/env');assert outer[pos:pos+5]==['/usr/bin/env','-u','COVERAGE_PROCESS_START','-u','COVERAGE_PROCESS_CONFIG'] and outer[pos+5:]==l['inner_argv'] and '/usr/bin/time' not in outer
 assert a['materials_before']==a['materials_after']==c['materials_before']==c['materials_after']
 for path,digest in [(K/'binding.json',bs),(K/'context.json',cs),(K/'grant.json',gs),(R/'grant.original.json',gs)]:assert a['materials_before'][str(path)]==digest
 assert c['material_identity_matches'] is True and a['git_before']==a['git_after'] and all(a['git_before'][k]==bound['candidate'][k] for k in a['git_before'])
 assert not a['wait_ownership_lost'] and not a['coordinator_recovery_required'] and not any(k in a for k in ['signals','failure','cleanup_failure','readiness_failure','identity_changed','identity_observation_failure'])
 assert a['parent_samples'] is None and c['qualification_receipt_loaded'] is False and c['reference_workflow_loaded'] is False and c['finite_outputs'] is True and c['branches']==e['expected_branches']==[['known']*3]
 owned=load(R/'owned-child.json');intent=load(R/'spawn-intent.json');assert owned==a['owned_child'] and intent['parent']==a['parent_identity'] and intent['argv']==l['inner_argv'][1:] and intent['grant_sha256']==gs
 assert all(c['identity'][k]==owned[k] for k in ['pid','boot_id','start_ticks']) and c['pid']==owned['pid'] and owned['boot_id']==a['parent_identity']['boot_id']
 readyraw=(R/'startup-readiness.bin').read_bytes();ready=json.loads(readyraw);bootstrap=a['launch']['bootstrap_argv'];fd=a['launch']['fd_plan']
 assert len(set(fd.values()))==3 and min(fd.values())>=3 and bootstrap[3]==str(fd['destination']) and bootstrap[6]==str(g['readiness_bytes']) and json.loads(bootstrap[5])==a['launch']['target_argv']
 assert sha(bootstrap[2].encode())==a['launch']['bootstrap_sha256']==bound['bootstrap_sha256'] and readyraw.count(b'\n')==1 and readyraw.endswith(b'\n') and len(readyraw)<=g['readiness_bytes']
 assert ready==a['readiness']==dict(pid=owned['pid'],ppid=a['parent_identity']['pid'],process_group=owned['pid'],session=owned['pid'],nonce=bootstrap[4],executable=bound['interpreter']['resolved'])
 assert a['readiness_observed_monotonic']*1e9<a['spawn_call_start_ns']+g['startup_seconds']*1e9
 assert c['identity']['process_group']==c['identity']['session']==owned['pid']
 terminal=a['terminal'];assert terminal is not None and terminal['pid']==owned['pid'] and terminal['raw_wait_status']==terminal['exit_code']==0 and terminal['signal'] is None
 assert terminal['native_units']=='Linux KiB' and terminal['multiplier_to_bytes']==1024 and terminal['terminal_child_peak_bytes']==terminal['native_ru_maxrss']*1024 and terminal['native_ru_maxrss']>0
 assert a['child_record_sha256']==h(R/'child.json') and t['attempt_sha256']==h(R/'attempt.json') and t['terminal']==terminal and t['returncode']==0 and t['status']==a['status']
 assert t['stdout_sha256']==h(K/'stdout.txt') and t['stderr_sha256']==h(K/'stderr.txt') and (K/'stdout.txt').read_bytes()==(K/'stderr.txt').read_bytes()==b''
 assert (R/'child.stdout').read_bytes()==(R/'child.stderr').read_bytes()==b'' and len((R/'child.json').read_bytes())<4*1024*1024
 close=load(K/'postclose.stdout');toclose=load(K/'identities-to-close.json');assert toclose=={'child':owned,'parent':a['parent_identity']}
 for role,identity in [('child',owned),('parent',a['parent_identity'])]:assert close[role]=={'pid':identity['pid'],'old_start':identity['start_ticks'],'original_identity_absent':True}
 assert (K/'postclose.stderr').read_bytes()==(K/'C.stderr').read_bytes()==b''
 assert set(c['outputs'])==set(e['expected_seven_outputs']) and c['entry']=='prepared-band public estimation + per-time known reconstruction'
 check(c['caller'],c['caller_stats'],e['expected_resource_caller']['original_NPY'],NAME+'.caller')
 for field,expect in e['expected_seven_outputs'].items():check(c['outputs'][field]['identity'],c['outputs'][field]['statistics'],expect['NPY'],NAME+'.outputs.'+field)
 assert c['environment']['internal_fft_arithmetic_precision']=='unknown' and c['environment']['scipy_fft_workers_during_call']==1 and set(c['environment']['threads'].values())=={'1'}
 for module,m in bound['native'].items():assert c['required_fft_after_call'][module]['sha256']==c['environment']['loaded_fft_binary_modules'][module]['sha256']==m['sha256']
 times=c;assert times['local_cold_start_ns']<=times['entry_start_ns']<times['numerical_import_start_ns']<=times['numerical_import_end_ns']<=times['setup_start_ns']<=times['setup_end_ns']<=times['conversion_start_ns']<=times['call_start_ns']<=times['call_end_ns']
 durations={'numerical_import_seconds':('numerical_import_start_ns','numerical_import_end_ns'),'cold_to_setup_start_seconds':('local_cold_start_ns','setup_start_ns'),'setup_seconds':('setup_start_ns','setup_end_ns'),'setup_to_call_seconds':('setup_start_ns','call_end_ns'),'local_cold_to_call_end_seconds':('local_cold_start_ns','call_end_ns'),'call_only_seconds':('call_start_ns','call_end_ns'),'conversion_and_call_seconds':('conversion_start_ns','call_end_ns')}
 for seconds,(start,end) in durations.items():assert c[seconds]==(c[end]-c[start])/1e9
 if ARM=='PREPARED_HALF':assert times['setup_start_ns']<=times['setup_pack_start_ns']<=times['setup_pack_end_ns']<=times['setup_end_ns'] and c['setup_pack_seconds']==(c['setup_pack_end_ns']-c['setup_pack_start_ns'])/1e9
 else:assert times['setup_pack_start_ns'] is times['setup_pack_end_ns'] is c['setup_pack_seconds'] is None
 assert c['whole_child_until_json_seconds']>0 and math.isfinite(c['whole_child_until_json_seconds'])
 snaps=c['snapshots'];assert list(snaps)==['pre_call','call_end','post_observation']
 assert times['setup_end_ns']<=snaps['pre_call']['monotonic_ns']<=times['conversion_start_ns'] and times['call_end_ns']<=snaps['call_end']['monotonic_ns']<=snaps['post_observation']['monotonic_ns']<=terminal['reaped_monotonic_ns']
 for snap in snaps.values():assert snap['native_units']=='Linux KiB' and snap['multiplier_to_bytes']==1024 and snap['bytes']==snap['native_ru_maxrss']*1024
 assert terminal['native_ru_maxrss']>=snaps['post_observation']['native_ru_maxrss']>=snaps['call_end']['native_ru_maxrss']>=snaps['pre_call']['native_ru_maxrss']
 assert a['spawn_to_terminal_observed_seconds']==(terminal['reaped_monotonic_ns']-a['spawn_call_start_ns'])/1e9
 payload=c['retained_payload'];assert type(payload['unique_array_backings']) is int and payload['unique_array_backings']>0 and payload['reachable_array_payload_bytes']>0 and payload['python_metadata_and_allocator_overhead_bytes'] is None
 results.append({'index_expected_order':INDEX,'row':ROW,'resource_arm':ARM,'repetition':REP,'run_id':NAME,'Bsha':bs,'Csha':cs,'Gsha':gs,'qualification_sha256':g['qualification_sha256'][ROW],'counterpart_run':e['diagnostic_run_id'],'counterpart_run_sha256':e['diagnostic_run_sha256'],'caller_identity':c['caller'],'seven_outputs':c['outputs'],'branches':c['branches'],'parent_identity':a['parent_identity'],'owned_child':owned,'post_exec_child_identity':c['identity'],'readiness':ready,'FD_plan':fd,'postclose':close,'native_terminal':terminal,'source_snapshots':snaps,'retained_payload':payload,'clock_seconds':{k:c[k] for k in list(durations)+['setup_pack_seconds','whole_child_until_json_seconds']},'unpack_window_seconds':(c['call_start_ns']-c['conversion_start_ns'])/1e9,'spawn_to_reap_seconds':a['spawn_to_terminal_observed_seconds'],'largest_observed_poll_gap_seconds':a['largest_observed_poll_gap_ns']/1e9,'bounds':{k:g[k] for k in ['deadline_seconds','startup_seconds','term_grace_seconds','kill_reap_seconds','readiness_bytes']},'outer_start_unix_ns':t['start_unix_ns'],'outer_finish_unix_ns':t['finish_unix_ns'],'L_time_unix_ns':l['time_unix_ns'],'warnings':c['warnings'],'scope':'recorded actual caller/outputs/statistics against expected counterpart bytes; no fabricated resource NPY/fullmetadata/trace or independent fullgrid science'})
actualorder=sorted(results,key=lambda x:x['outer_start_unix_ns']);assert [x['run_id'] for x in actualorder]==NAMES
assert all(actualorder[i]['outer_finish_unix_ns']<=actualorder[i+1]['outer_start_unix_ns'] for i in range(11))
summaries=[]
for row in ['W02','W05']:
 for arm in ['PREPARED_WIDER','PREPARED_HALF']:
  group=[x for x in results if x['row']==row and x['resource_arm']==arm];measures={'terminal_child_peak_bytes':[x['native_terminal']['terminal_child_peak_bytes'] for x in group],'retained_payload_bytes':[x['retained_payload']['reachable_array_payload_bytes'] for x in group],'unique_array_backings':[x['retained_payload']['unique_array_backings'] for x in group],'call_only_seconds':[x['clock_seconds']['call_only_seconds'] for x in group],'conversion_and_call_seconds':[x['clock_seconds']['conversion_and_call_seconds'] for x in group],'setup_to_call_END_seconds':[x['clock_seconds']['setup_to_call_seconds'] for x in group],'setup_seconds':[x['clock_seconds']['setup_seconds'] for x in group],'spawn_to_reap_seconds':[x['spawn_to_reap_seconds'] for x in group]}
  summaries.append({'row':row,'resource_arm':arm,'repetitions':[x['repetition'] for x in group],'three_successes':True,'measures':{k:{'values':v,'median':statistics.median(v),'minimum':min(v),'maximum':max(v)} for k,v in measures.items()},'scope':'finite descriptive medians/ranges only, no causal speed/RAM/fit/global negative/native precision/science conclusion'})
for filename,value in [('raw-read-ledger.json',reads),('expected-context-read-ledger.json',expectedreads),('actual-twelve-resource-results.json',results),('caller-and-seven-identity-comparisons.json',identitychecks),('all-numeric-statistics-comparisons.json',statchecks),('producer-layout-and-ownership-records.json',layout),('actual-counterpart-mismatches.json',issues),('actual-order.json',[x['run_id'] for x in actualorder]),('three-repetition-medians-and-ranges.json',summaries)]:
 (O/filename).write_text(json.dumps(value,indent=2)+'\n')
(O/'raw-and-expected-inputs-verified.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(inputs.items())))
print(json.dumps({'resource_cases':len(results),'provided_raw_files':264,'expected_NPY_context_files':len(cache),'caller_plus_seven_identities':len(identitychecks),'numeric_statistic_checks':len(statchecks),'mismatches':len(issues),'order_verified':True,'medians':[{'row':x['row'],'arm':x['resource_arm'],'peak_B':x['measures']['terminal_child_peak_bytes']['median'],'retained_B':x['measures']['retained_payload_bytes']['median'],'call_s':x['measures']['call_only_seconds']['median']} for x in summaries]}))
