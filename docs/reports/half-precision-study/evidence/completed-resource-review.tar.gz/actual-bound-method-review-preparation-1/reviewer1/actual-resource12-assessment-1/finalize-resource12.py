"""One-off completed resource12 handoff input/read/account/output bookkeeping."""
import hashlib,json
from pathlib import Path
B=Path('/workspace/work/campaign/evidence/114');O=B/'actual-bound-method-review-preparation-1/reviewer1/actual-resource12-assessment-1';P=B/'actual-bound-method-review-preparation-1/actual-resource12-followup-1';E=O.parent/'prepared-counterpart-assessment-1'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def write(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
primary=O/'resource12-raw-primary.md';assert h(primary)=='9d5f1f382d7a8531b177d1f7b8372bb7a8086aade36233266b29e98e097e1463'
rows=load(O/'actual-twelve-resource-results.json');assert len(rows)==12 and load(O/'actual-counterpart-mismatches.json')==[]
inputs={}
for line in (O/'raw-and-expected-inputs-verified.sha256').read_text().splitlines():
 expected,name=line.split('  ',1);assert h(Path(name))==expected;inputs[name]=expected
extra=[P/'reviewer-packet-1.md',P/'actual-resource12-inputs.sha256',E/'actual-twelve-counterpart-map.json',E/'report.md',E/'disposition.json',O.parent/'current-sixQ-pair-assessment-1/report.md',O.parent/'M01-actual-assessment-1/report.md',O.parent/'negative-controls-actual-assessment-1/report.md',B/'W02-direct-preparation-type-correction-1/author/study.py',B/'actual-bound-metadata-preparation-1/author/manifest.md',B/'actual-bound-metadata-preparation-1/author/qualification-obligations.md',Path('/workspace/work/issue-114/docs/contracts/half-precision-feasibility-v1.md')]
for p in extra:inputs[str(p)]=h(p)
assert h(E/'actual-twelve-counterpart-map.json')=='5e340a9a3268fb40307d47961738436903bd1adde7d59e1c18557cb6bad0d0aa'
assert h(B/'W02-direct-preparation-type-correction-1/author/study.py')=='246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635'
(O/'inputs.sha256').write_text(''.join(v+'  '+k+'\n' for k,v in sorted(inputs.items())))
write('read-ledger.json',{'ordering':'raw264+own accepted expected NPY context96 and source/public method applicability -> own resource RAW primary SHA freeze ->24 ROOT summary/comparison bodies as attributed targets',
 'raw':load(O/'raw-read-ledger.json'),'expected_NPY_context':load(O/'expected-context-read-ledger.json'),'phase2':load(O/'phase2-read-ledger.json'),
 'additional':[{'path':str(p),'sha256':h(p),'scope':'packet/pinned inert method/accepted own expected context; prior accepted proof reused from same-reviewer history, no target execution'} for p in extra],
 'limits':'Resource has no actual output NPY/fullmetadata/trace/liveheap observation; expected original NPYs decoded only by reviewer after exclusive window; ROOT opinions not read before primary. Shared workspace is not engineered isolation.'})
write('disposition.json',{'completed':True,'same_reviewer':True,'raw_primary_sha256':h(primary),'source_sha256':'246829749f356344fcd8e363e359039984da1911ee20b74a45637a6ff3226635','candidate':'c43913c75446272c5fc9c63aeb007dd9644568d0','tree':'d8810579d7b4a93d9bb2b1dd924b2ba0ebb5a350','direct_parent':'b4c600a4a8ee5a2b1645308a4a775dfe651bcb8d','accepted113_integration_base':'274c71912afba4f976f0b7ec248af6347c2addde',
 'verdict':'SUPPORTED_ACTUAL_FINITE_CONDITIONAL_SELECTED12_RESOURCE_CORRESPONDENCE_AND_OWNED_NATIVE_LIFECYCLE',
 'actual_attempts':12,'three_fresh_method_successes_each_row_arm':True,'provided_raw_files':264,'expected_counterpart_NPY_context_files':96,'actual_caller_plus_seven_identity_checks':96,'numeric_statistic_checks':1638,'mismatches':0,
 'actual_order':'fixed§8A W02r1wider/half,r2half/wider,r3wider/half then W05same, nonoverlapping recorded launches','sole_wait4_terminal_and_named_closure':'SUPPORTED_SCOPED_ALL12','original_G_copies_material_identity':'MATCH_ALL12',
 'layout_flags':'producer records retained/type-checked; not fresh liveheap proof or forced diagnostic-allocation equality',
 'clock_limit':'setup_to_call_seconds ends at call_end; whole_child_until_json has no serialized exact start/end; native terminal distinct from preJSON snapshots, local clocks and retained payload',
 'retained_native_wall_summary':'three-repetition-medians-and-ranges.json; finite descriptive values, no causal ratio/benefit/global negative/16GiB fit',
 'full_standalone_metadata_trace_and_unpacked_working_array_directly_exported':False,
 'independent_fullgrid_upstream_physical_nativeprecision_optimized_resource_benefit':'UNRESOLVED_NOACTIVATION',
 'blocking_issue_or_new_source_helper_controls_capture_framework_tolerance_polynomial_gate_required':False,'future_runtime_retry_global149_SCI_D_publication_grant':False,'ROOT_acceptance':False,'final_SCI':'DIFFERENT fresh independent session on completed exact whole-study evidence'})
commands=[]
for name,scope in [('resource12-retained-analysis.py','exact264 raw files,96 expected NPY contexts,96 identities+1638 statistics, nativewait4/clocks/order/medians retained-file arithmetic'),('resource12-phase2-comparison.py','post-primary24 attributed ROOT body comparisons'),('finalize-resource12.py','completed input/read/disposition/account/final/output bookkeeping')]:
 commands.append({'argv':['python3','-I','-S',str(O/name)],'code_sha256':h(O/name),'exit_code':0,'scope':scope})
commands.append({'argv':['python3','-I','-S',str(O/'finalize-resource12.py')],'code_snapshot':'finalize-resource12-failed-pass1.py.txt','code_sha256':h(O/'finalize-resource12-failed-pass1.py.txt'),'exit_code':1,'scope':'initial output-bookkeeping SyntaxError before writer body ran; preserved, corrected without changing raw/source/assessment'})
write('accounting.json',{'same_reviewer':True,'delegation':False,'completed_actual_selected_resource_attempts':12,'rows':['W02','W05'],'arms':['PREPARED_WIDER','PREPARED_HALF'],'repetitions_per_row_arm':3,'all_inputs':len(inputs),'command_identities':commands,
 'additional_inline_data_read':'Exact python3 -I -S - schema/value projections and supplemental raw environment/version/manifest checks, plus ordinary cat/hash reads, are preserved in tool transcript. Supplemental results are supplemental-raw-environment-checks.json; no target/native numerical operation was performed.',
 'authorized_operations_actually_performed':'isolated stdlib retained-file JSON/hash/NPY/header/IEEE/statistic/clock/order/median arithmetic, unlike earlier static-only clarification scopes',
 'not_performed':['product/source/study-helper/native/NumPy/SciPy import/execution','AST/compile/eval/pickle','new experiments/polynomial/oracle/upstream/comparator/capture/framework/epochs/tolerance/guard changes','live process probe/signal/wait/reap','Docker/tests/install/repair/source changes','new role/delegation','automatic retry'],
 'actual_resource_data_limit':'recorded identities/statistics under qualified unchanged observer and own-counterpart original-byte expectation; no fabricated actual resource NPY/trace/fullmetadata/live heap',
 'exclusive_window':'all12 closed and ROOT window ended before reads; no new runtime release',
 'artifact_preservation':'writes ONLY NEW reviewer1/actual-resource12-assessment-1; all prior primaries/reports/code/raw/source/failed/historical artifacts and costs unchanged',
 'actual_serving_model':'UNKNOWN','actual_effort':'UNKNOWN','actual_tokens':'UNKNOWN','actual_cache':'UNKNOWN','actual_money':'UNKNOWN','complete_elapsed':'UNKNOWN','human_numerical_quota':'NOT SET'})
reportsha=h(O/'report.md');summarysha=h(O/'three-repetition-medians-and-ranges.json')
final=('COMPLETED actual selected12 resource assessment. All twelve actual callers/seven outputs match their OWN row/arm/repetition counterpart;96 identity and1,638 numeric-statistic checks pass with zero mismatches. Three fresh completed method successes per row/arm, exact fixed order, Gcopy/material/admission/readiness/solewait4/native units/clocks/named closure supported.\n\n'
 'Finite conditional correspondence and descriptive retained/native/wall medians/ranges are supported. These do not establish independent fullgrid/upstream science, physical/native precision, causal optimized speed/RAM,16GiBfit or any broad negative. Full standalone metadata/trace/unpacked work is not newly exported. Science/activation remains UNRESOLVED. No extra source/helper/capture/framework/control/tolerance/polynomial/gate or future runtime/retry/global149/SCI/D/publication grant; this is not ROOT acceptance.\n\n'
 'Report SHA256: '+reportsha+'\nFrozen raw-primary SHA256: '+h(primary)+'\nDisposition SHA256: '+h(O/'disposition.json')+'\nMedians/ranges SHA256: '+summarysha+'\nInputs ledger SHA256: '+h(O/'inputs.sha256')+'\n\n'
 'Detailed report.md, actual-twelve-resource-results.json, caller-and-seven-identity-comparisons.json, all-numeric-statistics-comparisons.json, three-repetition-medians-and-ranges.json, disposition/read/input/account/output ledgers and this DISTINCT final form the completed handoff. All history/costs preserved; human numerical quota NOT SET, serving/meters/money/complete elapsed UNKNOWN. Final SCI DIFFERENT fresh independent session.\n')
(O/'final-message.md').write_text(final)
outputs=sorted(p for p in O.iterdir() if p.is_file() and p.name!='outputs.sha256')
(O/'outputs.sha256').write_text(''.join(h(p)+'  '+str(p)+'\n' for p in outputs))
print(json.dumps({'completed':True,'inputs':len(inputs),'outputs_pinned':len(outputs),'report_sha256':reportsha,'final_sha256':h(O/'final-message.md'),'disposition_sha256':h(O/'disposition.json'),'medians_sha256':summarysha,'outputs_sha256':h(O/'outputs.sha256')}))
