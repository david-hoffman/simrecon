# Bounded infrastructure owner handoff — five-minute attempt

Three authorized source files changed. No commit, push, PR action or merge performed. Root owns the sole Current state, exact-candidate full verification, cumulative campaign accounting and fresh independent review. This is an author handoff, not independent acceptance or a300 s full-gate result.

## Changes and preservation

- `tests/verification_fixture_dispatch.py::install_dispatch`: only the evidence-profile generated fake-uv stages installed ruff/Pyright/Coverage/pytest metadata strings at installation. Only exact four-argument `run --locked TOOL --version` calls take the shell path. Actual argv, measurement/evidence call records, status and emitted bytes remain observed. Unexpected shapes retain the qualified Python fallback. Controlled sync never modifies installed distributions; phase decisions remain in the real verifier. Native report/render/combine APIs, dynamic measurements, late alias/actions and source-free execution stay live.
- `src/simrecon/_pytest_policy.py::PARALLEL_GROUPS`: adds six explicit independent whole-file groups with the `infrastructure-test_` prefix: evidence outputs, receipt, measurements export, output protection, external native evidence and source-free checks. Existing science groups, reader/cache-affine serial-rest membership and unknown/new-file fallback remain. No hook outcome, worker flag/count, restart, discovery, coverage setting, gate, Makefile, dependency or lock change.
- `tests/test_parallel_runner.py`: independent expected six-file list joins its synthetic actual-public-runner proof. Exact node/call multiset, parameter text containing `@`, per-file order, both worker collection identities, serial behavior and unclassified/new-file controls remain. No original declaration, parameter row, assertion or keeper was removed. All original310 declarations/949 owned cases remain under the existing ledgers; this batch changes no scientific/neutral oracles or product numerical/binary behavior. The33,554,432-byte M25 limit and actual same-run canonical obligation remain untouched.

Frozen source SHA-256 values through the passing owner proof:

| File | SHA-256 |
| --- | --- |
| src/simrecon/_pytest_policy.py | e6020070dfa975fde048abcf3784e1845c9baac9d00a2d3ab0d0b6622dae3bdf |
| tests/test_parallel_runner.py | bb6bdbbb0078ad3b84e49f7a588e4432c5c9680d66fadcbe030ea1d1329c91f5 |
| tests/verification_fixture_dispatch.py | 066c78498751467b37d9492b2c4d25eb326f47a85be781e138f8bc5f86cc973e |

Launch baseline was HEAD6876e9ea3bd7ffb1feb46c5aec66667646de76cf/tree8f6949aa4a0a2705a9b91303cec255e6a60a8128. Owner proofs were run on the in-progress dirty author candidate with those exact frozen source bytes; they do not replace a clean exact-candidate canonical gate. Root's task-pointer edit was observed and not edited here. Complete relevant source/test/support/Make/pyproject/lock input snapshots stayed equal before/after the passing341 run.

## Valid checks and qualification

Ruff lint/format and diff checks passed for all three changed files. Canonical activated locked-uv Pyright outside the sandbox passed0 errors/warnings/informations for all three. Current six-suite collection confirmed341 cases. Runner, omission and native-combine keepers passed11 cases in8.63 s.

Before permanent map edits, the generated runtime-only map qualifier passed9 representative real owner cases in8.74 s pytest/9.581 s subprocess. Both workers executed calls; files stayed intact and kept call order.33 actual child shards remained byte-identical after archived fixture cleanup; their exact arc union combined to30-file JSON/HTML with consistent native integers. `affinity-cleanup-proof.json` retains scoped proof and limits.

A preceding generated-fixture-only paired metadata probe ran six unchanged full public verifier/assert_outcome invocations in12.10 s total: control→staged1.997→1.537 s safe nonnative;2.505→1.900 safe native;2.393→1.532 late receipt/wheel alias rejection. All13 phases, four actual tool-version calls and native emissions/statuses remained.49 native shards/48 with executed arcs retained all six verifier/source-free children. This supports a narrow tens-of-seconds aggregate lead, not a200 s reduction or a stable full-suite speed claim.

The final valid six-suite owner proof used canonical `uv run --locked coverage run -m pytest`, exactly two/loadgroup/no-restart, observation-only plugin, no manually injected COVERAGE_FILE/RCFILE, escalated intended execution context and unique `/tmp` fixtures. **341 passed in119.60 s pytest;120.374 s uv subprocess;122.77 s total wrapper/snapshot wall;203.42 user/32.24 system seconds.** The expected independently constructed duplicate-wheel warning remained; no skip/xfail/xpass/omission occurred. Exact call multiset and per-file order matched both worker collections. Entire files stayed on one worker:

| Suite | Cases | Aggregate case seconds |
| --- | ---: | ---: |
| receipt |79|47.195|
| measurements export |107|41.467|
| source-free |65|18.768|
| evidence outputs |46|70.868|
| output protection |31|25.969|
| external native evidence |13|25.984|

Total aggregate230.251 s. Prior traced full-candidate aggregate291.190 s uses a different context and concurrency; the entire60.939 s difference cannot be assigned to metadata staging. No comparable full-gate elapsed claim follows.

Native proof:743 actual root shards were copied durably;665 contain executed arcs,234 verifier arcs and152 source-free entry arcs. Pre-existing root shard bytes stayed unchanged. After the actual owned `/tmp` fixture tree was archived then removed, all743 copied hashes were unchanged and the combined database exactly equaled every per-source arc union. Current JSON/HTML represent all30 owned files and consistent per-file/package/global integers: statements1427/4920, branches255/1952. Package statements are827/4167 source and600/753 scripts; branches4/1648 source and251/304 scripts. Partial execution is honest scoped measurement, not a percentage target. `valid-owner-native-cleanup-proof.json`, `valid-owner-native/`, `valid-owner-root-shards/`, input snapshots, observation records, JUnit and logs retain proof. No actual canonical M25 invocation was added merely to retrieve numbers.

## Failed diagnostic work, retained charges

The first ptrace launch was sandbox-blocked before Python child startup; logs/time/trace retained. It was replaced with the explicitly recorded untraced bounded probe. Initial Ruff found two E501 shell-string lines; corrected using existing shell path/run_id variables before behavioral work.

Direct/sandboxed scoped Pyright attempts could not resolve pytest/_pytest despite a working pinned interpreter import. Explicit relative/absolute interpreter diagnosis and canonical sandbox invocation showed the same missing search paths. Canonical activated locked-uv outside the sandbox passed unchanged bytes. All failed logs remain; no type/config/dependency repair was made. Root's overlapping duplicate passing check remains its separate charge. The earlier metadata-only stdlib fixture check passed but did not prove pytest-dependent files.

The first complete341 proof was **failed/incomplete**:149.091 s,337 passed/4 failed. It incorrectly put basetemp inside the real Git checkout and explicitly overrode Coverage selectors with a shared absolute data path. Two genuine Coverage CLI fixture cases then included ROOT source rows instead of their four independently expected fixture files. Two identity-loss cases deliberately unlink private .git/HEAD; ordinary Git then discovered the real ROOT ancestor. This was directly observed with real ELF `/usr/local/bin/git` PID108081 from failed fixture cwd returning `/workspace/simrecon`; inherited GIT variables had no repo selectors. No PATH mock explained these outcomes. Raw failed run, input snapshots, coverage data, fixture tree and classification remain preserved.

The same four unchanged cases subsequently passed in intended canonical context with `/tmp` isolation, no manual Coverage selectors and escalation:4 passed2.83 s pytest/3.637 s subprocess. Five new native root shards were copied, prior shards unchanged, source hashes unchanged. This confirms the two harness defects; no test or product correction occurred. Renewed341 then passed as reported above. `failed-owner-harness-classification.json`, `full-owner-harness-git-diagnosis.json` and `minimal4-canonical-*` retain this history.

One archive listing piped to head emitted an expected stdout broken-pipe message; subsequent full listing validation to a file passed. This did not invalidate the retained archive.

## Remaining work and owned material

Root must combine these changes with authorized scientific work, obtain canonical13-phase verification of the exact clean candidate with same-run M25/current full native reports, measure actual full elapsed against the300 s attempt, and obtain the required fresh independent exact-candidate preservation/oracle/scope review. All original roles/failed attempts/accounting remain. Do not call the target met from owner timings.

No owned process remains running. The live valid-owner fixture `/tmp/simrecon-infra-owner-25n2n_8b` was removed after its raw tar archive and743-shard snapshots were retained. The earlier9-case affinity fixture was similarly archived/removed. Durable evidence and copied native databases must stay.

Other owned scratch still present and safe for coordinator-directed archive/cleanup when review no longer needs live paths: `full-owner-pytest-tmp` (failed under-repo341 fixture; preserve raw archive first), `final-runner-tmp`, `version-probe-fixtures`, and `/tmp/simrecon-infra-diagnosis-1wx5lsg6` (four-case intended-context fixture). Root `.coverage.*` files from the valid owner/minimal4 runs remain; their bytes are durably copied. Do not remove other owners' isolated databases, shared tool/JDK/reader caches or pre-existing root shards.

Accounting: one fresh author launch, zero subagents; all listed checks/probes/failures and scoped correction retained. Requested Sol/high; actual model attribution/tokens/cost unknown. Human total cap not set. Useful lesson: keep disposable Git-identity-loss fixtures outside any real repository ancestor, and keep the canonical coverage selection environment for broad owner proofs; an ostensibly isolated COVERAGE_FILE override changes the API behavior those tests intentionally exercise.
