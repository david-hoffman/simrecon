# Infrastructure read-only yield, 2026-11-09

Scope: fresh bounded infrastructure author; no nested delegation or Superpowers. Read AGENTS, bounded implement-work/test-audit, PROJECT commands/coverage and model guidance. No tracked source, gate, dependency, discovery or policy bytes edited. Baseline HEAD at launch was 6876e9ea3bd7ffb1feb46c5aec66667646de76cf, tree 8f6949aa4a0a2705a9b91303cec255e6a60a8128. Original declaration/obligation ledgers remain unchanged. Root owns the sole Current state and exact-candidate acceptance.

## Diagnosed cost and constraints

Existing candidate-3 JUnit has serial-rest aggregate 527.938 s. Science group totals remain separate and overlap in wall time. Individual disposable verifier suites: evidence_outputs 106.615 s/46 cases; receipt 57.429/79; measurements_export 50.704/107; output_protection 30.882/31. Moving those four whole files can move 245.630 s of baseline work, leaving a serial-rest floor of 282.308 s, before nonpytest phases. External native evidence 27.327 s/13 cases and source_free_check 18.233 s/65 cases are additional isolated-file leads; their qualification could lower that old floor to236.748 s. Cache-affine reader/JDK consumers must remain together. No elapsed target is proved by a sum or scheduling bound.

Existing execve trace has 418 genuine Coverage config interpreter queries totaling37.256 child-lifetime seconds, median85.8 ms. They query the selected installed public API and cannot be cached without proving changed interpreter/configuration/error behavior. No such product edit is proposed. Git accounts17.157 child-lifetime seconds across7229 calls; optimizing tiny Git setups cannot supply200 s. Preserve real native operations/report renderers and every operation-time action.

248 controlled tool-version Python invocations total29.765 child-lifetime seconds, median118 ms. In the evidence profile these launch the entire evidence observer merely to emit installed metadata strings after controlled sync. Controlled sync does not modify installed distributions, and expected versions are independently queried in the assertion owner. These are externally supplied fixture payloads suitable for pre-staging, while actual commands/argv and status remain observed. This is narrower than stubbing native reports or verifier decisions.

The attribution files retain overlap warnings. Parent and child lifetimes must never be added as wall time. Older strace arguments are truncated, so classifications are conservative and limited to visible argument shapes.

## One bounded paired probe

The generated-fixture-only probe stages the exact installed ruff/pyright/coverage/pytest strings into the generated fake-uv shell. It runs unchanged real public verifier through unchanged source-free wrapper, and calls unchanged assert_outcome for safe nonnative, safe native, and audit-time receipt alias to the emitted wheel. Candidate and control pairs are adjacent; preparation is included. No repository test or implementation byte changes.

| Scenario | Control total s | Staged total s | Difference s | Preserved status |
| --- | ---: | ---: | ---: | --- |
| Safe nonnative |1.997|1.537|0.460|0/passed|
| Safe native |2.505|1.900|0.605|0/passed|
| Late report alias |2.393|1.532|0.861|1/receipt unavailable as expected|

All six invocations executed all13 actual phases and four actual version calls. Each native invocation retained four actual native emissions, real database/combine/JSON/HTML and unchanged evidence assertions. Native outer child coverage was preserved:49 shards total;48 contain executed arcs; six contain verifier arcs and six source-free entry arcs. No coverage variables were removed. The outer probe itself is outside owned source and its empty shard emitted the expected no-data-collected warning. This is scoped child proof, not all30-file exact full verification or same-run M25 acceptance. Canonical M25 was not rerun.

Successful probe:12.10 s wall,10.20 user,1.79 system,33164 KiB max RSS,status0. A preceding ptrace-enabled launch failed before child startup because sandbox ptrace was unavailable; its logs/time/trace are retained separately and no source/test failure is inferred. The successful probe omitted ptrace. No approvals or network calls were needed.

These three pairs support a concrete narrow fixture change; they do not establish a stable full-suite saving or the300 s goal. Plausible metadata-call saving is tens of aggregate seconds, not200. Native report/API processes are not optimization targets without their own contract-specific attribution.

## Next coherent batch and qualification plan

Root should explicitly authorize metadata staging in tests/verification_fixture_dispatch.py and its evidence-profile fixture caller after reviewing this yield. Stage truthful external bytes at installation; preserve selected-command argv, status/output, actual version-call records, ordinary fallback for unexpected call shapes, and dynamic phase observers. No verifier, Coverage config, renderer, native child or gate change is needed.

Qualify explicit independent whole-file groups for the four named verifier suites; consider external-native and source-free suites as separately named extensions to meet the scheduling floor. All use private tmp_path repositories/bins and read ROOT scripts/interpreter/Makefile. Their mutable environments, linked Git repositories and late aliases remain worker/process-local. Native coverage uses inherited absolute parent configuration with unique process suffixes. Measurement fixture writer paths follow that worker's own cwd. Preserve existing reader-cache affinity.

Before persistent map edits, a generated runtime-only pytest plugin can inject the proposed map for selected representative real positive/error/native cases. Run exactly -n2 --dist=loadgroup --max-worker-restart=0; keep nested commands unchanged. Record worker collection/call identities, same-file order and source hashes. Snapshot actual child shards before fixture cleanup, remove only owned disposable fixture trees with existing commands, verify shard hashes and exact arc union after native combine, and emit JSON/HTML with all30 owned files represented. This diagnostic is not final acceptance. Full affected files, canonical full verify and fresh independent review on the exact passing candidate remain required.

Coordinate any run expected>30 s with science/root. The all-four affected suite is263 prior cases/~245.6 aggregate s and may take~120 s with two useful workers; six files are341 cases/~291.2 aggregate s. No reader cache group split, worker-count change, discovery omission, restart, environmental coverage stripping or stale evidence reuse is authorized.

## Artifact and accounting facts

Durable evidence: existing-profile-attribution.json, python-process-attribution.json, probe_versions.py, version-probe-inputs.json, version-probe-results.json, version-probe-native-shards.json, successful .log/.time and ptrace-blocked logs/time/trace. Generated fixture roots under version-probe-fixtures retain the actual emitted native/report/wheel/log bytes and aliases; they are evidence inputs pending review, not currently disposable cleanup targets. Probe child shards remain beside the reports.

One role launch, no subagents. One failed environment-only launch before child startup; one successful12.10 s probe containing six controlled public invocations; no source corrections or product tests changed. Actual model/effort/token/money attribution unknown beyond requested Sol/high. Human total budget cap not set. No owned process remains running at this yield. No publication, commit, push, PR change or merge performed.
