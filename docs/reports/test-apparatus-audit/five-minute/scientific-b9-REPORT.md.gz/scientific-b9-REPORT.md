# Fresh blind scientific B9 checkpoint review

Verdict: accept the exact revised acquisition scientific test checkpoint
`a64a93dae93864d5b76a2fb54b794a876b76f76527e7018966a681870ee82bf9`.
No actionable candidate finding remains in the inspected whole B7-to-a64 delta.
This is a test-checkpoint verdict, not full-canonical readiness, native-report
completeness, physical-recovery acceptance or a 300-second performance claim.

## Identity, authority and preservation

Read AGENTS, review-work blind B, test-audit public authoring/preservation
criteria, PROJECT's public interfaces/commands/coverage policy and the relevant
CE common, rebuild, CE03, CE04, CE05 and CE06 public equations. No Superpowers or
delegation was used. Approved behavior plus independent risk review binds;
percentages are advisory. All installed 13 gates, exact two-worker policy,
30-file native measurement scope and same-run M25 limit remain binding.

The independently verified accepted B7 fixture is
`ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc`.
The rejected B8 snapshot is
`624e5371a4d400be38946f1aeaf9a4d0f897df39789b499af5f412f1dcf40a64`.
Current and frozen-b9-a64a match the accepted hash above. All eight dependent
acquisition suites and c_workflow_support independently match B7's accepted
pins. The eight suites retain 132 declarations and 420 explicit Assert nodes;
unchanged file bytes preserve every parameter row, assertion, tolerance,
validation, warning, nonmutation and permitted-alternative control. No test
removal or consolidation occurs. Prior 26 clock/drift keepers remain unchanged
coordinator scope facts; global 722 declarations/3066 cases were not recounted
by this narrow review.

I reviewed the complete plain-file ea32-to-a64 delta and its scalar/lane/caller
and observer context. B8's early stop was not treated as acceptance of unreviewed
parts. The exact ASTs for Disc, local_samples, model_bands/model_table,
predict_public, observe_public, certified_close, numerical_case,
radial_decision and positive_quotient remain equal to B7. The existing
PUBLIC_MODELS/OBSERVATION_BINDINGS lifecycle is unchanged; new sample contexts
are private to one reconstruction invocation. The unchanged composition helper
retains the known control before estimation, independent factors, actual estimate
consumption and both observer/public reconstruction calls for the control and
per-time image. No observer/public call was removed.

## Independent equations and risk disposition

CE03's actual flat stencil governs full interpolation: all eight vertices,
including zero weights, y/z seams, all-coordinate negative-x reflection and
conjugation, and safe cross-row aliases. closed_full.py independently checks six
closed affine/wrapped/alias/negative-zero queries. Every nominal result equals
its independently calculated value, and all three columns exactly match the
unchanged scalar sampler. Two equal-center/different-error queries retain
separate keys. Mutating an extracted result cannot change cached or later
results. The unsafe zero-weight last vertex declines and the scalar sampler
raises its original assertion.

Full preparation preserves three distinct outward steps: order-table getter,
reshape, and flat scalar getter. _lane_columns supplies the last step and
_lane_scalar restores already-rounded bits without another constructor round.
The radial helper retains its separate vector/scalar getter steps. Full keys
include dtype, shape and nominal/observer/backend bytes plus order; native radial
raw/radius keys retain corresponding complete columns. Table/dzf ownership is
fixed by the invocation, not inferred from coordinates. Local dictionaries are
copied before component work and committed only after whole-component success;
prepared/sample cached objects are read operands. Independent late-stencil
failure leaves all three context dictionaries uncommitted, and returned native
values have fresh storage.

CE04 supplies the native truth: inverse scalar noise, signed-order powers,
self-inclusive versus other-strict radial support, ascending direction/signed
order accumulation, final w squared, complex conjugate transfer/modulation and
E+iO after each quadrature's reflection. closed_native.py checks 28 admitted
cells across all three orders in radial and full layouts, with unequal complex
transfers/modulations and noise2/3/5. At zero carrier and interior radius the
denominator is |H0| squared/v0 + twice the side-order power sum + .25; at the
exact self-support boundary all other terms are excluded. The independent values
also cover reflected negative native x. Output/cache ownership and transactional
failure controls pass.

CE05 supplies separate overlap truth: pair(0,b) displacement, inclusive masks,
complex OTHER transfer in each numerator, sqrt of the two transfer powers,
3D factor5 in threshold only, ascending axial visits and unnormalized positive
inverse. closed_overlap.py independently checks pair03 radial/Z3 and full/Z1,
all Fourier cells/written masks and direct spatial sums. It verifies 30 and10
successful writes respectively. The spatial comparison uses the explicit
operation-count bound gamma(32*N)*sum(abs(F)) to account for phase/product/sum
rounding and cancellation. It does not adjust a scientific fixture tolerance.

The broader eligibility retains other flags, odd geometry, axial cutoffs,
unknown/custom samplers and unfamiliar representations on the original scalar
path. Signed carrier multiples each receive finite headroom checks; the sum
reserve counts (2*O-1)*D+1, and a conservative 32-power/64-bit margin exceeds
the restricted full interpolation/filter error expression. Admitted cells
bound their sample coordinates/weights; invalid actual offsets decline before
public writes/certificates. No index clamp, zero-weight elision, source-domain
floor or new rejection was introduced. New quiet lower bounds are only
optimization eligibility, not a proof of underflow silence.

Uncertain carriers retain the original two-component norm/error expression and
support interval test. Per-cell support records precede that cell's divisor;
ambiguity returns to the original scalar traversal, preserving first failure
and the exact prefix. Independent uncertain and ambiguous controls match B7
45-record return and 6-record CertificateError prefix respectively. The unsafe
full stencil retains AssertionError with no public prefix. Unknown sampler
success and fifth-call ValueError retain exact call arguments/counts and four
preceding certificates. Tiny, subnormal-error, float32-error, Disc-subclass,
readonly/strided and large-carrier alternatives compare directly with accepted
B7, without disabling its helper.

Only admitted nonvarying masks discard unused norm error metadata; their nominal
norm remains np.linalg.norm of the same scalar two-element array. Complex 0D
nominal dispatch, complex abs and rounding remain unchanged. The only other
removed work is unused REAL abs metadata for operations whose propagation does
not consume it; real abs is a sign-bit operation. Finite/shape/class checks and
scalar fallback preserve unfamiliar/error-bearing cases. No global observer
result cache or across-invocation sample reuse appears.

Risk-to-keeper assessment: unchanged filter tests protect unequal-order complex
raw-to-native-to-image, all filter flags, dimensional inverse and signed views;
2d tests protect finite search, strict threshold alternatives and short-circuit
unsafe vertices; composition protects known controls before actual estimates
and use of returned factors; transfer protects empirical complex128 consumption,
full/radial geometry and literal padding; boundary protects records, representation,
operation-time failures and adjacent positives; preparation/drift/fitted-drift
retain their independent camera/phase/noise/clock proof. No sole proof was lost,
no new scientific meaning was identified, and no speculative percentage test or
production seam is needed. B7 evidence remains applicable to unchanged portions.
Workflow support's pin is unchanged; root's sanitized CE08 closure says no
acquisition-fixture dependency. Neither workflow nor CE08 oracle was opened or
newly accepted by this review.

## B8 diagnostic correction and retained proof

B8's real warning defect remains charged and its624e checkpoint remains rejected.
Actual NumPy underflow policy now selects the broader engine only for ignore.
Every non-ignore mode retains B7 O2/radial native eligibility/private caches/full
norm metadata and pair01/Z1-or-2 radial overlap behavior. New O3/full/uncertain
families use scalar ownership. No errstate, warning filter/replay or policy
mutation was added by the candidate.

Own challenge.py final groups pass9 guard,36 policy and8 overlap cases with exact
nominal/observer/backend bytes, ordered certificates, warning identities,
callback/log events, printed native NumPy text, custom call arguments, inputs,
policy restoration and outcomes. Policies include ignore/warn/print/call/log/
raise across O2 radial and O3 radial/full. Tiny-table policy controls preserve
83/471/474 warning, print or callback/log events as appropriate to these own
inputs; seventh-callback exceptions retain RuntimeError and the empty certificate
prefix. Actual diagnostic locations remain in the JSON. Printed NumPy diagnostics
have no location field in their native form. Author45 cases independently pin
a64 and additionally preserve the normalized B8 witness's370 events/9 records.
All probes assert that no simrecon product module was imported.

I retain the completed624e 597-case DEFAULT-ignore proof only within its stated
material-input scope. static_proof.py independently specializes the actual
geterr/extended gates and norm alias to ignore; after Boolean association/constant
normalization the ENTIRE fixture AST equals624e. Every numerical statement,
call, guard and cache path is retained in that projection. Added geterr reads
and local mode selection perform no floating arithmetic or mutation. All eight
suite ASTs contain no seterr/errstate calls; fixture's pre-existing contexts
change divide/invalid only. Author MODE-EQUIVALENCE supplies matching clause
reasoning. Thus the correction does not change those default-mode executions.
This is conditional evidence retention, not exact-candidate canonical evidence.

Independently parsed retained XML/log:597 cases,18 warnings,226.52s, zero failure/
error/skipped nodes; counts boundary313/preparation88/filter49/2d40/transfer38/
drift37/composition18/fitted-drift14. Sum testcase time350.437s. Independently
parsed renewed exact-a64 boundary XML/log:313 cases/16 warnings/7.59s, zero
failure/error/skipped nodes, summed testcase time5.947s. Fixed2/loadgroup/
no-restart/native-active/source-free provenance is coordinator supplied; I did
not inspect coverage data. The startup already-imported CoverageWarning remains
visible and supplies no coverage-completeness proof. Narrow types records
0 errors/warnings/informations; root reports full make check passes separately.

After root conveyed the explicit author ALLFINAL/STABLE signal, final author
manifest69 hashes and current scientific pins were independently rechecked.
Author manifest itself hashes to
4c003eaedca9bacb9e1d9944bfd31e810a8001b779233c97fd99d3d40d9b1d36.
No later author change is pending in this checkpoint. Full exact-candidate
make verify with all597 acquisition cases and all3066 collected cases, all13
phases, native/platform report integrity, M25 and fresh D remain coordinator
gates. No automatic duplicate597 run was requested by this review.

## Attempts, exposure and cleanup

This is fresh scientific B9/known launch22 per the coordinator; all original
roles, corrections, B8 nonacceptance and prior spending remain charged once.
Requested model/effort was Sol/high; actual serving model/effort/tokens/cost are
unknown. No human numeric review cap was supplied;300s is the full-gate goal.
No product-red was required or claimed and no scientific product edit occurred.

Own substantive probe/check executions before final manifest check:16 total,
11 passing and5 failed development attempts. The failures are my independent
probe scaffolding, not candidate defects: one native expected-value draft omitted
full negative-x H conjugation; one overlap draft used a fixed4e-15 absolute
cancellation tolerance instead of its operation-count bound; three AST projection
drafts needed Boolean flattening/not-True normalization before exact comparison.
All failed logs are retained. The final native/overlap algebra follows the public
contracts and passes. Initial three challenge runs were repeated to record caught
exception frame locations, then the policy group was expanded to include warn/
ignore; these executions remain counted. Final manifest validation supplied two
additional successful executions (the first manifest included its still-open log; the final manifest excludes that log). Seven artifact-edit helper interpreter runs are
charged separately: six source-free and one stdlib-only local string edit used
the system Python without the wrapper. That edit imported no fixture/product
module and exposed no prohibited content. Shell reads/diffs and truncated outputs
were not treated as numerical proof; expected plain-diff difference statuses
are retained, not check failures.

No product implementation, Git/history/conversation, Current state, nonblind
inventory, coverage file/map, raw canonical profile or existing LESSONS content
was opened. Author manifest entries outside selected evidence were verified by
hash only; their prose/build-script contents were not interpreted. No blindness
exposure occurred. All fixture imports/probes used the read source-free runner,
sitecustomize and plugin with timeout5; warnings/exceptions retain type/message/
frame location and outcome without source snippets. No target file was edited.

Own durable evidence is this scientific-b9 directory. The policy probe's unnamed
temporary files only captured native stderr; all files/descriptors closed on
exit. All own probe processes exited; no daemon/server or named /tmp scratch
remains. No fixture, Python cache, shared environment or unrelated path was
removed. No commit, publication, merge or external message occurred.
