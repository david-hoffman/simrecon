"""Challenge numerical/error-policy ownership without product imports."""
import hashlib
import importlib.util
import json
import sys
import warnings
from pathlib import Path
from types import SimpleNamespace

import numpy as np

ROOT = Path.cwd()
OUT = ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-a'
def load(name,path):
    spec = importlib.util.spec_from_file_location(name,path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module
old = load('policy_old',OUT/'before/c_acquisition_fixture.py')
new = load('policy_new',ROOT/'tests/c_acquisition_fixture.py')
def freeze(value):
    if isinstance(value,np.ndarray):
        data = [value.dtype.str,value.shape,np.asarray(value).tobytes().hex()]
        if hasattr(value,'observer'):
            data += [freeze(value.observer),freeze(value.backend)]
        return data
    if isinstance(value,dict): return {key:freeze(item) for key,item in value.items()}
    if isinstance(value,(list,tuple)): return [freeze(item) for item in value]
    if isinstance(value,(np.generic,float,complex)): return freeze(np.asarray(value))
    return value
class Events:
    def __init__(self): self.events=[]
    def __call__(self,message,flag): self.events.append(['call',message,int(flag)])
    def write(self,message): self.events.append(['log',message])
def run(f,orders,layout,exponent,mode):
    bands = SimpleNamespace(input_shape=(1,1,2*orders-1,1,2,2),acquisition_mode='2d',dxy_um=1.,dz_um=.5,lateral_zoom=1.,axial_zoom=1,quadratures=f.Disc(np.ones((1,1,2*orders-1,1,2,2),complex)),noise_variance_factors=f.Disc(np.ones((1,1,orders))))
    shape=(orders,16,1) if layout=='radial' else (orders,1,16,16)
    table=SimpleNamespace(samples=f.Disc(np.full(shape,2.0**exponent,complex)),layout=layout,dkr_cyc_um=.125,dkz_cyc_um=2.)
    table.samples[0]=1.
    carriers=f.Disc(np.array([[.07,.02]]))
    modulation=f.Disc(np.full((1,orders-1),2.0**exponent,complex))
    before=freeze((bands.quadratures,bands.noise_variance_factors,table.samples,carriers,modulation))
    events=Events(); previous_callback=np.geterrcall(); previous_policy=np.geterr().copy()
    f.CERTIFICATES.clear()
    try:
        np.seterrcall(events)
        with warnings.catch_warnings(record=True) as seen,np.errstate(under=mode):
            warnings.simplefilter('always')
            try: result=['return',freeze(f.reconstruct_expected(bands,table,carriers,modulation,**f.known_options()))]
            except Exception as error: result=[type(error).__name__,str(error)]
        warning_ids=[(item.category.__name__,str(item.message)) for item in seen]
        locations=[(item.filename,item.lineno) for item in seen]
    finally:
        np.seterrcall(previous_callback)
    assert np.geterr()==previous_policy
    assert before==freeze((bands.quadratures,bands.noise_variance_factors,table.samples,carriers,modulation))
    return result,freeze(f.CERTIFICATES),warning_ids,events.events,locations
rows=[]
for orders,layout in ((2,'radial'),(3,'radial'),(3,'full')):
    for exponent in (0,-256,-257):
        for mode in ('ignore','warn','raise','call','log'):
            answers=[run(f,orders,layout,exponent,mode) for f in (old,new)]
            exact=answers[0][:4]==answers[1][:4]
            row=dict(orders=orders,layout=layout,exponent=exponent,mode=mode,exact=exact,outcomes=[answer[0][0] for answer in answers],warnings=[len(answer[2]) for answer in answers],events=[len(answer[3]) for answer in answers],certificates=[len(answer[1]) for answer in answers],warning_locations=[answer[4] for answer in answers])
            rows.append(row)
            if not exact:
                (OUT/'policy-failure-details.json').write_text(json.dumps(answers,indent=2)+'\n')
                raise AssertionError((orders,layout,exponent,mode,row))
report=dict(fixture_sha256=hashlib.sha256((ROOT/'tests/c_acquisition_fixture.py').read_bytes()).hexdigest(),rows=rows,product_imported=any(name=='simrecon' or name.startswith('simrecon.') for name in sys.modules))
(OUT/'policy-exact.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(fixture_sha256=report['fixture_sha256'],cases=len(rows),all_exact=all(row['exact'] for row in rows),product_imported=report['product_imported'],normalized_witness=[{key:row[key] for key in ('orders','layout','exponent','mode','outcomes','warnings','events','certificates')} for row in rows if row['orders']==3 and row['layout']=='radial' and row['exponent']==-256]),indent=2))
