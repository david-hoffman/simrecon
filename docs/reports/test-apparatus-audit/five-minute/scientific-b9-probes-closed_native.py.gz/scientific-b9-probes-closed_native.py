import importlib.util,json,sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
ROOT=Path.cwd();OUT=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-b9'
s=importlib.util.spec_from_file_location('b9_native',ROOT/'tests/c_acquisition_fixture.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
orders=3;x=4;y=2;shape=(1,1,5,1,y,x//2+1)
q=np.arange(np.prod(shape)).reshape(shape)/16+1j*np.arange(np.prod(shape)).reshape(shape)/32
bands=SimpleNamespace(input_shape=(1,1,5,1,y,x),quadratures=f.Disc(q),noise_variance_factors=f.Disc(np.array([[[2.,3.,5.]]])))
h=np.array([1+.125j,.75-.25j,.3+.4j]);am=np.array([1,.5+.25j,-.2+.1j]);car=f.Disc(np.zeros((1,2)));mod=f.Disc(am[None,1:]);noise=np.array([2.,3.,5.]);dx=f.Disc(1/x);dy=f.Disc(1/y);dz=f.Disc(2.);radius=.5;w=f.Disc(.5)
rows=[]
for layout in ('radial','full'):
 tshape=(orders,16,1) if layout=='radial' else (orders,1,16,16)
 table=SimpleNamespace(samples=f.Disc(np.broadcast_to(h.reshape((orders,)+(1,)*(len(tshape)-1)),tshape).copy()),layout=layout,dkr_cyc_um=.125,dkz_cyc_um=2.)
 context=({},{},{})
 for m in range(orders):
  cells=f._native_radial_batch(bands,table,car,mod,0,0,m,dx,dy,dz,radius,w,sample_context=context)
  assert cells is not None
  checked=0
  for (iy,ix),cell in cells.items():
   r=np.hypot(ix/x,iy/y)
   assert cell['inside']==(r<=radius)
   if r>radius:continue
   stored=np.conj(q[0,0,:,0,(-iy)%y,-ix]) if ix<0 else q[0,0,:,0,iy%y,ix]
   b=stored[0] if m==0 else stored[2*m-1]+1j*stored[2*m]
   power=abs(h[m])**2*abs(am[m])**2/noise[m]
   if r<radius:power=abs(h[0])**2/noise[0]+2*sum(abs(h[n])**2*abs(am[n])**2/noise[n] for n in range(1,orders))
   sampled_h=np.conj(h[m]) if layout=='full' and ix<0 else h[m]
   expected=b/noise[m]*np.conj(sampled_h)*np.conj(am[m])/(power+.25)
   assert np.isclose(np.asarray(cell['value']),expected,rtol=2e-15,atol=2e-15),(layout,m,iy,ix,cell['value'],expected)
   assert cell['support_records']==[]
   checked+=1
  rows.append(dict(layout=layout,order=m,checked=checked,cache_entries=[len(c) for c in context]))
 # Repeated component uses fresh output storage; mutation cannot change cached sample values.
 first=f._native_radial_batch(bands,table,car,mod,0,0,1,dx,dy,dz,radius,w,sample_context=context)
 saved=np.asarray(first[0,0]['value']).copy();first[0,0]['value'][...]=999;first[0,0]['value'].observer[...]=888
 second=f._native_radial_batch(bands,table,car,mod,0,0,1,dx,dy,dz,radius,w,sample_context=context)
 assert np.array_equal(np.asarray(second[0,0]['value']),saved)
# One component prepares/samples valid earlier cells, then encounters an unsafe vertex: no context commit.
bad=SimpleNamespace(samples=f.Disc(np.ones((orders,1,4,5),complex)),layout='full',dkr_cyc_um=.125,dkz_cyc_um=2.)
context=({},{},{})
assert f._native_radial_batch(bands,bad,car,mod,0,0,0,dx,dy,dz,radius,w,sample_context=context) is None
assert context==({},{},{})
assert not any(n=='simrecon' or n.startswith('simrecon.') for n in sys.modules)
report=dict(rows=rows,transactional_context=True,output_ownership=True,product_imported=False)
(OUT/'closed-native.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
