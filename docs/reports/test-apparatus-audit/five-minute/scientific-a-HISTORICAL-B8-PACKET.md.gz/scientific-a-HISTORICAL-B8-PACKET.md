# Fresh B8 public scientific checkpoint

Frozen fixture: `tests/c_acquisition_fixture.py`, SHA256
`624e5371a4d400be38946f1aeaf9a4d0f897df39789b499af5f412f1dcf40a64`.
Same bytes: `frozen_fixture.py`. Accepted B7 baseline: `before/c_acquisition_fixture.py`,
SHA256 `ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc`.
Only this tracked fixture changed. All eight acquisition test bodies/assertions,
rows, tolerances, public calls, validation/rejection/nonmutation checks and the
26 prior consolidation keepers remain unchanged. No product-red/change.

## Reviewable change and preservation

* Native zero-axial lane eligibility now covers O>=2 and radial/full tables.
  Order loops, signed-order loops, quadrature indices and shapes generalize the
  existing expressions. Every signed carrier multiple has its own existing
  finite-range preflight. The expression degree is unchanged; the terms reserve
  now counts `(2*O-1)*D+1`. Other flags/odd geometry/axial cutoffs keep scalar work.
* Full zero-axial interpolation retains scalar coordinate arithmetic, reflection,
  wraps and all eight vertex accesses including zero weights. Prepared table
  getter/reshape rounds plus each flat scalar getter round remain separate.
  Vertex weights/products/ascending sums retain original scalar nominal ufunc
  dispatch and separate error algebra. Invalid offsets/derived headroom decline
  before writes/certificates, restoring scalar diagnostic ownership.
* Native sample caches are private to one reconstruction observer invocation,
  fixed table/dzf owner. Raw keys retain dtype/shape/bytes for nominal and both
  error columns plus order; radial keys retain the same complete data. Each
  component works in private dictionary copies and commits only on full success.
  Returned lanes restore existing bits without an extra outward constructor.
  No cross-test/new global expected-result cache or across-observation reuse.
  Existing per-case PUBLIC_MODELS/OBSERVATION_BINDINGS clearing stays unchanged.
* Varying native carriers retain the original full two-component norm and
  support-decision expression. Support records stage per cell before its filter
  divisor. Unresolved intervals decline with no public prefix/cache commit, so
  scalar traversal retains the original first failure and ordered certificates.
* Only admitted quiet nonvarying masks use the original scalar nominal norm
  without dead error columns. Strict binary64/error-column class/shape/finite
  checks and nonzero lower magnitude2**-256 protect normal linear geometry;
  tiny/subnormal/unfamiliar forms retain scalar work. Geometry scalars receive
  the same quiet-domain guard. Original complex abs/rounding calls stay intact;
  only unused real absolute-value metadata is omitted (real abs clears a sign).
* Overlap lanes cover public pairs(0,b), cutoff0/1, and full tables at cutoff0.
  Ascending h/side/row order, strict threshold short circuit, factors1/5, all-axis
  band reflection and external/custom sampler ownership remain unchanged.

Requirement/risk keepers remain the existing raw→bands→actual-estimate→signed
image composition, known controls before estimation, radial/full transfer and
Nyquist geometry, all filter flags and representation failures, finite-search
trace/threshold alternatives, drift/preparation and immutable record suites.
Public sources are CE common, CE03 sampling O25–O28, CE04 native support/weights/
traversal, CE05 overlap/finite search and CE06 mode contracts. No new scientific
meaning or production seam is introduced. Fresh B owns omission/alternative audit.

## Evidence and limits

`attribution.json/log`: frozen B7 public heavy composition, covered48.246s,
four reconstruction observers/32native components and eight overlap batches;
no product profiling. `matched-cache.json`, `matched-multiorder.json`,
`matched-full.json`, `qualify-coherent.json`, `qualify-broad.json` and
`qualify-guards.json` retain every staged experiment, not a canonical claim.
Source-only probes explicitly recorded no product imports. Expected source-only
native coverage no-data warnings remain visible; their data were not read.

Broad8 prototype comparisons retained exact nominal/observer/backend bytes,
ordered certificates/warnings, input nonmutation; full O3 1.797→.656s, O4
2.771→1.110s, uncertain radial1.129→.663s/full1.832→.897s. Ambiguous support
preserved55certificate prefix+CertificateError; unsafe full zero-weight stencil
preserved AssertionError/empty prefix. Subsequent quiet-domain tightening and
formatting are explicit; these earlier timings do not name the final hash.

Final preformat guard8 on SHA2986096b... passed actual radialZ3 cutoff1,
fullZ1 overlap, unfamiliar Disc/custom callback controls (including fifth-call
ValueError+4certprefix), and literal-scalar tiny/subnormal/float32-error controls.
Tiny/subnormal controls preserve exactly1625/349 ordered underflow warning
identities; actual locations remain source-free in the log. Final formatting and
one generator-variable rename produce the frozen624e... checkpoint.

Ruff format/check PASS. First lint found B020 and was mechanically corrected.
An already-started direct Pyright returned only missing NumPy/pytest imports
(known environment route); authoritative activated/locked narrow types belongs
to coordinator. Renewed all8 covered597-case source-frozen proof is pending that
result. Full canonical/all13 gates, same-run M25, native report integrity and
fresh D remain coordinator gates; five-minute success is unproved.

`clock-default-gw0.json/log/xml`: unchanged workflow clock row1pass13.27s;
case12.026wall/12.024CPU, five real caller runs10.776wall/10.775CPU versus
observe.463/error_budget.769. Fourteen observed threads but CPU≈wall; no BLAS
environment experiment/adoption. Earlier full-run32.79s versus isolated12.0s
is context variation, not an optimization claim. Workflow files stay untouched.

Root sanitized CE08 public import closure confirms no acquisition/workflow
fixture dependency; author did not open CE08 implementation. All8 acquisition
suites require renewed proof. B7 unaffected oracle evidence and B5 workflow
evidence retain only their unchanged material-input scope; B decides applicability.

## Role/exposure/accounting

Fresh blind A19/known launch19 supplied by coordinator; requested Sol/high,
actual serving model/effort/tokens/cost unknown. No Superpowers/delegation.
No product source/history/conversations, raw canonical profiles/traces, coverage
data/maps, nonblind discovery, task Current state or prior lessons read. All
probes use the read source-free harness/sitecustomize/plugin with explicit
timeouts; warnings/categories/messages/locations/status retained. No exposure.
No numeric author-time cap supplied; five-minute full gate is the performance goal.

Owned durable scratch/evidence: this directory only, including prior/final
fixture snapshots and isolated coverage data (unread). No `/tmp` scratch,
daemon/server, deleted fixture/environment, commit or external message. No
owned probe remains running at this freeze. Owner proof will be reported when
complete. Missing-path reads, initial lint/type failures and all staged probe
attempts remain charged; root owns cumulative prior-role/full-baseline accounting.
