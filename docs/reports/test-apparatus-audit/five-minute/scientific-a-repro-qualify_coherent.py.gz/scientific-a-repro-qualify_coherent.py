"""Matched exact public-test-observer comparisons for the scratch candidate."""
import hashlib
import importlib.util
import json
import sys
import time
import warnings
from pathlib import Path
from types import SimpleNamespace

import coverage
import numpy as np

ROOT = Path.cwd()
OUT = ROOT / "artifacts/test-apparatus-audit/five-minute/scientific-a"
sys.path.insert(0, str(ROOT / "tests"))
import c_acquisition_fixture as old

prefix = "qualify-guards" if "--guards" in sys.argv else "qualify-broad" if "--broad" in sys.argv else "qualify-coherent"
candidate_path = OUT / ("candidate_broad.py" if "--broad" in sys.argv or "--guards" in sys.argv else "candidate_coherent.py")
spec = importlib.util.spec_from_file_location("scratch_acquisition", candidate_path)
new = importlib.util.module_from_spec(spec)
spec.loader.exec_module(new)

def freeze(value):
    if isinstance(value, np.ndarray):
        result = [value.dtype.str, value.shape, np.asarray(value).tobytes().hex()]
        if hasattr(value, "observer"):
            result.extend((freeze(value.observer), freeze(value.backend)))
        return result
    if isinstance(value, dict):
        return {key: freeze(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [freeze(item) for item in value]
    if isinstance(value, np.generic):
        return freeze(np.asarray(value))
    if isinstance(value, (float, complex)):
        return freeze(np.asarray(value))
    return value

def call(fixture, orders, z, y, layout, operation, *, transpose=False, uncertainty=0.0, ambiguous=False, unsafe=False):
    raw = fixture.raw_pattern(t=2, d=2, p=2*orders-1, z=z, y=y, x=6)
    truth = fixture.prepare_expected(raw, fixture.options(acquisition_mode="2d" if z == 1 else "3d", norders=orders))
    bands = SimpleNamespace(**truth, input_shape=raw.shape, acquisition_mode="2d" if z == 1 else "3d", dxy_um=1.0, dz_um=.5, lateral_zoom=1.0, axial_zoom=1)
    shape = (orders, 32, z) if layout == "radial" else (orders, z, 32, 32)
    if unsafe:
        shape = (orders,z,1,1)
    samples = fixture.Disc(np.full(shape, 1+.2j), 2**-48, 2**-47)
    table = SimpleNamespace(samples=samples, layout=layout, dkr_cyc_um=.125, dkz_cyc_um=2.0)
    carrier_values = np.zeros((2,2)) if ambiguous else np.array([[.07,.02],[-.03,.08]])
    carriers = fixture.Disc(carrier_values, uncertainty, uncertainty/2)
    modulation = fixture.as_disc(np.full((2, orders-1), .3+.1j))
    if transpose is True:
        bands.quadratures = bands.quadratures[..., ::-1]
    if transpose == "subclass":
        class ForeignDisc(fixture.Disc):
            pass
        bands.quadratures = bands.quadratures.view(ForeignDisc)
    quiet = transpose in ("tiny", "subnormal-errors", "float32-errors")
    if transpose == "tiny":
        carriers = fixture.Disc(np.asarray(carriers)*2.0**-1000)
    if transpose == "subnormal-errors":
        bands.quadratures.observer.fill(np.nextafter(0.0,1.0))
    if transpose == "float32-errors":
        bands.quadratures.observer = bands.quadratures.observer.astype(np.float32)
    saved_native = fixture._native_radial_batch
    if quiet and fixture is old:
        fixture._native_radial_batch = lambda *args,**kwargs: None
    fixture.CERTIFICATES.clear()
    before = freeze((bands.quadratures,bands.noise_variance_factors,table.samples,carriers,modulation))
    captured = []
    with warnings.catch_warnings(record=True) as seen, np.errstate(under="warn" if quiet else np.geterr()["under"]):
        warnings.simplefilter("always")
        try:
            if operation == "reconstruct":
                result = fixture.reconstruct_expected(bands, table, carriers, modulation, **fixture.known_options())
            else:
                custom_calls = 0
                def custom_sampler(*args):
                    nonlocal custom_calls
                    custom_calls += 1
                    if transpose == "sampler-raise" and custom_calls == 5:
                        raise ValueError("custom sampler fifth-call sentinel")
                    return fixture.sample(table,*args)
                sampler_args = {"sampler":custom_sampler} if transpose in ("sampler","sampler-raise") else {}
                result = fixture.overlaps(bands, table, carriers[0], (0, orders-1), **fixture.optics(), **sampler_args)
                if sampler_args:
                    result["custom_sampler_calls"] = custom_calls
            captured = ["return", freeze(result)]
        except Exception as error:
            captured = [type(error).__name__, str(error)]
        warning_ids = [(item.category.__name__, str(item.message)) for item in seen]
        for item in seen:
            print(f"{item.filename}:{item.lineno}: {item.category.__name__}: {item.message}")
    assert before == freeze((bands.quadratures,bands.noise_variance_factors,table.samples,carriers,modulation))
    fixture._native_radial_batch = saved_native
    return captured, freeze(fixture.CERTIFICATES), warning_ids

cases = [
    (2,1,4,"radial","reconstruct",False),
    (3,3,4,"radial","reconstruct",False),
    (4,1,4,"radial","reconstruct",False),
    (3,3,4,"radial","overlap",False),
    (3,1,4,"radial","overlap",False),
    (3,3,3,"radial","reconstruct",False),
    (3,3,4,"radial","reconstruct",True),
    (3,5,4,"radial","reconstruct",False),
    (3,3,4,"full","reconstruct",False),
]
cases = [(*case,0.0,False) for case in cases]
if "--broad" in sys.argv:
    cases = [
        (3,3,4,"full","reconstruct",False,0.0,False),
        (3,3,4,"full","overlap",False,0.0,False),
        (4,1,4,"full","reconstruct",False,0.0,False),
        (3,3,4,"radial","reconstruct",False,1e-10,False),
        (3,3,4,"full","reconstruct",False,1e-10,False),
        (3,1,4,"radial","reconstruct",False,1e-8,True),
        (3,1,4,"full","reconstruct",False,1e-8,True),
    ]
cases = [(*case,False) for case in cases]
if "--broad" in sys.argv:
    cases.append((3,1,4,"full","reconstruct",False,0.0,False,True))
if "--guards" in sys.argv:
    cases = [
        (3,3,4,"radial","overlap",False,0.0,False,False),
        (3,1,4,"full","overlap",False,0.0,False,False),
        (2,1,4,"radial","reconstruct","subclass",0.0,False,False),
        (3,1,4,"full","overlap","sampler",0.0,False,False),
        (3,1,4,"full","overlap","sampler-raise",0.0,False,False),
        (2,1,2,"radial","reconstruct","tiny",0.0,False,False),
        (2,1,2,"radial","reconstruct","subnormal-errors",0.0,False,False),
        (2,1,2,"radial","reconstruct","float32-errors",0.0,False,False),
    ]
reports = []
cov = coverage.Coverage(data_file=str(OUT / (".coverage-"+prefix)))
cov.start()
try:
    for orders,z,y,layout,operation,transpose,uncertainty,ambiguous,unsafe in cases:
        results, timings = [], []
        for fixture in (old,new):
            start = time.perf_counter()
            results.append(call(fixture,orders,z,y,layout,operation,transpose=transpose,uncertainty=uncertainty,ambiguous=ambiguous,unsafe=unsafe))
            timings.append(time.perf_counter()-start)
        assert results[0] == results[1], (orders,z,y,layout,operation,transpose,uncertainty,ambiguous,unsafe)
        reports.append(dict(orders=orders,z=z,y=y,layout=layout,operation=operation,transpose=transpose,uncertainty=uncertainty,ambiguous=ambiguous,unsafe=unsafe,baseline_seconds=timings[0],candidate_seconds=timings[1],outcome=results[0][0][0],certificates=len(results[0][1]),warnings=len(results[0][2]),baseline_mode="literal scalar" if transpose in ("tiny","subnormal-errors","float32-errors") else "accepted fixture",exact=True))
finally:
    cov.stop()
    cov.save()
report = dict(baseline_sha256=hashlib.sha256((ROOT / "tests/c_acquisition_fixture.py").read_bytes()).hexdigest(), candidate_sha256=hashlib.sha256(candidate_path.read_bytes()).hexdigest(), cases=reports, product_imported=any(name == "simrecon" or name.startswith("simrecon.") for name in sys.modules))
(OUT / (prefix+".json")).write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
