# a64 versus624e: inspected mode-only delta

The complete source-file diff is `mode-correction-a64-vs-624e.diff`; it changes
only `_full_zero_samples` (its query closure), `_native_radial_batch`,
`_overlap_radial_batch`, `overlaps` and `reconstruct_expected`. No other
numerical, assertion, tolerance, public predictor or record code differs.

For an invocation whose underflow policy is `ignore` at the new lookups:

| Scope | Substitution and unchanged624e path |
| --- | --- |
| Full sampler query | The new `under != ignore` early return is false; all coordinate, vertex, ordered arithmetic, cache and returned-value code is identical. |
| Native component | `extended=True`; carrier-varying expression becomes the original expression. Quiet/range guards and signed-carrier preflight execute unchanged. Context copies, full-varying/nominal-nonvarying norm choice and successful context commit select exactly the624e alternatives. |
| Overlap component | `norm` aliases the original624e `_lane_nominal_norm2`; quiet/delta guards execute unchanged. Every other expression is unchanged. |
| Overlap eligibility | The pair conditional selects the624e `(0,b)` expression; added Z restriction reduces to true; layout condition reduces to the same radial/full-zero-cutoff expression; the error-representation condition reduces to its original `all(...)`. |
| Reconstruction eligibility | Order, layout and array predicates select the624e expressions; the added carrier restriction reduces to true. All remaining guards and numerical work are unchanged. |

The added reads of `np.geterr()` and Boolean/local alias selection do no floating
arithmetic, mutate no NumPy policy and create no certificate or returned field.
This is conditional path equivalence, not a claim that every possible caller
keeps its policy unchanged. Non-ignore paths intentionally preserve B7 warning,
callback/log and first-failure ownership, as exercised in45 exact policy cases.

An explicit search of all eight unchanged acquisition test files found no
`errstate`/`seterr` calls. The fixture's three pre-existing `np.errstate` contexts
change divide/invalid only. This supports B9's retained-proof assessment; it does
not replace B9's independent scope decision or final exact canonical evidence.

The exact624e complete owner proof is597passed/18warnings/226.52s. The renewed
exacta64 boundary proof is313passed/16warnings/7.59s. No source changed during
either run. All8 test bodies,132 declarations/420assertions and prior26 keepers
remain pinned. Coverage data/maps were not read. Full300-second readiness and
all13/native/M25/D obligations remain coordinator-owned and unproved here.
