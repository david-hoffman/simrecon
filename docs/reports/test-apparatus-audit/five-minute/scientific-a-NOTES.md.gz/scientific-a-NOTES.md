# Fresh scientific A19 measurement ledger

Role supplied by coordinator: high-risk blind A, known launch19 (including
infrastructure18). Original baseline/accounting remains coordinator-owned.
No Superpowers/delegation. Actual model, effort, tokens and cost unknown beyond
requested Sol/high. No product source/history/conversations/coverage maps read.

Named source-free harness/sitecustomize and pytest plugin read before probes.
All probes run through `.venv/bin/python scripts/source_free_check.py` with
explicit timeout and inherited source-free warning/traceback/subprocess output.
No exposure occurred. No tracked source edit as of these measurements.

Baseline fixture SHA256:
`ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc`.
Inherited coverage is approved behavior plus independent risk review; native
report integrity remains binding and percentages advisory. Exactly two workers,
loadgroup/no restart, all13 gates and same-run M25 remain coordinator gates.

## Attempts retained

1. Representative covered public heavy composition `between=False`: status0,
   48.245996s. Four independent reconstruct observers remain present; 32 native
   components, eight overlap batches. Native26.096581s within reconstruction
   29.830009s; overlap batches9.270901s within overlaps10.281720s. Interpolation
   8.198648s inclusive; regression0.018650s. No product profiling.
2. Scratch matched invocation-owned native sample reuse: status0. Independent
   synthetic D4/O2/Z2/Y10/X80 reconstruction8.981434s→7.474892s. All result
   nominal/observer/backend values and3700 ordered certificates equal. Pure
   per-reconstruction cache; clone read results; commit only successful native
   component. This alone does not support the five-minute goal; not adopted.
3. Scratch matched ordinary zero-axial O3/O4 native extension: status0. O3,
   T2/D3/Z3/Y4/X6:1.747670s→0.826856s; O4,T2/D3/Z1:3.209490s→1.428638s.
   All result nominal/observer/backend array bytes and270/372 ordered
   certificates equal; no product imports. Current scalar unsupported paths
   retained. Not yet adopted.

Fixture-only matched probes have coverage tracing active, with the native
configuration excluding test files; therefore the retained expected
`CoverageWarning: No data was collected` is no native completeness claim.
Representative public composition ran actual public entries with native
coverage active. Raw coverage data are retained but not read by blind A.

## Static population and preservation

Heavy composition T1/D4/O2/Z2/Y10/X80 has observer-control plus explicit-control
and observer-estimated-image plus explicit-expected-image. Each reconstruct
observer visits eight components:32 total and20,480 native cells. All four
independent numerical obligations and actual public calls remain required.
Within a reconstruction, table/dzf are fixed while native components repeat
exact sample/geometry work. Native local query keys preserve nominal,
observer/backend dtype, shape and bytes. No cross-test/global expected-result
cache is proposed; existing PUBLIC_MODELS/OBSERVATION_BINDINGS per-case clearing
remains unchanged.

The filter suite has12 initial O3 raw→known rows (radial/full,2D/Z3,three zooms)
currently excluded from native O2 lanes. Expensive2D search uses O3 and has
radial/full rows; uncertain carriers retain scalar behavior pending separately
proved certificate/first-failure ownership. Workflow clock-label proof already
shares one independent observation/budget while retaining baseline plus four
actual public calls. Its cost cannot be assumed to be oracle work.

No assertions, rows, tolerances, public observations, validation/rejection,
nonmutation checks, finite decisions or scientific contracts were changed.
No product-red is needed or claimed. Any revised checkpoint requires fresh B8
before exact full verification/fresh D. Canonical goal remains unproved.

Own durable scratch/evidence is this directory only. No own `/tmp` scratch,
daemon/server, owned process left running after completed probes, or deleted
fixture/environment. Two initial permitted report paths were missing because
ROUND7/packet belong to the author directory; corrected to the allowed B7
REPORT/accepted-filehashes. No prohibited contents were opened.
