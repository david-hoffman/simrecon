# Public-only advisor20

One fresh requested Astra/ultra consultation under project model guidance;
actual serving/model tokens/cache/cost remain unknown. No probes, source edits,
product implementation/history reads or delegation. Inputs were permitted public
contracts, acquisition fixtures/tests, B7 evidence and A19 fixture-only attribution.
No raw canonical profile/trace/coverage/Current state/LESSONS was read.

Question: identify an exact program capable of a major scientific-observer work
reduction for the300-second goal, beyond small cache changes, while preserving
scalar nominal dispatch, separate error columns and ordered diagnostics.

The advisor prioritized one reconstruction-owned context for immutable geometry,
sampling and individual denominator terms. Each component must retain original
addition order and self exclusion; never rearrange a final denominator sum.
Complete dtype/nominal/error-bit keys and fresh result metadata storage remain
required; all four top-level observer calls must remain.

It identified unconsumed norm metadata at qualified nonvarying masks and unused
input magnitudes in some lane operations, but warned that finite input bounds do
not prove quiet high-degree arithmetic: tiny/subnormal warning/exception behavior
needs fallback. Complex raw-result versus0D ndarray absolute-value semantics are
not interchangeable. This was advice, not proof; B8 later found the concrete
underflow-warning defect and A19/B9 separately corrected/reviewed it.

The larger supported population leads were nativeO>2 zero-cutoff cases and radial
Z3/pair(0,2) overlaps. Generic shapes/order loops and headroom term counts must
change together; preserve CE05's distinct cutoff and axial visits. Unknown
samplers, threshold alternatives and uncertain inputs need original paths until
separately qualified. A19 subsequently qualified full and uncertain extensions;
that evidence is owned by A19/B9, not this report.

Broad vector complex nominal substitution was not justified. Homogeneous real
elementary operations could be a separate qualification; complex multiply/divide,
abs/hypot and axis-wise norm cannot assume scalar equivalence. map/frompyfunc
would retain primitive calls but cannot alone support a250-second saving claim.

Cost bound: the native26.097s and overlap9.271s regions are inclusive; nested
interpolation8.199s must not be added again. Even eliminating both in two such
heavy rows yields only about70.7 aggregate seconds. A250-second saving requires
500s affected population at50% reduction,357s at70%, or313s at80%; current evidence
established none. The advisor recommended measured broader populations and net
context/cloning cost before claims. No300-second outcome was asserted.

All prior17-role charges remain; this advisory launch20 adds no implementation
ownership or acceptance. Fresh B/full canonical/final reviews remain required.
