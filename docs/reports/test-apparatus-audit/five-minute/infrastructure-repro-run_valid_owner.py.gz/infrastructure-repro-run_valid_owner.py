"""Renewed six-suite proof with canonical coverage and /tmp fixture isolation."""
import collections,hashlib,json,os,shutil,subprocess,sys,tempfile,time
from pathlib import Path
from coverage import CoverageData
ROOT=Path.cwd();OUT=ROOT/'artifacts/test-apparatus-audit/five-minute/infrastructure'
assert 'COVERAGE_FILE' not in os.environ and 'COVERAGE_RCFILE' not in os.environ
def root_shards():
    return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.glob('.coverage.*') if p.is_file()}
initial=root_shards()
tmp=Path(tempfile.mkdtemp(prefix='simrecon-infra-owner-'))
shard_dir=OUT/'valid-owner-root-shards'
shard_dir.mkdir()
plan=json.loads((OUT/'affinity-qualification-plan.json').read_text())

def inputs():
    paths=[ROOT/name for name in ('Makefile','pyproject.toml','uv.lock')]
    paths += [p for directory in ('src','tests','scripts') for p in (ROOT/directory).rglob('*')
              if p.is_file() and '__pycache__' not in p.parts]
    return {str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(paths)}
before=inputs()
metadata={'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
          'tracked_status':subprocess.check_output(['git','status','--porcelain','--untracked-files=no'],text=True),
          'material_inputs':before,'observer_sha256':hashlib.sha256((OUT/'valid_owner_observer.py').read_bytes()).hexdigest(),
          'run_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'valid-owner-inputs-before.json').write_text(json.dumps(metadata,indent=2)+'\n')
env=os.environ.copy();env['PYTHONPATH']=str(OUT)+os.pathsep+env.get('PYTHONPATH','')

command=['uv','run','--locked','coverage','run','-m','pytest','-q','-p','valid_owner_observer',
         *plan['flags'],'--basetemp',str(tmp),
         '--junitxml',str(OUT/'valid-owner-junit.xml'),*plan['mapping']]
start=time.perf_counter();result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=240)
elapsed=time.perf_counter()-start
(OUT/'valid-owner-run.log').write_text(result.stdout+result.stderr)
(OUT/'valid-owner-run.json').write_text(json.dumps({'argv':command,'status':result.returncode,'elapsed_seconds':elapsed,
 'explicit_coverage_env':'No COVERAGE_FILE/RCFILE present or injected','basetemp':str(tmp)},indent=2)+'\n')
after=inputs();(OUT/'valid-owner-inputs-after.json').write_text(json.dumps(after,indent=2)+'\n')
assert before==after,'material source/test/support/config input drift'
assert result.returncode==0,result.stdout+result.stderr
records=[json.loads(line) for p in sorted((OUT/'valid-owner-observations').glob('*.jsonl')) for line in p.read_text().splitlines()]
collections_=[r for r in records if r['kind']=='collection' and r['worker']]
assert len(collections_)==2 and {r['worker'] for r in collections_}=={'gw0','gw1'}
assert collections_[0]['nodes']==collections_[1]['nodes']
assert len(collections_[0]['nodes'])==341
workers={r['pid'] for r in collections_}
calls=[r for r in records if r['kind']=='report' and r['when']=='call' and r['pid'] in workers]
assert len(calls)==341 and all(r['outcome']=='passed' and r['wasxfail'] is None for r in calls)
assert {r['pid'] for r in calls}==workers
assert collections.Counter(r['node'] for r in calls)==collections.Counter(collections_[0]['nodes'])
ownership={}
for r in calls:ownership.setdefault(r['node'].partition('::')[0],set()).add(r['pid'])
assert set(ownership)==set(plan['mapping']) and all(len(v)==1 for v in ownership.values())
for collection in collections_:
    order=[r['node'] for r in calls if r['pid']==collection['pid']]
    for file in ownership:
        actual=[node for node in order if node.startswith(file+'::')]
        expected=[node for node in collection['nodes'] if node.startswith(file+'::')]
        if actual:assert actual==expected,file
after_shards=root_shards()
assert all(after_shards.get(k)==v for k,v in initial.items()), 'existing root shards changed'
for name,value in after_shards.items():
    if initial.get(name)!=value:shutil.copyfile(ROOT/name,shard_dir/name)
(OUT/'valid-owner-root-shard-delta.json').write_text(json.dumps({'initial':initial,'after':after_shards,'basetemp':str(tmp)},indent=2)+'\n')
shards=[]
for p in sorted(shard_dir.glob('.coverage.*')):
    data=CoverageData(basename=str(p));data.read();assert data.has_arcs()
    shards.append({'name':str(p.relative_to(OUT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                   'arcs':{name:sorted(data.arcs(name) or []) for name in data.measured_files()}})
assert len(shards)>3
summary={'status':result.returncode,'elapsed_seconds':elapsed,'cases':len(calls),'workers':sorted(workers),
         'file_case_counts':dict(collections.Counter(r['node'].partition('::')[0] for r in calls)),
         'whole_file_owners':{k:list(v) for k,v in ownership.items()},
         'inputs_unchanged':True,'basetemp':str(tmp),'prior_root_shards_unchanged':True,'shards':shards}
(OUT/'valid-owner-before-cleanup.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='shards'}))
