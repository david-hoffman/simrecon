import ast,hashlib,json,re,sys,xml.etree.ElementTree as ET
from pathlib import Path
ROOT=Path.cwd();A=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-a';OUT=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-b9'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=ast.parse((A/'before/c_acquisition_fixture.py').read_text());rejected=ast.parse((A/'rejected-624e.py').read_text());current=ast.parse((ROOT/'tests/c_acquisition_fixture.py').read_text())
class IgnoreMode(ast.NodeTransformer):
 def visit_Assign(self,n):
  if any(isinstance(t,ast.Name) and t.id in ('extended','norm') for t in n.targets):return None
  return self.generic_visit(n)
 def visit_Name(self,n):
  if isinstance(n.ctx,ast.Load):
   if n.id=='extended':return ast.Constant(True)
   if n.id=='norm':return ast.Name(id='_lane_nominal_norm2',ctx=ast.Load())
  return n
 def visit_UnaryOp(self,n):
  n=self.generic_visit(n)
  return ast.Constant(not n.operand.value) if isinstance(n.op,ast.Not) and isinstance(n.operand,ast.Constant) and type(n.operand.value) is bool else n
 def visit_Compare(self,n):
  n=self.generic_visit(n)
  if isinstance(n.left,ast.Subscript) and ast.unparse(n.left)=="np.geterr()['under']" and len(n.ops)==1:
   assert isinstance(n.comparators[0],ast.Constant) and n.comparators[0].value=='ignore'
   return ast.Constant(isinstance(n.ops[0],ast.Eq))
  return n
 def visit_IfExp(self,n):
  n=self.generic_visit(n)
  return n.body if isinstance(n.test,ast.Constant) and n.test.value is True else n.orelse if isinstance(n.test,ast.Constant) and n.test.value is False else n
 def visit_If(self,n):
  n=self.generic_visit(n)
  return n.body if isinstance(n.test,ast.Constant) and n.test.value is True else n.orelse if isinstance(n.test,ast.Constant) and n.test.value is False else n
 def visit_BoolOp(self,n):
  n=self.generic_visit(n)
  n.values=[item for value in n.values for item in (value.values if isinstance(value,ast.BoolOp) and type(value.op) is type(n.op) else [value])]
  if isinstance(n.op,ast.And):
   n.values=[v for v in n.values if not (isinstance(v,ast.Constant) and v.value is True)]
   if not n.values:return ast.Constant(True)
  else:
   if isinstance(n.values[0],ast.Constant) and n.values[0].value is True:return ast.Constant(True)
   n.values=[v for v in n.values if not(isinstance(v,ast.Constant) and v.value is False)]
   if not n.values:return ast.Constant(False)
  return n.values[0] if len(n.values)==1 else n
# This specializes actual mode gates/aliases only; all numerical/statements/calls remain for AST equality.
a=IgnoreMode().visit(rejected);b=IgnoreMode().visit(current)

if ast.dump(a)!=ast.dump(b):
 import difflib
 print(''.join(difflib.unified_diff(ast.unparse(a).splitlines(True),ast.unparse(b).splitlines(True))))
 raise AssertionError('default ignore AST projection differs')
pins=json.loads((ROOT/'artifacts/test-apparatus-audit/resume/scientific-b-round7/accepted-filehashes.json').read_text())['scientific_files_sha256']
files={};policy_calls=[]
for name,expected in pins.items():
 p=ROOT/name
 if name.endswith('/c_acquisition_fixture.py'):continue
 assert digest(p)==expected,name
 if '/test_c_acquisition_' in name:
  tree=ast.parse(p.read_text());tests=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
  files[name]=dict(sha256=expected,declarations=len(tests),asserts=sum(isinstance(n,ast.Assert) for n in ast.walk(tree)))
  for n in ast.walk(tree):
   if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in ('seterr','errstate'):
    policy_calls.append([name,n.lineno,ast.unparse(n)])
assert sum(v['declarations'] for v in files.values())==132
assert sum(v['asserts'] for v in files.values())==420
assert not policy_calls
# All observer/public machinery remains byte-equivalent AST to accepted B7.
byname=lambda tree:{n.name:n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
o=byname(old);c=byname(ast.parse((ROOT/'tests/c_acquisition_fixture.py').read_text()))
unchanged=['Disc','local_samples','model_bands','model_table','predict_public','observe_public','certified_close','numerical_case','radial_decision','positive_quotient']
for name in unchanged:assert ast.dump(o[name])==ast.dump(c[name]),name
proofs={}
for basename,expected in [('covered8-final',597),('boundary-b9',313)]:
 tree=ET.parse(A/(basename+'.xml'));nodes=list(tree.iter('testcase'));assert len(nodes)==expected
 assert not any(n.tag in ('failure','error','skipped') for n in tree.iter())
 counts={}
 for n in nodes:counts[n.attrib['classname']]=counts.get(n.attrib['classname'],0)+1
 log=(A/(basename+'.log')).read_text();match=re.search(r'(\d+) passed, (\d+) warnings in ([\d.]+)s',log);assert match and int(match[1])==expected
 proofs[basename]=dict(cases=len(nodes),warnings=int(match[2]),seconds=float(match[3]),by_suite=counts,summed_case_seconds=round(sum(float(n.attrib.get('time',0)) for n in nodes),3),xml_sha256=digest(A/(basename+'.xml')),log_sha256=digest(A/(basename+'.log')))
assert digest(ROOT/'tests/c_acquisition_fixture.py')=='a64a93dae93864d5b76a2fb54b794a876b76f76527e7018966a681870ee82bf9'
assert digest(A/'frozen-b9-a64a.py')==digest(ROOT/'tests/c_acquisition_fixture.py')
report=dict(default_ignore_entire_fixture_AST_equivalent_to_624e=True,files=files,unchanged_observer_functions=unchanged,underflow_policy_changes_in_eight_suites=policy_calls,proofs=proofs)
(OUT/'static-proof.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
