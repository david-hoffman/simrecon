"""Blind fixture-only boundary comparison; no product imports."""
import importlib.util
import json
import sys
import warnings
from pathlib import Path
from types import SimpleNamespace
import numpy as np

ROOT = Path.cwd()
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

old = load('b8_old', ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-a/before/c_acquisition_fixture.py')
new = load('b8_new', ROOT/'tests/c_acquisition_fixture.py')

def freeze(v):
    if isinstance(v, np.ndarray):
        out = [v.dtype.str, v.shape, np.asarray(v).tobytes().hex()]
        if hasattr(v, 'observer'):
            out += [freeze(v.observer), freeze(v.backend)]
        return out
    if isinstance(v, dict): return {k:freeze(x) for k,x in v.items()}
    if isinstance(v, (tuple,list)): return [freeze(x) for x in v]
    if isinstance(v, (np.generic,float,complex)): return freeze(np.asarray(v))
    return v

def run(f, scale, scalar, mode):
    bandscale,tablescale,modscale=(2.**v for v in scale)
    o=3; z=1; y=x=2
    bands=SimpleNamespace(input_shape=(1,1,5,z,y,x), acquisition_mode='2d', dxy_um=1., dz_um=.5, lateral_zoom=1., axial_zoom=1,
        quadratures=f.Disc(np.ones((1,1,5,z,y,x//2+1),complex)*bandscale), noise_variance_factors=f.Disc(np.ones((1,1,o))))
    table=SimpleNamespace(samples=f.Disc(np.ones((o,16,1),complex)*tablescale), layout='radial', dkr_cyc_um=.125, dkz_cyc_um=2.)
    if '--normalized' in sys.argv:
        table.samples[0] = 1.
    carriers=f.Disc(np.array([[.07,.02]]))
    modulation=f.Disc(np.full((1,o-1), modscale, complex))
    saved=f._native_radial_batch
    if scalar: f._native_radial_batch=lambda *a,**k:None
    f.CERTIFICATES.clear()
    with warnings.catch_warnings(record=True) as got, np.errstate(under=mode):
        warnings.simplefilter('always')
        try: result=['return',freeze(f.reconstruct_expected(bands,table,carriers,modulation,**f.known_options()))]
        except Exception as error: result=[type(error).__name__,str(error)]
    f._native_radial_batch=saved
    warnings_out=[(v.category.__name__,str(v.message)) for v in got]
    locations=[(v.filename,v.lineno) for v in got]
    return result, freeze(f.CERTIFICATES), warnings_out, locations

rows=[]
for exponent in ((0,0,0),(-128,-128,-128),(-256,-256,-256),(-149,-149,-256),(0,-256,-256),(0,0,-256)):
    for mode in ('warn','raise'):
        answers=[run(f,exponent,scalar,mode) for f,scalar in ((old,False),(old,True),(new,False))]
        rows.append(dict(exponent=exponent,mode=mode,outcomes=[x[0][0] for x in answers],warnings=[len(x[2]) for x in answers],certificates=[len(x[1]) for x in answers],old_scalar_equal=answers[0][:3]==answers[1][:3],new_scalar_equal=answers[2][:3]==answers[1][:3],new_scalar_result_equal=answers[2][0]==answers[1][0],new_scalar_certificates_equal=answers[2][1]==answers[1][1],warning_details=[x[2] for x in answers],warning_locations=[x[3] for x in answers]))
assert not any(n=='simrecon' or n.startswith('simrecon.') for n in sys.modules)
print(json.dumps(rows,indent=2))
