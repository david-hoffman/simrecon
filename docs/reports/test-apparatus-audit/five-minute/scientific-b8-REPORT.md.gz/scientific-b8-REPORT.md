# Fresh blind scientific B8: correction required

Verdict: do not accept fixture `624e5371a4d400be38946f1aeaf9a4d0f897df39789b499af5f412f1dcf40a64`.
One concrete test-apparatus diagnostic-preservation defect was independently
reproduced. Numerical result and certificate equality do not remove it. This
is not a product-red claim, a canonical readiness verdict or a 300-second claim.

## Finding: quiet input boundary still permits underflow diagnostics

`_ordinary_lane_operand` admits a nonzero magnitude exactly `2**-256`. In a
newly admitted O3 native component, ordinary table and modulation magnitudes
at that boundary produce subnormal high-degree intermediates. In particular,
the transfer-power times modulation-power has ideal magnitude `2**-1024`,
below binary64's smallest normal `2**-1022`; further error terms also enter the
underflow regime. The input guard therefore does not establish the claimed
quiet arithmetic regime.

The independent fixture-only reproducer uses T=D=Z=1, O=3, X=Y=2, noise1,
carrier `[[.07,.02]]`, real/complex128 ordinary storage, positive w=.5,
no taper/suppression, radial dkr=.125/dkz=2, quadratures1, order-zero table1,
side-order tables `2**-256` and modulation `2**-256`. With
`np.errstate(under="warn")` and warnings filtered to always:

| Observer | Outcome | Ordered warnings | Certificates |
| --- | --- | ---: | ---: |
| Accepted B7, unchanged O3 scalar path | return | 370 | 9 |
| B7 with native helper explicitly declined | return | 370 | 9 |
| Current B8 | return | 228 | 9 |

The complete returned nominal/observer/backend bits and ordered certificate
records are equal in this witness. Warning sequences differ at zero-based
position4, independently of their expected file/line relocation. B7/scalar has
160 scalar-multiply,110 multiply and100 nextafter underflow warnings; B8 has
50,120 and58 respectively, all RuntimeWarning. Actual warning category,
message, filename and line are preserved in the JSON evidence. With
under="raise", all three raise the same first FloatingPointError with no
certificate prefix. Ordinary scale1 and scale2**-128 controls, and the
complex64-representable table2**-149/tiny-modulation control, match exactly.

The positive-domain qualification is explicit: direct `declare_otf` requires
complex64-representable samples, so the tiny table witness is not a direct-table
declaration witness. CE03 explicitly allows tables produced by preparation
without complex64 rounding and adds no tiny-positive floor; its normalization
is common order-zero scaling, preserved by the second witness above. This
review has not constructed an entire public bead-preparation input yielding
this exact table. The reproduced defect is in the broader fixture diagnostic
preservation promised by the packet and guard, not a claim that a current
product test fails or a complete public prepared record has been generated.

Requested bounded A correction: make unsafe quiet-domain acceleration decline
to the original scalar diagnostic owner, or demonstrate full ordered
diagnostic equivalence for the admitted domain. Preserve legitimate tiny
positive alternatives and scientific meaning. Renew affected proof and obtain
a fresh B after correction. No test/product edits were made by this reviewer.

## Scope, evidence and limits

Current fixture and frozen snapshot independently matched624e; the supplied
B7 snapshot independently matched
`ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc`.
I read AGENTS, review-work B, test-audit public authoring/preservation criteria,
the public PROJECT commands/coverage policy, B8-PACKET, B7 REPORT, the complete
421-line fixture delta and relevant scalar/lane/caller definitions. CE common,
rebuild and the complete optical-transfer contract establish the relevant
mapping, tiny-value/stencil rules and claim boundaries. Additional combined
contract reads were truncated; they were not treated as complete review.

The inherited policy is approved behavior plus independent risk review;
percentages are advisory and installed native/full gates remain mandatory.
Two workers remain policy. No four-worker adoption was assumed. The current
597-case owner proof was still running when the defect was reported. It is not
used as acceptance evidence. Author evidence/report finalization and ALLFINAL
were not awaited because this is a nonacceptance verdict. No author evidence
hash was captured. The complete requested entire-delta/keeper review was
halted on this actionable finding, so unchanged tests/workflow evidence and
all other B8 risks have no new blanket acceptance from this role.

Own durable source-free evidence under `probes/`:

* `range_control.py`: current reproducer, accepts `--normalized` to retain
  order-zero normalization. Every probe asserts no simrecon product import.
* `range_control.json/log`: first six warn/raise rows (scale0,-128,-256),
  execution status0, wall .65s.
* `range_control-expanded.json/log`: twelve warn/raise rows including separate
  band/table/modulation scaling, execution status0, about1s.
* `range_control-normalized.json/log`: same twelve rows with order-zero table1,
  execution status0, about1s. This is the strongest reported witness.
* `delta.txt`: exact plain-file B7-to-B8 delta.

Before any imports/probes I read source_free_check, sitecustomize and the pytest
plugin. All Python executions used the inherited source-free runner with
timeout5, retaining warning/exception categories/messages/locations/status.
Three numerical probe executions and three evidence-summary executions passed;
no timeout or probe failure occurred. Probe expansion and normalization are
diagnostic refinements, not candidate changes. Two attempted author-script
reads used nonexistent hyphen filenames; subsequent allowed glob inventory
identified underscore names. Several oversized static/JSON outputs were
truncated and followed by targeted reads/summaries; truncation supplies no
missing evidence. Plain diff's difference status was expected.

No product implementation, Git/history/conversations, nonblind discovery,
Current state, coverage data/maps, raw canonical profile, CE08 implementation,
new workflow oracle or existing LESSONS was opened. No prohibited exposure
occurred. No Superpowers or delegation was used. No commit/external message or
tracked edit occurred. Requested model/effort was Sol/high; actual serving
model/effort/tokens/cost are unknown. This is known launch21 per coordinator;
prior charges remain unchanged. No human numeric cap was supplied;300seconds
is the performance goal, not a measured outcome.

Own scratch: `/tmp/b8-delta.txt` only, now copied to durable evidence and
removed. All own probe processes exited; no daemon/server remains. Durable
evidence is retained. No fixture, shared environment/cache or unrelated work
was removed.
