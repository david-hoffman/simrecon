import hashlib,json
from pathlib import Path
ROOT=Path.cwd();A=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-a';OUT=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-b9'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=A/'final-evidence.sha256';assert digest(manifest)=='4c003eaedca9bacb9e1d9944bfd31e810a8001b779233c97fd99d3d40d9b1d36'
lines=manifest.read_text().splitlines();assert len(lines)==69
for line in lines:
 expected,name=line.split('  ',1)
 assert name.startswith('artifacts/test-apparatus-audit/five-minute/scientific-a/') or name=='tests/c_acquisition_fixture.py' or name.startswith('tests/test_c_acquisition_')
 assert digest(ROOT/name)==expected,name
prior=json.loads((ROOT/'artifacts/test-apparatus-audit/resume/scientific-b-round7/accepted-filehashes.json').read_text())
scientific={name:digest(ROOT/name) for name in prior['scientific_files_sha256']}
assert scientific['tests/c_acquisition_fixture.py']=='a64a93dae93864d5b76a2fb54b794a876b76f76527e7018966a681870ee82bf9'
for name,h in scientific.items():
 if name!='tests/c_acquisition_fixture.py':assert h==prior['scientific_files_sha256'][name]
policy=json.loads((A/'policy-exact.json').read_text());assert policy['fixture_sha256']==scientific['tests/c_acquisition_fixture.py'];assert len(policy['rows'])==45 and all(row['exact'] for row in policy['rows']);assert not policy['product_imported']
for group,count in [('guards',9),('policies',36),('overlap',8)]:
 d=json.loads((OUT/('challenge-'+group+'.json')).read_text());assert len(d['cases'])==count and d['all_exact'] and not d['product_imported']
static=json.loads((OUT/'static-proof.json').read_text());assert static['default_ignore_entire_fixture_AST_equivalent_to_624e']
selected=['B9-PACKET.md','B8-PACKET.md','MODE-EQUIVALENCE.md','mode-correction-a64-vs-624e.diff','frozen-manifest-b9.json','fixture-b9.diff','covered8-final-summary.json','covered8-final.xml','covered8-final.log','boundary-b9-summary.json','boundary-b9.xml','boundary-b9.log','policy-exact.json','policy-exact.log','qualify_policy.py','root-types-b9.log','final-evidence.sha256']
evidence={str((A/name).relative_to(ROOT)):digest(A/name) for name in selected}
own={str(p.relative_to(ROOT)):digest(p) for p in sorted(OUT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name not in ('accepted-filehashes.json','final-manifest.log')}
report=dict(verdict='accept exact revised scientific checkpoint; canonical/native/M25/platform/performance/D gates remain',review_round=9,scientific_files_sha256=scientific,evidence_sha256=evidence,own_artifacts_sha256=own,author_manifest69_verified=True,source_free_product_imported=False,blindness_exposure=False,retained_597_proof='624e default-ignore conditional AST/path equivalence only; exact a64 boundary313 and policy/guards renewed',own_executions=dict(substantive_before_final=16,pass_before_final=11,failed_probe_scaffolding_before_final=5,final_manifest_pass=2,artifact_edit_helpers=7,artifact_edit_helpers_outside_runner_stdlib_only=1),actual_model_effort_tokens_cost='unknown; requested Sol/high')
(OUT/'accepted-filehashes.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(verdict=report['verdict'],fixture=scientific['tests/c_acquisition_fixture.py'],author_hashes=len(lines),scientific_pins=len(scientific),own_artifacts=len(own),product_imported=False)))
