"""Observation-only permanent whole-file affinity/isolation evidence."""
import json,os
from pathlib import Path

OUT=Path(__file__).parent / 'valid-owner-observations'
MAPPING = {'tests/test_verification_evidence_outputs.py': 'infrastructure-test_verification_evidence_outputs', 'tests/test_verification_receipt.py': 'infrastructure-test_verification_receipt', 'tests/test_measurements_export.py': 'infrastructure-test_measurements_export', 'tests/test_verification_output_protection.py': 'infrastructure-test_verification_output_protection', 'tests/test_shared_node_baseline_external_native_evidence.py': 'infrastructure-test_shared_node_baseline_external_native_evidence', 'tests/test_source_free_check.py': 'infrastructure-test_source_free_check'}

def record(kind,**data):
    OUT.mkdir(exist_ok=True)
    with (OUT/(str(os.getpid())+'.jsonl')).open('a') as stream:
        stream.write(json.dumps(dict(kind=kind,pid=os.getpid(),**data))+'\n')

def pytest_configure(config):
    import simrecon._pytest_policy as policy
    assert all(policy.PARALLEL_GROUPS.get(name) == group for name, group in MAPPING.items())
    record('configure',worker=getattr(config,'workerinput',{}).get('workerid'),
           coverage_file=os.environ.get('COVERAGE_FILE'),
           coverage_rcfile=os.environ.get('COVERAGE_RCFILE'))

def pytest_collection_finish(session):
    record('collection',worker=getattr(session.config,'workerinput',{}).get('workerid'),
           nodes=[item.nodeid for item in session.items],
           groups=[[mark.args[0] for mark in item.iter_markers('xdist_group')]
                   for item in session.items])

def pytest_runtest_logreport(report):
    record('report',node=report.nodeid,when=report.when,outcome=report.outcome,
           wasxfail=getattr(report,'wasxfail',None))
