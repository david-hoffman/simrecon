# Fresh B9: whole scientific fixture delta plus B8 correction

Frozen current `tests/c_acquisition_fixture.py` and `frozen-b9-a64a.py` SHA256:
`a64a93dae93864d5b76a2fb54b794a876b76f76527e7018966a681870ee82bf9`.
Accepted B7 baseline remains `before/c_acquisition_fixture.py`,
`ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc`.
Nonaccepted B8 checkpoint624e remains `rejected-624e.py`/`frozen_fixture.py`:
`624e5371a4d400be38946f1aeaf9a4d0f897df39789b499af5f412f1dcf40a64`.
Current input manifest/diff: `frozen-manifest-b9.json`/`fixture-b9.diff`.
Original B8 manifest/diff filenames remain preserved with their624e contents.

Review the **whole B7→current delta**, including the new native/full samplers,
cache/error/finite-decision ownership, O>=2/pair(0,b) support, legitimate
alternatives and every unchanged dependent test. B8 halted on a concrete warning
defect and did not accept the remaining full delta. `B8-PACKET.md` describes the
whole earlier proposal and staged probes; its pending statuses are historical.

B8 found a real test-apparatus defect: normal input lower bounds do not prove
high-degree error arithmetic avoids underflow. Its public fixture-only O3/Z1/
Y2/X2 normalized example, side tables/modulation2**-256, changes370 scalar
underflow warnings to228 in624e although all numbers/error bytes/9certs match.
No product defect or manufactured product-red is claimed. The permitted B8
`range_control.py`/JSON evidence remains in sibling `scientific-b8/probes/`.

The correction uses actual NumPy underflow policy for optimization eligibility.
It never changes that policy or filters/replays a warning. Under=`ignore`, the
qualified broader engine remains enabled. Under every other policy, new-family
observations use the existing scalar procedure; prior B7 O2/radial native lanes
and pair(0,1)/Z1/2 radial overlap lanes retain their original eligibility,
per-component caches, full norm metadata and guards. New context sharing,
new-family eligibility, extra headroom/quiet guards and dead norm metadata are
disabled there. Complex nominal0D operations and repeated complex abs/rounding
remain unchanged. Only unused real abs metadata is omitted (bit-only real abs).

`qualify_policy.py`, `policy-exact.json/log`: PASS45 matched cases, with exact
nominal/observer/backend bytes, ordered certificates, warning identities,
callback/log events, caller input nonmutation and restored NumPy settings.
Cases cross accepted B7 O2/radial and new O3/radial/full families, exponents
0/−256/−257, underflow ignore/warn/raise/call/log. The normalized witness now
preserves370 warnings/callbacks/log events and9certs; raise preserves the same
FloatingPointError/empty certificate prefix. Actual warning locations remain in
the JSON; no product modules were imported. Current Ruff format/lint PASS;
authoritative root narrow types PASSexit0/0errors/0warnings/0information on
exacta64 (`root-types-b9.log`, coordinator evidence). Five failed apply_patch lookups
made no edit and remain charged; no extra597 replay is scheduled automatically.

Requested final exacta64 boundary renewal PASS:313cases/16warnings/7.59s,
source-free native coverage, fixed2/loadgroup/no restart; see
`boundary-b9-summary.json` plus XML/log. Existing45 policy cases were reused
without replay because their source hash is unchanged. `MODE-EQUIVALENCE.md`
and `mode-correction-a64-vs-624e.diff` provide the inspected conditional
under=`ignore` path-equivalence argument for B9's retained-proof decision.

`covered8-final.xml/log` retains exact624e normal proof:597passed,18warnings,
226.52s, native coverage active, fixed2/loadgroup/no worker restart, source-free
diagnostics. No source edit occurred during that run. B9 decides retained proof
applicability and any affected expansion; final exact canonical verification
still includes all597 cases/all13 gates/native report integrity/same-run M25.
Full300-second success remains unproved. The earlier complete8 proof does not
override B8 nonacceptance. All source-only/staged probes remain explicitly
distinguished from native full-scope reports. Coverage data remain unread.

All8 test bodies still match accepted B7 hashes (132declarations/420asserts).
No rows, assertions, tolerances, predictor/public calls, validation/rejection,
input nonmutation, warnings or prior26 keeper obligations were removed. Workflow
files and CE08 remain unchanged; root's sanitized import closure confirms CE08
has no fixture dependency. Fresh B9 owns omission/alternative audit; full D and
canonical readiness remain coordinator gates. No Superpowers/delegation/source
exposure. Prior charges, B8 finding,624e proof and all probes remain retained.
Requested Sol/high; actual model/effort/tokens/cost unknown. Own durable evidence
is this directory; no own live probe, `/tmp` scratch, daemon/server or deletion.
All author source/reports/evidence are finalized; `final-evidence.sha256` pins
the final text inputs. Raw native coverage files remain excluded and unread.
