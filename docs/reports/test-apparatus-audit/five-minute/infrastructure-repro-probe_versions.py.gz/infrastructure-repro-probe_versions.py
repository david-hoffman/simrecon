"""Bounded generated-fixture-only paired probe; no repository source edits."""
import hashlib
import json
import os
from pathlib import Path
import shlex
import sys
import time
from importlib.metadata import version

import pytest

ROOT = Path.cwd()
sys.path.insert(0, str(ROOT / 'tests'))
from test_verification_evidence_outputs import (
    DEFAULT_RECEIPT, WHEEL, assert_outcome, invoke, prepare_evidence_repository,
)

OUT = ROOT / 'artifacts/test-apparatus-audit/five-minute/infrastructure'
versions = {tool: version(tool) for tool in ('ruff', 'pyright', 'coverage', 'pytest')}

def stage_versions(target):
    original = target.read_text()
    marker = 'if [ -z "$phase" ]; then\n'
    assert original.count(marker) == 1
    body = '''if [ "$#" = 4 ] && [ "$1" = run ] && [ "$2" = --locked ] && [ "$4" = --version ]; then
    case "$3" in
'''
    for tool, value in versions.items():
        payload = f'{tool} {value}\n'
        body += f'    {tool}) output={shlex.quote(payload)};;\n'
    body += '''    *) output='';;
    esac
    if [ -n "$output" ]; then
        record calls.jsonl "$@"
        record measurement-calls.jsonl "${SIMRECON_MEASUREMENTS_PATH:-}" "${SIMRECON_MEASUREMENTS_RUN_ID:-}" "$@"
        record evidence-calls.jsonl fast '' "$output" '' "${SIMRECON_MEASUREMENTS_PATH:-}" "${SIMRECON_MEASUREMENTS_RUN_ID:-}" "$0" "$@"
        printf '%s' "$output"
        exit 0
    fi
fi
'''
    target.write_text(original.replace(marker,body+marker))

rows=[]
# Keep baseline and staged pairs adjacent. Each invokes unchanged full public
# verifier through its source-free CLI, then unchanged complete assertion owner.
for scenario, arguments in (
    ('safe-nonnative', {}),
    ('safe-native', {'native': True}),
    ('late-report-alias', {'action': {'phase':'audit', 'destination':DEFAULT_RECEIPT, 'target':WHEEL, 'kind':'symlink'}}),
):
    for staged in (False, True):
        variant='staged' if staged else 'baseline'
        case=OUT / 'version-probe-fixtures' / (scenario+'-'+variant)
        case.mkdir(parents=True,exist_ok=False)
        with pytest.MonkeyPatch.context() as patch:
            start=time.perf_counter()
            repository=prepare_evidence_repository(case,patch)
            if staged: stage_versions(repository.bin_dir/'uv')
            prepared=time.perf_counter()
            observation=invoke(repository,**arguments)
            invoked=time.perf_counter()
            assert_outcome(observation)
            finished=time.perf_counter()
            row={'scenario':scenario,'variant':variant,'preparation_seconds':prepared-start,
                 'invoke_seconds':invoked-prepared,'assertion_seconds':finished-invoked,
                 'total_seconds':finished-start,'status':observation.status,
                 'phases':[call['phase'] for call in observation.calls if call['phase']],
                 'tool_version_calls':sum(call['argv'][-1:] == ['--version'] for call in observation.calls),
                 'native_emissions':len(observation.native_emissions),
                 'receipt_result':observation.receipt['result'] if observation.receipt else None,
                 'fixture':str(case),'uv_sha256':hashlib.sha256((repository.bin_dir/'uv').read_bytes()).hexdigest()}
            rows.append(row)
            (OUT/'version-probe-results.json').write_text(json.dumps(rows,indent=2)+'\n')
            print(json.dumps(row),flush=True)
manifest={'head':os.popen('git rev-parse HEAD').read().strip(),'versions':versions,
          'source_hashes':{name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in (
              'tests/test_verification_evidence_outputs.py','tests/verification_fixture_dispatch.py',
              'tests/verification_fixture_tools.py','tests/measurements_fixture_commands.py','scripts/verify.py')},
          'probe_hash':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT/'version-probe-inputs.json').write_text(json.dumps(manifest,indent=2)+'\n')
