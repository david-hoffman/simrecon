import importlib.util,json,sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
ROOT=Path.cwd();OUT=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-b9'
s=importlib.util.spec_from_file_location('b9_overlap',ROOT/'tests/c_acquisition_fixture.py');f=importlib.util.module_from_spec(s);s.loader.exec_module(f)
rows=[]
for z,layout in ((3,'radial'),(1,'full')):
 o=4;y=2;x=4;qshape=(1,1,7,z,y,x//2+1)
 q=(np.arange(np.prod(qshape)).reshape(qshape)+1)/32+1j*(np.arange(np.prod(qshape)).reshape(qshape)+3)/64
 bands=SimpleNamespace(input_shape=(1,1,7,z,y,x),dxy_um=1.,dz_um=.5,quadratures=f.Disc(q),noise_variance_factors=f.Disc(np.ones((1,1,o))))
 hs=np.array([1+.25j,.75-.25j,.25+.125j,.5-.125j]);tshape=(o,16,z) if layout=='radial' else (o,1,16,16)
 table=SimpleNamespace(samples=f.Disc(np.broadcast_to(hs.reshape((o,)+(1,)*(len(tshape)-1)),tshape).copy()),layout=layout,dkr_cyc_um=.125,dkz_cyc_um=2.)
 actual=f.overlaps(bands,table,np.zeros(2),(0,3),**f.optics())
 expected=np.zeros((2,z,y,x),complex);written=np.zeros(expected.shape,bool)
 for iy,ix in np.ndindex(y,x):
  qx=(ix if ix<=x//2 else ix-x)/x;qy=(iy if iy<=y//2 else iy-y)/y
  if np.hypot(qx,qy)>.5:continue
  ha,hb=hs[0],hs[3]
  if layout=='full' and qx<0:ha,hb=np.conj(ha),np.conj(hb)
  denom=np.sqrt(abs(ha)**2+abs(hb)**2)
  for h in ((-1,0,1) if z==3 else (0,)):
   slots=q[0,0,:,h%z,iy,ix] if ix<=x//2 else np.conj(q[0,0,:,(-h)%z,(-iy)%y,x-ix])
   expected[0,h%z,iy,ix]=slots[0]*hb/denom
   expected[1,h%z,iy,ix]=(slots[5]+1j*slots[6])*ha/denom
   written[:,h%z,iy,ix]=True
 assert np.array_equal(np.asarray(actual['written']),written)
 assert np.allclose(np.asarray(actual['fourier']),expected,rtol=2e-15,atol=2e-15)
 spatial=np.zeros_like(expected)
 for side,h,i,j in np.ndindex(spatial.shape):
  spatial[side,h,i,j]=sum(expected[side,hh,ii,jj]*np.exp(2j*np.pi*(hh*h/z+ii*i/y+jj*j/x)) for hh,ii,jj in np.ndindex(z,y,x))
 # At most 32 real roundings per term cover phase/product/sum and the staged transform.
 n=z*y*x;g=(32*n*2.**-53)/(1-32*n*2.**-53)
 bounds=np.array([g*sum(abs(expected[side]).reshape(-1)) for side in range(2)])
 differences=np.max(abs(np.asarray(actual['spatial'])-spatial),axis=(1,2,3))
 assert np.all(differences<=bounds),(z,layout,differences,bounds)
 rows.append(dict(layout=layout,z=z,pair=[0,3],written=int(written.sum()),fourier_cells=int(expected.size),spatial_cells=int(spatial.size),spatial_absolute_bound=bounds.tolist(),spatial_max_difference=differences.tolist()))
assert not any(n=='simrecon' or n.startswith('simrecon.') for n in sys.modules)
report=dict(rows=rows,product_imported=False);(OUT/'closed-overlap.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
