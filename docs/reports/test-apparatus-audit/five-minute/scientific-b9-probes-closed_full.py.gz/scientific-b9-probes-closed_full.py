import importlib.util,json,sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
ROOT=Path.cwd();OUT=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-b9'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);f=importlib.util.module_from_spec(s);s.loader.exec_module(f);return f
f=load('b9_full',ROOT/'tests/c_acquisition_fixture.py')
def bits(v):
 return [(np.asarray(x).dtype.str,np.asarray(x).shape,np.asarray(x).tobytes().hex()) for x in (v,v.observer,v.backend)]
# A tensor affine field has exact trilinear truth, with all-coordinate reflection.
a=np.empty((2,2,4,4),complex)
for o,z,y,x in np.ndindex(a.shape):a[o,z,y,x]=(3+o+2*x+4*y+8*z)+1j*(1-o+x-2*y+3*z)
t=SimpleNamespace(samples=f.Disc(a,2**-40,2**-42),layout='full',dkr_cyc_um=1.,dkz_cyc_um=1.)
queries=[(.25,.5,0),(-.25,-.5,0),(0.,0.,1),(3.,0.,0),(1.,3.5,0),(-0.,.5,0)]
query=f._full_zero_samples(t,f.Disc(1.),f._batch_range_limit(1));packed=query(queries)
rows=[]
for n,(x,y,o) in enumerate(queries):
 value=f._lane_scalar(packed,n);scalar=f.sample(t,x,y,0,1.,o)
 if x<0:xx,yy=-x,-y
 else:xx,yy=x,y
 # Periodic y interpolation or literal flat x alias, specified by CE03 actual vertices.
 iy=int(np.floor(yy if yy>=0 else yy+4));ix=int(np.floor(xx));ay=(yy if yy>=0 else yy+4)-iy;ax=xx-ix
 lo=(1-ax)*a[o,0].reshape(-1)[iy*4+ix]+ax*a[o,0].reshape(-1)[iy*4+ix+1]
 hi=(1-ax)*a[o,0].reshape(-1)[((iy+1)%4)*4+ix]+ax*a[o,0].reshape(-1)[((iy+1)%4)*4+ix+1]
 expected=(1-ay)*lo+ay*hi
 if x<0:expected=np.conj(expected)
 assert np.asarray(value)==expected,(x,y,o,value,expected)
 assert bits(value)==bits(scalar),(x,y,o)
 rows.append(dict(query=[x,y,o],expected=[expected.real,expected.imag],exact_scalar=True))
# Same raw nominal with distinct uncertainty must retain distinct cache keys.
q=f._full_zero_samples(t,1.,f._batch_range_limit(1))
x1=f.Disc(.25,2**-30,2**-32);x2=f.Disc(.25,2**-29,2**-31)
p=q([(x1,.5,0),(x2,.5,0)])
for n,x in enumerate((x1,x2)):assert bits(f._lane_scalar(p,n))==bits(f.sample(t,x,.5,0,1.,0))
assert p[1][0]!=p[1][1]
# Returned lane extraction and one query's result cannot mutate cache or another result.
saved=bits(f._lane_scalar(p,0));v=f._lane_scalar(p,0);v[...]=987;v.observer[...]=456
assert bits(f._lane_scalar(q([(x1,.5,0)]),0))==saved
# Last lateral zero-weight vertex is mandatory; a source-safe cross-row alias above succeeded.
bad=SimpleNamespace(samples=f.Disc(np.ones((2,1,1,1),complex)),layout='full',dkr_cyc_um=1.,dkz_cyc_um=1.)
assert f._full_zero_samples(bad,1.,f._batch_range_limit(1))([(0.,0.,0)]) is None
try:f.sample(bad,0.,0.,0,1.,0)
except AssertionError as e:assert str(e)=='independent unsafe full stencil'
else:raise AssertionError('zero-weight stencil was skipped')
assert not any(n=='simrecon' or n.startswith('simrecon.') for n in sys.modules)
report=dict(rows=rows,uncertainty_keys=2,cache_ownership=True,zero_weight_rejection=True,product_imported=False)
(OUT/'closed-full.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
