import importlib.util,json,sys,warnings,os,tempfile,traceback
from pathlib import Path
from types import SimpleNamespace
import numpy as np
ROOT=Path.cwd();OUT=ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-b9';MODE=sys.argv[1]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);f=importlib.util.module_from_spec(s);s.loader.exec_module(f);return f
old=load('b9_challenge_old',ROOT/'artifacts/test-apparatus-audit/five-minute/scientific-a/before/c_acquisition_fixture.py');new=load('b9_challenge_new',ROOT/'tests/c_acquisition_fixture.py')
def freeze(v):
 if isinstance(v,np.ndarray):return [v.dtype.str,v.shape,v.strides,v.flags.writeable,np.asarray(v).tobytes().hex()]+([freeze(v.observer),freeze(v.backend)] if hasattr(v,'observer') else [])
 if isinstance(v,dict):return {k:freeze(x) for k,x in v.items()}
 if isinstance(v,(tuple,list)):return [freeze(x) for x in v]
 if isinstance(v,(np.generic,float,complex)):return freeze(np.asarray(v))
 return v
class Events:
 def __init__(self,fail=False):self.items=[];self.fail=fail
 def __call__(self,m,flag):
  self.items.append([m,int(flag)])
  if self.fail and len(self.items)==7:raise RuntimeError('seventh callback sentinel')
 def write(self,m):self.items.append(m)
def run(f,c):
 o,z,layout,op,flavor,mode=c
 shape=(1,1,2*o-1,z,2,2)
 values=(np.arange(np.prod(shape)).reshape(shape)+1)/16+1j/8
 bands=SimpleNamespace(input_shape=shape,acquisition_mode='2d' if z==1 else '3d',dxy_um=1.,dz_um=.5,lateral_zoom=1.,axial_zoom=1,quadratures=f.Disc(values),noise_variance_factors=f.Disc(np.arange(1,o+1)[None,None,:].astype(float)))
 tshape=(o,16,z) if layout=='radial' else (o,z,16,16)
 samples=np.full(tshape,1+.125j)
 table=SimpleNamespace(samples=f.Disc(samples,2**-48,2**-47),layout=layout,dkr_cyc_um=.125,dkz_cyc_um=2.)
 carriers=f.Disc(np.array([[.07,-.02]]));mod=f.Disc(np.full((1,o-1),.5+.25j))
 if flavor=='tiny':carriers=f.Disc(np.array([[2.**-1000,-2.**-999]]))
 if flavor in ('tiny-table','callback-fail'):
  table.samples[1:]=2.**-256;mod[...]=2.**-256
 if flavor=='subnormal-errors':bands.quadratures.observer.fill(np.nextafter(0.,1.))
 if flavor=='float32-errors':bands.quadratures.observer=bands.quadratures.observer.astype('f4')
 if flavor=='subclass':
  class Foreign(f.Disc):pass
  bands.quadratures=bands.quadratures.view(Foreign)
 if flavor=='readonly-strided':
  for v in (bands.quadratures,table.samples):
   v.flags.writeable=False;v.observer.flags.writeable=False;v.backend.flags.writeable=False
  carriers=carriers[:,::-1];mod=mod[:,::-1]
 if flavor=='uncertain':carriers=f.Disc(np.array([[.07,-.02]]),2**-36,2**-38)
 if flavor=='ambiguous':carriers=f.Disc(np.zeros((1,2)),2**-30,2**-32)
 if flavor=='unsafe':table.samples=f.Disc(np.ones((o,1,1,1),complex));table.layout='full'
 if flavor=='high-carrier':carriers=f.Disc(np.array([[2.**29,-2.**29]]))
 saved=freeze((bands.quadratures,bands.noise_variance_factors,table.samples,carriers,mod));f.CERTIFICATES.clear();calls=[];exception_locations=[];events=Events(flavor=='callback-fail');prior=np.geterrcall();policy=np.geterr().copy()
 with tempfile.TemporaryFile() as sink:
  saved_fd=os.dup(2)
  try:
   os.dup2(sink.fileno(),2);np.seterrcall(events)
   with warnings.catch_warnings(record=True) as seen,np.errstate(under=mode):
    warnings.simplefilter('always')
    try:
     if op=='native':value=f.reconstruct_expected(bands,table,carriers,mod,**f.known_options())
     else:
      def custom(*args):
       calls.append([freeze(x) for x in args])
       if flavor=='custom-fail' and len(calls)==5:raise ValueError('fifth sampler sentinel')
       return f.sample(table,*args)
      kwargs={'sampler':custom} if flavor in ('custom','custom-fail') else {}
      value=f.overlaps(bands,table,carriers[0],(0,o-1),**f.optics(),**kwargs)
     outcome=['return',freeze(value)]
    except Exception as e:
     outcome=[type(e).__name__,str(e)]
     exception_locations=[(frame.f_code.co_filename,line,frame.f_code.co_name) for frame,line in traceback.walk_tb(e.__traceback__)]
   ids=[(w.category.__name__,str(w.message)) for w in seen];locations=[(w.filename,w.lineno) for w in seen]
  finally:np.seterrcall(prior);os.dup2(saved_fd,2);os.close(saved_fd)
  sink.seek(0);printed=sink.read().decode()
 assert policy==np.geterr();assert saved==freeze((bands.quadratures,bands.noise_variance_factors,table.samples,carriers,mod))
 return [outcome,freeze(f.CERTIFICATES),ids,events.items,printed,calls],dict(warnings=locations,exception=exception_locations)
if MODE=='guards':
 cases=[(2,1,'radial','native',v,'ignore') for v in ('tiny','subnormal-errors','float32-errors','subclass','readonly-strided')]+[(3,1,'full','native',v,'ignore') for v in ('uncertain','ambiguous','unsafe','high-carrier')]
elif MODE=='policies':
 cases=[(o,1,l,'native',v,m) for o,l in ((2,'radial'),(3,'radial'),(3,'full')) for v in ('tiny-table','callback-fail') for m in ('ignore','warn','print','call','log','raise')]
elif MODE=='overlap':
 cases=[(o,z,l,'overlap',v,m) for o,z,l,v,m in [(3,3,'radial','normal','ignore'),(4,1,'full','normal','ignore'),(3,1,'full','custom','ignore'),(3,1,'full','custom-fail','ignore'),(2,2,'radial','tiny-table','warn'),(2,2,'radial','tiny-table','print'),(3,3,'radial','normal','call'),(3,1,'full','normal','log')]]
else:raise ValueError(MODE)
rows=[]
for c in cases:
 a,aloc=run(old,c);b,bloc=run(new,c)
 row=dict(case=c,exact=a==b,outcomes=[a[0][0],b[0][0]],certificates=[len(a[1]),len(b[1])],warnings=[len(a[2]),len(b[2])],events=[len(a[3]),len(b[3])],printed_lines=[len(a[4].splitlines()),len(b[4].splitlines())],custom_calls=[len(a[5]),len(b[5])],diagnostic_locations=[aloc,bloc]);rows.append(row)
 if a!=b:
  (OUT/('challenge-'+MODE+'-failure.json')).write_text(json.dumps(dict(row=row,old=a,new=b),indent=2)+'\n');raise AssertionError(row)
assert not any(n=='simrecon' or n.startswith('simrecon.') for n in sys.modules)
report=dict(cases=rows,product_imported=False,all_exact=True);(OUT/('challenge-'+MODE+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(group=MODE,cases=len(rows),all_exact=True,rows=[{k:v for k,v in r.items() if k!='diagnostic_locations'} for r in rows])))
