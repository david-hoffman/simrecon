"""Independent exact fixture-equivalence and quietness challenges."""
import importlib.util
import sys
import warnings
from pathlib import Path
import numpy as np

root = Path('/workspace/simrecon')
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, root / path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod
old = load('prior7', 'artifacts/test-apparatus-audit/resume/scientific-a/round7-before/tests/c_acquisition_fixture.py')
new = load('now7', 'tests/c_acquisition_fixture.py')

def bits(value):
    arr = np.asarray(value)
    return arr.dtype.str, arr.shape, arr.strides, arr.flags.writeable, arr.tobytes()
def freeze(plane):
    return bits(plane), bits(plane.observer), bits(plane.backend)
def input_for(m, kind, shape):
    arr = np.arange(np.prod(shape), dtype=float).reshape(shape)/16 - 1
    value = m.Disc(arr, 2.**-43, 2.**-39)
    if kind == 'cancel-low':
        np.asarray(value)[:] = 2.**-256
        np.asarray(value)[-1, -1] = np.nextafter(2.**-256, np.inf)
        value.observer[:] = value.backend[:] = 0
    if kind == 'high-error': value.observer[:] = value.backend[:] = 2.**256
    if kind == 'error-low': value.observer[:] = value.backend[:] = 2.**-256
    if kind == 'subnormal': np.asarray(value)[:] = np.finfo(float).smallest_subnormal
    if kind == 'sNaN': np.asarray(value).view(np.uint64)[0, 0] = 0x7ff0000000000001
    if kind == 'infinite-error': value.backend[-1, -1] = np.inf
    if kind == 'negative-error': value.observer[0, 0] = -1.
    if kind == 'f32-error': value.backend = value.backend.astype(np.float32)
    if kind == 'matrix-error': value.backend = np.asmatrix(value.backend)
    if kind == 'readonly':
        np.asarray(value).flags.writeable = False
        value.observer.flags.writeable = False
        value.backend.flags.writeable = False
    if kind == 'reversed':
        value = value[::-1, ::-1]
        value.observer = value.observer[::-1, ::-1]
    if kind == 'subclass':
        class Sub(m.Disc): pass
        value = Sub(arr, 2.**-43, 2.**-39)
    if kind == 'error-alias':
        np.asarray(value)[:] = abs(arr)
        value.observer = np.asarray(value)
        value.backend = value.observer
    return value

def run(m, kind, shape, width, bead, policy):
    plane = input_for(m, kind, shape)
    original = freeze(plane)
    m.CERTIFICATES.clear()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter('always')
        with np.errstate(all=policy):
            try:
                result = m.edge(plane, width, bead=bead)
                outcome = ('return', freeze(result), np.shares_memory(result, plane), np.shares_memory(result.observer, plane.observer), np.shares_memory(result.backend, plane.backend))
            except Exception as error:
                trace = error.__traceback__
                locations = []
                while trace:
                    locations.append((trace.tb_frame.f_code.co_filename, trace.tb_lineno, trace.tb_frame.f_code.co_name))
                    trace = trace.tb_next
                outcome = (type(error).__name__, str(error))
                diagnostic_locations.append((kind, policy, locations))
    assert original == freeze(plane), 'input mutated'
    assert not m.CERTIFICATES
    identities = [(w.category.__name__, str(w.message)) for w in caught]
    warning_locations.extend((kind, policy, w.filename, w.lineno, w.category.__name__, str(w.message)) for w in caught)
    return outcome, identities

warning_locations = []
diagnostic_locations = []
count = 0
for kind in ('ordinary', 'cancel-low', 'high-error', 'error-low', 'subnormal', 'sNaN', 'infinite-error', 'negative-error', 'f32-error', 'matrix-error', 'readonly', 'reversed', 'subclass', 'error-alias'):
    for width in (0, 2):
        for policy in ('warn', 'raise'):
            assert run(old, kind, (3, 4), width, False, policy) == run(new, kind, (3, 4), width, False, policy), (kind, width, policy)
            count += 1
for shape, width, bead in [((10,8),10,True), ((4,1),1,True), ((3,1),1,True), ((2,4),3,False), ((4,2),2,True), ((0,3),0,False), ((3,0),1,False), ((2,4),-1,False), ((2,4),-3,False)]:
    for policy in ('warn', 'raise'):
        assert run(old, 'ordinary', shape, width, bead, policy) == run(new, 'ordinary', shape, width, bead, policy), (shape, width, bead, policy)
        count += 1
# Factor evaluations are lazy, and multiplication leaves each retained scalar
# and its independent error columns untouched throughout pixel processing.
for m in (old, new):
    orig_sin = m.sin
    factors = []
    def counted(value):
        result = orig_sin(value)
        factors.append((result, freeze(result)))
        return result
    m.sin = counted
    m.edge(m.Disc(np.arange(12.).reshape(3,4)/16, 2.**-40, 2.**-38), 2)
    m.sin = orig_sin
    assert all(freeze(value) == saved for value, saved in factors)
    assert len(factors) == (14 if m is old else 2)
assert not any(name == 'simrecon' or name.startswith('simrecon.') for name in sys.modules)
print(f'PASS {count} exact old/current controls and 2 factor immutability/count controls; no product imported')
print('Retained warning locations:', warning_locations)
print('Retained exception locations:', diagnostic_locations)
