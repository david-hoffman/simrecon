# Fresh blind scientific B review

Verdict: accept the exact scientific test checkpoint. No actionable finding
remains in this optimization and preservation review. The complete affected
14-suite focused run passed and all 16 scoped file hashes were independently
confirmed afterward. This is one completed fresh B review round, not canonical
full verification, platform qualification or a coverage report.

## Authority and reviewed checkpoint

The authorized work optimizes only test-owned apparatus, preserving every
C-equivalent scientific obligation, example, assertion, tolerance and independent
on-demand oracle. No new scientific meaning or production correction is allowed.
The four candidate scientific files are frozen at:

| File | SHA-256 |
| --- | --- |
| tests/c_acquisition_fixture.py | 82198507fa1c799bf5b34e58d21cf55ea4c9288fde5dfec6dfe137e98170e127 |
| tests/c_workflow_support.py | 10265f0a62703ee30f136e00559cbbc8fbda470cf01213c7487bb39ff7705902 |
| tests/test_c_acquisition_composition.py | 5337985855e5e41c96c7b323ff18519e4841d41b2cda1eb51becb9cef28a0158 |
| tests/test_c_workflow_numerical.py | 82497fe024d5b6dca96feb4821f1f5fa49e34e980fa3d671c1f8628b6321b3c5 |

B independently read and compared the allowed current and prior test bytes,
inspected changed helper implementations and their call paths, and checked the
14-suite declaration/decorator/assertion inventory. The public authority is
AGENTS.md, the B review role, test-audit public authoring/preservation criteria,
PROJECT public interfaces/coverage policy/commands and the supplied CE common,
rebuild, preprocessing, optical-transfer, known-parameter, carrier/modulation,
acquisition-mode/ledger, workflow/map and independent-acceptance contracts.
No linked source/archive/history was followed.

## Preservation and evidence applicability

All 188 scoped declarations retain themselves as keepers. Every parameter
decorator and row expression is unchanged. Independent AST comparison finds
543 explicit assert statements before and after. All acquisition test bodies
are unchanged. Only three workflow numerical test bodies differ, by the stated
calibration/budget reuse. Total calls inside test declarations are 3637 before
and 3635 after; the two removed calls are redundant empirical/error-budget
calculations, not assertions. The assertions' values/tolerances remain the same;
the single changed assert expression references the already computed identical
budget entry instead of recomputing that entry.

The newly supplied baseline-test-hashes.json was independently checked against
all 14 prior snapshots and current bytes. Twelve whole suite files are byte
identical to the accepted baseline. The other two differ only as reviewed.
A's declaration ledger hashes/counts agree with independent calculation. The
723 global declaration / 3087 baseline native-example counts are coordinator
baseline evidence, not a fresh B global collection claim. No deletion,
consolidation or lost keeper was found.

Shared Disc/public-observer behavior expands affected scope to all eight
acquisition suites and all six workflow suites. Historical accepted obligation
and test-design evidence remains applicable to byte-identical assertions,
rows, examples and unchanged independent equations. Historical execution alone
cannot establish the changed shared apparatus; the passing full expanded focused
run now supplies current execution evidence. Unchanged CE08 acceptance oracles and
omission guards retain their prior meaning and require the coordinator's exact
candidate full verification; this B review grants no waiver of them.

## Independent risk disposition

- Local cache lifetime and table mutation: each closure is created inside one
  owning reconstruction, overlap, parameter-model or independent-factor call.
  No cache enters a global or returned scientific record. The table samples,
  layout and increments are fixed while that owner executes; the loops make
  no product call capable of changing them. A new invocation makes a new cache.
  Mutable tables are therefore not silently shared across separate cases.
- Complete keys: nominal, observer and backend dtype/shape/bytes all enter each
  coordinate component. Full tables retain both signed lateral components,
  axial integer, order and complete native-dkz component. Radial sharing is
  justified only by the exactly recomputed certified u=hypot(kx,ky)/dkr;
  nominal-radius-only or approximate angular symmetry is not used. The unchanged
  sample depends on radial lateral coordinates only through that exact u.
- Signs and alternatives: negative-x full reflection still flips all coordinates
  and conjugates; x=0 and negative zero remain nonreflected. Keys retain signed
  zero and dtype distinctions. Separate observer/backend distributions cannot
  collide merely because total error is equal. All actual callers pass integer
  axial/order values. Threshold decisions are still evaluated on every use;
  threshold_choices is consumed independently per reached decision, preserving
  the explicit sensitivity alternatives without imposing extra mask symmetry.
- Errors and cache aliasing: misses execute the unchanged on-demand sampler,
  including every actual zero-weight stencil vertex. No failure is cached as a
  value. Identical successful keys on a fixed table cannot later become unsafe.
  Cached scalars feed nonmutating absolute/conjugate/product/quotient operations;
  writes target independent coefficient/temporary arrays. Neither the nominal
  cache value nor either uncertainty column is modified by callers.
- Disc allocations: conversion to independently owned float64 C-order error
  columns still precedes positive outward nextafter. Zero signs and positive
  values retain exact bits. The constructor copies the supplied error columns,
  so removing earlier copies preserves independence. Ordinary ndarray views
  still obtain zeros; inherited views retain the same attributes. Matching-shape
  direct error references are read only by propagation. propagate(obs) has no
  mutation, certificate append or dependence on changing state, so one result
  can replace its second identical computation.
- Invariant hoists: the finite-sum x/y/z matrices depend only on fixed input/
  output geometry and are never modified by contractions. First-carrier norm,
  carrier-error flag and suppression radius are invariant within one call.
  Time-specific noise/Wiener/modulation, direction/order arithmetic, signed
  support inequalities and native-filter-before-relocation remain inside their
  original loops. No reduction order, independent truth or tolerance changed.
- Workflow reuse: observe(case) computes calibration independently from raw
  beads before any product run, and uses it without modifying it. Reusing that
  same calibration does not turn product output into truth. The explicit reused
  budget belongs to the same case/truth pair and is consumed read-only by both
  absolute assertion sets. Raw/precomputed diagnostic accuracy, complex128
  preservation, later mutation isolation and both selection paths remain.

These conclusions challenge the concrete risks introduced by this optimization.
They do not assert that every possible scientific behavior has been proved.
The retained controls distinguish complex/sign/scale, threshold/strict-tie,
unsafe-vertex, native-before-relocation, positive/zero/negative and ownership
alternatives. No high-impact missing approved behavior attributable to this
change was found. The inherited coverage policy selects no percentage target;
all required native reports and full gates remain mandatory.

## Checks and numerical evidence

B used scripts/source_free_check.py and its inspected source-free diagnostic
support before every fixture/oracle probe. No probe imported scientific runtime
or supplied product output as an expectation. No pytest/full/heavy test ran in
parallel with A's focused proof.

1. Static current/prior SHA-256 and AST comparisons passed for all 14 suite
   files and the four candidate files; decorators, declarations and assertion
   counts agree with the preservation ledger. Plain difflib compared only
   permitted test snapshots, never Git diffs/history.
2. Source-free fixture-only probe: 694 checks passed. It compares prior/current
   exact nominal/error dtype, shape, strides, writability and bytes; checks
   float16/32/64 and endian conversion, signed zero/subnormal/positive error
   inputs, read-only/broadcast/strided errors, copy independence, asymmetric
   radial/full tables with table uncertainty, native-dz/axial/order changes,
   both uncertainty columns, coordinate mutation and cached-read nonmutation.
   Every cached value is compared against both unchanged prior arithmetic and
   independent on-demand current sample.
3. Independent closed interpolation arithmetic passed: radial positive axial
   sample 2.203125+0.04296875i, radial negative axial wrap
   2.234375+0.03515625i, and full negative-x/all-axis/conjugated sample
   2.4296875+0.0009765625i, from independently specified linear complex tables
   and binary-exact fractional weights. Four direct/cached final-allocation
   zero-weight stencil rejections also passed.
4. Source-free pure workflow-oracle check passed all six affected row families:
   empirical-z1/z2 and search-3d/2d-reuse/all-times. Repeated error_budget results
   are byte-identical, case/truth snapshots remain unchanged, and recomputing
   empirical calibration exactly matches observe(case)['calibration'].
5. A's permitted exact-equivalence.json and qualifier script were reviewed.
   Its five exact sections pass and preserve warning/category lists and complete
   certificate lists. These supplement, rather than replace, the independent
   derivation/call-path/alias review above.
6. A's current expensive False row passes, 1 passed in 171.57 s. B then
   independently inspected focused14.log, focused14.xml and
   focused14-summary.json: 1083 passed, 18 source-free warnings, 578.07 s.
   XML contains exactly 1083 testcase nodes across all 14 expected suites and
   zero failures, errors or skips; every per-file node count matches the summary.
   A/coordinator confirm fixed two workers, loadgroup, no restart and the
   source-free harness. B independently rehashed all 16 scoped scientific files
   after this result; every hash matches the reviewed checkpoint. The accepted
   filehash manifest also pins these focused evidence files. Existing invalid-
   input warning categories/messages/locations remain visible; no warning was
   suppressed to create the pass.

One first supplemental probe failed because B incorrectly assumed that z=100
must make a radial flat address unsafe. The approved source stencil permits an
in-allocation cross-row alias; both prior/current oracles returned success.
Changing only diagnostic z to1000 reached the intended out-of-allocation error,
and the corrected probe passed. This was B's diagnostic-input defect, not a
candidate defect or product-red evidence. Candidate bytes were never changed.

## Exposure, accounting and scratch

One fresh B launch; one completed review round accepted; zero candidate corrections.
One diagnostic probe failure and one probe-input correction are retained above;
three successful source-free supplemental command families followed. No
production implementation, Git history/log/diff, implementation-bearing task
state, nonblind audit report/ledger, raw profile/log, coverage map or lesson was
read. The policy skill was read more broadly than the requested subsection,
but no forbidden implementation or historical evidence was exposed. No
Superpowers, delegation, production/test/gate edits, commits or external message.

Own temporary probe.py was the only scratch file, created under scientific-b;
it has been removed after retaining its results here. All owned probe processes have exited;
there is no owned daemon/server. Durable output is this report plus accepted-filehashes.json.
Canonical full verification, all required native coverage/platform reports,
unchanged acceptance/omission-guard proof and the overall runtime goal remain
coordinator gates; this scientific checkpoint acceptance does not claim them. No human total/review/scenario/token/money limit
was supplied. Actual served attribution, effort, token metering and monetary
cost are unknown, not zero. Earlier author/coordinator charges are not reset
or counted again by this report.
