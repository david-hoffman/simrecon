# Blind scientific A: frozen static checkpoint

Status: all 14 affected suites pass on the frozen scientific checkpoint; fresh
blind B acceptance and canonical verification remain coordinator gates.
This report contains test-owned observations and public contracts only. It is
not a full verification or native-coverage report.

## Scope and preservation

The authorized change removes repeated test-owned work while retaining every
scientific obligation, input example, tolerance and assertion. No scientific
runtime, discovery, coverage, runner, CE08 acceptance or PR83 change is owned here.
The inherited policy is approved behavior coverage with independent risk review;
percentages are advisory and complete native reports remain mandatory
(`docs/PROJECT.md`, coverage-policy section).

Exactly four scientific files changed. SHA-256 values for this frozen checkpoint:

| File | SHA-256 |
| --- | --- |
| tests/c_acquisition_fixture.py | 82198507fa1c799bf5b34e58d21cf55ea4c9288fde5dfec6dfe137e98170e127 |
| tests/c_workflow_support.py | 10265f0a62703ee30f136e00559cbbc8fbda470cf01213c7487bb39ff7705902 |
| tests/test_c_acquisition_composition.py | 5337985855e5e41c96c7b323ff18519e4841d41b2cda1eb51becb9cef28a0158 |
| tests/test_c_workflow_numerical.py | 82497fe024d5b6dca96feb4821f1f5fa49e34e980fa3d671c1f8628b6321b3c5 |

`declaration-preservation.json` records every declaration in the 14 affected
test files, its self-keeper and disposition R, source location, assertion count
and unchanged parameter decorators: 188 scoped declarations retained. Static
inventory still contains 723 test declarations globally. The coordinator supplied
the passing baseline count of 3087 collected nodes; this author has not yet rerun
full collection and makes no new exact-node acceptance claim. No test declaration,
parameter row, example, scientific observer, tolerance or omission guard was removed.
Every baseline obligation stays at its existing test/self-keeper. The three
CE08 acceptance suites and their independent on-demand oracles remain unchanged.

## Changes and complete dependencies

| Changed helper or call | Exact removal of repeated work | Dependent proof scope |
| --- | --- | --- |
| Disc.__new__ | One C-order independent float copy per error column; positive outward nextafter writes into that copy instead of allocating a nextafter result plus where result | All eight acquisition suites below; retain nominal/error bytes, ownership, dtype/layout, signed zero and outward rounding |
| Disc.__array_finalize__ | Allocate zero fallback only when the source attribute is absent | All eight acquisition suites; inherited views and ordinary-ndarray views remain covered |
| Disc.copy | Constructor already copies error columns; remove the preceding copies | All eight acquisition suites; copied nominal/observer/backend storage remains independent |
| Disc.__array_ufunc__ | Reuse identical propagate(obs); use matching-shape Disc error arrays directly instead of identical broadcast wrappers | All eight acquisition suites; retain arithmetic order, complex/real rounding, in-place behavior, fallback broadcasting and primitive-domain failures |
| reconstruct_expected | Reuse identical Fourier matrices, first-carrier norm, varying-error flag and suppression radius within one call; local_samples reuses identical table queries | All eight acquisition suites via public-call prediction; direct consumers in acquisition 2d, composition, filter and transfer; every native filtered coefficient, signed image, physical coordinate and divisor certificate remains checked |
| local_samples / overlaps | Invocation-local pure query reuse; optional sampler shares queries across one owning helper's overlap builds | Direct overlaps consumers: acquisition 2d and composition; fixture finite_search and parameter_model; all eight acquisition suites transitively via wrapped public prediction |
| parameter_model | One local sampler for its known/reused-carrier overlap builds | All acquisition estimator consumers; search still executes its unchanged finite procedure; overlap support/threshold and final fit arithmetic remain unchanged |
| composition.independent_factors | One local sampler for this existing independent owner invocation, passed into its existing overlaps calls | All seven declarations and all parameter rows in test_c_acquisition_composition.py through composition; no test body/assertion/parameter change |
| assert_scientific | Optional explicit budget reuse for one unchanged case/truth pair | Direct callers in workflow numerical, records, compatibility, failures; sibling known and validation retained |
| complete workflow empirical branch | Reuse independent expected['calibration'] instead of independently recomputing the same empirical result | All original complete-workflow empirical rows; table complex128 values, dkz and complete calibration diagnostics retain identical comparisons |
| literal finite-search test | Retain one complete error_budget result for parameter bounds and modulation threshold | All four existing search rows, all decision/overlap/reuse assertions retained |
| raw/precomputed empirical test | Pass existing budget to both unchanged absolute assert_scientific assertion sets | Both z rows; raw/precomputed selection, full diagnostic accuracy, snapshot isolation and mutation controls retained |

Complete affected suites, with every declaration/row retained:

- tests/test_c_acquisition_2d.py
- tests/test_c_acquisition_boundary.py
- tests/test_c_acquisition_composition.py
- tests/test_c_acquisition_drift.py
- tests/test_c_acquisition_filter.py
- tests/test_c_acquisition_fitted_drift.py
- tests/test_c_acquisition_preparation.py
- tests/test_c_acquisition_transfer.py
- tests/test_c_workflow_00_known.py
- tests/test_c_workflow_compatibility.py
- tests/test_c_workflow_failures.py
- tests/test_c_workflow_numerical.py
- tests/test_c_workflow_records.py
- tests/test_c_workflow_validation.py

The existing public contracts remain the only science sources: common/rebuild,
preprocessing, optical transfer, known parameters, carrier/modulation,
acquisition modes and ledger, workflow and map, independent acceptance v1.
In particular CE07 WF035–WF061, WF067–WF080 and WF096–WF098 retain complete
preparation, literal finite decisions, actual fitted-factor consumption, native
filtering/assembly, scale and independent conditional tolerances.

## Query key and alias review

Each local_samples closure owns a private dictionary and one fixed test-owned
table. Its lifetime is one reconstruct_expected, overlaps, parameter_model or
independent_factors invocation. No closure/cache enters a returned record or a
module global. No product call occurs inside those observer loops. Table samples,
layout and increments stay unchanged within each owning invocation. Native dz
is fixed for those geometries and is included in the key regardless.

The radial branch of the unchanged on-demand sample depends on kx/ky only through
its exact computed Disc u=hypot(as_disc(kx),as_disc(ky))/dkr. The cache recomputes
that same intermediate for its key, including nominal dtype/shape/bytes and both
uncertainty-column dtype/shape/bytes. It does not assume nominal symmetry or
merge unequal errors. Full layout retains both signed coordinate components,
including their complete nominal/error metadata, preserving negative-x
conjugation and wrapped-y semantics. Both layouts also key axial integer, order
and the full native-dz component. The table is an immutable closure dependency.
Signed-zero bits are retained in all keyed components; strict overspecification
of a key may miss reuse but cannot manufacture agreement.

sample remains independently callable without any cache and retains its original
scalar arithmetic, finite stencil checks and errors. Cached scalar results are
only read by overlaps/reconstruct_expected: subsequent abs, conjugation, powers,
products and quotient operations create their own results; writes target distinct
fourier/temporary/filtered arrays. Fresh invocations get fresh caches. B should
independently challenge these dependency and nonmutation facts, radial factoring,
full-layout reflection, changed uncertainty/dtype inputs, invalid/zero-weight
stencils, threshold sensitivity, strict ties, and permitted positive alternatives.

## Supplemental exact evidence

`qualify_exact.py` imports only the permitted prior/current test fixture modules.
It compares nominal arrays and both error columns by exact dtype/shape/strides,
writability and SHA-256 bytes, recursively compares scalar bits and complete
certificate lists, and compares warning category/message lists and deliberate
certificate rejection category/message. No product result supplies an expectation.

Latest qualifier passed all five sections: real/complex primitives and in-place/
view/copy behavior; 2D/3D preparation with four edge policies; 2D/3D native
reconstruction with fractional output, complex factors and uncertain inputs;
radial/full sampling; and repeated overlap builds across directions, axial
geometry and omit-kz0 choices. Sampling includes sign flips, signed zero,
float32/64, differing observer/backend bits, axial sign/order/dz and a fresh
invocation after changed table values. Repeated cached reads and subsequent
caller operations preserve cached bytes, and every sampled value also equals
the unchanged on-demand sample result exactly. All five fingerprints are in
`exact-equivalence.json`.

Representative timings are diagnostic probes only: latest native reconstruction
before 3.574400334 s / after 2.102536678 s; overlaps before 2.995860330 s / after
1.231476540 s. They are not canonical-gate timing claims.

Initial qualifier attempt failed in the BEFORE fixture because Python **-1
dispatched NumPy reciprocal, which that fixture does not certify. The probe was
corrected to the already-supported explicit np.power(a,-1); no candidate/product
repair or product-red claim followed. Subsequent three complete qualifier runs
passed; the third added full sampling/overlap checks. Earlier representative
reconstruction before/after timings were 3.682/3.367 s and 3.486/2.154 s.

## Checks, performance diagnosis and remaining gates

- Scoped Ruff lint and format: pass on all four changed files. One lint-only
  correction round wrapped lines and removed the now-unused empirical import.
- Scoped Pyright: initial command could not resolve numpy/pytest because its
  interpreter was implicit (environment/tooling failure). Explicit
  --pythonpath .venv/bin/python retry also reported the same seven missing-import
  messages. Canonical type-tool environment guidance requested from coordinator;
  no product or test defect inferred.
- The retained expensive False composition row passed under cProfile: 1 passed
  in 528.25 s; wrapper elapsed 528.894697314 s. This was an earlier local-hoist
  checkpoint, before query reuse and the latest allocation changes. Instrumented
  timing is not directly comparable to the unprofiled coordinator baseline.
- Its permitted fixture-only profile identified sample: 226080 calls / 322.410 s,
  reconstruct_expected: 4 calls / 391.280 s, overlaps: 8 calls / 126.647 s,
  Disc.__new__: 9653058 calls / 215.835 s. Inclusive costs overlap and must not be
  added. Raw runtime profile rows were not inspected or included here.
- A suggested optional interrupt raced natural completion; the owned PID had
  already exited, no signal was delivered, and status was 0. This is a complete
  diagnostic test pass, not an incomplete/interrupted result.
- Current frozen candidate's unprofiled False row passed: 1 passed in 171.57 s,
  call 171.53 s, against the coordinator's baseline call 435.55 s. Different run
  conditions limit direct timing attribution.
- All eight acquisition plus all six workflow suites passed together with fixed
  two workers, loadgroup and no restart: 1083 passed, 18 source-free warnings,
  578.07 s pytest elapsed. Command and complete output are in focused14.log;
  focused14.xml and focused14-summary.json retain exact node counts and file
  durations. Composition: 18 nodes / 430.178 s summed JUnit durations; retained
  False/True calls: 176.71 / 170.42 s. Filter: 70.268 s; transfer: 65.595 s;
  workflow records: 53.525 s; numerical: 50.958 s. Summed file durations include
  overlapping worker time and are not additive wall time. The canonical 600 s
  goal has not been measured by this focused run.
- sha256sum -c scientific-inputs.sha256 passed for all four changed files after
  the full focused run. No material scientific input changed during checks.
- Fresh B acceptance, canonical full verification, exact native reports and
  unchanged CE08/omission-guard proof remain coordinator gates. Initially passing
  baseline tests are legitimate; no product-red was manufactured.

## Own role accounting and exposure

One fresh blind A launch/session, resumed in place with blindness preserved.
No delegation, Superpowers, scientific runtime edits, Git history, nonblind
reports/ledgers, implementation-bearing task/state, coverage maps or current-task
lessons were read. Public test imports invoke the real public product boundary
only through source-free diagnostics. Approved source_free_check.py and its
sitecustomize/pytest diagnostic helpers were inspected and used.

Candidate edits occurred only after the coordinator's clean baseline finished;
no material scientific input was edited during any running diagnostic/check.
Created paths are only this scientific-a evidence directory and its listed
scripts/reports/profiles/logs. All owned profiling/focused/type-check processes
have exited. No owned daemon/server or active process remains.
No commits. Human numeric iteration/spending cap: not supplied here. Native
time/token/cost metering is unavailable to this author; model/effort identity
and monetary cost are unknown, not zero. Every qualifier/lint/type failure,
correction and profile/check attempt above remains charged.

Representative computation count: the same reconstruction probe makes 1204
sample requests; the original fixture executes sample 1204 times and the
candidate executes it 684 times, removing 520 identical pure evaluations.
This is a representative-probe count, not the long composition or canonical
run's eliminated-work count. The original sample function remains callable.
