# Fresh blind scientific B correction review, round 2

Verdict: accept the exact revised scientific test checkpoint. No actionable
finding remains within the reviewed apparatus and preservation scope. The current
14-suite focus passed 1062 cases with 18 warnings in 387.00 seconds. B independently
verified its XML, summary, keeper occurrences and all 16 scoped manifest file
hashes after completion. This accepts the scientific checkpoint; canonical full
verification, complete native reports and platform gates remain mandatory.

## Scope, identities and retained evidence

Authority is the supplied test-apparatus reduction request, AGENTS.md, the blind
B review role and test-audit public authoring/preservation criteria. Public CE
common, optical-transfer sampling, known-parameter gain, acquisition-mode/ledger,
workflow/map and independent-acceptance obligations govern the reviewed risks.
PROJECT public commands and coverage policy select approved behavior with
independent risk review; percentages are advisory and complete native reports
are required. No background link/source archive supplies new scientific meaning.

The exact candidate and evidence hashes are in accepted-filehashes.json. The five
candidate identities agree with A2's frozen checkpoint. All eight acquisition
suites and six workflow suites are included. Twelve suite files and workflow
support remain byte-identical to B1. Only c_acquisition_fixture.py,
test_c_workflow_numerical.py and test_c_workflow_records.py changed since B1;
c_workflow_oracle.py is byte-identical to its original before/ snapshot.

B compared permitted original, accepted round1 and current test bytes using
plain difflib/AST/hash reads, without Git. Original and B1 numerical equations,
unchanged assertions/examples and their accepted design evidence retain their
applicability. B1's 1083-case execution alone does not certify the changed shared
fixture. The current complete 1062-case affected run now supplies that execution
proof. Existing CE08 independent acceptance and omission guards retain their
meaning and remain full-gate requirements; this review grants no waiver.

## Independent preservation assessment

The scoped declaration inventory is 188 before and 187 after. B independently
compared every old explicit Assert, close call and np.testing.assert_* call in
the two changed workflow suites to its keeper. Their ASTs are identical, including
all tolerance expressions. All unchanged test decorators remain identical.
There are 633 explicit Assert nodes across the complete 14 suite modules both
before and after. The narrower count inside top-level test declarations is
543 before and 542 after because assert len(events)==1 moved into the retained
assert_drift_consumption helper. Neither count measures behavioral completeness;
exact keeper mapping and execution are the preservation evidence.

All six old drift rows map to the complete raw finite-observer row with the same
name: between-current-background, within2d-unfitted, within2d-fitted,
within3d-cubic-first-block, within2d-exact-cubic-impulses and
within3d-exact-cubic-impulses. B verified control_cases assigns precisely those
case.name values and no later case family overwrites them. The complete keeper
already computes the same case, observe(case), run(case) and independent budget.
Its absolute preparation/parameter/native/image proof and records checks remain.
The helper keeps the original returned-field-conditioned native reconstruction,
its bound and both independent cubic coefficient truths (1 and 1/216). The
conditional relation supplies consumption proof, not absolute raw truth.

The five clock controls retain all four exact labels in their original order:
seconds, milliseconds, acquisition-clock-ticks and ` ms `. B independently
verified all 20 old control/label mappings, including the seconds self-label call
and surrounding whitespace. Each iteration still makes the real renamed public
call and executes every old identity, returned-label, clock/matrix/coefficient/
evaluation and cubic-algebra assertion. run(case) deep-copies configuration and
checks caller inputs and NumPy error settings for nonmutation. The original
numeric baseline and independent observation/budget can therefore be reused
within a control without importing returned product truth or carrying mutated
clock data across labels. The six removed drift nodes and fifteen removed label
nodes remove duplicate physical work; no logical example or obligation is lost.
B verified current XML contains each six-name keeper exactly once and five clock
control nodes. Global 723→722 declarations and 3087→3066 native nodes remain
coordinator baseline/accounting figures, not B's independent global collection.

## Scientific risks and numerical evidence

- Radial interpolation retains the exact four flat offsets, all zero-weight
  vertices, once-only axial wrap and scalar multiplication/addition order.
  On-demand sample still evaluates the independent expression. Preparing h and
  its flattened Disc once repeats the same constructor/error-rounding sequence
  per distinct value, without dropping uncertainty columns.
- Radial keys include the computed certified radius's nominal, observer and
  backend dtype/shape/bytes. Axial keys include all three columns for integer z,
  native dz and order. Orders distinguish prepared tables/axial lengths. Full
  sampling retains both signed lateral components, all-axis reflection and
  conjugation; positive/negative zero and different error columns cannot silently
  collide. The table/layout/increments are fixed during each owning observer.
- Every local_samples closure belongs to one reconstruction, overlap, parameter
  observer or composition-factor invocation. It neither enters global state nor
  escapes in a scientific record. Calls are synchronous and the table is not
  modified before disposal. Prepared arrays and cached scalar outputs are read
  only; caller products/conjugations/absolute values create separate results.
  A new owning invocation sees changed tables. No cross-test lifetime exists.
- Inverse-noise keys include time, direction and order. Support, suppression,
  damping/omission precedence, omit-kz0 and arithmetic still execute at every
  original visit. Replacing in-place scaling of a fresh scalar with scaling
  into a new scalar prevents mutation of the cached inverse. Disc's out path
  assigns the already computed wrapped nominal/error values, so this change
  preserves scalar arithmetic and outward rounding. Conditional errors remain
  reached at their original scientific decision; no zero-noise result is cached
  as a successful value. The ez guard follows the same non-2D condition as its
  construction and changes no valid scientific result.
- B source-free fixture-only probe passed 1953 controls across original/B1/current
  observers. It compares exact nominal/error bytes, dtype, shape, strides and
  writability; includes spatially varying nonzero table observer error, backend
  error, coordinate-error alternatives, float16/32/64 inputs, signed zero,
  positive/negative axial queries, different orders/native increments, permitted
  flat aliases and unsafe value-or-error outcomes. Cached values match both
  original and independently callable on-demand sample; subsequent operations
  and table inputs remain unchanged. An independently calculated binary-exact
  bilinear control gives 2.1953125+0.08984375i.
- A second small B fixture-only command passed three B1/current paired gain
  cases with distinct noise over two times, two directions and three orders.
  Suppression, dampen+omit precedence and omit-kz0/no-overlap preserve complete
  nominal/error arrays, certificate lists and input nonmutation. Both B commands
  confirmed simrecon was not imported; no product output supplied expectations.
- B inspected A's six-section qualifier and exact evidence, plus the supplemental
  qualify_table_errors.py and table-errors-equivalence.json. The latter compares
  144 queries per revision with nonzero table errors and separately varied
  uncertain native dz, including on-demand/cached and original/current bytes,
  complete certificates and zero warnings. These supplement independent static
  and mathematical checks rather than replacing them.

B independently reproduced invalid-infinite private-sampler warnings: original
6, accepted B1 6, current 4. Every distinct RuntimeWarning category/message
remains, with source locations recorded; source line numbers move with edits.
The reduction removes repeated private arithmetic diagnostics. Warning lists
are not equal and no such equality is claimed. No product/test warning filter,
error category, scientific assertion or public warning behavior was changed to
obtain the pass. The full affected run retains its 18 source-free warnings.
This diagnostic difference is not a lost C-equivalent scientific obligation.

The concrete changed risks above have retained positive/error/alias and absolute
proof. No plausible high-impact omission caused by this correction was found.
This is a scoped assessment, not proof of every possible scientific behavior.

## Execution proof, limits and accounting

B read the permitted current focused14-round2.log, XML and summary only after
completion was supplied. XML has exactly 1062 testcase nodes over the expected
14 suites, with zero failures, errors or skips; every per-suite count matches
the summary. The log ends with 1062 passed, 18 warnings in 387.00s. Coordinator
and A attest fixed two workers, loadgroup, no worker restart and source-free
harness. B independently rehashed all scoped scientific inputs afterward; all
16 manifest entries match, and the manifest also pins unchanged workflow oracle
and focused/supplemental evidence. Canonical make check passed locked sync/reader preparation, Ruff lint/format
and Pyright with zero errors/warnings across all 116 files, as supplied by the
coordinator after this focus. B ran no concurrent heavy pytest/product test,
no coverage operation and no canonical full verification.

One fresh B2 launch/session; one completed correction review, accepted; zero
candidate corrections requested; two successful source-free supplemental command
families and static/evidence checks. One optional evidence-script read used the
approximate supplied qualifier_table_errors.py name and returned missing-file;
the actual qualify_table_errors.py was then authorized and read. This was an
evidence pointer lookup, not a candidate defect. B1 remains one prior completed
accepted round with zero requested candidate corrections and one own probe-input
correction; none of those charges is erased or counted twice. A/coordinator
corrections and earlier work retain their separate accounting. Human numeric
review/scenario/time/token/money limits are not set; actual served model/effort,
token metering and monetary cost are unknown, not zero.

No scientific implementation, Git history/diff/log, implementation-bearing task
state, nonblind scientific reports/ledgers, baseline runtime/profile data,
coverage map, lessons or parent conversation was read. One orchestration status
inventory displayed infrastructure-only progress summaries; these contained no
scientific implementation or oracle evidence and supplied no review conclusion.
No Superpowers, delegation, product/test/gate edit, commit or external message.
Own /tmp/scientific-b-round2-probe.py and /tmp/scientific-b-round2-gain.py scratch
were removed after checks; both owned processes exited. No daemon/server remains.
Durable output is only this report and accepted-filehashes.json. Full canonical
verification, complete required native reports/platform proof and overall runtime
acceptance remain coordinator gates.
