# A6 search experiment withdrawn; B6 restored

The shared-fixture experiment did not earn its complexity and was removed.
All six scientific source hashes match round5-scientific-inputs.sha256 exactly
(round6-restored-hash-check.log), including fixture
ad6bfba65482e125ecbcd5fa191afd5500205e5c7e4823bf504a278ec2f0f5e4.
The previously accepted B5/B6 checkpoint is again the current source. No new
test assertion, example, tolerance or production change remains.

| Matched covered scope | Before | Experiment |
| --- | --- | --- |
| two real2D public rows |2pass38.79s|2pass36.14s|
| full/radial printed call times |18.86/18.38s|18.21/16.90s|
| radial/full independent helper |1.4413/1.8828s|1.2638/1.6168s|
| three3D composition searched directions |2.2568s|1.9341s|

The~2.13s printed aggregate real-row saving and small3D helper gain cannot
establish the required~30s margin. Normal helper outputs, observer/backend
columns, complete traces/certificates, warnings and input bits matched exactly:
628 evaluations/1046 certificates for each2D layout and509/2060 for the3D
witness. The other large composition controls use search_carriers=False.

The attempted eligibility guard restricted finite exact Disc fields, typed
pitch/pair and complete field/error bits; unknown metadata fell back. SX copies
were intended to preserve per-fit storage. Wider alias/failure-domain probes
were planned but not run after the real cost rejection; no complete alias/error
acceptance or product-red is claimed. One format-check failure was corrected;
all numerical/public probes passed. No broad proof, B7 or canonical rerun was
performed for the withdrawn experiment.

Before/experiment snapshots and detailed accounting are retained under
round6-before/, round6-regression-experiment/ and
ROUND6-REGRESSION-EXPERIMENT.md. All A6 helper/public-row processes completed;
no owned process remains. Scratch artifacts/data remain only in this role's
artifact paths, with isolated coverage data unread. Existing candidate2
all13-phase/3066-pass611.04s result remains the over-target baseline.

Same blind A root, zero child agents; no implementation/history/nonblind
reports/coverage maps/raw canonical profiles/current-task lessons read. Actual
model/token/dollar accounting remains unavailable. No further source work is
under way while the coordinator evaluates the separate JVM measurement and
public-only advisor.
