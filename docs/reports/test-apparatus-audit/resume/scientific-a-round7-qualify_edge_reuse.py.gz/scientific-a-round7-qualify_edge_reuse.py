"""Exact edge arithmetic, diagnostic fallback and ownership qualification."""
import hashlib
import itertools
import json
import warnings

import numpy as np
import qualify_exact as q

old=q.module("edge_prior",q.ROOT/"artifacts/test-apparatus-audit/resume/scientific-a/round7-before/tests/c_acquisition_fixture.py")
new=q.module("edge_candidate",q.ROOT/"tests/c_acquisition_fixture.py")


def make(m,shape,kind):
    values=(np.arange(np.prod(shape),dtype=float).reshape(shape)%7-3)/8
    if kind=="float32":return values.astype(np.float32)
    if kind=="object":return values.astype(object)
    if kind=="complex":return values+1j*(values+1)
    result=m.Disc(values,2**-42,2**-39)
    if kind=="plain":return values
    if kind=="readonly":np.asarray(result).flags.writeable=False
    if kind=="strided":result=result[::-1,::-1]
    if kind=="fortran":
        result=m.Disc(np.asfortranarray(values),np.asfortranarray(result.observer),np.asfortranarray(result.backend))
    if kind=="subclass":
        class Sub(m.Disc):pass
        result=Sub(values,2**-42,2**-39)
    if kind=="signed-zero":
        np.asarray(result)[:]=np.array([0.,-0.]*((values.size+1)//2))[:values.size].reshape(shape)
        result.observer[:]=-0.
        result.backend[:]=0.
    if kind in ("nan","inf","interior-nan"):
        np.asarray(result)[(1,1) if kind=="interior-nan" else (0,0)]=np.nan if "nan" in kind else np.inf
    if kind=="error-inf":result.observer[0,0]=np.inf
    if kind=="error-nan":result.backend[0,0]=np.nan
    if kind=="error-negative":result.observer[:]=-2**-42
    if kind=="error-object":result.observer=result.observer.astype(object)
    if kind=="subnormal":np.asarray(result)[:]=np.array([[0.,np.nextafter(0.,1.)],[2*np.nextafter(0.,1.),-np.nextafter(0.,1.)]])
    if kind=="error-subnormal":result.backend[:]=np.nextafter(0.,1.)
    if kind=="maximal":np.asarray(result)[:]=np.array([[np.finfo(float).max,-np.finfo(float).max],[1.,-1.]])
    if kind.startswith("bound-"):
        bound=2.**(-256 if "low" in kind else 256)
        destination=0. if kind.endswith("below") else np.inf
        value=np.nextafter(bound,destination) if not kind.endswith("equal") else bound
        np.asarray(result)[:]=value
        np.asarray(result)[-1,-1]=-value
    return result


def run(m,settings,policy):
    shape,kind,width,bead=settings
    plane=make(m,shape,kind)
    before=q.freeze(plane)
    m.CERTIFICATES.clear()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        with np.errstate(all=policy):
            try:
                result=m.edge(plane,width,bead=bead)
                output=("return",q.freeze(result),dict(nominal_input_alias=np.shares_memory(result,plane),observer_input_alias=hasattr(plane,"observer") and np.shares_memory(result.observer,plane.observer),backend_input_alias=hasattr(plane,"backend") and np.shares_memory(result.backend,plane.backend),column_alias=np.shares_memory(result.observer,result.backend)))
                location=[]
            except Exception as error:
                output=(type(error).__name__,str(error))
                location=[]
                trace=error.__traceback__
                while trace is not None:
                    location.append(dict(filename=trace.tb_frame.f_code.co_filename,line=trace.tb_lineno,function=trace.tb_frame.f_code.co_name))
                    trace=trace.tb_next
    assert before==q.freeze(plane),"edge mutated input"
    return (output,q.freeze(m.CERTIFICATES),[(w.category.__name__,str(w.message)) for w in caught]),dict(warnings=[dict(category=w.category.__name__,message=str(w.message),filename=w.filename,line=w.lineno) for w in caught],exception_locations=location)


cases=[]
for shape,width,bead in itertools.product(((1,1),(2,3),(3,2),(4,4),(4,6),(6,4)),(-2,-1,0,1,2,4),(False,True)):
    cases.append((shape,"disc",width,bead))
for shape,kind in itertools.product(((2,2),(4,6)),("plain","float32","object","complex","readonly","strided","fortran","subclass","signed-zero","nan","inf","interior-nan","error-inf","error-nan","error-negative","error-object","error-subnormal")):
    cases.append((shape,kind,0,False))
for kind in ("subnormal","maximal","bound-low-below","bound-low-equal","bound-low-above","bound-high-below","bound-high-equal","bound-high-above"):
    cases.append(((2,2),kind,0,False))
for shape,width in itertools.product(((0,0),(0,3),(3,0)),(0,1)):
    cases.append((shape,"disc",width,False))
for width in (np.int64(0),np.uint32(0),False,True,0.,1.,None,0j,np.array(0)):
    cases.append(((2,3),"disc",width,False))
for shape,bead,width in (((24,22),True,10),((22,24),True,10),((10,10),False,10),((3,1),True,1),((4,1),True,1),((4,2),True,2)):
    cases.append((shape,"disc",width,bead))
report=[]
for index,settings in enumerate(cases):
    for policy in ("warn","raise"):
        a,diagnostic_a=run(old,settings,policy)
        b,diagnostic_b=run(new,settings,policy)
        assert a==b,(index,settings,policy,a,b)
        report.append(dict(case=index,shape=settings[0],kind=settings[1],width_type=type(settings[2]).__name__,width=str(settings[2]),bead=settings[3],numpy_policy=policy,outcome=a[0][0],exact_equal=True,old_diagnostics=diagnostic_a,new_diagnostics=diagnostic_b))
for bound in (2.**-256,2.**256):
    for value in (np.nextafter(bound,0),bound,np.nextafter(bound,np.inf)):
        plane=new.Disc(np.full((2,2),value))
        assert new._ordinary_edge_values(plane)==(2.**-256<=value<=2.**256)
q.Path(__file__).with_name("edge-reuse-equivalence.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(dict(cases=len(report),exact_values_columns_certificates_status_warnings_aliases=True,fingerprint=hashlib.sha256(json.dumps(report,sort_keys=True).encode()).hexdigest(),product_imported=any(n=="simrecon" or n.startswith("simrecon.") for n in q.sys.modules)),indent=2))
