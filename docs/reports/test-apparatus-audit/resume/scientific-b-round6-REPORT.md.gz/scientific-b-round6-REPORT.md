# Fresh blind scientific B6 acquisition checkpoint review

Verdict: accept the exact revised acquisition scientific test checkpoint. No
actionable finding remains in the inspected scope. The completed affected proof
has 597 passing cases, 18 warnings and pytest wall time 282.58 seconds. This is
not canonical readiness, a full-runtime claim, native coverage acceptance or D.

## Identity, authority and scope

The frozen target is `tests/c_acquisition_fixture.py`, SHA-256
`ad6bfba65482e125ecbcd5fa191afd5500205e5c7e4823bf504a278ec2f0f5e4`.
The exact accepted comparison snapshot exists at
`artifacts/test-apparatus-audit/resume/scientific-a/round3/tests/c_acquisition_fixture.py`,
SHA-256 `f7ee10cc241a022f4a0206d00bad3439c9456f74bb64ace5c7bb03125334377f`.
Both hashes were independently checked. The final manifest records current
fixture, eight acquisition suites, workflow dependency-boundary support and
permitted completed proof/supplemental evidence hashes.

Authority is the supplied apparatus-optimization request preserving every
scientific obligation and C-equivalent behavior, root AGENTS.md, review-work B
and test-audit public authoring/preservation criteria. Public PROJECT boundary,
commands and coverage policy and the permitted CE common/rebuild/stage/acquisition/
ledger/workflow/map/independent-acceptance contracts supply meaning. Relevant
equations inspected include CE03 actual radial stencils; CE04 ordered native
powers/support/assembly; CE05 overlap short circuit and duplicate axial writes;
and CE06 sections7/10/12. Approved behavior plus independent risk review governs;
percentage targets are advisory, required reports/gates remain mandatory.

I reviewed the entire new overlap lane path and its admission, sampler ownership,
private records/results, threshold/division/sqrt/interpolation helpers, changed
native radial-u misses and packing/tile changes, shared lane primitives and Disc
construction/dispatch. I inspected the complete plain-file fixture delta against
accepted A3, relevant original scalar paths, numerical callers and public-call
support, acquisition declaration inventories and affected keeper bodies. I did
not treat B4's earlier native acceptance or green probes as sufficient evidence
for the changed shared helpers.

All eight acquisition suite files and `tests/c_workflow_support.py` independently
match B4's accepted hashes. The acquisition inventory is 132 top-level test
declarations and 420 explicit Assert nodes. This is preservation evidence, not
coverage completeness. The original scalar overlaps loop body and result tail
are byte-identical to the accepted snapshot. The plain-file delta contains no
test/assertion/row/tolerance removal. The five-clock/four-label and six same-case
drift keepers remain applicable through unchanged suite bytes; their workflow
execution belongs to the separately reviewed B5 slice. Workflow support imports
its separate workflow oracle and has no acquisition-fixture dependency. I did
not open that new oracle or B5 raw evidence.

## Independent numerical and preservation assessment

The owning obligations remain real public raw-to-bands, transfer-to-overlap/
finite-fit and native-filter-to-image compositions. General finite observers
and independent closed controls remain; conditional threshold alternatives and
drift-consumption relations retain their limited claims. No product output,
mocked scientific decision, new production export or new numerical threshold
supplies the changed expectations.

The new fast path selects only a restricted radial pair(0,1), Z1/Z2, even-grid,
zero incoming carrier-error, ordinary-threshold representation family. Plain
quadratures, uncertain carriers, later pairs, full tables and threshold-choice
proofs retain scalar dispatch. Recognized local samplers must match their own
closure identity, captured table identity and current factory. Wrapped/custom
or another-table samplers retain their original effects. Plain/Disc table and
carrier distinctions are explicit; native plain-noise/plain-quadrature fallback
from the B3 correction remains present.

The lane representation retains individual 0D nominal operations and dtype
dispatch. Error columns retain separate observer/backend algebra and nextafter
construction steps. The packed radial helper reads all four literal flat
addresses, including K1 duplicates and zero-weight vertices, then reproduces
both outward getter rounds, original u-i subtraction and original interpolation
addition/multiplication order. Native raw and certified-u keys retain dtype,
shape and bytes; overlap keys also distinguish signed h/order. No global numeric
cache or mutating sampled-value consumer was introduced.

The ordinary division helper uses observed and total interval margins, unlike
the native Wiener-lower-bound quotient. Sqrt preserves each scalar nominal and
both scalar error expressions. Two-coordinate norm reductions retain their
original size/order/gamma(16). Native self power, direction/signed-order other
powers and final w-squared order remain unchanged. Conservative private range/
margin checks decline acceleration rather than restrict supported science.

Overlap records and values remain private until the entire overlap succeeds;
native components likewise publish nothing on decline. Overlap output records
are sorted back to row/column/side/h traversal before publication. Both h=-1
and +1 visits remain for Z2, preserving duplicate-address last-write order.
Rejected or ambiguous thresholds decline to scalar traversal, preserving its
short circuit, first failure and prior certificate prefix. Only visited support
queries are sampled. No broad catch masks unknown programming errors.

Risk-to-keeper mapping remains: preparation camera/off/phase/Nyquist in the
preparation suite; actual complex empirical transfers and stencils in transfer;
overlap/search/strict thresholds/weak unequal-energy positives in 2d; signed
native filter, suppression/overlap flags, zoom and Wiener schedule in filter;
actual drift/cubic controls in drift/fitted_drift; raw-to-fit-to-image consumption
in composition; representation/provenance/operation-time failure and legitimate
positive alternatives in boundary. The unchanged scalar branches preserve odd
Y, full transfer, later pair, uncertainty and alternative-threshold obligations.
No sole scientific proof was retired. No product-red was claimed or required.

## Own source-free checks

Before any probe I read the approved source-free runner/sitecustomize/pytest
plugin. All Python checks ran through `.venv/bin/python
scripts/source_free_check.py` with retained diagnostic category/message/location/
status and no source snippets. Numerical probes imported only the two permitted
fixture versions; each asserted that no simrecon product module was imported.

1. `--timeout 5 python /tmp/scientific-b6-nodes.py`: passed 57 exact scalar/lane
   checks across exponents -28,-7,0,9,28. Real/complex division, signed zero, sqrt,
   nonzero separate errors and K1/K2/K4 four-vertex interpolation, including legal
   flat aliases, match nominal/observer/backend dtype, shape and bytes.
2. `--timeout 30 python /tmp/scientific-b6-complete.py`: final 17 accepted-A3/current
   complete overlap controls pass. They include Z1/Z2, uncertain transfer/pitch,
   plain quadratures, valid later pair, custom sampler call traces, another-table
   sampler, strided/read-only inputs, all-rejected and alternating transfer
   tables, unsafe stencil failure, omit-all, explicit threshold choices and
   partial128 tiles. Complete result/error outcomes, error columns, certificate
   sequences, warning identities and input nonmutation match exactly. Batch
   instrumentation confirms no certificate publication during preflight;
   unsafe-stencil decline preserves the scalar one-certificate prefix.
3. `--timeout 30 python /tmp/scientific-b6-native.py`: 10 complete native controls
   pass, including two directions, 3D/two times, uncertain tables/carriers, plain
   noise/quadratures, zero modulation, readonly inputs, unsafe stencil and a
   partial64 grid. All complete fields/certificates/outcomes/warning identities
   and caller inputs match. Eligible controls enter native batching; plain or
   uncertain controls keep scalar dispatch.

Two independently derived closed checks run on both versions: H0=3,H1=4,
B0=10,B1=5 and zero carrier yield lower8/higher3 from denominator5; unit transfer,
noise and modulation with zero carrier and w=.5 give native denominator
1+1+1+.25=3.25 and DC image4/13. These supplement full exact comparisons.

Own initial complete probe underspecified later-pair input with only three
quadratures; both fixtures consistently failed. That private invalid control
was replaced by a valid five-quadrature input and rerun; it was never a candidate
finding. One unmatched-parenthesis SyntaxError introduced during this scratch
edit exited1 through the source-free harness, was corrected, then final checks
passed. Preserve both reviewer correction charges. One early static read found
the author's still-pending round5-checks.json absent (status1); it was later
provided and reviewed. No target file was repaired. Static AST/hash checks and
final XML/hash verification also passed through source-free Python.

## Completed affected proof and limits

I independently parsed covered8-round5-acquisition.xml: exactly597 testcase
nodes, expected eight classnames/counts, no failure/error/skipped element and
summed testcase time461.713 seconds matching the supplied summary. Suite counts
are boundary313, preparation88, filter49, 2d40, transfer38, drift37, composition18,
fitted_drift14. The completed log reports597 passed/18warnings/282.58 seconds and
two workers. The coordinator supplies fixed2/loadgroup/no-restart/source-free
command provenance. Its unchanged authorized measurement plugin matches B4's
hash `a9b67104370db5f06c214c19b4e2bc1803f30a4bc8478ae98577e3422e26e5ae`.
Current fixture/suite hashes were rechecked after proof and own probes.
The author finalized ROUND5.md and added admission metadata to the summary
while this report was being written. I reread those final evidence bytes,
reconfirmed the unchanged597-node XML/source identity and refreshed their hashes.
The manifest retains the earlier evidence-only snapshot hashes separately;
no source change or renewed scientific execution was needed.

I read A's completed current-hash supplemental ledger and relevant sanitized
logs: overlap88/37 admissions; native23 plus8 boundary/readonly/strided controls;
representation64; interpolation/sqrt/division54; constructor46; lane135; pinned
B3 reproducers and original-six-section equivalence. These are supplemental,
not independent scientific oracle acceptance by themselves. The known private
invalid-infinite sampler warning duplicate difference6vs4 remains disclosed;
distinct categories/messages and actual locations are retained. No supported
scientific diagnostic was suppressed. The covered-run startup already-imported
CoverageWarning is disclosed, not native-report completeness evidence.

The focused covered proof uses the authorized artifact measurement plugin and
does not prove ordinary canonical runtime. Full3066-node make verify under600s,
all13 phases, same-run M25, current complete native/platform reports, frozen
candidate integrity and fresh D remain coordinator gates. No coverage data/map,
profile or full canonical evidence was inspected or accepted here.

## Exposure, accounting and cleanup

This is the sixth fresh scientific B launch and one completed accepted B6
correction review, with zero candidate correction requests and zero delegation.
All prior B1/B2/B3/B4/B5 and author/coordinator attempts/spending remain charged
once; this report does not reset them. Three numerical probe families passed;
the complete family has an initial passing run with one invalid private row,
one source-free syntax failure, one input correction and a final passing run.
Static diff expected status1 denotes a difference, not a failed verification.
Actual serving model/effort/tokens/monetary cost are unknown beyond requested
Sol/high; missing values are not zero. No human numeric cap was supplied; the
under600s full-gate performance target remains unproved by this role.

Exposure remained within permitted public contracts/rules, exact current/prior
fixtures, acquisition tests/public-call support, B4 report/manifest and named
sanitized author evidence. Bulk static outputs were truncated and followed by
targeted reads; truncation is not evidence. No product implementation, Git/history,
task Current state, nonblind audit/discovery, raw canonical log/profile, coverage
data/map, existing LESSONS, prior conversation, new workflow oracle or B5 raw
evidence was read. No Superpowers, child role, commit, external communication or
gate edit occurred. There was no blindness exposure requiring stop/rerouting.

All own probe processes exited. Exact own scratch sources were copied into this
durable report directory under `probes/`, with their SHA-256 identities in the
manifest, before deleting only the four named `/tmp/scientific-b6-*.py` files.
Absence was confirmed. No daemon/server or live owned process remains. No target,
tracked fixture, shared cache or unrelated path was removed.
