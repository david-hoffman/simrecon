# Blind A5 radial overlap and packed native lanes

Frozen fixture SHA-256:
ad6bfba65482e125ecbcd5fa191afd5500205e5c7e4823bf504a278ec2f0f5e4.
Only tests/c_acquisition_fixture.py changes from accepted A3/B4. The separately
reviewed workflow slice is accepted by B5 and remains frozen at ROUND4's three
hashes. No declaration, row, assertion, example, tolerance, independent expected
truth, omission guard or CE08 acceptance test changes in this slice. Counts
remain722 declarations,597 acquisition plus465 workflow focused nodes,3066 full
nodes. Accepted A3 is preserved in round3/; intermediate batch/packing checkpoints
and their timing/probe charges are retained.

## Exact expressions and ownership

The original scalar overlaps, sample, threshold_survives and division/sqrt
equations remain callable. A new private overlap path admits only pair(0,1),
Z1/Z2 with cutoff0/1, even native X/Y, zero incoming carrier uncertainty,
ordinary threshold mode, exact Disc complex128 quadratures, ordinary float64
carrier arrays/Disc and radial complex128 ndarray/Disc tables. Unsupported
representations, custom/subclass samplers, threshold alternatives, ambiguous or
rejected thresholds, nonfinite/out-of-headroom inputs and unsafe visited stencils
decline acceleration and execute the original scalar traversal.

local_samples adds only three identity markers to the returned pure closure:
owner is that exact function, table is the exact captured table, factory is the
current local_samples. A copied/wrapped callable fails owner identity; a sampler
bound to another table fails table identity. Unknown samplers retain all their
original calls/effects. No numerical state is global or shared across tests.

Private overlap tiles prepare original(i,j,side,h) visits, retaining both
h=-1 and h=1 and duplicate h%Z last-write order. Only support-visited queries are
sampled; the second transfer is queried only after the first threshold survives.
Both threshold certificates use unchanged nominal values, gap/error arithmetic
and strict decisions. All prepared records/results are private until the entire
overlap succeeds. Records/writes are then emitted in original traversal order.
A recognized decline leaks no records/writes and replays scalar traversal, so
an earlier threshold/division/stencil failure retains its original prefix.
Unknown programming errors are not broadly caught or masked.

_overlap_lane_sqrt evaluates each original0D nominal sqrt and both scalar error
sqrt expressions, with the original gamma(1)/nextafter steps. The ordinary
_overlap_lane_divide uses the original observed/total interval margins and
complex/real rounding; it does not use the native Wiener lower-bound quotient.
Plain/Disc dispatch is kept explicit; no plain quadrature is admitted. The native
B3 correction still requires both Disc quadratures and Disc noise. Existing
native modulation/table representation semantics and all flags are unchanged.

_radial_lane_interpolation replaces per-vertex Disc allocations only: it reads
the same literal four flat addresses, preserves duplicated K1/zero-weight
vertices and legal flat aliases, and explicitly performs the two distinct
outward getter steps in lane arrays. The original scalar u-i node, per-lane
nominal operand dtypes and exact multiplication/addition order remain. Both
restricted native and overlap owners use this helper. No stencil is clipped,
merged, sampled earlier on scalar fallback or omitted.

Native radial-u nodes now batch already-visited raw-query misses using the
qualified0D nominal/error hypot and ordinary divide. Every raw key retains
nominal/error dtype/shape/bits, including signed zero. The complete certified
radial u plus order determines interpolation; native axial0/dzf/table declarations
are fixed by the owner. Overlap additionally keys each signed h/order. Table
values/errors are fixed and read-only throughout each owner. Cached scalar
results are only read by arithmetic; target assignments copy their values and
columns. All memo dictionaries die with that invocation. Readonly and strided
inputs have retained arithmetic/fallback proofs, and outputs do not mutate inputs.

Native tiles are64, overlap tiles128. Elementwise lane expressions are
independent; no reduction gains a lane dimension. Each original geometric norm
still has exactly two components, original reduction order and gamma(16).
Direction/signed-order denominator additions, native divisor record order,
Hermitian reflection, sideband reconstruction and assembly remain unchanged.

Both paths use the existing conservative private exponent reserve, not a new
scientific domain/tolerance: B=2**floor((maxexp-1-ceil(log2(T))-64)/32).
Finite components/errors are bounded by B; positive steps/margins used by the
accelerated expressions are at least1/B. Interpolation error degree<=3 and
the restricted products/divisor expressions are enclosed by the existing32-power
reserve plus64 exponent bits. Overlap thresholds additionally keep visited
denominator amplitudes away from zero; its ordinary observed/total margins are
checked before acceleration. Outside this private headroom the original scalar
path retains the supported public behavior and first failure. Bound constants,
scientific intervals and support decisions are unchanged.

## Complete affected helper/caller scope

local_samples remains used by reconstruct_expected, parameter_model and
test_c_acquisition_composition.independent_factors. Its new recognition metadata
selects only the new overlap path; all original scalar queries remain available.
overlaps callers are: independent_factors; finite_search coarse/frozen builds;
later-pair builds; parameter_model known/reused carrier builds; and the direct
2D overlap/search/threshold-sensitivity witnesses. All use unchanged scalar
fallback for excluded/uncertain/search/alternative/custom cases.

_radial_lane_interpolation serves only _native_radial_batch.samples and
_overlap_radial_samples.query. _overlap_lane_divide serves their radial-u
division, overlap coordinate division and final ordinary overlap quotient.
_overlap_lane_sqrt/_overlap_threshold serve only the new overlap path.
_native_radial_batch remains called only by reconstruct_expected, including
independent direct expectations and test-owned public predictors. Its eligibility
and scalar reconstruction/assembly are unchanged.

All eight acquisition suites are affected proof/review scope: 2d, boundary,
composition, drift, filter, fitted_drift, preparation and transfer. Six workflow
suites use the separate c_workflow_oracle/support and have no dependency on this
fixture; their B5 acceptance/465-pass proof is prior integrated evidence subject
to final independent review. All test files are byte-identical to the already
accepted workflow/A3 checkpoints. No production caller/history was inspected.

## Supplemental qualification and cost evidence

Current-hash supplemental proof covers original/current exact values, observer/
backend columns, complete certificates, warning identities and input nonmutation.
It includes the six original sections,64 plain/Disc native field combinations,
23 native/range/fallback cases,8 additional native boundary/readonly/strided
cases,54 interpolation/sqrt/division node cases, ordinary overlap representation/
guard cases, constructor and lane primitive checks, and both pinned B3
representation reproducers. Final counts/statuses are in round5-checks.json.
The far native stencil failure preserves200 prior divisor records; earlier bad
noise/Wiener preserve0. Partial64/128 final tiles and both sides of old/new
boundaries are included. K1 duplicates, nonuniform errors, positive legal axial
flat aliases and another-table/custom/wrapped samplers are explicit witnesses.

Matched covered overlap-only large witness (8owners,Z2/Y10/X80): accepted A3
wall36.7078/CPU38.8659s, initial lane16 wall19.0930/CPU21.2786s. Packed vertices
+tile128 changes matched lane16 wall18.5922/CPU20.7580 to10.3349/12.5046s.
All exact fingerprints/certificates agree;8/8 owners and28200 visits admitted.
These are separate explicit matched probes, not full-suite cost claims.

Packed-code tiles16/64/128 on a small matched witness give overlap
.6431/.5630/.5121s and native1.0165/.9999/.9922s, exact at every size. Large
native A3 wall13.6872/CPU14.9505s versus packed16 10.9458/12.2415, packed64
10.7959/12.0475, packed12810.7889/12.0503. Native64 was chosen for the essentially
tied64/128 result with smaller bounded working arrays. Finally matched radial-u
batching at64 changes native10.3922/11.6308 to7.0800/8.4427s, exact. Data lives
under this role's isolated coverage paths and was not inspected. These helper
probes import no product, so coverage retains its already-imported/no-data
warnings; they are not native coverage reports or scientific acceptance.

Initial overlap59-case proof and expanded83-case proof passed before final
renewal. The first expression-node probe mistakenly omitted the original u-i
node in its reference; correcting the probe to u-0 restored exact parity with
no fixture fix. One long formatting line and then three B010 setattr diagnostics
were corrected before final checks; metadata now uses vars(function).update.
No apparatus mismatch was called product-red. The B5 measurement-provenance
correction and withdrawn pre-guard timing claim remain in ROUND4.md.

Scoped Ruff/format pass. Root narrow canonical Pyright passes0 errors/warnings/
informations on this frozen hash (coordinator evidence round5-root-types.log).
The eight real acquisition suites now pass597/18warnings in282.58s, with
461.713s summed JUnit duration: composition157.950,2d68.580,transfer76.104,
filter76.250,preparation27.242,drift27.049,fitted_drift20.307,boundary8.231s.
The two critical composition rows take49.052/48.720s. Every frozen source hash
matches after the run; its controller/workers exited0. The unchanged authorized
admission plugin was loaded, so this timing includes its instrumentation.
It records32/32 eligible native components for each critical row, all with Disc
quadratures/noise. Evidence: covered8-round5-acquisition.log/.xml/-summary.json
and batch-eligibility-48227.jsonl. Combined with the accepted465 workflow proof,
all1062 affected focused nodes pass at these exact integrated scientific hashes.

Fresh B6 acceptance and final integrated same-run native coverage/M25/all13
phases/600s gate remain pending. Simple projections near606s are diagnostic
estimates only; the canonical command determines the actual goal. The role has
not repeated the old long full-case profile or another full canonical gate.

## Accounting/exposure

Same continuing blind A root, zero delegation. Prior attempts/charges and rejected
checkpoints are preserved. Only permitted tests/public contracts/own artifacts
and the explicitly approved B3 reproducers were read. No production implementation,
Git history, nonblind report/ledger, coverage data/map, raw product profile or
current-task lesson was inspected. Small profile exports contain fixture
functions only. All probes inherit approved source-free warnings/tracebacks/
subprocess rendering. Actual token/model dollar accounting remains unavailable.
