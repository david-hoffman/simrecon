# Public-only observer performance advice

Report-only Astra/ultra advisor, one native launch after the first complete
candidate passed checks in 829.59s but missed 600s. No edits, probes, tests,
processes, delegation or Superpowers. Served model, metering/cost unknown.
Initial broad filename inventory exposed prohibited-directory names, no contents;
subsequent reads were confined to named public contracts and test apparatus.
No product/history/raw-pstats/coverage/lessons content read. This is advice, not
an acceptance verdict or extra implementation authority.

Highest potential: batch independent native cells only in radial layout with all
axial cutoffs 0, taper none and suppression/damping/order-omission/omit-kz0 inactive.
Keep original scalar fallback elsewhere, outer t/d/m traversal, exact index lists,
self/other eligibility and sequential e/n denominator accumulation. Keep signed
recombination and independent direct Fourier assembly unchanged. For N cells and P
expression nodes, associated Disc allocations can fall from P*N to P*ceil(N/B),
without reducing mathematical element count. Runtime remains unmeasured.

Exactness risks: preserve actual zero-dimensional operand dtypes (NumPy scalar
extraction differs), abs of complex values and error-column hypot as well as
nominal ufuncs, every structural getitem/stack/reshape nextafter stage, and the
original two-component norm/gamma16 rather than a batch-size gamma. Lossless
packing must not add constructor rounding. No fused/reordered arithmetic.

Certificate replay must preserve first-error prefix: a later unresolved support
must not precede an earlier unsafe visited stencil. Preflight must be side-effect
free; decline must discard speculative records/mutations before untouched scalar
traversal, rather than a catch-all hiding apparatus defects. Validate all four
literal flat radial addresses including zero-weight and duplicate axial vertices;
allow legal flat aliases and never sample masked/unvisited queries. Qualify empty
traversal, native-radius equality, strict other-order support, signed zero andK1.

Supporting lower-risk exact hoists: modulation powers/conjugates, signed carrier
multiples, w²/certified margin, taper denominator and lateral products, lazily at
first reached use. A complete raw-coordinate lookup before the existing radial
key may avoid repeated hypot/divide. Shape-matching scalar metadata copies may
avoid broadcast wrappers. Do not redesign lazy error properties/finalize just
for speed: earlier finalize inclusive cost was16.17 s of 528.89 s; earlier A2 small
reconstruction 1.898 s had 41288 constructors/29771 ufuncs, constructor 0.924 s inclusive
and query 0.702 s inclusive (overlap; not additive savings estimates).

Qualification: one/multiple/nonuniform lane primitive-node parity, nominal/both
error bytes/dtypes/shapes/certificates/outcomes; nonzero uncertainties and complex
values; 2D and 3D Z2 multiple directions and signed carriers; excluded-flag/unsafe/
unresolved-support fallback first-failure/nonmutation witnesses. Extend existing
exact/table-error probes and retain all 26 keeper mappings. Measure unchanged long
observer and both cubic rows before claiming enough gain; all 8 acquisition + 6 workflow
proof, fresh B3 and exact canonical full verification/fresh D remain required.
