# Blind A7: minimal edge work reuse

Frozen tests/c_acquisition_fixture.py SHA-256:
ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc.
Accepted B6/ad6 fixture is preserved in round7-before/tests/. No other source,
test, declaration, row, assertion, example, tolerance or CE08 obligation changes.
Eight acquisition test hashes and all accepted B5 workflow hashes are unchanged.
Expected affected proof is597 acquisition nodes;465 workflow nodes retain B5
evidence subject to independent reviewers. Candidate2 all13-phase/3066-pass
611.04s remains the measured over-target canonical baseline.

edge retains original as_disc, dimensions, padded allocation/assignment,
flat=padded.reshape(-1), scalar pixel updates and final getter/copy. It only
skips width0's unused delta loops on selected quiet binary64 inputs and reuses
the identical width/k sinusoid factor lazily within one eligible positive-width
invocation. No per-pixel arithmetic, vertical-before-horizontal order, ascending
k or add-before-subtract changes. Overlapping strips keep scalar writes.

The selector requires strict Disc/float64 inputs with matching finite float64
error arrays, nonnegative observer/backend bounds and nonempty shape. Every
nonzero nominal/error magnitude lies between2**-256 and2**256. This conservative
private headroom selector never rejects public input: outside it the original
scalar loops remain. Width0 deltas contain only two getter outward steps,
subtraction and division by exact2, with nonnegative error sums and two backend
subtractions. These bounds leave hundreds of exponent bits before overflow or
underflow, including ulp-sized cancellation and gamma(1) rounding. Signed zeros
remain allowed. Nonfinite, extreme, subnormal, empty and unfamiliar inputs keep
their original diagnostic arithmetic. Only strict Python-int widths qualify;
float/bool/NumPy integer/unsupported widths retain their original behavior.

Positive reuse also requires strict bool bead and0<W<=Y, W<=R<=X+2 where
R=Y for bead and X otherwise. Alias-risk/legal-spill layouts outside this
sufficient guard retain the original expressions. Factors are first computed at
their original reached k point, using the unchanged certified_pi/sin expression
and all getter/ufunc/outward roundings, then only read by delta multiplication.
They never alias returned values and die with the edge invocation. No eager
future-k work is introduced before a possible earlier failure. Width=-1 and
width<-1 paths remain byte-identical in function behavior.

Crucially, flat's nominal data share padded storage but its reshape-created
error columns are independently rounded/copied. All horizontal delta reads
still use padded, all horizontal writes still use flat, and output still uses
padded. These views/error columns were not unified or reassociated.

Complete dependent scope: edge is called by prepare_expected for on/off frames,
between_expected's drift prepass and test_c_acquisition_transfer.bead_expected.
The latter also supplies the public-entry independent calibration predictor.
All eight shared-fixture acquisition suites are affected:2d,boundary,
composition,drift,filter,fitted_drift,preparation,transfer. The separate workflow
oracle has no dependency on this fixture. Scalar on-demand expectations remain.

Measurement-first evidence uses actual public heavy-control inputs, the
independent prepare_expected and test-owned bead_expected observers, transparent
edge-only counting, source-free diagnostics and isolated native-coverage command.
No product was imported or native coverage data inspected. Accepted prep:
1.5307s wall/1.9225CPU;48 width0 calls .3504s and4 width10 calls .8367s.
Initial correction: .7487/1.1896s; width0 .0090s, width10 .3613s. Accepted public
P5/Z5(24x22) bead observer:9.1715/9.5918s with25 width10 calls2.8785s;
initial correction7.1002/7.5200s with edge1.1566s. Complete outputs/columns,
16/0 certificates, warnings and input bits match exactly. Initial timing hash
814df51a differs only by Ruff's line formatting. Final frozen-hash measurements
are edge-probe-final/bead-final.json: prep .8238s wall/1.3264CPU, with width0
.0107s and width10 .4006s; bead8.4124/8.8332s, with edge1.2450s. Both final-hash
complete outputs/certificates/warnings/input bits match accepted B6 exactly.
Non-edge bead timing varied versus the initial attempt; no favorable-only
selection or full-suite speed claim is made from either helper run.

qualify_edge_reuse.py passes270 old/current comparisons under NumPy warn/raise.
It covers positive/zero/negative widths, overlap and legal/risky flat geometry,
bead/nonbead, signed zero, readonly/strided/Fortran, float32/object/complex/subclass
fallback, nonfinite/extreme/subnormal values/error columns, empty dimensions,
unsupported width types and both headroom boundaries. Output nominal/error bits,
status/messages, certificates, warning categories/counts, input nonmutation and
output alias relations match; actual warning/exception locations are retained.
Evidence: edge-reuse-equivalence.log/.json. No product-red or manufactured guard.

Scoped Ruff passes; one formatting correction preceded the frozen hash. Root
narrow canonical Pyright passes0 errors/warnings/informations on ea32; root's
full make check also passes all116 Ruff/format files and Pyright0 diagnostics
(coordinator check-round7.log). Covered eight-suite proof PASSES597/18warnings
in246.24s, with379.665s summed JUnit duration: composition155.487,2d60.882,
transfer54.397,filter61.645,preparation14.581,drift13.733,fitted_drift13.340,
boundary5.600s. The two critical rows take49.050/48.117s; the unchanged authorized
instrumentation records32/32 native admissions in each, all Disc quad/noise.
Evidence: covered8-round7-acquisition.log/.xml/-summary.json and
batch-eligibility-68971.jsonl. This focused timing includes that artifact plugin.
All13 pinned scientific/test hashes match after proof. All owned measurement
and pytest controller/worker processes exited0 and are closed. No source changed
during proof. Fresh B7 acceptance remains the coordinator's pending decision;
this completed author packet will not change after its stable-hash handoff.
Final canonical same-run native/M25/all13 phases/600s proof remains mandatory;
helper gains are not a claim that the goal has passed. A6 regression experiment
and all previous charges/rejected states remain preserved separately.

Same continuing blind A, zero delegation. Only permitted public tests/contracts,
own artifacts/prior snapshots and approved diagnostics were used. No product
implementation/history/nonblind report/coverage data/map/raw canonical profile/
current-task lessons read. Actual model/token/dollar accounting is unavailable.
