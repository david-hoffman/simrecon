# Fresh blind scientific B correction review, round 4

Verdict: accept the exact revised scientific test checkpoint. No actionable
finding remains within the inspected apparatus/preservation scope. The renewed
14-suite focus passed 1062 cases with 18 warnings in 346.53 seconds. B independently
verified the completed XML, summary, keeper occurrences, admission instrumentation
and all 17 scientific file hashes. This accepts a scientific checkpoint; it
does not establish canonical readiness or the requested performance outcome.

## Scope and exact identity

The fixture reviewed is `tests/c_acquisition_fixture.py`, SHA-256
`f7ee10cc241a022f4a0206d00bad3439c9456f74bb64ace5c7bb03125334377f`.
B independently compared its bytes with accepted A2
`e6aaeb89cc32e055f5b74b65018bbd6e35e580390f4eef5545cd32c159760aa5`
and rejected B3
`bb051b2efc6b8a00d39f8b2e59104672c13260626c116d00190d066ba2ed133d`
using plain file/difflib reads, without Git. B3-to-B4 consists only of the two
Disc admission conditions and their explanatory comment. The complete A2-to-B4
change was reviewed independently; B3 supplies no accepted batch checkpoint.

All 17 scientific files in the accepted B2 manifest were independently rehashed.
Only the fixture differs. All eight acquisition suites, six workflow suites,
workflow support and workflow oracle retain B2's exact bytes. The 14-suite AST
inventory remains 187 top-level test declarations and 633 explicit Assert nodes.
These counts describe preservation, not behavioral completeness. Coordinator
figures 722 global declarations and 3066 full nodes remain supplied accounting,
not an independently collected global result from this role.

Authority is the supplied apparatus-speedup/preservation request, AGENTS.md,
review-work's blind B instructions and test-audit's public authoring/preservation
criteria. Public CE common/rebuild/preprocessing/optical-transfer/known-parameter/
carrier/acquisition/ledger/workflow/map/independent-acceptance contracts supply
meaning. PROJECT's permitted public boundary, commands and coverage policy
select approved behavior plus independent risk review; percentages are advisory.
Full canonical/native/platform reports and fresh D remain required.

## Preservation and independent requirement assessment

No scientific equation, assertion, conditional tolerance, supported positive or
on-demand expectation was removed in this correction. Original accepted design
and preservation evidence remains applicable to the 16 unchanged scientific
files. It cannot supply execution proof for the changed shared fixture.

B reviewed the declaration/assertion/decorator inventory across all 14 suites,
the affected numerical callers, the complete fixture delta and necessary
shared observer/public-call support. The owning proof remains real public
raw-to-bands-to-fit-to-native-filter-to-image composition, with independently
specified raw inputs and finite/algebraic expectations. Conditional consumption
relations are separately labeled; they do not replace absolute accuracy truth.
No production function or mock supplies a changed oracle's expected decision.

The retained obligation families include camera/off statistics and phase/Nyquist
preparation; complex radial/full interpolation and actual flat stencils;
finite ordered carrier/regression decisions; self/other support and native
filter/assembly; clock/cubic and drift consumption; representation/provenance/
validation with legitimate positive alternatives; caller nonmutation and
allocation/backend failures. Relevant keepers include acquisition preparation,
transfer, 2d, filter, drift/fitted-drift and composition suites, and workflow
known/numerical/records/validation/failures/compatibility suites. General raw
finite observers, independent closed controls and native-before-relocation
counterexamples remain present. No new custom production seam, scientific
selector, rejection threshold or tolerance was introduced.

All 26 accepted B2 preservation mappings retain applicability. Five clock nodes
still execute four labels each in their original order: seconds, milliseconds,
acquisition-clock-ticks and ` ms `. Each iteration makes the real public call
and retains numeric identity, exact returned label, input identities, cubic
matrix/clock/coefficient/evaluation and independent cubic-unit checks. Six drift
consumption assertion sets still run inside the same named complete raw cases.
B independently compared their original-before assertion/close ASTs with the
current helper/clock loop: all match exactly (3 and 9 check nodes respectively).
Separate raw absolute observations, both exact cubic coefficient truths 1 and
1/216 and the conditional consumption bounds remain intact. Unchanged run(case)
checks caller inputs and NumPy settings for nonmutation.

## Batch, representation and numerical risk assessment

B3's two real test-apparatus defects were an admission/dispatch error family,
not product-red evidence. Plain noise lacks `.error`; plain quadratures perform
initial plain arithmetic without Disc's modeled rounding. Current admission
requires both to be Disc, so these representations retain original scalar
fallback. Plain table/modulation remain valid: table values are explicitly
certified at the original sample boundary, while plain modulation constants
retain their original dtype and zero-error dispatch. The correction changes no
exception handler and introduces no broad catch.

The restricted acceleration family is O2, radial, even native lateral grids,
both axial cutoffs zero, no taper/suppression/damping/omission/precise mode,
normal overlap filtering and zero incoming carrier uncertainty. f64/c128,
shape/contiguity and conservative finite-range checks select acceleration only.
Other branches use the original scalar expression. The range limit reserves
32 powers and 64 exponent bits with a terms-dependent allowance; positive
Wiener/noise margins and native-step/radius checks decline out-of-range work.
Positive w squared lower-bounds the sum of nonnegative powers. The guard is
not a new scientific domain restriction.

The lane machinery keeps nominal operands as zero-dimensional arrays, avoiding
NumPy scalar promotion/dispatch changes. Only the unchanged real error algebra
is batched. Complex magnitude and error-hypot retain scalar calls; two-coordinate
norm retains the original two reductions and gamma(16). Pack/take/scalar restore
preserve existing bits without a new outward round. Original stack, getitem,
reshape and constructor nextafter steps remain represented at their original
logical points. Error columns remain distinct; no blanket tolerance replaces
propagation.

Radial sampling retains all four original flat offsets and expression order,
including zero-weight vertices, K1 duplicates, once-only axial wrap and legal
in-allocation flat aliases. Full sampling retains its scalar path and all-axis
reflection/conjugation. Raw keys and certified radial keys include complete
nominal/observer/backend dtype, shape and bytes. Order/native axial inputs
remain distinguished. Sampling caches belong to one owning invocation or native
component, tables stay fixed during that lifetime and cached values have no
mutating consumer. There is no global/cross-test numeric cache.

Self power occurs once. Other powers accumulate in the original direction then
signed-order sequence, with strict other support and inclusive self support;
w squared is last. Native reflection, original traversal, zeroed axial slots,
side temporary storage, conjugate recombination and later finite-sum assembly
remain unchanged. The batch buffers values/certificates privately until an
entire component succeeds. Unsafe stencils decline without publishing any
batch prefix; scalar fallback recovers the original first failure and original
certificate prefix. Lazy scalar amplitude/power/conjugate/carrier/Wiener/taper
hoists have local lifetimes and no mutating consumers.

The scalar constructor buffer fast path preserves nominal aliasing, dtype,
shape, strides and read-only status while copying the independent error
columns. Unsupported shapes/kinds and construction through a Disc subclass still use
the original general path. No changed cache or constructor supplies expectations from product output.

## Own source-free checks and supplemental evidence

Three successful tiny fixture-only commands used scripts/source_free_check.py
with source-free warnings, exceptions and child diagnostics before execution.
No simrecon module was imported. No heavy pytest, coverage operation or product
probe ran alongside the author's proof.

1. `/tmp/scientific-b4-probe.py` compared accepted A2 and current complete results
   on 16 controls: nonconstant complex data/table and unequal noises, zero
   carriers, plain modulation/table/quadratures/noise, uncertain table increments,
   small/boundary support, zero table/bands, 3D, multiple times, unsafe-first and
   unsafe-later stencils, and noncontiguous quadratures. All nominal/error bytes,
   dtypes/shapes/strides/writeability, complete ordered certificate lists,
   value-or-error outcomes and input nonmutation matched. Plain noise/bands and
   noncontiguous controls did not enter batch; first/later unsafe stencils
   declined and preserved scalar prefixes of one/two certificates.
2. `/tmp/scientific-b4-lanes.py` passed 2716 exact scalar/lane/sampling checks,
   with deterministic independent values across binary exponents -28..28,
   nonzero separate incoming errors, real/complex ufunc nodes, 17-lane mixtures,
   direct/on-demand/cached radial samples, signed zero/coordinates and axial
   indices, plus 10 constructor dtype/read-only/alias/error-copy cases.
3. `/tmp/scientific-b4-algebra.py` checked two independently derived closed
   controls on both revisions: unit transfer/noise/modulation, zero carriers
   and DC input give divisor 3+0.5 squared=3.25 and native/image 4/13; four
   quarter-weighted complex corners give bilinear value 4+1.25i exactly.

B inspected the permitted constructor/lane/native/representation/exact qualifier
sources and sanitized summaries. The 64 representation cases cover all 16
plain/Disc field combinations in 2D/3D with zero/nonzero incoming errors;
constructor 46-case and 135 lane-node evidence, 23 native/fallback cases and
144-query uncertain-table sampling supplement the independent checks. The
native qualifier's plain label means plain carriers, so it alone does not
prove B3's plain-noise/quadrature fixes. Direct A2-based representation and own
checks fill that gap.

The artifact-only `batch_measurement.py` hash is
`a9b67104370db5f06c214c19b4e2bc1803f30a4bc8478ae98577e3422e26e5ae`.
It delegates the same arguments, result object and exceptions, then logs only
admission/type flags and time/direction/order for two existing cubic rows. It
adds no scientific decision, expectation, numeric cache, collection or assertion
change. Focused timing includes instrumentation; canonical proof must use its
ordinary command without this plugin.

Existing private invalid-infinite sampler diagnostics differ in duplicate count
(6 original versus 4 optimized), with all distinct warning categories/messages
retained. No warning filter or public scientific behavior was changed to hide
this known private diagnostic difference. The interrupted obsolete 14-suite
run remains status2, 593 passed/18 warnings/228.71 seconds, incomplete evidence.
It cannot count as an accepted run. No broad performance conclusion follows
from a small eligible probe or fixture-only profiles.

## Execution proof, exposure, limits and accounting

The completed covered14-round3-corrected.log ends with 1062 passed, 18 warnings
in 346.53 seconds. B independently parsed its XML: exactly 1062 testcase nodes
over the expected 14 suites, with no failure/error/skip nodes. Every per-suite
node count and time sum matches covered14-round3-corrected-summary.json. All six
drift keepers and all five clock keeper nodes occur exactly once. The plugin
JSONL contains 32/32 accepted components for each named cubic row, all with Disc
quadratures/noise. B rehashed all 17 scientific files afterward: the current
fixture matches the pinned identity and the other 16 match accepted B2. The
current five-file scientific-inputs.sha256 also matches. Exact evidence hashes
are in accepted-filehashes.json.

The coordinator attests fixed two workers, loadgroup, no worker restart and
source-free diagnostics; the log shows two worker startup cycles and retains
source-free warning categories/messages/locations. Its separate startup
CoverageWarning reports the source-free sitecustomize file already imported;
this is disclosed diagnostic evidence, not proof of native report completeness.
The current narrow canonical type log has zero errors/warnings/informations;
scoped Ruff lint/format pass is coordinator-supplied.

Full canonical under-600-second runtime proof, all 3066 full nodes, complete
native/platform reports and fresh D remain separate coordinator gates. The
346.53-second covered focus uses an artifact-only measurement plugin and is
not the full canonical command. This role has not inspected coverage data/maps,
raw runtime profiles or full canonical evidence and grants no waiver.

B4 is one fresh blind launch and one completed accepted correction review,
with zero requested candidate corrections, three successful source-free command
families, zero failed probes/launches, no probe-input correction and no target
edits. One own static XML-evidence helper initially omitted xdist
@group suffixes when matching keeper names; it failed its own assertion, then
passed after normalizing that suffix. This was a reviewer check-input
correction, not a candidate defect; it remains charged.
B1 accepted/B2 accepted/B3 correction-required and all author/coordinator work,
including the interrupted obsolete run, remain charged once each. No human
review/scenario/time/token/money cap was supplied. Actual serving/effort,
token metering and monetary cost are unknown, not zero.

Exposure stayed within the supplied role/public packet, accepted A2/B2 and
original-before tests/evidence, rejected B3 fixture/scoped report/reproducers,
current fixture/dependent tests and permitted qualifier/correction evidence.
One narrow filename inventory displayed excluded pstats/raw-coverage filenames;
none of their data was opened or used. Bulk static listings that exceeded the
output budget were followed by targeted reads/inventories; truncation supplies
no passing evidence. No product implementation, Git history/diff/log,
implementation-bearing task state, nonblind scientific reports/ledgers,
baseline/candidate raw runtime logs/summary/pstats, coverage data/map, LESSONS,
parent conversation or agent inventory was read. No Superpowers, delegation,
commit, gate edit or external message.

All three own probe processes exited. Their exact three scratch files
`/tmp/scientific-b4-probe.py`, `/tmp/scientific-b4-lanes.py` and
`/tmp/scientific-b4-algebra.py` were removed after source-hash recording and
absence confirmation.
No daemon/server remains. Durable role output is this report and accepted-filehashes.json. No target or unrelated path may be removed by this role.
