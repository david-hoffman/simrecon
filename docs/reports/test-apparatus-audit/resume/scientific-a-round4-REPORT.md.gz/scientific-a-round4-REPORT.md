# Blind A4 workflow facts checkpoint

Accepted A3/B4 source and proof are preserved in round3/. This checkpoint changes
only tests/c_workflow_oracle.py and three repeated-budget call sites in
tests/test_c_workflow_numerical.py and tests/test_c_workflow_records.py. No
production changes, tests, rows, assertions, logical examples, tolerances,
independent expectations, CE08 obligations, or omission guards were removed.
The 722 declarations and expected1062 focused/3066 full nodes remain.

## Change and mathematical equivalence

_SampleFacts owns one Table and one table_error ndarray by identity, for one
error_budget invocation. It lazily records _table_slopes(table, order) and
float(max(table_error[order])) only when that order is first actually reached.
Both depend solely on these fixed arrays/declarations. The independent
Table.sample call still executes first on every query; the existing position
error, norm, axial error, full-table reflection assertion and final sum preserve
their arithmetic/order and constants. The maximum is still first computed
after the reflection assertion. Original _sample_error without facts remains
available on demand. Table, coefficients and incoming error arrays are never
written by any consumer; returned complex/float facts are immutable.

Direct overlap_errors, parameter_errors and native_errors callers receive fresh
local facts when none are supplied. error_budget creates one fresh pair after
calibration has selected the effective table, then shares it only with that
invocation's parameter_errors and native_errors. Wrong table/error identities,
custom Table subclasses/samplers and unfamiliar array representations keep the
original uncached path. Original pure bound-method identity is captured as an
instance function value; no numerical state exists at module/class/global/test
scope. There is no nominal query memo in the final checkpoint.

The hidden-fit discriminator passes its already computed same-case/expected
budget into assert_scientific. The direction/z-major discriminator computes the
same two budgets once and passes each unchanged into its corresponding
assert_scientific call. The separation assertion still evaluates the identical
image difference before the budgets, using the same absolute budgets and factor
100. Every real public call and subsequent assertion remains. These three
removed evaluations have explicit keepers: the existing local budget, budget_d
and budget_z objects. Conditional stage-consumption and absolute raw-observation
proofs are unchanged and distinct.

## Complete dependent scope

_table_slopes -> _sample_error -> overlap_errors (two sample sites) and
native_errors (two sample sites). parameter_errors has four overlap_errors
sites covering coarse, refinement, later pair and known/reused carriers.
error_budget invokes parameter_errors/native_errors. The public-test caller
c_workflow_support.assert_scientific defaults to error_budget; its independent
carrier-radius and numerical-model qualifier helpers also use error_budget.
Direct calls exist in test_c_workflow_00_known, numerical and records;
native_errors also supplies the conditional numerical stage proof.

All six workflow files are affected review/check scope: test_c_workflow_00_known,
compatibility, failures, numerical, records and validation. Validation imports
the shared controls but does not consume these changed numerical bounds.
The eight acquisition files and c_acquisition_fixture are byte-identical to
accepted A3; applicability of prior evidence remains an independent B decision.
No test-call relationship or expectation was inferred from production source.

## Supplemental evidence and measured limits

qualify_workflow_facts.py compares accepted A3 and current outputs for all56
existing control_cases, including independent observations, complete nested
budgets, warning categories/messages and input nonmutation. All match exactly.
Its70 additional sample-error cases cover radial/full layout, signed zero,
nonuniform coefficients/errors, both axial signs, reflection ambiguity,
unsafe/nonfinite queries, nonfinite table values, wrong table/error identities,
fresh contexts and a mutating custom sampler. Original/current values, failures,
warnings and custom invocation effects match; diagnostic locations are retained
in workflow-facts-equivalence.json. These are supplemental equivalence probes,
not a product-red claim or substitute for real scientific tests.

workflow-facts-probe.{log,json} is a PRE-GUARD diagnostic of the preserved
round4-fixed-facts/tests checkpoint. Its Table.sample wrapper disables caching
under the later frozen pure-method guard. B5 correctly identified that it was
misrepresented as final-checkpoint performance in the first report. That claim
is withdrawn; the fixture was not changed to accommodate instrumentation.

The renewed probe_workflow_final.py leaves Table.sample unchanged and wraps only
_sample_error and _table_slopes, transparently forwarding all arguments/returns/
exceptions. workflow-final-probe.{log,json} matches all five complete prior/final
observations/budgets/warnings and input bits. Heavy within3d wall2.5937->1.2695s,
CPU2.9027->1.5768s, slopes87556->2 with87556 sample-error queries retained.
Full3d wall.2300->.0856s/slopes4639->3, empirical .4947->.2722s/13990->3,
literal direction .2321->.1264s/8112->3 and z .2347->.1289s/8112->3. These are
uncovered representative calls excluding observe, not whole-suite saving claims.

workflow-stage-probe.{log,json} separately times current observe, independent
budget and public run once on two controls, followed by unchanged scientific
assertions. Within3d wall/CPU: observe.7912/3.1271s, budget1.2230/1.5317s,
run2.2679/2.6652s. Empirical: observe.1418/.5425s, budget.2545/.6695s,
run.3327/.3325s. No production implementation was inspected.

An authorized experimental exact typed-query nominal memo is preserved only in
round4-fixed-facts/experimental-nominal-memo.py with workflow-memo-probe evidence.
It matched all five witnesses but failed to earn its cost: heavy budget
1.2984->1.2820s, full-table .0927->.0979s, literal-z .1190->.1218s. It was removed
before final qualification. Original pure method capture initially needed an
instance default_factory to avoid descriptor rebinding; corrected before its
first measurement. The final checkpoint keeps only slopes/maxima reuse.

Scoped Ruff/format and root canonical narrow Pyright pass (0 errors/warnings).
The frozen covered six-suite proof passes465 in63.43s, with121.360s summed test
durations. Prior A3 corresponding sum130.616s, so observed aggregate saving is
only9.256s across these runs. Exact frozen workflow hashes remain unchanged.
Evidence: covered6-round4-workflow.log/.xml/-summary.json; isolated native
coverage data remains unread. Initial three long call lines were formatted;
that lint attempt remains recorded. Fresh B5 acceptance and canonical same-run
native/M25/600s gate remain pending. These measured savings do not establish
sufficient margin. The separate overlap-lane slice was proposed and explicitly
authorized independently; no workflow source changes belong to that slice.

## Role accounting/exposure

Same continuing blind A root; zero child roles. Previous charges, A3 rejected
checkpoint, interrupted proof and B3/B4 evidence are retained. This round used
only permitted test fixtures/prior accepted snapshots/public commands and its
own supplemental artifacts; no implementation, history, nonblind reports,
coverage data/maps or raw product diagnostics were inspected. A narrow Makefile
read confirmed only the already public canonical coverage command. All Python
commands use the approved inherited source-free harness. No new product-red
claim. Actual model/token/dollar accounting is unavailable, not zero.
