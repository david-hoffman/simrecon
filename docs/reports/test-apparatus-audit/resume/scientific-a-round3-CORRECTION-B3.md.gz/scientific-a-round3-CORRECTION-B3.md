# A3 correction 1 for fresh B4

Stable fixture SHA-256:
`f7ee10cc241a022f4a0206d00bad3439c9456f74bb64ace5c7bb03125334377f`.
Root canonical narrow Pyright and scoped Ruff lint/format pass.

B3 rejected `bb051b2efc6b8a00d39f8b2e59104672c13260626c116d00190d066ba2ed133d`
for two test-apparatus representation regressions: plain noise has no `.error`,
and plain quadratures make the initial numerator operations plain, with zero
error, whereas the lane path added a modeled rounding. No product defect/red.

The correction only adds admission requirements that quadratures and noise be
Disc. Other supported representations run the existing scalar path. No math,
bound, certificate, tolerance, sample or exception handler changed. Plain table
and modulation remain eligible when quadratures/noise are Disc; their original
scalar operations/zero-error constants are retained.

Both exact B3 reproducers now pass against accepted A2, without importing product:
`reproduce-plain-noise-corrected.log` and `reproduce-representations-corrected.log`.
The latter retains the original first observer/conditional divisor bounds
6.154461134763113e-14 / 6.215714818880378e-14.

`representation-matrix-equivalence.json` passes 64 cases: every one of the
16 plain/Disc combinations of quadratures/noise/table/modulation, in 2D and 3D,
with zero and nonzero incoming certificate errors. Each case independently
matches A2's nominal/error arrays, complete ordered certificates and input
nonmutation. Only both-Disc quadrature/noise combinations accelerate.

Rejected source/proofs/reproduction failures are preserved under `round3-rejected/`.
Its obsolete covered14 was interrupted once by SIGINT: status2, 593 passed,
18 warnings, 228.71 s. This is partial diagnostic evidence, never acceptance.
No worker/controller from it remains active. All prior attempts remain charged.

The renewed covered14 will use `batch_measurement.py`, an artifact-only plugin
authorized by the coordinator. It forwards numerical arguments, return object
and exceptions, and records only test-owned admission flags and(t,d,m) for the
two existing cubic composition rows. It changes no collection/assertion/flag/
scientific decision. Focused timings include this instrumentation. The ordinary
final canonical command will not load it. Exact plugin hash/logs accompany proof.

No production/history/nonblind/coverage-map exposure, no global/cross-test numeric
memoization, no additional declaration/example removal, no commits. Author A
continues the same blind session; fresh B4 must decide acceptance/evidence reuse.
