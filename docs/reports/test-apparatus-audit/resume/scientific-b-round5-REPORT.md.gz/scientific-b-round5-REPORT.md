# Fresh blind scientific B workflow review, round 5

Verdict: accept the exact three-file workflow checkpoint named in
accepted-filehashes.json. No actionable scientific or preservation finding
remains in this slice. The completed affected proof has 465 passing cases in
63.43 seconds. This is workflow-oracle acceptance, not canonical, performance,
native-report, acquisition-overlap or final D acceptance.

## Scope and retained checkpoint

Reviewed current c_workflow_oracle.py, all six test_c_workflow suites,
c_workflow_support.py, the accepted round3 workflow snapshots and permitted B4
acceptance. The changed files are the oracle, numerical suite and records suite.
Their exact SHA-256 values independently match all three supplied pins. The
other four workflow suites and support match accepted B4. The round3 versions
of the three changed files also match B4's accepted identities.

Authority is the supplied apparatus-work reduction/preservation request,
AGENTS.md, review-work's blind B role and test-audit's public authoring and
preservation questions. Public common, optical-transfer sampling, known-filter,
carrier overlap, workflow and workflow-map contracts supply the relevant
mathematics. PROJECT selects approved behavior with independent risk review;
percentages are advisory, while complete native reports and the exact full
local/platform gates remain mandatory.

The workflow oracle imports only standard-library modules and NumPy. Workflow
support uses that oracle and resolves product entries only in its public-call
functions. These workflow suites do not import c_acquisition_fixture.py. The
separate acquisition overlap change therefore does not supply this oracle's
expectations. B5 has not opened or accepted that fixture. B6 and the final
integrated full gate/D must cover it and combined inputs independently.

## Oracle and preservation assessment

The only changed existing oracle functions are _sample_error, overlap_errors,
parameter_errors, native_errors and error_budget; _SampleFacts is the only added
class. No existing function was removed. The observer's raw inputs, independent
finite transforms, empirical preparation, finite search and native image truth
are unchanged. The original uncached _sample_error remains directly callable.

Facts contain immutable scalar slopes and per-order error maxima for one exact
table/error-array pair. error_budget creates its context after selecting the
effective calibration table and shares it through parameter and native bounds.
Direct owner calls allocate fresh contexts. Both arrays and all relevant table
declarations remain fixed during these owners' traversals; no consumer writes
them. Identity mismatch, Table subclasses, array subclasses and changed/custom
sample implementations use the scalar path. There is no module/global numeric
state and no coordinate, nominal-query or cross-test memo.

Every nominal Table.sample call still occurs before cache admission or slope
lookup. Slopes are reached only after that sample succeeds. Position/norm and
axial errors, full-table reflection assertion, first maximum evaluation and
final error addition retain their original order and constants. Reflection
failure does not populate maxima; an unsafe nominal sample populates neither
fact dictionary. Reached-order-only facts introduce no eager unused-order
failure. Independent fixed-cell checks derive the same bounds from known
coefficient increments, rather than only comparing two oracle revisions.

The hidden-fit test passes its already computed budget for the identical
case/expected object pair. Its wrong-class table and wrong-gain discriminators
operate on independent copies and do not mutate that pair. The literal layout
test computes the same direction/z-major image difference first, derives the
same two case-specific budgets, and passes each with its corresponding case
and expectation. The factor-100 discriminator, actual public calls and later
scientific assertions remain. Three duplicate budget evaluations are removed;
no independent expectation or assertion is removed.

Static comparison finds 55 test declarations and 213 explicit assertions in
the six suites, unchanged. The numerical suite's complete assertion AST is
unchanged. The records suite changes only the literal-layout function; its
single inline discriminator is expressed using the equivalent local difference
and budgets. Other function ASTs are identical. Ordered run, observe, close and
filter_and_assemble call expressions remain identical in both changed suites.
The shared scientific assertion helper is byte-identical to B4.

The owning boundary still exercises real raw-to-preparation-to-fit-to-native
filter-to-signed-image composition. Independent known/closed controls precede
nuisance fitting. Returned-field consumption relations remain explicitly
conditional and separate from absolute raw-observation accuracy. The workflow
keepers retain empirical complex128 consumption, arbitrary complex layouts,
reflection/stencils, finite decisions, true2D/literal layout, current-time fits,
clock/cubic units, ownership/identity and operation-failure obligations. No new
product seam, selector, domain restriction, tolerance or favorable-only bypass
was added. All prior 26 keeper mappings retain applicability for this workflow
delta because their keepers/assertions remain; B5 grants no verdict about the
concurrent acquisition delta. Coordinator totals 722 global declarations and
3066 full nodes remain supplied accounting, not B5 full-suite collection.

## Independent source-free checks

Four tiny fixture/static command families used .venv/bin/python with
scripts/source_free_check.py and its inherited sitecustomize diagnostics.
No product module was imported and no heavy test/coverage run was launched.

1. The main probe passed 240 exact prior/current sample-outcome cases across
   radial/full layouts, K1/K2/K3, complex64/complex128/float32/float64/big-endian
   storage, signed zero, both coordinate signs, shifted axial requests, unsafe
   stencils, NaN/Inf queries and unresolved reflection. Ten independent checks
   cover analytic affine interpolation/error bounds and a closed DC native
   control. With unit transfer/noise/modulation, zero carriers and w=0.5, three
   eligible powers give denominator 3.25 and coefficient/image 4/13. Three lazy
   ordering checks and six fallback families pass. Ten direct/conditional
   native comparisons and four fresh-call checks vary incoming table error and
   mutate table values between new owner calls; a later zero-uncertainty call
   does not inherit a preceding uncertain call. The actual test-owned
   conditioned_native_expectation helper was checked using synthetic observed
   fields and independent zero-input-uncertainty native bounds.
2. A counting witness independently diagnoses the instrumentation issue below:
   a Table.sample wrapper gives 33 nominal/33 slope calls on both revisions;
   wrapping _sample_error instead gives 33 nominal queries with prior33/current2
   slopes and identical image bounds. The witness itself takes milliseconds.
3. The static/XML helper verified hashes, preservation, exact six-suite counts,
   unique node identities, per-file duration sums and all named keeper nodes.
4. Eight additional closed-value checks establish full all-axis reflection and
   conjugation, once-only negative axial radial wrap, and signed-zero behavior
   on both revisions.

The main probe initially imposed a binary64 analytic exact-value assertion on
complex64 arithmetic; it failed its own overstrong premise. Restricting that
analytic check to binary64 components fixed the probe; complex64 remains in the
240 exact prior/current checks. The static helper initially passed a Python list
to ast.dump; its list handling was corrected. A later log-consistency check
incorrectly expected JSON-only fingerprint rows to appear in the log; it was
corrected to compare the rows the measurement actually prints. These are three
charged reviewer check-input corrections, not candidate defects or product-red
evidence.

An invalid infinite-table probe retains the same NaN-bound outcome and distinct
RuntimeWarning/"invalid value encountered in subtract" identity. Repeated
cached queries emit two warnings versus six originally. This is a disclosed
duplicate-warning difference outside the accepted finite-transfer domain,
not exact diagnostic-count parity. No warning filter or scientific assertion
was changed to hide it.

## Evidence correction and execution proof

B5 found one real measurement-provenance defect: workflow-facts-probe.py
replaces Table.sample after module load, which disables the final captured
pure-method guard. Its supplied 2/3-slope results therefore did not identify
the final guarded checkpoint. The author corrected ROUND4.md to mark this
PRE-GUARD evidence and withdrew its final-checkpoint claim. No source change
was made to accommodate instrumentation.

The replacement probe_workflow_final.py wraps only _sample_error and
_table_slopes, forwarding arguments, results and exceptions. Table.sample and
the purity guard remain unchanged. B inspected that code and the matching
five-case log/JSON: complete observations/budgets/warnings and input snapshots
agree. The heavy witness retains 87556 nominal sample-error queries while
slopes fall 87556 to 2; wall time is 2.5937 to 1.2695 seconds. Other cases retain
4639/13990/8112/8112 queries and reduce slopes to 3 each. This resolves the
evidence finding and agrees with B's independent tiny witness. These are
representative uncovered budget calls, not a full-suite runtime guarantee.
The removed memo experiment remains historical evidence, not current code.

B independently parsed covered6-round4-workflow.xml: exactly 465 unique
testcases, with no failure/error/skipped nodes. Counts are validation285,
records86, numerical80, compatibility6, known5 and failures3. Every per-suite
count/time sum matches its summary. All five clock keeper nodes, six complete
drift keeper rows and both changed discriminator nodes occur exactly once.
The log finishes 465 passed in 63.43s and shows two workers; fixed-two,
loadgroup and no restart are coordinator-attested. A startup CoverageWarning
reports the already imported source-free sitecustomize file. It is disclosed
diagnostic evidence and does not prove native report completeness. Root's
narrow canonical Pyright and scoped Ruff/format passes are supplied evidence.
The three frozen source hashes were independently reconfirmed after the proof
and replacement measurement.

Full canonical 3066-node proof, the requested under-600-second outcome,
same-run M25, complete native/platform reports and fresh integrated D remain
coordinator gates. No percentage, performance or coverage waiver follows.

## Accounting, exposure and scratch

B5 is one fresh blind launch and one completed accepted workflow review, with
zero candidate-source corrections requested, one measurement-evidence defect
corrected without source changes, four successful own command families and
three failed own check-input attempts retained. B1 accept, B2 accept, B3
nonaccept with two admission defects, B4 accept and all prior author/coordinator
charges remain. Human review/scenario/time/token/money caps are not set.
Requested model/effort is Sol/high; actual serving, metering and monetary cost
are unknown, not zero.

Exposure was limited to the named public/role documents, workflow tests/support,
accepted workflow snapshots/B4 evidence and permitted sanitized artifacts.
Filename inventories displayed excluded profile/coverage/nonblind-report names;
their contents were not opened or used. No product implementation, acquisition
fixture contents, Git history/diff/log, task state, nonblind ledger/report data,
raw canonical logs/summary/pstats/native coverage, LESSONS, parent conversation
or agent inventory was read. No Superpowers, delegation, source fix, commit,
gate edit or external message occurred.

All own probe processes exited. The only own scratch paths were
/tmp/scientific-b5-probe.py, /tmp/scientific-b5-counts.py,
/tmp/scientific-b5-evidence.py and /tmp/scientific-b5-edge.py. Their source hashes
are preserved in accepted-filehashes.json; they were removed after recording
and their absence was confirmed. No owned daemon/server remains. Durable B5
output is only this report and accepted-filehashes.json.
