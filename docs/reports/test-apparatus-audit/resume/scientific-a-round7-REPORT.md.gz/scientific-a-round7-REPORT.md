# Current blind A7 author checkpoint

Current fixture is ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc.
The coherent new correction is only minimal edge dead-work/local-factor reuse;
ROUND7.md contains its complete mathematical/diagnostic/ownership review scope.
No product, tests, rows, assertions, examples, tolerances, independent truth or
CE08 obligation changes in A7. Accepted B5 workflow hashes remain unchanged.

The270-case old/current edge matrix passes exact nominal/error columns,
certificates, statuses/warnings, input nonmutation and alias checks under NumPy
warn/raise. Matched final-hash complete preparation and public bead observers
retain exact outputs/certificates/diagnostics; measured costs and all attempts
are in ROUND7.md and edge-probe-*.json. Earlier exploratory timings remain
separately labeled, including the rejected/restored A6 regression experiment.

The eight affected acquisition suites pass597/18warnings in246.24s with379.665s
summed JUnit durations. All pinned source hashes are unchanged after proof.
The unchanged artifact instrumentation records32/32 native admissions in each
critical cubic row. All owned helper/pytest controller/worker processes exited0.
Root full make check passes116 Ruff/format files and Pyright0 diagnostics.

Current evidence: ROUND7.md, round7-checks.json,
round7-scientific-inputs.sha256, edge-reuse-equivalence.json and
covered8-round7-acquisition-summary.json/.log/.xml. All14 focused suites are
covered by this597 proof plus the unchanged accepted B5 workflow465 proof,
subject to reviewers' applicability decisions. B7 acceptance and final canonical
same-run native/M25/all13 phases/600s gate remain pending. Candidate2's previous
3066-pass/all13-phase611.04s baseline is over target; no helper/focused result is
claimed as the final goal. No further source/probe work is active.

Same continuing blind A, zero delegation. No implementation/history/nonblind
discovery/coverage data or maps/raw canonical profiles/current-task lessons read.
All earlier attempts and charges remain retained; actual model/token/dollar
metering is unavailable. Prior reports below are historical checkpoint records,
not statements of current source identity or current pending review stage.

---

# Historical A3 correction packet (retained verbatim)

Status: corrected source is frozen, narrow root Pyright and scoped Ruff pass,
small equivalence probes pass, and covered14 passes:1062 tests,18 warnings,
346.53 s. Fresh B4 acceptance and canonical 600 s remain pending.
See CORRECTION-B3.md for the diagnosed
representation defects and exact correction.

## Identity and preservation

Only tests/c_acquisition_fixture.py changed from accepted A2/B2. Its current
SHA-256 is `f7ee10cc241a022f4a0206d00bad3439c9456f74bb64ace5c7bb03125334377f`.
The other scientific hashes remain:

| File | SHA-256 |
| --- | --- |
| c_workflow_support.py | 10265f0a62703ee30f136e00559cbbc8fbda470cf01213c7487bb39ff7705902 |
| test_c_acquisition_composition.py | 5337985855e5e41c96c7b323ff18519e4841d41b2cda1eb51becb9cef28a0158 |
| test_c_workflow_numerical.py | 2d6b65408d545da5890911c97ac8d9dac7ba9a013cbf7e337c7f74a4cf45e659 |
| test_c_workflow_records.py | cccbbcc9a16fdfcdaa43727bfe38359d2bd67bddfb3d40a67232f5e73b121461 |

All 14 test files remain byte-identical to A2. There are still 187 scoped and
722 global static declarations, with expected 1062 focused / 3066 full physical
nodes. No additional assertion, parameter row, logical example, tolerance,
on-demand expectation, omission guard or CE08 acceptance test was removed.
A2's 26 old-row keeper mappings remain in round2/declaration-preservation.json.
Accepted A2 files/reports are in round2/; rejected B3 source/proof is in
round3-rejected/. The original scalar equations remain callable.

## Exact local reuse and scalar allocation

Disc's numeric 0D fast path allocates its view directly on the same C-contiguous
nominal buffer and copies/rounds the two real scalar error columns exactly once.
It avoids discarded finalize zero arrays and scalar broadcast wrappers. Other
shapes, representations and unsupported metadata retain the original path.
The constructor probe covers nominal aliasing, independent writable error
storage, readonly/unaligned/endian inputs, signed zero, subnormal/nonfinite
values, empty/strided arrays, object fallback, errors and warning identities.

reconstruct_expected lazily reuses identical modulation powers/conjugates,
signed carrier multiples, per-time Wiener square/margin and taper denominator.
Python center-order 1 and plain NumPy scalar operations keep their original
types/zero incoming errors. First computation stays at the original reached
point; Wiener failure is not moved earlier. local_samples adds an exact raw
coordinate key before its existing certified radial key. Keys include complete
nominal/error dtype/shape/bits and native axial/order inputs; table declarations
stay fixed for the invocation. No global/cross-test numerical cache exists.

## Restricted native lane path

Acceleration requires two orders, all axial cutoffs zero, even native X/Y,
radial complex128 transfer, float64 carriers, zero incoming carrier uncertainty,
none taper, overlaps enabled, and no suppression/damping/omission/precise flags.
Quadratures and noise must be Disc, with the expected shapes/dtypes and ordinary
contiguous storage. Plain quadratures/noise and every excluded mode use the
existing scalar path. Plain table/modulation are supported when the other
conditions hold. Incoming band/noise/table/modulation uncertainty remains active;
coordinate arithmetic and norm uncertainty are not removed.

The private lane value is a list of original 0D nominal ndarrays and two real
error columns. Every nominal ufunc uses the original 0D operands per lane;
complex magnitudes retain the distinction between 0D operands and raw NumPy
scalar results. Error-hypot evaluations remain scalar. Real error add/multiply/
square expressions retain their scalar arithmetic order, with unchanged gamma
arguments and outward nextafter steps. Stack/index structural roundings are
explicit; pack/unpack adds none. Each geometric norm still evaluates exactly
two components with the original reductions and gamma(16), never a batch-size
allowance. Plain modulation power/conjugate expressions are calculated as
plain scalars before packing, rather than being assigned Disc rounding.

Tiles contain at most 16 cells. Denominator additions retain direction/signed-
order order, with no reduction over that sequence. Native self support remains
inclusive; other support remains strict. Only originally visited stencils are
sampled. All four literal radial flat addresses are checked, including zero-
weight and duplicated K1 vertices. Reflection, positive Nyquist, assembly,
scale, coordinates, output fields and existing scalar side-band recombination
remain unchanged.

Preflight/results/records remain private until the entire native component
succeeds. Recognized unsupported representations, unresolved positive bounds,
unsafe visited stencils or out-of-headroom inputs decline to the scalar path
without target writes or global certificate records. This prevents a later
failure from replacing the original earlier failure. Unknown programming or
headroom-proof failures raise RuntimeError, not a catchall fallback. On success,
divisor records and writes occur in original cell order. Zero incoming carrier
uncertainty means this eligible family emitted no support-certificate records
before acceleration either; its nominal support comparisons remain unchanged.

The private finite-arithmetic guard only chooses acceleration. For T=3D+1 it
uses E=floor((float64.maxexp-1-ceil(log2(T))-64)/32), B=2**E. Incoming components
and error columns must be finite within B; noise/Wiener positive margins and
frequency increments must be at least 1/B. Interpolation error degree is at
most3, denominator error at most9, and quotient error at most17 after the
positive Wiener lower bound. Reserving32 powers plus64 exponent bits and the
term-count allowance leaves conservative finite-arithmetic headroom. The original
scalar path remains available on both sides of this operational guard; it is
not a scientific domain limit, tolerance or rejection. Just-inside/just-outside
and signed-zero guard examples retain exact scalar outcomes/certificates.

## Complete dependency and review scope

Disc/local_samples changes reach every declaration/row in the eight acquisition
suites: 2d, boundary, composition, drift, filter, fitted_drift, preparation and
transfer. reconstruct_expected is called directly by 2d/composition/filter/
transfer and by predict_public's real reconstruct_known wrapper. overlaps is
used by 2d/composition and finite_search/parameter_model. The finite search,
threshold/equality/sensitivity rules and public result/schema checks remain.

All six workflow suites remain sibling proof: 00_known, compatibility, failures,
numerical, records and validation. c_workflow_oracle/support and all their test
files are unchanged from A2. The independent CE08 small/matched/large suites and
their on-demand oracles remain unchanged and required by canonical verification.
Approved public CE02–08 contracts remain the only scientific sources; advisory
percentages and complete native reporting remain the inherited coverage policy.

Fresh B4 should independently review representation/dispatch admission, each
nextafter boundary, scalar-vs-NumPy-scalar magnitude/dtype behavior, norm size,
range headroom, visited stencils, ordered divisor records, failure prefixes,
input/cache aliasing and every legitimate excluded-mode fallback. Retained A2
evidence applicability belongs to B4, not this author.

## Evidence and limitations

- Exact B3 reproducers were run before correction and preserved both failures.
  Corrected logs show A2/current success with six certificates and identical
  plain-quadrature divisor bounds. No product is imported by those probes.
- representation-matrix-equivalence.json: 64 cases, all16 plain/Disc combinations
  across quadratures/noise/table/modulation in 2D/3D and zero/nonzero incoming
  certificate profiles. Each representation matches A2 independently; differing
  representations are not asserted to have the same uncertainty model.
- lane-node-equivalence.json: 135 single-/heterogeneous-multilane primitive
  cases, including plain/certified asymmetry, dtype variants, signed zero and
  subnormals. Native/fallback parity: 23 complete cases, including 2D/3D,
  nonzero input errors, one-cell/multi-cell tiles, multi-time Wiener steps,
  excluded modes/fields, range edges and first-failure ordering. A failure in
  the second tile retains exactly the original20 prior divisor records;
  earlier noise/Wiener failures beat later unsafe vertices with zero prefix.
- Constructor46, table-error144 and six complete observer/gain-section probes
  pass. Numeric centers, both error columns, shapes/dtypes/strides/writability,
  ordered certificates, outcomes and caller nonmutation compare to independent
  preoptimization/A2/scalar snapshots. All eight gain branch combinations remain.
- The previously disclosed invalid-infinite private-observer warning count is
  still6 before /4 after, with identical category/messages and all locations/
  counts retained. This is not a claim of identical duplicate warning lists.
  No test/product warning filter or suppression was introduced.
- Matched covered eligible-family probe (historical pre-admission correction,
  same all-Disc fields that satisfy the correction): A2 CPU6.408715 s versus
  A3 2.771051 s, exact fingerprint,16/16 accepted components/680 inside cells.
  5424 lane dispatches cover125146 original scalar operations. Conditions are
  small D4 native controls and current coverage tracing; no owned runtime was
  imported, so already-imported/no-data CoverageWarnings are retained. These
  probes are performance estimates, never complete native coverage reports.
- The renewed full1062 focus is source-free, fixed2/loadgroup/no restart and
  isolated coverage data, with JUnit/durations. It includes authorized artifact
  batch_measurement.py (SHA-256 a9b67104370db5f06c214c19b4e2bc1803f30a4bc8478ae98577e3422e26e5ae)
  for the two existing cubic rows' admission counts only. Timings include this
  transparent instrumentation. Final canonical verification will not load it.
- Corrected covered focus passed1062/18warnings in346.53 s. JUnit test-time sum
  is667.454 s: composition278.541, records58.693, numerical67.659, filter59.672,
  transfer67.199, acquisition2d54.926. False/True cubic calls are104.51/103.10 s.
  All five source hashes passed the post-run manifest check. Admission logs
  confirm32/32 accepted components for EACH cubic row, all Disc quadratures and
  noise: all four reconstruction-observer calls per row are covered. Evidence:
  covered14-round3-corrected.log/.xml/-summary.json and batch-eligibility JSONL.
  The observed scientific aggregate is about36.23% below the coordinator's A2
  canonical1046.65 s, with different run conditions. With its unchanged505.69 s
  remaining work and46.274 s outer cost, the optimistic wall projection is
  about632.85 s, so this does not credibly establish the600 s completion goal.

## Accounting and exposure

One blind A launch/session continued through A1/A2/A3 and this correction.
B1/B2 history remains in prior reports. B3 did not accept the reviewed bb051b2
checkpoint: this author missed plain-noise metadata and plain-quadrature
dispatch in admission. These are test-apparatus regressions, not product-red.
The correction is only two admission predicates; no broad exception mask,
certificate widening or math repair. Fresh B4 is required.

The obsolete covered14 was stopped with one SIGINT: status2,593 passed,
18 warnings,228.71 s. It is partial diagnostic evidence only. Controller44561
and its managed session exited before editing. Rejected source/proof is retained.
All earlier scalar probes, qualifier corrections, tool lookup failures, typed-ez
defect, lint fixes, profile runs and interrupted work remain charged; no reset.

No implementation/history/nonblind discovery/coverage-map/current-task lesson
exposure. Only coordinator-approved public test-only B3 correction JSON and
reproducers were read. No product edits, delegation, Superpowers or commits.
Created paths are only scientific-a evidence/snapshots/logs/data. Native cost,
token/model/effort metering is unavailable and remains unknown, not zero; no
owner numeric iteration/spending limit was supplied. No scientific source was
edited during checks. All owned processes have exited; canonical
same-run13-phase/native/M25/platform proof and600 s target remain coordinator gates.
