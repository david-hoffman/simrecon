"""Parse completed permitted scientific proof without product imports."""
import collections
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET
root = Path('/workspace/simrecon')
base = root/'artifacts/test-apparatus-audit/resume/scientific-a'
document = ET.parse(base/'covered8-round7-acquisition.xml')
cases = document.findall('.//testcase')
assert len(cases) == 597
assert not document.findall('.//failure')
assert not document.findall('.//error')
assert not document.findall('.//skipped')
counts = dict(collections.Counter(case.attrib['classname'] for case in cases))
expected = {'tests.test_c_acquisition_boundary':313, 'tests.test_c_acquisition_preparation':88, 'tests.test_c_acquisition_filter':49, 'tests.test_c_acquisition_2d':40, 'tests.test_c_acquisition_transfer':38, 'tests.test_c_acquisition_drift':37, 'tests.test_c_acquisition_composition':18, 'tests.test_c_acquisition_fitted_drift':14}
assert counts == expected
log = (base/'covered8-round7-acquisition.log').read_text()
assert '597 passed, 18 warnings in 246.24s' in log
fixture_sha256 = hashlib.sha256((root/'tests/c_acquisition_fixture.py').read_bytes()).hexdigest()
assert fixture_sha256 == 'ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc'
summary = dict(nodes=len(cases), failure=0,error=0,skipped=0,warnings=18,pytest_seconds=246.24,summed_testcase_seconds=sum(float(case.attrib.get('time', 0)) for case in cases),by_suite=counts,fixture_sha256=fixture_sha256)
(root/'artifacts/test-apparatus-audit/resume/scientific-b-round7/completed-proof.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
