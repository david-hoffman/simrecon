# Scientific A round 2: frozen checkpoint

Status: all 14 affected suites pass on the frozen scientific checkpoint:
1062 passed, 18 source-free warnings, 387.00 s with fixed two workers and no
restart. Scoped Ruff passes; root's canonical narrow Pyright passed all five
stable files with zero errors/warnings.
Fresh B2 acceptance and exact canonical verification remain required.

The accepted round1 report, five relevant test files, numerical fingerprints and
declaration mapping are preserved under `round1/`; its 1083-node focused pass
does not certify this changed checkpoint. No implementation/history/nonblind
material was read. The same public contracts, advisory percentage policy and
complete native-report requirement apply.

## Checkpoint identity

| File | SHA-256 |
| --- | --- |
| tests/c_acquisition_fixture.py | e6aaeb89cc32e055f5b74b65018bbd6e35e580390f4eef5545cd32c159760aa5 |
| tests/c_workflow_support.py | 10265f0a62703ee30f136e00559cbbc8fbda470cf01213c7487bb39ff7705902 |
| tests/test_c_acquisition_composition.py | 5337985855e5e41c96c7b323ff18519e4841d41b2cda1eb51becb9cef28a0158 |
| tests/test_c_workflow_numerical.py | 2d6b65408d545da5890911c97ac8d9dac7ba9a013cbf7e337c7f74a4cf45e659 |
| tests/test_c_workflow_records.py | cccbbcc9a16fdfcdaa43727bfe38359d2bd67bddfb3d40a67232f5e73b121461 |

Support and composition are unchanged from B1; fixture, numerical and records
changed in A2. `declaration-preservation.json` contains all file hashes, prior
snapshot paths, 187 retained scoped declarations, exact assertion-AST checks and
all 26 logical old-row-to-keeper mappings. Global static declarations are 722.
Only authorized physical duplication changed: 15 label nodes and six drift
nodes removed; no logical example removed. Expected focused nodes: 1062;
expected full nodes from the coordinator's 3087 baseline: 3066.

## Changes and independent preservation argument

The diagnosed type defect is in test code: the precomputed axial Fourier matrix
was inferred as Any-or-None. The non-2D branch now asserts it is present before
tensordot. Its construction uses the exact same non-2D condition; no valid
scientific execution or numerical output changes. This is distinct from the
three source-free Pyright import-lookup failures recorded below.

`sample` still computes its own certified input quantities on demand. Its
four-vertex radial expression moved verbatim into `radial_interpolate`, with the
same scalar multiplication/addition order, complete flat-address stencil and
error propagation. Invocation-local `local_samples` now reuses the same computed
radial u instead of recomputing it on a cache miss, prepares each order's h and
flattened certified values once, and prepares each identical axial t/j/b/j1 once.
Keys include full nominal and error-column dtype/shape/bytes for u, axial integer,
native axial step and order. The unchanged closure table is the other dependency.
Full-layout signed-coordinate/conjugation evaluation remains the on-demand sample
path with complete signed-coordinate and axial/order keys. No global or cross-test
cache exists. Prepared arrays and returned scalar discs are only read; no cache
or closure escapes the owning observer invocation.

`reconstruct_expected` reuses the same 1/noise_variance value per (time,direction,
order). Suppression, damping, omission and omit-kz0 decisions and arithmetic still
execute on every visit. Conditional operations now produce a new local g value,
preventing in-place mutation of the cached base. Every arithmetic operation and
outward-rounding step remains present for each distinct numerical result.

All six prior drift-consumption rows have the existing complete raw-to-image
row with the exact same case name as their keeper. The complete row already
computes the identical case, independent expected observation, product result and
full budget. It now calls `assert_drift_consumption` with those unchanged values.
The helper retains every prior assertion, the conditional native reconstruction
and bound formula, and both exact cubic coefficient controls. Its conditional
returned-field proof remains separate from the keeper's absolute raw proof.
Only duplicate observe, product run and budget work was removed.

The clock-label test retains the original five independent numeric controls.
For each control it computes the same independent observation, budget and original
clock-label product baseline once, then executes the same four real renamed-label
calls in the original order: `seconds`, `milliseconds`, `acquisition-clock-ticks`,
and ` ms `. Every label retains all original array-identity, input-identity,
returned-label, cubic event/matrix/clock/coefficient/evaluation and independent
cubic-algebra assertions. Original numeric clocks/settings/raw data remain
unchanged. Each old `(control,label)` row maps to the same control keeper's exact
label iteration; the full mapping is machine-readable in the preservation JSON.

The preservation script compares every old Assert, close and np.testing.assert_*
AST against its keeper, including each drift helper and each label-loop body.
All compare equal. Original control decorators and the four literal label values
also compare exactly. No tolerance, example value, expected formula, error guard,
CE08 test/oracle, omission guard, scientific runtime or PR83 scope changed.

## Complete dependency and risk scope

The eight acquisition suites remain affected by Disc, sample, overlaps,
parameter_model and reconstruct_expected through wrapped public calls:
`test_c_acquisition_{2d,boundary,composition,drift,filter,fitted_drift,preparation,transfer}.py`.
Direct reconstruct_expected callers are 2d/composition/filter/transfer. Direct
overlaps callers are 2d/composition and fixture finite_search/parameter_model.
The existing composition sampler-sharing call remains unchanged from B1.

All six workflow suites remain sibling proof:
`test_c_workflow_{00_known,compatibility,failures,numerical,records,validation}.py`.
Direct assert_scientific callers remain numerical/records/compatibility/failures;
its A1 budget-reuse API is unchanged. Only the two authorized consolidation
declarations changed in A2. Existing independent CE08 small/matched/large suites
and on-demand expectation functions stay unchanged and required by full verification.

Fresh B2 should review prepared-table and axial-key completeness, nominal/error
dtype/shape/signed-zero distinctions, immutable cache lifetime and nonmutation,
the unchanged zero-weight/flat-allocation stencil, full-layout reflection,
strict overlap thresholds/ties/sensitivity, all conditional gains, and every
old-row keeper including seconds and spaced labels. The assertion-AST comparison
is preservation evidence, not a completeness or mathematical correctness oracle.

## Supplemental evidence and diagnostic limits

Latest `qualify_exact.py` run passed six sections: real/complex primitives,
2D/3D preparation, 2D/3D fractional native reconstruction, radial/full sampling,
repeated overlap builds and eight suppression/damping/omission/gain combinations.
Nominal arrays, both uncertainty columns, dtype/shape/strides/writability, finite
certificate records and deliberate value-or-error outcomes compare exactly to
the independent preoptimization fixture. Each cached sample also compares to
the independently callable sample expression. Cache reads and subsequent caller
operations preserve cached bits; fresh invocations see changed table values.

Diagnostic distinction: newly added invalid-infinite probes expose duplicate
private-observer warnings from repeated arithmetic that was removed. Before:
six warnings; candidate: four. RuntimeWarning categories/messages are the same;
every original/current warning count, filename and line remains recorded in
`exact-equivalence.json`. Exact numerical/certificate/outcome equivalence does
not claim identical duplicate warning lists or unchanged source line numbers.
No product/test warning filter or suppression was introduced. Distinct category/
message identities match; public product error/warning behavior is not weakened.

Representative timing only: preoptimization/native reconstruction 3.806 s versus
candidate 1.903 s; overlap probe 3.191 versus 1.280 s; eight gain probes 7.380 versus
3.832 s. Instrumentation and small-control conditions limit these claims; they
do not establish canonical wall time or whole-suite CPU savings.

Additional `qualify_table_errors.py` passed 144 before/current queries per
revision, each also compared to the independently callable sample, with nonzero
table observer/backend errors, uncertain native axial step, both layouts,
signed coordinates/zero, axial signs and both orders. Nominal/error arrays,
certificate records and warning lists match exactly; no warnings arose. Evidence:
`table-errors-equivalence.json`, fingerprint
`9bbb4475de3e462fd107dd9ba986db835aba2e74d13112e8dae15f23203a62c4`.

## Checks, attempts and accounting

- A1's exact 14-suite pass remains 1083 passed / 18 warnings / 578.07 s, composition
  430.178 s summed JUnit duration. It is retained historical evidence only.
- A2's complete 14-suite run passed: 1062 passed / 18 warnings / 387.00 s, with
  the exact authorized 21-node reduction and all 26 mapped logical examples
  retained. `focused14-round2.log`, XML and summary JSON retain the full evidence.
  JUnit summed test durations: 694.731 s across overlapping workers; composition
  385.622 s (False/True calls 162.48/148.53 s), records 29.013 s, numerical
  41.226 s, filter 66.977 s, transfer 65.566 s. These sums are not additive wall
  time; the canonical 600 s goal remains unmeasured here.
- `sha256sum -c scientific-inputs.sha256` passed for all five scientific files
  after the full focus. No scientific input changed during any check.
- Coordinator's canonical A1 type check found two optional-ez argument errors;
  A2 fixes that diagnosed test-code type defect. Root canonical narrow Pyright
  now passes all five stable scientific files: zero errors, zero warnings.
  No product-red claim.
- Scoped Ruff lint/format on all five files now pass. A2's initial lint-only
  attempt found a docstring mood and two wrapped-line issues; one correction
  round fixed those without changing science.
- A2 source-activated pinned uv through the source-free Python wrapper still
  reported nine missing numpy/pytest imports. Alongside the two A1 attempts,
  this is the third wrapper type-tool lookup failure. Root canonical narrow
  Pyright passes, isolating the wrapper failures as tooling, not test/product defects.
- A2 qualifier attempt 1 made an invalid rejection assumption about a coordinate
  whose literal flat-address stencil is permitted by the BEFORE observer. It
  was corrected to compare value-or-error outcomes, preserving positive inputs.
- A2 qualifier attempt 2 found the warning-list multiplicity difference above;
  a separate small diagnostic probe established that arrays, certificates and
  outcomes matched and only duplicate warning count differed. The final run
  records all raw warning metadata while comparing distinct diagnostic identity.
- A failed evidence-script apply_patch operation (unsupported delete/add of the
  same evidence filename) changed no candidate/evidence bytes; a separate new
  build_round2_manifest.py subsequently generated the exact preservation map.
- Initial A1 qualifier reciprocal-dispatch defect, earlier lint correction,
  diagnostic profile and all prior checks/charges remain in round1/REPORT.md.

One A launch/session continued with blindness preserved; no delegation or
Superpowers. No implementation/history/nonblind/coverage/lesson exposure.
Created paths remain only scientific-a evidence and its round1 snapshot directory.
No commits. No owner numeric iteration/spending cap supplied. Token/cost/model/
effort metering is unavailable here and remains unknown, not zero. No material
scientific input was edited during any check. All owned focus/qualifier/type
processes have exited; no active owned process, daemon or server remains.
