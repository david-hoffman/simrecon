# Fresh blind scientific B7 acquisition checkpoint review

Verdict: accept the exact revised acquisition scientific test checkpoint.
No actionable finding remains in the inspected scope. The completed affected
proof passes597 cases/18 warnings in246.24s on the exact fixture hash below.
This is neither canonical readiness nor an under600s/full-native/D verdict.

## Authority, identity and preserved scope

The authorized change optimizes test apparatus while retaining all scientific
obligations and C-equivalent behavior. AGENTS.md, review-work blind B and
test-audit public authoring/preservation criteria apply. PROJECT's public array
boundaries, canonical commands and approved-behavior/independent-risk coverage
policy apply; percentages are advisory while installed native/full gates bind.
No Superpowers or delegation was used.

Current `tests/c_acquisition_fixture.py` independently hashes to
`ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc`.
The supplied prior accepted B6 snapshot at
`scientific-a/round7-before/tests/c_acquisition_fixture.py` hashes to
`ad6bfba65482e125ecbcd5fa191afd5500205e5c7e4823bf504a278ec2f0f5e4`.
Plain-file comparison shows only `_ordinary_edge_values` and the edge function's
width0 dead-loop skip/local lazy scalar factor reuse. All other fixture bytes
are unchanged. No assertion, row, tolerance, public call, allocation, assignment,
scalar pixel operation, flat reshape or final getter/copy was removed.

All eight acquisition suites independently match B6's accepted manifest pins,
as does `tests/c_workflow_support.py`. Static AST inventory remains132 top-level
test declarations/420 explicit Assert nodes. The supplied global723 logical
obligations, unchanged26 keeper maps and722 declarations/3066 collected cases
are coordinator scope facts, not independently recounted global claims here.
Unchanged B6 oracle/evidence remains applicable outside this exact edge delta;
the delta and every fixture-dependent acquisition suite require renewed proof.
The separate workflow support imports its own oracle and has no acquisition
fixture dependency. B5's separate workflow slice therefore retains its own
checkpoint; I did not open its oracle or raw evidence. The withdrawn A6
regression factoring supplies no candidate change or evidence requirement.

## Independent oracle and omission assessment

Public CE02 section3 specifies vertical-then-horizontal deltas, ascending k,
add-before-subtract, overlapping strips, width0 empty inner loops, width-1 sine
window and below-1 bypass. Its published width1 closed result is independent
truth. CE03 section2 retains fixed10 order; CE06 section8 and ledger M36 retain
literal Y-based bead subtraction and initialized X+2 padding, including X8/Y10.
These determine the changed oracle's obligations without product source.

The guard inspects only strict Disc/native float64 and ordinary ndarray error
columns. All checks are nonmutating finite/class/shape/sign/magnitude operations;
unfamiliar subclasses/dtypes/representations decline acceleration. Its nonzero
headroom interval [2**-256,2**256] leaves ample exponent margin for the discarded
width0 delta getter/subtraction/division rounding, including adjacent-input
cancellation and nonnegative observer/backend error arithmetic. Zero deltas
cannot produce division-interval failures because the denominator is exact2.
Extreme, subnormal, nonfinite and negative-error inputs keep scalar diagnostics.
Both negative-width branches precede the new guard. Non-Python-int widths and
nonboolean bead flags retain scalar behavior; no public input is newly rejected.

Reused positive-width factors use the same certified pi/sin/subtract operations
and rounding, computed at the first originally reached k. They are scalar read
operands of nonmutating multiplication, private to one invocation. No eager
future-k work moves a failure before its original pixel update. Strict width/
geometry bounds restrict reuse to safe scalar traversals; others retain the
original factor expression and ordered failures. Pixel deltas, updates and
overlap ordering remain scalar and unchanged.

The critical ownership distinction remains intact: flat and padded share
nominal storage, while reshape constructs independently outward-rounded error
arrays. Horizontal deltas read padded; updates target flat; the returned
getter/copy reads padded. Reusing factors adds no getter/copy rounding and does
not merge these error stores. Independent ownership controls explicitly verify
this behavior, rather than assuming ordinary NumPy view semantics.

Risk-to-keeper mapping remains preparation's raw camera/on/off edge composition
(width0,1,-1,-2,4, including overlap); transfer's real rectangular/compensated
bead preparation and literal-padding/adjacent-invalid controls; drift's actual
fixed10 prepass at X=Y10 and unsafe-small-dimension rejection; fitted-drift and
composition's actual raw-to-fit-to-image consumers; 2d/filter's downstream
finite-search/native-image checks; boundary's representation, provenance,
failure and permitted-positive controls. All remain exact pinned bodies.
The width0 closed copy-rounding proof distinguishes a tempting direct-copy
shortcut; the literal-Y control distinguishes an X-address repair; retained
flat bounds distinguish an accidental unification of nominal/error storage.
No missing sole proof or new scientific meaning was identified. No production
seam or product-red was required or claimed.

## Own source-free checks

Before probes I read `scripts/source_free_check.py`, its sitecustomize and
pytest plugin. Every Python command used the source-free runner with timeout5,
preserving diagnostic categories/messages/locations/status. Probe imports were
only the two allowed fixture versions and ordinary dependencies; each numerical
probe asserts no simrecon product module was imported.

1. `edge_closed.py`: PASS10 independent closed/ownership controls over both
   fixture versions, from public CE02/CE06 equations. Published width1 result,
   half-sample sine, bypass/width0 nominal bits and exact copy/getter outward
   rounds, literal Y padding write, nominal-share/error-independence and input/
   output ownership all pass. Wall time0.20s.
2. `edge_challenge.py`: PASS74 exact old/current warn/raise controls plus two
   scalar factor count/immutability controls. Cases include low-bound adjacent
   cancellation, high/low errors, subnormal nominal, signaling NaN, infinite/
   negative bounds, matrix/float32 error columns, Disc subclass, readonly,
   reversed and nominal/error alias inputs; empty/unsafe/overlapping/legal
   bead geometries including X8/Y10; sine and bypass. Complete nominal/error
   dtype/shape/stride/bits/writeability, exception category/message, ordered
   warning identities, input bits, output alias relations and empty certificate
   lists match. Actual warning/exception locations are retained in the durable
   log. Factor evaluation count drops14to2 on one small admitted call and every
   captured scalar/error column remains unchanged. Wall time0.44s.
3. `inspect_evidence.py`: PASS exact prior/current pins, all eight unchanged
   suite/support pins, AST inventory and author270-row ledger (warn/raise;
   return/FloatingPointError/IndexError/TypeError). Wall time0.10s.
4. `check_completed_proof.py`: PASS independent XML/log parsing and frozen
   fixture recheck. Exact8 suite counts,597 nodes and379.665s summed testcase
   time agree with the completed final author summary.

These independently challenge the delta; A's270 comparisons supplement them.
The reviewed author measurement script uses test-owned complete preparation
and bead observers, without product imports. Final-hash preparation wall
0.823750s versus1.530678s and bead8.412408s versus9.171537s have identical
whole-result/certificate/warning fingerprints; bead edge inclusive time is
1.245026s versus2.878502s. The earlier preformat bead7.1002s belongs to its own
observation and is not substituted for final-hash evidence. These component
measurements establish neither canonical runtime nor under600s success.

## Completed affected proof and limits

I independently parsed completed `covered8-round7-acquisition.xml`:597 testcase
nodes, no failure/error/skipped elements, exactly boundary313, preparation88,
filter49,2d40,transfer38,drift37,composition18,fitted_drift14. Summed testcase
time379.665s matches the final summary; log reports597 passed/18warnings/246.24s
with two workers, Python3.13.12/pytest9.1.1/xdist3.8.0. The coordinator supplies
source-free fixed2/loadgroup/no-restart proof provenance. The unchanged artifact
measurement plugin independently matches B6's a9b67104370db5f06c214c19b4e2bc1803f30a4bc8478ae98577e3422e26e5ae.
The separate startup already-imported CoverageWarning remains visible, not
native-report completeness evidence. A7's final complete output captures also
match before/final SHA-256 exactly: preparation052a2a6a198d74ff65cc34c15736221bc71d4abd72de826e001e7b54576a1cf4;
bead1e87afd00e0b9d6609e2891b3d62340c5fb339d9879182f389fa09f0de6dfeaa.
After the explicit author all-final/stable signal, I reread final ROUND7,
REPORT, checks, summary, source manifest and post-proof hash log; independently
verified final packet pins and rechecked current fixture/eight suites/support.
No author evidence edits remain pending. The final manifest records exact
source/evidence identities and retained B6 evidence applicability.

Full3066-case canonical `make verify` under600s, all13 phases, same-run M25,
complete native/platform reports and fresh D remain coordinator gates. This
role inspected no coverage data/maps, canonical raw logs or profiles and makes
no global numerical correctness or canonical readiness claim.

## Exposure, attempts and cleanup

This is the seventh fresh scientific B launch/known fifteenth role including
four original discovery roles, according to the coordinator packet. All prior
attempts/spending remain charged once. This review has four successful probe
scripts/five executions (including final pin recheck), zero probe failures,
zero candidate correction requests and no false
candidate findings. The initial manifest read used nonexistent suffix.sha256;
the actual permitted.json manifest was then read. One filename inventory and
one later premature tail confirmed the still-pending affected summary absent;
all three missing-path attempts are retained charges, not test failures or
findings. Several oversized static outputs were truncated and
followed by targeted reads; truncation was never treated as evidence. Plain
diff's expected difference status is not a verification failure.

Exposure stayed within instructions/public contracts, exact old/new fixtures,
eight dependent tests/public-call support, B6 REPORT/manifest and named sanitized
A7 evidence. The first path inventory revealed only instruction filenames,
including a template AGENTS path; no prohibited file contents were opened.
No product implementation, Git/history/conversations/task Current state,
nonblind discovery, coverage data/map, raw canonical profile, existing LESSONS,
new workflow oracle or B5 raw evidence was read. No blindness exposure occurred.
Actual serving model/effort, tokens and monetary cost are unknown beyond the
requested Sol/high. No human numeric cap is set; under600s remains the user's
full-canonical target. No edit to the review target, commit or external message
occurred.

Own probe sources/logs are durable evidence under this report's `probes/`;
there is no own /tmp scratch, daemon/server or still-running probe process.
No tracked fixture, cache, shared environment or unrelated path was removed.
