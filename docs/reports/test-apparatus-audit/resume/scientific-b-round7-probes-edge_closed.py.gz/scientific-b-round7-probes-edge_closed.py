"""Independent public-equation edge controls, fixture imports only."""
import importlib.util
import sys
from pathlib import Path
import numpy as np

root = Path('/workspace/simrecon')

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, root / path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod

mods = [load('b7prior', 'artifacts/test-apparatus-audit/resume/scientific-a/round7-before/tests/c_acquisition_fixture.py'), load('b7current', 'tests/c_acquisition_fixture.py')]
controls = 0
for mod in mods:
    # CE02 published width1 closed control, independently supplied truth.
    c = 1 - np.sqrt(2.) / 2
    expected = np.array([[7*c, 2+4*c, 4+4*c, 6+c], [8-c, 10-4*c, 12-4*c, 14-7*c]])
    out = mod.edge(np.arange(8.).reshape(2, 4)*2, 1)
    np.testing.assert_allclose(out, expected, rtol=0, atol=4e-15)
    controls += 1
    # Half-sample sine window and explicit bypass are distinct contracts.
    np.testing.assert_allclose(mod.edge(np.ones((2, 2)), -1), .5, rtol=0, atol=3e-16)
    source = mod.Disc(np.array([[0., -0.], [1., -1.]]), 2.**-33, 2.**-31)
    for width in (0, -2):
        before = (np.asarray(source).tobytes(), source.observer.tobytes(), source.backend.tobytes())
        result = mod.edge(source, width)
        assert np.asarray(result).tobytes() == before[0]
        for field in ('observer', 'backend'):
            error = getattr(source, field).copy()
            # Width0 preserves final getter then copy; bypass has copy alone.
            for unused in range(2 if width == 0 else 1):
                error = np.nextafter(error, np.inf, where=error > 0, out=error.copy())
            assert getattr(result, field).tobytes() == error.tobytes()
            assert not np.shares_memory(getattr(result, field), getattr(source, field))
        assert not np.shares_memory(source, result)
        assert before == (np.asarray(source).tobytes(), source.observer.tobytes(), source.backend.tobytes())
        controls += 1
    # A bead horizontal subtraction can target initialized padding. It must
    # not silently use X in place of the contract's literal Y.
    plane = np.arange(8.).reshape(4, 2)
    contract = np.pad(plane, ((0, 0), (0, 2)))
    for j in range(2):
        delta = (contract[-1, j] - contract[0, j]) / 2
        contract[0, j] += delta*c
        contract[-1, j] -= delta*c
    for i in range(4):
        delta = (contract[i, 1] - contract[i, 0]) / 2
        contract[i, 0] += delta*c
        contract[i, 3] -= delta*c
    np.testing.assert_allclose(mod.edge(plane, 1, bead=True), contract[:, :2], rtol=0, atol=2e-15)
    controls += 1
    # Disc reshape intentionally shares only nominal storage. Capture the
    # original padded bounds: horizontal flat writes must not publish into them.
    original = mod.Disc.reshape
    captured = []
    def reshape(self, *args, **kwargs):
        result = original(self, *args, **kwargs)
        assert np.shares_memory(result, self)
        assert not np.shares_memory(result.observer, self.observer)
        assert not np.shares_memory(result.backend, self.backend)
        captured.append((self, self.observer.copy(), self.backend.copy()))
        return result
    mod.Disc.reshape = reshape
    result = mod.edge(mod.Disc(plane, 2.**-40, 2.**-38), 2, bead=True)
    mod.Disc.reshape = original
    padded, obs, back = captured[0]
    assert padded.observer.tobytes() == obs.tobytes()
    assert padded.backend.tobytes() == back.tobytes()
    for field, errors in [('observer', obs), ('backend', back)]:
        selected = errors[:, :2].copy()
        for unused in range(2):
            np.nextafter(selected, np.inf, where=selected > 0, out=selected)
        assert getattr(result, field).tobytes() == selected.tobytes()
    controls += 1
assert not any(name == 'simrecon' or name.startswith('simrecon.') for name in sys.modules)
print(f'PASS {controls} independently derived closed/ownership controls; no product imported')
