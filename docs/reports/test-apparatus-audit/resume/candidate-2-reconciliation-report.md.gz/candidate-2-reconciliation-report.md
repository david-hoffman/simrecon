# Candidate 2 preserved-run reconciliation

Exact clean candidate: `8b9c39f7ea458a21c5feed39775005dc8cf487bd`, tree
`0b0e02c817ae186b6655525090867ac2e6a2e5e5`. All 13 native phases passed.
Outer wall was **611.04 seconds**, missing the strict under-600-second target by
**11.04 seconds**. No readiness, D or submission conclusion follows.

JUnit reports 3066 passed, zero failure/error/skip, suite wall 564.184 seconds.
The console's native summary reports 564.25 seconds; the receipt tests phase
is 565.953532 seconds. These have distinct measurement boundaries. Outer time
minus tests phase is 45.086468 seconds; summed worker durations are not elapsed.

Relative to baseline's 3087 cases, exact normalized identity reconciliation
finds 26 removed identities (20 clock parameter rows plus six drift-only rows),
five added clock keeper identities and 3061 unchanged identities. There are no
other additions/removals and no normalized duplicate. Only the last observed
`@xdist-group` suffix was removed with `rsplit('@', 1)`; spaces and internal `@`
inside parameter IDs remain intact. This catalog check does not independently
prove all assertions or keeper behavior.

Every one of all eight native integer counters matches baseline in every one
of the 30 owned files. Global coverage remains 4783/4919 statements and
1845/1952 branch destinations; complete package/file counters are in the JSON.
Receipt native counters, coverage JSON and all 30 HTML file-page integer
summaries agree. All per-file HTML pages and index/class/function pages are
preserved. Read-only SQLite integrity passes; the combined native database has
all 30 owned files and native arcs. Raw collector arcs are normalization inputs,
so they are not directly equated with analyzed statement/branch endpoints.

Candidate before/after commit, tree, tracked manifest (939 entries) and all
three named external input fingerprints match exactly. Same-run M25 report,
receipt run ID/hash/values agree: `dfcc09c0-921b-493c-9d15-5eeb87dc735f`,
baseline=peak=101828 KiB, increment=0 bytes, unchanged limit=33554432 bytes.
Zero high-water increment does not prove allocation-free behavior.

Same-run ImageJ children are selected strictly by that run ID: 20 reader
observations with true `assertions_passed`, and 27 separate API/report
observations whose schema has no such field. Other retained run-ID directories
are ignored. Candidate combine recorded 293 combined and 1274 duplicate-skipped
inputs; baseline recorded 294 plus 1273, both 1567 inputs. Canonical combine has
no `--keep`: child coverage inclusion/union is retained in the combined data
and prior bounded qualification. Consumed raw shards are not claimed to survive
post-combine and their absence is not a missing required post-combine report.
The final bounded reviewer still owns independent gate/evidence acceptance.

The separate public-only scientific cost export contains 2117 scientific test
nodes with printed setup/call/teardown totals and file totals. It contains no
product implementation, raw product profile, coverage, receipt manifest or
subprocess evidence. The coordinator selects sanitized diagnostic rows for A6.
Its largest scientific file totals are composition 169.96 seconds, transfer
72.55, filter 62.89, workflow numerical 56.75, records 56.24 and acquisition 2d
55.56. These are worker-duration sums. The two cubic composition calls are
54.21/53.51 seconds; the heavy workflow clock row is 32.01 seconds.

Ignored outputs:

- `candidate-2-reconciliation.json`: exact node delta, all 30 file integers,
  receipt/input/M25/native report identities and limits.
- `candidate-2-measurements.json`: phase/wall/resource/exec and top-test costs.
- `candidate-2-public-scientific-test-costs.json`: test-only diagnosis packet.
- `candidate-2-archive-manifest.json`: source/archive hashes for seven new
  deterministic portable gzip archives under docs/resume. Existing README,
  manifest and continuation catalog remain unchanged until root's next freeze.
- `reconcile_candidate2.py`: one-off parser used for this reconciliation.

Only preserved run directories were read, never live canonical verification
outputs. No repository test, coverage command, scientific probe, heavy profile,
source edit, staging, commit, cleanup deletion or persistent process occurred.
Two exporter interpretation issues were corrected during preparation: raw SQLite
collector arcs are not analyzed JSON endpoints, and the 27 API report schemas
do not expose the reader schema's assertion boolean. No candidate defect or
product-red result was inferred from either. One initial exporter assertion
failed on the latter absent field; the schema-aware exporter then completed.
All prior failed/partial/accepted task attempts remain charged.
