"""Read only permitted scientific fixture/tests and sanitized evidence."""
import ast
import hashlib
import json
from pathlib import Path
root = Path('/workspace/simrecon')
out = root / 'artifacts/test-apparatus-audit/resume/scientific-b-round7'
prior = json.loads((root / 'artifacts/test-apparatus-audit/resume/scientific-b-round6/accepted-filehashes.json').read_text())
files = {}
declarations = asserts = 0
for path, expected in prior['scientific_files_sha256'].items():
    digest = hashlib.sha256((root/path).read_bytes()).hexdigest()
    if path != 'tests/c_acquisition_fixture.py':
        assert digest == expected, path
    files[path] = digest
    if path.startswith('tests/test_c_acquisition_'):
        tree = ast.parse((root/path).read_text())
        declarations += sum(isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith('test_') for n in tree.body)
        asserts += sum(isinstance(n, ast.Assert) for n in ast.walk(tree))
assert files['tests/c_acquisition_fixture.py'] == 'ea32ed4fb891b18af81dcc557ef0ad1fa6ac958068406a8b20032b7acdfac7dc'
baseline = 'artifacts/test-apparatus-audit/resume/scientific-a/round7-before/tests/c_acquisition_fixture.py'
assert hashlib.sha256((root/baseline).read_bytes()).hexdigest() == 'ad6bfba65482e125ecbcd5fa191afd5500205e5c7e4823bf504a278ec2f0f5e4'
ledger_path = 'artifacts/test-apparatus-audit/resume/scientific-a/edge-reuse-equivalence.json'
ledger = json.loads((root/ledger_path).read_text())
assert len(ledger) == 270 and all(r['exact_equal'] for r in ledger)
summary = dict(scientific_files_sha256=files, declarations=declarations, explicit_assert_nodes=asserts, author_comparisons=len(ledger), author_numpy_policies=sorted(set(r['numpy_policy'] for r in ledger)), author_outcomes=sorted(set(r['outcome'] for r in ledger)))
(out/'static-evidence.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
