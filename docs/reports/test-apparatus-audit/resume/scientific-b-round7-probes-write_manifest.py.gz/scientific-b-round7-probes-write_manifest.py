"""Materialize the final accepted identities from permitted evidence only."""
import hashlib
import json
from pathlib import Path
root = Path('/workspace/simrecon')
base = root/'artifacts/test-apparatus-audit/resume/scientific-b-round7'
author = 'artifacts/test-apparatus-audit/resume/scientific-a/'
def digest(path): return hashlib.sha256((root/path).read_bytes()).hexdigest()
pins = json.loads((base/'static-evidence.json').read_text())
for path, value in pins['scientific_files_sha256'].items():
    assert digest(path) == value, path
packet = root/(author+'round7-final-packet.sha256')
for line in packet.read_text().splitlines():
    value, path = line.split('  ',1)
    assert digest(path) == value, path
proof = json.loads((base/'completed-proof.json').read_text())
summary = json.loads((root/(author+'covered8-round7-acquisition-summary.json')).read_text())
assert proof['nodes'] == summary['nodes'] == 597
assert proof['summed_testcase_seconds'] == summary['summed_seconds'] == 379.665
assert proof['pytest_seconds'] == summary['pytest_wall_seconds'] == 246.24
assert proof['by_suite'] == {key:value['nodes'] for key,value in summary['files'].items()}
names = ['REPORT.md','ROUND7.md','round7-checks.json','round7-scientific-inputs.sha256','round7-final-packet.sha256','round7-hashes-after-proof.log','covered8-round7-acquisition-summary.json','covered8-round7-acquisition.log','covered8-round7-acquisition.xml','qualify_edge_reuse.py','qualify_exact.py','edge-reuse-equivalence.json','edge-reuse-equivalence.log','probe_edge_zero.py','batch_measurement.py']
for label in ('before','final','bead-before','bead-final'):
    names += ['edge-probe-'+label+'.json','edge-output-'+label+'.json']
evidence = {author+name:digest(author+name) for name in names}
for path in ('scripts/source_free_check.py','scripts/source_free_sitecustomize/sitecustomize.py','scripts/source_free_sitecustomize/pytest_plugin.py','artifacts/test-apparatus-audit/resume/scientific-b-round6/REPORT.md','artifacts/test-apparatus-audit/resume/scientific-b-round6/accepted-filehashes.json'):
    evidence[path] = digest(path)
baseline = author+'round7-before/tests/c_acquisition_fixture.py'
assert digest(baseline) == 'ad6bfba65482e125ecbcd5fa191afd5500205e5c7e4823bf504a278ec2f0f5e4'
own = {str(path.relative_to(root)):digest(str(path.relative_to(root))) for path in sorted(base.rglob('*')) if path.is_file() and '__pycache__' not in str(path) and path.name != 'accepted-filehashes.json'}
manifest = dict(verdict='accept exact revised acquisition scientific checkpoint; canonical/native/platform/performance/D gates remain',review_round=7,baseline_fixture_path=baseline,baseline_fixture_sha256=digest(baseline),scientific_files_sha256=pins['scientific_files_sha256'],evidence_sha256=evidence,own_artifacts_sha256=own,affected_proof=proof,own_checks=dict(independent_closed_ownership_controls=10,exact_prior_current_controls=74,factor_immutability_count_controls=2,author_supplemental_comparisons=270,probe_scripts=4,probe_executions=5,probe_failures=0,missing_pending_or_misnamed_path_attempts=3,candidate_correction_requests=0,false_candidate_findings=0,product_imported=False),retained_evidence='B6 unchanged portions applicable; renewed exact delta and all8 fixture-dependent acquisition suites reviewed. B5 workflow remains separate, unchanged, no acquisition-fixture dependency.',actual_serving_model_effort_tokens_cost='unknown; requested Sol/high',human_caps='not set; full canonical make verify under600 seconds remains target',coverage_data_or_maps_read=False,workflow_oracle_read=False,blindness_exposure=False,cleanup='No own /tmp scratch or live probe process; durable own evidence retained; no target/tracked fixture/cache/environment/unrelated path removed')
(base/'accepted-filehashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Accepted B7 manifest:', hashlib.sha256((base/'accepted-filehashes.json').read_bytes()).hexdigest())
print('Report:', digest(str((base/'REPORT.md').relative_to(root))))
