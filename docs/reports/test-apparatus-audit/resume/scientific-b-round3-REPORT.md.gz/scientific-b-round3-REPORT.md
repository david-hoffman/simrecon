# Fresh blind scientific B correction review, round 3

Verdict: correction required. Do not accept this checkpoint. Two independently
reproduced test-apparatus representation regressions violate the authorized
preservation requirement. Neither is a product-red finding. A passing focused
run would not resolve these concrete counterexamples.

## Findings

**B3-F1 — plain noise factors fail before the scalar path's successful result.**
`tests/c_acquisition_fixture.py:704` reads `nv.error` directly. The eligibility
predicate at lines 1198–1229 admits ordinary float64 NumPy arrays, whose scalar
getter returns `numpy.float64`, without this attribute. Accepted A2 completes the
same reconstruction and publishes six divisor certificates; A3 raises
`AttributeError: 'numpy.float64' object has no attribute 'error'` with zero
certificates. The old scalar `1 / nv` supports this representation. This is a
coding error in an admitted representation, not a recognized acceleration decline.

**B3-F2 — plain quadratures change exact certificates.** With ordinary
complex128 quadratures and certified noise/table, eligibility also admits the
batch path. At lines 897–899 it sends `band * 1.0` through `_lane_op`, which
always adds a Disc primitive's rounding. In the original scalar expression,
plain `b * taper` is plain NumPy arithmetic; its first certified operation is
the subsequent multiplication by `g`. Packing values does not preserve this
plain-versus-Disc dispatch distinction. The resulting nominal arrays agree, but
the exact filter-divisor certificates differ. On the tiny control the first
observer is `6.154461134763113e-14` in A2 versus `6.509732502643165e-14` in A3;
conditional backend is `6.215714818880378e-14` versus
`6.570986186760436e-14`. Preserving these certificates is explicitly in scope.

Both controls use input shape `(1,1,3,1,2,2)`, acquisition mode `2d`, pitch 1,
axial spacing 0.5, zoom 1, unit complex quadratures, unit positive noise factors,
radial unit table `(2,32,1)` with steps 0.125 and 2, carrier `[[0.03,0.02]]`,
modulation `[[0.3+0.1j]]`, and unchanged `known_options()`. F1 uses Disc
quadratures/table with plain noise and modulation. F2 uses plain quadratures
with Disc noise/table/modulation. This is ordinary positive finite data and
safe stencils, not an invented invalid scientific obligation. Exact tiny
reproducers are `artifacts/test-apparatus-audit/resume/scientific-b-round3/reproduce_plain_noise.py` and
`artifacts/test-apparatus-audit/resume/scientific-b-round3/reproduce_representations.py`; their hashes are in
`classified-correction.json`. Run each with:

```
.venv/bin/python scripts/source_free_check.py --timeout 20 python <probe-path>
```

The source-free fixture-only commands completed in about 0.2–0.4 seconds each,
with no product import. The second script was extended and rerun once to print
the exact first certificate values. Plain table and plain modulation controls
matched A2. No target code was changed. A scoped correction can either retain
scalar fallback for unsupported representations or preserve their original
arithmetic and error dispatch; a fresh B must independently assess its exact
candidate and affected evidence.

## Independent static and preservation assessment

The accepted A2 fixture hash is
`e6aaeb89cc32e055f5b74b65018bbd6e35e580390f4eef5545cd32c159760aa5`.
The accepted B2 manifest contains 17 scoped scientific files. B independently
rehashes all 17: only `tests/c_acquisition_fixture.py` differs. Its reviewed hash
is `bb051b2efc6b8a00d39f8b2e59104672c13260626c116d00190d066ba2ed133d`.
All eight acquisition suites, all six workflow suites, workflow support and
workflow oracle are byte-identical to B2. B independently counts 187 top-level
test declarations and 633 explicit Assert nodes across the 14 suite modules.
The B2 design/preservation evidence for unchanged tests remains applicable:
there is no further assertion, logical example, tolerance or declaration change.
Execution proof for a changed shared observer cannot be inherited from B2.

B inspected the retained clock keeper: five control nodes still loop through
`seconds`, `milliseconds`, `acquisition-clock-ticks`, and ` ms ` in the original
order, with real public calls, returned-label, numeric identity, cubic event,
matrix/coefficient/evaluation and independent cubic-algebra checks. The drift
consumption helper still conditions only the consumption relation on returned
fields and retains separate absolute cubic truths 1 and 1/216. Its complete raw
keeper invokes it, with the separate raw observation/budget. These unchanged
keepers are not implicated by a new keeper-removal claim.

Public CE common, optical-transfer, known-parameter and acquisition-mode
contracts supply the scientific decisions; PROJECT's approved behavior plus
independent risk review policy makes percentages advisory and complete native
reports mandatory. No background implementation link supplies new meaning.
From the permitted operation maps B independently checks these relationships:
self support is inclusive, other support strict; denominator accumulation visits
direction then signed order, includes self power once and adds w² last; the
numerator contains conjugated transfer and modulation; radial interpolation
reads all four flat addresses even at zero weights. For unit transfer/noise/modulation,
zero carriers, O=2 and unit center data at an interior point, the three eligible
unit powers and w=0.5 give center divisor 3.25 and coefficient 4/13. This differs
from omitting the negative order or squaring w incorrectly.

The lane code preserves nominal operands as zero-dimensional arrays and uses
scalar complex magnitude and error-hypot calls. `_lane_norm2` uses exactly two
coordinates and gamma(16). Structural rounds for the original stack and getters
are present. Radial sampling retains all four flat offsets, zero-weight and
K=1 duplicate visits; prepared values and query keys include nominal, observer
and backend dtype/shape/bytes. Native sample/cache lifetimes are per component;
local_samples raw/radial caches are per owning invocation. The batch does not
publish certificates or output writes until its whole component succeeds.
Unsafe stencils return None and run the original scalar order, preserving an
existing prefix. There is no broad catch converting coding errors to fallback.
Those controls are sound in the inspected certified-input path, but the two
admission/dispatch failures above prevent its claimed general preservation.

The float64 guard is an acceleration selector only: it checks finite nominal
components and nonnegative finite error columns, uses a terms-dependent upper
headroom, requires positive Wiener/noise margins and positive lower-bounded table
steps, and declines out-of-range coordinates. No guard changes the scalar
scientific contract. Static degree/headroom reasoning is conservative for the
restricted expression, but does not prove unsupported operand representations
safe. The scalar constructor's 0D buffer path preserves nominal aliasing while
copying independent error columns; scalar/subclass/unsupported-kind fallback
remains. Lazy amplitude/power/conjugate/carrier and Wiener/taper hoists have
local lifetime and no observed mutating consumer. No additional actionable
finding arose from these inspected changes.

B read the permitted constructor/lane/native qualifier source and their sanitized
summary evidence. The native qualifier's “plain” cases mean plain carriers;
its bands quadratures and noise factors are always Disc. Its green cases do
not cover F1/F2. The qualifier uses a permitted scalar intermediate snapshot;
B's own counterexamples instead compare the exact accepted A2 file directly
with current bytes. Existing supplemental evidence therefore cannot negate
these failures.

## Limits, exposure and accounting

This is a nonacceptance correction checkpoint, not final readiness. The current
source-free 14-suite 1062-case proof and final filehash confirmation were pending
when findings were established; no current run log/XML/summary was opened.
No full canonical run, coverage operation, native report inspection or product
probe was performed. Full 3066/declaration 722 figures remain supplied coordinator
accounting, not independently collected global proof. Canonical verification,
complete native platform reports and fresh D are still separate mandatory gates.

B3 is one fresh native review launch and one completed correction review, with
two actionable findings in one representation family. Prior accepted B1/B2 and
all A/coordinator attempts remain charged; none is reset or double counted.
Three successful tiny source-free command executions were performed (one noise
probe, the representation probe, then its diagnostic print extension). There
were no failed launches, no probe-input correction, no candidate edit, no
Superpowers and no delegation. Actual model serving/effort, token metering and
monetary cost are unknown; no human numeric cap was supplied.

Read exposure stayed within AGENTS, B and public test-audit instructions,
authorized public contracts/PROJECT policy, accepted B2 report/manifest, accepted
A2/current fixture and authorized dependents, permitted qualifier source and
sanitized summaries, and source-free diagnostic harness. A narrow filename
inventory displayed a raw coverage artifact's path; its data was not opened or
used. No product implementation, Git history/diff/log, implementation-bearing
Current state, nonblind audit report/ledger, raw baseline/candidate logs/profile,
coverage data/map, LESSONS, parent conversation or agent inventory was read.

At the coordinator’s explicit handoff request, both tiny reproducers were copied
into this review directory. Their owned processes exited and no daemon/server
remains. The two known `/tmp/scientific-b3-*.py` originals were removed after
copy/hash confirmation. Durable output is this report, `classified-correction.json`
and those two explicitly authorized reproducer scripts. This report requests a test-
apparatus correction without changing any reviewed target, scientific meaning,
assertion/tolerance or gate.
