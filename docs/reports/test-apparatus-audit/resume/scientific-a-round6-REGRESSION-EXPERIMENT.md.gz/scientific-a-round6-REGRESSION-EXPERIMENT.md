# A6 regression factoring: measured and withdrawn

This experiment was authorized within one finite_search invocation. It is not
part of the candidate. The exact B6 fixture ad6bfba65482e125ecbcd5fa191afd5500205e5c7e4823bf504a278ec2f0f5e4
has been restored. Before and experimental snapshots are retained in
round6-before/tests/ and round6-regression-experiment/tests/. Experimental hash
e1d8fe73c38d2fbbea1246b9bdf0b38faecd7b992d4f80d76db1716e88e3ff6d.

The initial public source lead was narrowed by measurement: each two-time2D
control has6 overlap builds/30 full expansions, not an overlap rebuild at each
phase evaluation. It has628 regression evaluations, on four spatial owners.
Regression dominates the measured independent search, while full expansion
cost is~.013s and cannot support a useful optimization alone.

The experiment lazily retained the frozen regression field's unchanged grid,
left operand/energy/conjugate and phase prefix. Every changing phase, right
energy, cross product and fit/division remained. Typed complete input bits and
identity guarded reuse; returned SX fields were losslessly cloned to preserve
independent storage. Unknown/error metadata fell back to original arithmetic.
Original standalone regression and all tests/rows/assertions remained. No
production code or tolerances changed.

Source-free native-coverage-wrapped helper probes used unmodified Table/sample
implementations and transparent test-owned full/overlaps/regression counting
wrappers. No product import or native coverage-data inspection occurred.
Before/current complete output, observer/backend columns, all certificates,
warning category/messages and input bytes matched exactly on the normal2D
and3D witnesses. The guard was tightened for unsupported error metadata after
the first normal helper measurement; normal witness behavior was unaffected.
No alias/error-domain completeness acceptance is claimed: those wider probes
were not pursued once performance proved insufficient.

Measured2D helper, both times:

| Layout | Accepted A5 wall/CPU | Experiment wall/CPU | Regression wall before/after |
| --- | --- | --- | --- |
| radial |1.4413/1.4397s|1.2638/1.2625s|.9887/.8021s|
| full |1.8828/1.8809s|1.6168/1.6155s|.9948/.7696s|

Each retains628 evaluations,1046 certificates, zero warnings and zero input
mutation. Exact fingerprints are in search-probe-before/factored.json and
complete comparison outputs in search-output-before/factored.json.

The matched two real public2D search rows passed under the same source-free,
isolated native coverage and fixed2/loadgroup/no-restart command:
before2pass38.79s (full18.86/radial18.38 call), experiment2pass36.14s
(full18.21/radial16.90 call). This is2.65s elapsed and~2.13s printed aggregate
saving on these rows, insufficient to establish the required~30s margin.
Logs/JUnit are search-real-before/after.log/.xml; coverage data remain unread.

The exact public3D composition control's three searched directions retained509
evaluations,2060 certificates, zero warnings/mutation and equal fingerprints.
Accepted helper2.2568/2.2535s became1.9341/1.9329s; regression.8238 became.6268s.
Its direct/predictor call mapping cannot plausibly provide the required margin.
The useful ordinary and two critical cubic composition examples use fixed
carriers (search_carriers=False) and receive no benefit from this experiment.

No broad acquisition proof, new full canonical run or B7 acceptance was claimed.
The experiment is withdrawn to avoid retaining insufficiently useful shared
fixture complexity. Source-free Ruff passed; one formatting correction was
applied before the real-row experiment. Every launched command completed and
all owned process sessions are closed. Prior candidate2 all13-phase/3066-pass
611.04s result remains the passing-but-over-target baseline.

Same blind A role, zero delegation. Only allowed public tests/contracts and own
prior artifacts/snapshots were read. No implementation/history/nonblind report,
coverage data/map, raw canonical/profile or current-task lessons were read.
No product-red claim; actual model/token/dollar charges remain unavailable.
