# Continued public-only advisor: remaining work after 611.04 s

The same advisor continued report-only at requested Astra/ultra. No new role
launch, fixture/product execution, source edit or delegation occurred. Permitted
reads were acquisition test fixtures, public contracts and sanitized test costs.
No product implementation/history, raw canonical profile, coverage map, Current
state or lesson was supplied. Prior filename-only exposure remains disclosed;
actual serving/model/tokens/cost remain unknown. This is advice, not acceptance.

A6 regression factoring did not reach the expensive ordinary/cubic controls;
its small measured wider yield justifies withdrawal. Native axial geometry is
also an unproved target: main Z3 filter cutoffs clamp to zero; the costly P5/Z5
transfer row uses bead reconstruction rather than native reconstruction.

Measure edge() first. Bead P5/Z5 24x22 alone has 25 edge(width10, bead=True)
calls; drift prepass has D*max(Z//2,1) per time point. The heavy cubic controls
have only four active width10 prepass calls each, plus many width-zero calls.
Neither their whole-row times nor these populations establish savings.

The smallest subset is unused delta work for width0, subject to exact diagnostics.
For a needed positive-width extension, retain vertical before horizontal, k in
ascending order and addition before subtraction; overlapping strips are valid.
Factor evaluation can be reused per invocation, retaining scalar expressions.
Independent columns/rows may batch only with valid addresses. For horizontal
row independence, let R=Y for bead mode and X otherwise. Sufficient restrictions
are 0<=W<=Y, W<=X+2 and W<=R<=X+2; excluded shapes keep scalar behavior, including
legal flat aliases and first-failure prefixes.

Critical ownership: flat=padded.reshape(-1) has freshly rounded error arrays but
shares nominal storage. Horizontal deltas read padded; updates target flat;
return reads padded. Unifying their error views changes certificates. Any batch
must retain getter rounding and separate columns. No old behavior is repaired
or reinterpreted during this performance correction.

The advisor recommended canonical-coverage-condition fixture-only timings of
unchanged bead_expected for the P5/Z5 case and one drift preparation observer,
with edge inclusive time/counts. No performance claim follows until measured.
